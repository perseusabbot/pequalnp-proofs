import ActualPinTables
import PinRules
import ThetaBounds
import SizeFifteen

namespace Petersen1676.Actual
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

def regularVertex : Fin 6 → Fin 9 := ![0,1,2,3,5,8]
def regularRename : Fin 6 → Fin 8 → Fin 8 := ![
  ![0,1,2,6,7,4,5,3],
  ![0,7,3,4,1,6,5,2],
  ![1,0,7,5,2,4,6,3],
  ![2,1,0,6,3,5,4,7],
  ![0,1,2,3,4,5,6,7],
  ![1,2,3,4,0,5,6,7]]
def regularGraph (x : Fin 8 → Bool) : Bool :=
  (x 0 && x 1) || (x 1 && x 2) || (x 2 && x 3) || (x 3 && x 4) || (x 4 && x 0) ||
  (x 1 && x 5) || (x 2 && x 6) || (x 3 && x 7) || (x 5 && x 7)

set_option maxRecDepth 5000 in
set_option maxHeartbeats 2000000 in
theorem regularShape : ∀ i : Fin 6,
    (fun x => pinned (regularVertex i) (x ∘ regularRename i)) = regularGraph := by
  decide +kernel

/-- The one-leaf reduction of L-meta-1664, using the already verified
seven-variable theta theorem directly. -/
private def tau : Fin 8 → Fin 8 := ![3,0,2,1,4,5,7,6]
private def pendant (x : Fin 8 → Bool) :=
  (x 0 && x 2) || (x 2 && x 1) || (x 0 && x 3) || (x 3 && x 4) || (x 4 && x 1) ||
  (x 0 && x 5) || (x 5 && x 6) || (x 6 && x 1) || (x 2 && x 7)
set_option maxRecDepth 5000 in
private theorem pendantShape : (fun x => regularGraph (x ∘ tau)) = pendant := by decide +kernel
set_option maxRecDepth 5000 in
private theorem thetaShape : (fun y : Fin 7 → Bool => pendant (Fin.snoc y false)) = theta := by decide +kernel
private theorem noEleven (h : HasCircuitSize 8 regularGraph 11) : False := by
  have hp := Relabel.relabel_size tau regularGraph 11 h
  rw [pendantShape] at hp
  have dep : ∃ x : Fin 8 → Bool,
      pendant (Function.update x (Fin.last 7) (!x (Fin.last 7))) ≠ pendant x :=
    ⟨fun i => decide (i = 2), by decide +kernel⟩
  have nonc : ∃ y y' : Fin 7 → Bool, pendant (Fin.snoc y false) ≠ pendant (Fin.snoc y' false) :=
    ⟨fun _ => true,fun _ => false,by decide +kernel⟩
  have ht := Live514.gate_elim 7 pendant false 10 dep nonc hp
  rw [thetaShape] at ht
  have bad := PEqualNP.Outside.L_meta_517 10 ht
  omega

theorem regularLower (i : Fin 6) (s : Nat) (h : HasCircuitSize 8 (pinned (regularVertex i)) s) :
    12 ≤ s := by
  by_contra! contra
  obtain ⟨C,ok,hs,hc⟩ := h
  have ub : HasCircuitSize 8 (pinned (regularVertex i)) 11 := ⟨C,ok,by omega,hc⟩
  have ht := Relabel.relabel_size (regularRename i) _ _ ub
  rw [regularShape] at ht
  exact noEleven ht

def low1 (v : Fin 9) := if v = 4 ∨ v = 6 ∨ v = 7 then 13 else 12

theorem allSingleLower (v : Fin 9) (s : Nat) (h : HasCircuitSize 8 (pinned v) s) : low1 v ≤ s := by
  by_cases sp : v = 4 ∨ v = 6 ∨ v = 7
  · simpa [low1,sp] using degreeTwoLower v sp s h
  · have casesAll : ∀ u : Fin 9, (u = 4 ∨ u = 6 ∨ u = 7) ∨ ∃ i : Fin 6, regularVertex i = u := by
      decide +kernel
    obtain ⟨i,rfl⟩ := (casesAll v).resolve_left sp
    simpa [low1,sp] using regularLower i s h


open Table Prune PinRules

def extended (i : Fin 9) (x : Fin 7 → Bool) : Fin 9 → Bool :=
    (deletedPair i).1.insertNth false ((deletedPair i).2.insertNth false x)

noncomputable def sr (v : Fin 9) (x : Fin 8 → Bool) := fullRow (v.insertNth false x)
noncomputable def pr (i : Fin 9) (x : Fin 7 → Bool) := fullRow (extended i x)

theorem singleData (v : Fin 9) (x : Fin 8 → Bool) :
    allMask.testBit (sr v x) = true ∧ (pinMask (singleFix v)).testBit (sr v x) = true ∧
    goal.testBit (sr v x) = pinned v x := by
  refine ⟨fullMask _,singleChecked v _ ?_,fullGoal _⟩
  exact Fin.insertNth_apply_same _ _ _

theorem doubleData (i : Fin 9) (x : Fin 7 → Bool) :
    allMask.testBit (pr i x) = true ∧ (pinMask (pairFix i)).testBit (pr i x) = true ∧
    goal.testBit (pr i x) = pinnedPair (deletedPair i).1 (deletedPair i).2 x := by
  refine ⟨fullMask _,doubleChecked i _ ?_ ?_,fullGoal _⟩
  · exact Fin.insertNth_apply_same _ _ _
  · simp [extended,otherIndex]

theorem srRaws (v : Fin 9) : RawWords (sr v) raw := by
  intro w hw
  obtain ⟨j,rfl⟩ := rawHaveIndex w hw
  rcases Fin.eq_self_or_eq_succAbove v j with rfl | ⟨k,rfl⟩
  · left; refine ⟨false,funext fun x => ?_⟩
    exact (fullRaw _ _).trans (Fin.insertNth_apply_same _ _ _)
  · right; refine ⟨k,funext fun x => ?_⟩
    exact (fullRaw _ _).trans (Fin.insertNth_apply_succAbove _ _ _ _)

theorem prRaws (i : Fin 9) : RawWords (pr i) raw := by
  intro w hw
  obtain ⟨j,rfl⟩ := rawHaveIndex w hw
  rcases Fin.eq_self_or_eq_succAbove (deletedPair i).1 j with rfl | ⟨k,rfl⟩
  · left; refine ⟨false,funext fun x => ?_⟩
    exact (fullRaw _ _).trans (Fin.insertNth_apply_same _ _ _)
  · rcases Fin.eq_self_or_eq_succAbove (deletedPair i).2 k with rfl | ⟨q,rfl⟩
    · left; refine ⟨false,funext fun x => ?_⟩
      rw [show decode (pr i) (rawWord _) x = extended i x _ from fullRaw _ _]
      simp [extended]
    · right; refine ⟨q,funext fun x => ?_⟩
      rw [show decode (pr i) (rawWord _) x = extended i x _ from fullRaw _ _]
      simp [extended]

theorem singleNonconstant : ∀ v : Fin 9,
    pinned v (fun _ => false) = false ∧ pinned v (fun _ => true) = true := by decide +kernel
theorem doubleNonconstant : ∀ v : Fin 9,
    let f := pinnedPair (deletedPair v).1 (deletedPair v).2
    f (fun _ => false) = false ∧ f (fun _ => true) = true := by decide +kernel

private theorem notConstant {n} {f : (Fin n → Bool) → Bool}
    (h : f (fun _ => false) = false ∧ f (fun _ => true) = true) : ¬Constant f := by
  rintro ⟨b,rfl⟩
  cases b <;> simp_all

noncomputable def singleModel (v : Fin 9) : Model allMask goal (pinMask (singleFix v)) (low1 v) raw := by
  have eq : decode (sr v) goal = pinned v := funext fun x => (singleData v x).2.2
  refine ⟨8,sr v,fun x => (singleData v x).1,fun x => (singleData v x).2.1,
    srRaws v, ?_, ?_⟩
  · rw [eq]; exact notConstant (singleNonconstant v)
  · rw [eq]; exact allSingleLower v

noncomputable def doubleModel (i : Fin 9) : Model allMask goal (pinMask (pairFix i)) 11 raw := by
  have eq : decode (pr i) goal = pinnedPair (deletedPair i).1 (deletedPair i).2 :=
    funext fun x => (doubleData i x).2.2
  refine ⟨7,pr i,fun x => (doubleData i x).1,fun x => (doubleData i x).2.1,
    prRaws i, ?_, ?_⟩
  · rw [eq]; exact notConstant (doubleNonconstant i)
  · rw [eq]; exact thetaPairLower i

def header : Nat := rawWord 0 ||| rawWord 4
def ruleItem (ws : List Nat) (fix lower : Nat) : Item :=
  ⟨pinMask fix,lower,headerCost (pinMask fix) raw ws header⟩
def items (ws : List Nat) : List Item :=
  (List.ofFn fun v : Fin 9 => ruleItem ws (singleFix v) (low1 v)) ++
  (List.ofFn fun i : Fin 9 => ruleItem ws (pairFix i) 11)

theorem initialInvariant (ws : List Nat) (h : ∀ w ∈ ws, w = header ∨ w ∈ raw) :
    Invariant allMask goal raw ws (items ws) := by
  have a : rawWord 0 ∈ raw := by decide +kernel
  have b : rawWord 4 ∈ raw := by decide +kernel
  intro entry he
  simp only [items,List.mem_append,List.mem_ofFn] at he
  rcases he with ⟨i,rfl⟩ | ⟨i,rfl⟩
  · exact headerValid (singleModel i) _ _ a b h
  · exact headerValid (doubleModel i) _ _ a b h

#print axioms initialInvariant
#print axioms singleModel
#print axioms doubleModel
end Petersen1676.Actual
