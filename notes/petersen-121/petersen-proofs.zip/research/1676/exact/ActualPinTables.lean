import PairedData
import DegreePairs

namespace Petersen1676.Actual
open Table

def singleFix (v : Fin 9) : Nat := 2 ^ v.val
def otherIndex (i : Fin 9) : Fin 9 := (deletedPair i).1.succAbove (deletedPair i).2
def pairFix (i : Fin 9) : Nat := 2 ^ (deletedPair i).1.val + 2 ^ (otherIndex i).val
def rawWord (j : Fin 9) := raw[j.val]?.getD 0

set_option maxRecDepth 5000
set_option maxHeartbeats 4000000

/-- Each branch retains precisely the rows matching the next chosen bit. -/
def populated (pool : Nat) : List Nat → Bool
  | [] => decide (pool ≠ 0)
  | w :: ws =>
    populated (pool &&& w) ws && populated (pool ^^^ (pool &&& w)) ws

theorem populated_real (ws : List Nat) (pool : Nat) (bits : List Bool)
    (ok : populated pool ws = true) (lengths : bits.length = ws.length) :
    ∃ j : Nat, pool.testBit j = true ∧ ws.map (fun w => w.testBit j) = bits := by
  induction ws generalizing bits pool with
  | nil =>
    have hn : pool ≠ 0 := of_decide_eq_true ok
    have hw : ∃ j, pool.testBit j = true := by
      by_contra! h
      apply hn
      apply Nat.eq_of_testBit_eq
      intro i; simpa using h i
    obtain ⟨j,hj⟩ := hw
    have emp : bits = [] := List.length_eq_zero_iff.mp (by simpa using lengths)
    exact ⟨j,hj,by simp [emp]⟩
  | cons w ws ih =>
    cases bits with
    | nil => simp at lengths
    | cons b bs =>
      change (populated (pool &&& w) ws && populated (pool ^^^ (pool &&& w)) ws) = true at ok
      rw [Bool.and_eq_true] at ok
      obtain ⟨ht,hf⟩ := ok
      have hl : bs.length = ws.length := by simpa using lengths
      cases b
      · obtain ⟨j,hj,rest⟩ := ih _ _ hf hl
        have pp : pool.testBit j = true ∧ w.testBit j = false := by
          rw [Nat.testBit_xor,Nat.testBit_and] at hj
          cases z : pool.testBit j <;> cases q : w.testBit j <;> simp_all
        exact ⟨j,pp.1,by simp [rest,pp.2]⟩
      · obtain ⟨j,hj,rest⟩ := ih _ _ ht hl
        rw [Nat.testBit_and,Bool.and_eq_true] at hj
        exact ⟨j,hj.1,by simp [rest,hj.2]⟩

theorem rawHaveIndex : ∀ w ∈ raw, ∃ j : Fin 9, w = rawWord j := by decide +kernel
theorem rawLength : raw.length = 9 := by decide +kernel
theorem fullCoverage : populated allMask raw = true := by decide +kernel

theorem fullWitness (x : Fin 9 → Bool) :
    ∃ j : Nat, allMask.testBit j = true ∧ ∀ i : Fin 9, (rawWord i).testBit j = x i := by
  obtain ⟨j,hj,hs⟩ := populated_real raw allMask (List.ofFn x) fullCoverage (by simp [rawLength])
  refine ⟨j,hj,?_⟩
  intro i
  have hh := congrArg (fun bs : List Bool => bs.getD i.val false) hs
  have ii : i.val < raw.length := by rw [rawLength]; exact i.isLt
  change (raw.map (fun w => w.testBit j)).getD i.val false = (List.ofFn x).getD i.val false at hh
  rw [List.getD_eq_getElem _ _ (by simpa using ii), List.getElem_map,
      List.getD_eq_getElem _ _ (by simp), List.getElem_ofFn] at hh
  simpa [rawWord,ii] using hh

noncomputable def fullRow (x : Fin 9 → Bool) : Nat := Classical.choose (fullWitness x)
theorem fullMask (x : Fin 9 → Bool) : allMask.testBit (fullRow x) = true := (Classical.choose_spec (fullWitness x)).1
theorem fullRaw (x : Fin 9 → Bool) (j : Fin 9) : (rawWord j).testBit (fullRow x) = x j :=
  (Classical.choose_spec (fullWitness x)).2 j

private def edgeWord : Nat :=
  (rawWord 0 &&& rawWord 1) ||| (rawWord 1 &&& rawWord 2) ||| (rawWord 2 &&& rawWord 3) |||
  (rawWord 3 &&& rawWord 4) ||| (rawWord 4 &&& rawWord 0) ||| (rawWord 0 &&& rawWord 5) |||
  (rawWord 1 &&& rawWord 6) ||| (rawWord 2 &&& rawWord 7) ||| (rawWord 3 &&& rawWord 8) |||
  (rawWord 5 &&& rawWord 7) ||| (rawWord 6 &&& rawWord 8) ||| (rawWord 8 &&& rawWord 5)
private theorem actualGoal : goal = edgeWord := by decide +kernel
theorem fullGoal (x : Fin 9 → Bool) : goal.testBit (fullRow x) = edge9 x := by
  simp only [actualGoal,edgeWord,Nat.testBit_or,Nat.testBit_and,fullRaw,edge9]

private theorem singleMask : ∀ v : Fin 9, pinMask (singleFix v) = allMask ^^^ rawWord v := by decide +kernel
private theorem doubleMask : ∀ i : Fin 9, pinMask (pairFix i) =
  (allMask ^^^ rawWord (deletedPair i).1) &&& (allMask ^^^ rawWord (otherIndex i)) := by decide +kernel

theorem singleChecked (v : Fin 9) (x : Fin 9 → Bool) (h : x v = false) :
    (pinMask (singleFix v)).testBit (fullRow x) = true := by
  rw [singleMask,Nat.testBit_xor,fullRaw,fullMask,h]; rfl

theorem doubleChecked (i : Fin 9) (x : Fin 9 → Bool)
    (a : x (deletedPair i).1 = false) (b : x (otherIndex i) = false) :
    (pinMask (pairFix i)).testBit (fullRow x) = true := by
  simp only [doubleMask,Nat.testBit_and,Nat.testBit_xor,fullRaw,fullMask,a,b]
  rfl
end Petersen1676.Actual
