import Guided
import WordPrune

namespace Petersen1676.PinRules

open PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_274_aux
open Petersen1676.Prune Petersen1676.Search

/-- A numeric mask, a lower bound on the target under that mask, and the
number of gates already sufficient to generate the projected live signals. -/
structure Item where
  pin : Nat
  lower : Nat
  spent : Nat
deriving DecidableEq, Repr

def update (raw ws : List Nat) (v : Nat) (i : Item) : Item :=
  {i with spent := i.spent + if freeOn i.pin raw ws v then 0 else 1}

def advance (raw ws ys : List Nat) (items : List Item) : List Item :=
  items.map (update raw ws (ys.headD 0))

def legal (s : Nat) (ws : List Nat) (items : List Item) : Bool :=
  items.all (fun i => decide (i.lower + (ws.filter (constantOn i.pin)).length ≤ i.spent+s))

/-- Semantic facts about a mask can be supplied once and reused as its numeric
budget changes. Separate masks may use different projections and arities. -/
structure Model (mask goal pin lower : Nat) (raw : List Nat) where
  n : Nat
  row : (Fin n → Bool) → Nat
  maskTrue : ∀ x, mask.testBit (row x) = true
  pinTrue : ∀ x, pin.testBit (row x) = true
  inputs : RawWords row raw
  nonconstant : ¬ Constant (decode row goal)
  bound : ∀ t, HasCircuitSize n (decode row goal) t → lower ≤ t

def Valid (mask goal : Nat) (raw ws : List Nat) (i : Item) : Prop :=
  ∃ d : Model mask goal i.pin i.lower raw, Built i.spent (ws.map (decode d.row))

def Invariant (mask goal : Nat) (raw ws : List Nat) (items : List Item) : Prop :=
  ∀ i ∈ items, Valid mask goal raw ws i

theorem advance_one {mask goal : Nat} {raw ws ys : List Nat} {i : Item}
    (hi : Valid mask goal raw ws i) (edge : EdgeStep mask ws ys) :
    Valid mask goal raw ys (update raw ws (ys.headD 0) i) := by
  cases ys with
  | nil => exact False.elim edge
  | cons v rest =>
    obtain ⟨d,h⟩ := hi
    refine ⟨d,?_⟩
    obtain ⟨made,hr⟩ := edge
    have large : Built ((update raw ws v i).spent) ((v::ws).map (decode d.row)) := by
      cases made with
      | @unary a ha => exact newNot d.row mask i.pin d.maskTrue d.pinTrue raw ws d.inputs a ha h
      | @binary a b ha hb c =>
        exact newBinary d.row i.pin d.pinTrue raw ws d.inputs c a b ha hb h
    apply builtSubset large
    intro f hf
    obtain ⟨w,hw,rfl⟩ := List.mem_map.1 hf
    rcases List.mem_cons.1 hw with rfl | hw
    · exact List.mem_map.2 ⟨_,List.mem_cons_self,rfl⟩
    · exact List.mem_map.2 ⟨_,List.mem_cons_of_mem _ (hr w hw),rfl⟩

theorem advance_sound {mask goal : Nat} {raw ws ys : List Nat} {items : List Item}
    (good : Invariant mask goal raw ws items) (edge : EdgeStep mask ws ys) :
    Invariant mask goal raw ys (advance raw ws ys items) := by
  intro i hi
  obtain ⟨old,hold,rfl⟩ := List.mem_map.1 hi
  exact advance_one (good old hold) edge

theorem legal_sound {mask goal s : Nat} {raw ws : List Nat} {items : List Item}
    (good : Invariant mask goal raw ws items) (h : NatRun mask goal s ws) :
    legal s ws items = true := by
  apply List.all_eq_true.2
  intro i hi
  obtain ⟨d,hpref⟩ := good i hi
  obtain ⟨t,ht,hc⟩ := wordPrune d.row d.maskTrue h i.pin d.pinTrue d.nonconstant hpref
  exact decide_eq_true ((Nat.add_le_add_right (d.bound t ht) _).trans hc)

theorem guided_sound {mask goal s : Nat} {raw ws : List Nat} {items : List Item}
    (good : Invariant mask goal raw ws items) (h : NatRun mask goal s ws) :
    guided mask goal legal (advance raw) s ws items = true :=
  guided_of_run (Invariant mask goal raw) (fun hw hr => legal_sound hw hr)
    (fun hw he => advance_sound hw he) good h

/-- Every raw projected signal can be supplied at zero shared cost, including
projections which fix several original inputs to the same value. -/
theorem rawBuilt {n : Nat} (row : (Fin n → Bool) → Nat) (raw : List Nat) (hr : RawWords row raw)
    (ws : List Nat) (sub : ∀ w ∈ ws, w ∈ raw) : Built 0 (ws.map (decode row)) := by
  induction ws with
  | nil => exact buildEmpty n
  | cons w ws ih =>
    apply includeFree (ih (fun v hv => sub v (List.mem_cons_of_mem _ hv)))
    rcases hr w (sub w List.mem_cons_self) with h | h
    · exact Or.inl h
    · exact Or.inr (Or.inl h)

/-- The header is optional: if absent or already free at this pin it contributes
zero gates. The amount depends only on the numeric state. -/
def headerCost (pin : Nat) (raw ws : List Nat) (header : Nat) : Nat :=
  if header ∈ ws then (if freeOn pin raw raw header then 0 else 1) else 0

theorem headerValid {mask goal pin lower : Nat} {raw ws : List Nat}
    (d : Model mask goal pin lower raw) (a b : Nat) (ha : a ∈ raw) (hb : b ∈ raw)
    (sub : ∀ w ∈ ws, w = (a ||| b) ∨ w ∈ raw) :
    Valid mask goal raw ws ⟨pin,lower,headerCost pin raw ws (a ||| b)⟩ := by
  refine ⟨d,?_⟩
  by_cases present : a ||| b ∈ ws
  · have start := rawBuilt d.row raw d.inputs raw (fun _ h => h)
    have full := newBinary d.row pin d.pinTrue raw raw d.inputs false a b ha hb start
    have wanted : Built (if freeOn pin raw raw (a ||| b) then 0 else 1)
        (((a ||| b)::raw).map (decode d.row)) := by simpa [binaryWord] using full
    simp [headerCost,present]
    apply builtSubset wanted
    intro f hf
    obtain ⟨w,hw,rfl⟩ := List.mem_map.1 hf
    exact List.mem_map.2 ⟨w,List.mem_cons.2 (sub w hw),rfl⟩
  · simp [headerCost,present]
    exact rawBuilt d.row raw d.inputs ws (fun w hw => (sub w hw).resolve_left (fun e => present (e ▸ hw)))

end Petersen1676.PinRules
