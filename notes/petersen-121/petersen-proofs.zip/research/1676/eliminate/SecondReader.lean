import FirstOrElimination

namespace Checkpoint118.Eliminate

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.MetaComplexity.Helpers

def wireValue {n : ℕ} (gs : List Gate) (x : Fin n → Bool) (j : ℕ) : Bool :=
  (wiresFrom gs (List.ofFn x)).getD j false

/-- A changing gate output has a changing input among its strictly earlier wires.
Future and nonexistent references always take the default value at evaluation time. -/
theorem differentInput {n : ℕ} (gs : List Gate) (x y : Fin n → Bool) (p : ℕ) (g : Gate)
    (hp : gs[p]? = some g) (hd : wireValue gs x (n+p) ≠ wireValue gs y (n+p)) :
    ∃ a ∈ g.inputs, a < n+p ∧ wireValue gs x a ≠ wireValue gs y a := by
  obtain ⟨pre,post,rfl,rfl⟩ := split_at _ _ _ hp
  let w (z : Fin n → Bool) := wiresFrom pre (List.ofFn z)
  let gv (z : Fin n → Bool) := g.op.eval (g.inputs.map fun j => (w z).getD j false)
  have hl (z) : (w z).length = n+pre.length := by simp [w,length_wiresFrom]
  have allw (z) : wiresFrom (pre ++ g :: post) (List.ofFn z) = wiresFrom post (w z ++ [gv z]) := by
    rw [wiresFrom_append]; rfl
  have here (z) : wireValue (pre ++ g :: post) z (n + pre.length) = gv z := by
    unfold wireValue
    rw [allw, getD_wiresFrom _ _ _ (by simp [hl]), getD_snoc_len _ _ _ _ (hl z)]
  have prev (z) (a : ℕ) (ha : a < n+pre.length) :
      wireValue (pre ++ g :: post) z a = (w z).getD a false := by
    unfold wireValue
    rw [wiresFrom_append,getD_wiresFrom]
    simpa [length_wiresFrom] using ha
  by_contra! h
  apply hd
  rw [here,here]
  apply congrArg g.op.eval
  apply List.map_congr_left
  intro a ha
  by_cases hlt : a < n+pre.length
  · simpa [prev _ a hlt] using h a ha hlt
  · rw [List.getD_eq_default _ _ (by rw [hl]; omega),
      List.getD_eq_default _ _ (by rw [hl]; omega)]

/-- The first changing nonconstant wire on a pair of inputs has a changing constant
as an earlier operand when the differing primary input has been pinned. -/
theorem firstVarying (gs : List Gate) (out : ℕ)
    (first : ∀ y : Fin 9 → Bool, wireValue gs y 9 = (y 0 || y 4))
    (hs : wireValue gs (test true false) out ≠ wireValue gs (test true true) out)
    (hout : ∀ c, stF 8 gs 4 false out ≠ Stat.const c) :
    ∃ p, p ≠ 0 ∧ (∀ c, stF 8 gs 4 false (9+p) ≠ Stat.const c) ∧ Charged 8 4 false gs p := by
  classical
  let d (j : ℕ) := wireValue gs (test true false) j ≠ wireValue gs (test true true) j
  let nc (j : ℕ) := ∀ c, stF 8 gs 4 false j ≠ Stat.const c
  have hex : ∃ j, d j ∧ nc j := ⟨out,hs,hout⟩
  let j := Nat.find hex
  have spec : d j ∧ nc j := Nat.find_spec hex
  have small (a : ℕ) (ha : a < j) (had : d a) : ∃ c, stF 8 gs 4 false a = Stat.const c := by
    by_contra! hc
    exact Nat.find_min hex ha ⟨had,hc⟩
  have hj : 9 < j := by
    by_contra! h
    by_cases h9 : j = 9
    · apply spec.1
      rw [h9,first,first]; rfl
    · by_cases h4 : j = 4
      · exact spec.2 false (h4 ▸ stF_self 8 gs 4 false)
      · apply spec.1
        unfold wireValue
        rw [getD_wiresFrom _ _ _ (by simp; omega), getD_wiresFrom _ _ _ (by simp; omega)]
        exact test_agree true j h4
  have hjlt : j < 9 + gs.length := by
    by_contra! h
    apply spec.1
    unfold wireValue
    rw [List.getD_eq_default _ _ (by simpa [length_wiresFrom] using h),
      List.getD_eq_default _ _ (by simpa [length_wiresFrom] using h)]
  let p := j-9
  have jp : 9+p = j := by dsimp [p]; omega
  have hp : p < gs.length := by omega
  have hg : gs[p]? = some gs[p] := List.getElem?_eq_getElem hp
  obtain ⟨a,ha,halt,had⟩ := differentInput gs (test true false) (test true true) p gs[p] hg
    (jp ▸ spec.1)
  obtain ⟨c,hc⟩ := small a (jp ▸ halt) had
  exact ⟨p,by omega,jp ▸ spec.2,gs[p],hg,a,ha,halt,c,hc⟩

theorem otherReaderSavings (f : (Fin 9 → Bool) → Bool) (C : Circuit) (ok : FanInTwo C)
    (first : ∀ y : Fin 9 → Bool, (C.wires (List.ofFn y)).getD 9 false = (y 0 || y 4))
    (he : circuitFun 9 C = f)
    (hsep : f (test true false) ≠ f (test true true))
    (hnc : ∃ y z : Fin 8 → Bool, f (Fin.insertNth (4 : Fin 9) false y) ≠
      f (Fin.insertNth (4 : Fin 9) false z))
    (q : ℕ) (g : Gate) (hq : (C.gates.map normGate)[q]? = some g) (hq0 : q ≠ 0)
    (hr : 4 ∈ g.inputs) (hop : g.op ≠ GateOp.or) :
    ∃ s', HasCircuitSize 8 (fun y => f (Fin.insertNth (4 : Fin 9) false y)) s' ∧ s' + 3 ≤ C.size := by
  let gs := C.gates.map normGate
  have hok : ∀ g ∈ gs, NOk g := by
    intro g hg
    obtain ⟨g₀,h₀,rfl⟩ := List.mem_map.1 hg
    exact normGate_nok _ (ok _ h₀)
  have hfst (x : Fin 9 → Bool) : wireValue gs x 9 = (x 0 || x 4) := by
    simpa [wireValue,gs,wiresFrom_norm,← wires_eq] using first x
  have hval (x : Fin 9 → Bool) : wireValue gs x C.output = f x := by
    unfold wireValue
    rw [show wiresFrom gs (List.ofFn x) = C.wires (List.ofFn x) from wiresFrom_norm _ _, ← he]; rfl
  have hout (c : Bool) (hc : stF 8 gs 4 false C.output = Stat.const c) : False := by
    obtain ⟨y,z,h⟩ := hnc
    have same (w : Fin 8 → Bool) : f (Fin.insertNth (4 : Fin 9) false w) = c := by
      have hi := inv_elim 8 _ (by simp) gs _ _ (fun g hg => (hok g hg).1) (inv_at 8 4 false w)
      have hv := (hi.2 C.output).2
      change (stF 8 gs 4 false C.output).val _ = wireValue gs _ C.output at hv
      rw [hc,hval] at hv
      exact hv.symm
    exact h ((same y).trans (same z).symm)
  obtain ⟨p,hp0,hpnc,hpc⟩ := firstVarying gs C.output hfst (by simpa [hval] using hsep) hout
  have hlen : (statAt 8 4 false, ([] : List Gate)).1.length = 9 := statAt_length 8 4 false
  have hFix : fixBit g = false := by cases h : g.op <;> simp_all [fixBit]
  have hconst := const_of_read 8 gs (statAt 8 4 false,[]) q g hq (hok g (List.mem_of_getElem? hq))
    4 hr (by rw [hlen]; omega) (by rw [hFix]; exact stF_self 8 gs 4 false)
  rw [hlen] at hconst
  obtain ⟨c,hc⟩ := hconst
  have hpq : p ≠ q := fun e => hpnc c (e ▸ hc)
  have hne : gs ≠ [] := by rintro h; change gs[q]? = _ at hq; simp [h] at hq
  have hpos : 0 < gs.length := List.length_pos_iff.2 hne
  have hhead : gs[0]? = some gs[0] := List.getElem?_eq_getElem (List.length_pos_iff.2 hne)
  have hd : wireValue gs (test false false) 9 ≠ wireValue gs (test false true) 9 := by
    rw [hfst,hfst]; decide
  obtain ⟨a,ha,halt,hda⟩ := differentInput gs (test false false) (test false true) 0 gs[0] hhead hd
  have ha4 : a = 4 := by
    by_contra h; apply hda
    unfold wireValue
    rw [getD_wiresFrom _ _ _ (by simpa using halt),getD_wiresFrom _ _ _ (by simpa using halt)]
    exact test_agree false a h
  subst a
  have stat4 : stF 8 gs 4 false 4 = Stat.const false := stF_self 8 gs 4 false
  have hcharge (k : ℕ) (hk : k ∈ ({0,q,p} : Finset ℕ)) : Charged 8 4 false gs k := by
    simp only [Finset.mem_insert,Finset.mem_singleton] at hk
    rcases hk with rfl | rfl | rfl
    · exact ⟨gs[0],hhead,4,ha,by decide,false,stat4⟩
    · exact ⟨g,hq,4,hr,by omega,false,stat4⟩
    · exact hpc
  have card : ({0,q,p} : Finset ℕ).card = 3 :=
    Finset.card_eq_three.2 ⟨_,_,_,hq0.symm,hp0.symm,hpq.symm,rfl⟩
  obtain ⟨s,hs,hlen⟩ := savingsByStatus 8 4 false gs hok {0,q,p} hcharge C.output f hval hnc
  exact ⟨s,hs,by simpa [card,gs,Circuit.size] using hlen⟩

end Checkpoint118.Eliminate
