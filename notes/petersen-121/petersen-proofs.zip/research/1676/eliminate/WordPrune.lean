import RunPrune

namespace Petersen1676.Prune

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_274_aux

/-- Read a truth-table word on the selected row for each projected input. -/
def decode {n : ℕ} (row : (Fin n → Bool) → ℕ) (w : ℕ) : BFn n := fun x => w.testBit (row x)

theorem decodedRun {n : ℕ} (row : (Fin n → Bool) → ℕ) {mask goal s ws}
    (hm : ∀ x, mask.testBit (row x) = true) (h : NatRun mask goal s ws) :
    Run invF meetF joinF (decode row goal) s (ws.map (decode row)) := by
  apply Run.map (decode row) _ _ _ h
  · intro w
    funext x
    simp [decode,invF,Nat.testBit_xor,hm]
  · intro a b
    funext x
    simp [decode,meetF,Nat.testBit_and]
  · intro a b
    funext x
    simp [decode,joinF,Nat.testBit_or]

theorem maskedEqual {n : ℕ} (row : (Fin n → Bool) → ℕ) (pin : ℕ)
    (hp : ∀ x, pin.testBit (row x) = true) {a b : ℕ} (h : a &&& pin = b &&& pin) :
    decode row a = decode row b := by
  funext x
  have e := congrArg (fun w : ℕ => w.testBit (row x)) h
  simpa [decode,Nat.testBit_and,hp] using e

def constantOn (pin w : ℕ) : Bool := decide (w &&& pin = 0 ∨ w &&& pin = pin)

theorem maskedConstant {n : ℕ} (row : (Fin n → Bool) → ℕ) (pin : ℕ)
    (hp : ∀ x, pin.testBit (row x) = true) {w : ℕ} (h : constantOn pin w = true) :
    Constant (decode row w) := by
  obtain h | h := of_decide_eq_true h
  · refine ⟨false,?_⟩
    have eq := maskedEqual row pin hp (a := w) (b := 0) (by simpa using h)
    funext x; rw [congrFun eq x]; simp [decode]
  · refine ⟨true,?_⟩
    have eq := maskedEqual row pin hp (a := w) (b := pin) (by simpa using h)
    funext x; rw [congrFun eq x]; exact hp x

theorem maskedCount {n : ℕ} (row : (Fin n → Bool) → ℕ) (pin : ℕ)
    (hp : ∀ x, pin.testBit (row x) = true) (ws : List ℕ) :
    (ws.filter (constantOn pin)).length ≤ count (ws.map (decode row)) := by
  induction ws with
  | nil => simp [count]
  | cons w ws ih =>
    rw [List.map_cons]
    change (List.filter (constantOn pin) (w::ws)).length ≤ charge (decode row w) + count (ws.map (decode row))
    cases he : constantOn pin w
    · simp [he]; omega
    · have hc : charge (decode row w) = 1 := by
        classical
        simp [charge,maskedConstant row pin hp he]
      simp [he,hc]; omega

/-- The bitmask pruning test can be checked without computing the semantic predicate
that a Boolean function is constant. Row selection need not be injective. -/
theorem wordPrune {n : ℕ} (row : (Fin n → Bool) → ℕ) {mask goal s ws}
    (hm : ∀ x, mask.testBit (row x) = true) (h : NatRun mask goal s ws)
    (pin : ℕ) (hp : ∀ x, pin.testBit (row x) = true)
    (hnc : ¬ Constant (decode row goal)) {b : ℕ} (prefixRep : Built b (ws.map (decode row))) :
    ∃ t, HasCircuitSize n (decode row goal) t ∧ t + (ws.filter (constantOn pin)).length ≤ b+s := by
  obtain ⟨gs,ok,hlen,hw⟩ := prefixRep
  obtain ⟨t,ht,hc⟩ := runPrune (decodedRun row hm h) hnc gs ok hw
  have hcount := maskedCount row pin hp ws
  exact ⟨t,ht,(Nat.add_le_add_left hcount t).trans (hc.trans (Nat.add_le_add_right hlen s))⟩

/-- An emitted wire needs no further gate if its restriction is constant, an
input, or a wire already produced by the shared projected prefix. -/
def freeOn (pin : ℕ) (raw history : List ℕ) (w : ℕ) : Bool :=
  constantOn pin w || (raw++history).any (fun v => decide (w &&& pin = v &&& pin))

def RawWords {n : ℕ} (row : (Fin n → Bool) → ℕ) (raw : List ℕ) : Prop :=
  ∀ w ∈ raw, Constant (decode row w) ∨ ∃ i : Fin n, decode row w = fun x => x i

theorem freeWord {n : ℕ} (row : (Fin n → Bool) → ℕ) (pin : ℕ)
    (hp : ∀ x, pin.testBit (row x) = true) (raw hist : List ℕ) (hraw : RawWords row raw)
    (w : ℕ) (hw : freeOn pin raw hist w = true) {b : ℕ} (start : Built b (hist.map (decode row))) :
    Built b ((w :: hist).map (decode row)) := by
  apply includeFree start
  simp only [freeOn,Bool.or_eq_true] at hw
  rcases hw with hc | ha
  · exact Or.inl (maskedConstant row pin hp hc)
  · obtain ⟨v,hv,eq⟩ := List.any_eq_true.1 ha
    have h := maskedEqual row pin hp (of_decide_eq_true eq)
    rw [h]
    rcases List.mem_append.1 hv with h1 | h2
    · rcases hraw v h1 with h | h
      · exact Or.inl h
      · exact Or.inr (Or.inl h)
    · exact Or.inr (Or.inr (List.mem_map.2 ⟨v,h2,rfl⟩))

theorem newNot {n : ℕ} (row : (Fin n → Bool) → ℕ) (mask pin : ℕ)
    (hm : ∀ x, mask.testBit (row x) = true) (hp : ∀ x, pin.testBit (row x) = true)
    (raw hist : List ℕ) (hr : RawWords row raw) (v : ℕ) (hv : v ∈ hist) {b : ℕ}
    (start : Built b (hist.map (decode row))) :
    Built (b + if freeOn pin raw hist (v ^^^ mask) then 0 else 1)
      (((v ^^^ mask)::hist).map (decode row)) := by
  cases h : freeOn pin raw hist (v ^^^ mask)
  · have eq : decode row (v ^^^ mask) = invF (decode row v) := by
      funext x; simp [decode,invF,Nat.testBit_xor,hm]
    simpa [eq] using buildUnary start (List.mem_map.2 ⟨v,hv,rfl⟩)
  · simpa using freeWord row pin hp raw hist hr _ h start

def binaryWord (c : Bool) (v w : ℕ) := if c then v &&& w else v ||| w

theorem newBinary {n : ℕ} (row : (Fin n → Bool) → ℕ) (pin : ℕ)
    (hp : ∀ x, pin.testBit (row x) = true) (raw hist : List ℕ) (hr : RawWords row raw)
    (c : Bool) (v w : ℕ) (hv : v ∈ hist) (hw : w ∈ hist) {b : ℕ}
    (start : Built b (hist.map (decode row))) :
    Built (b + if freeOn pin raw hist (binaryWord c v w) then 0 else 1)
      ((binaryWord c v w::hist).map (decode row)) := by
  cases h : freeOn pin raw hist (binaryWord c v w)
  · have eq : decode row (binaryWord c v w) = comb c (decode row v) (decode row w) := by
      funext x; cases c <;> simp [decode,binaryWord,comb,joinF,meetF,Nat.testBit_and,Nat.testBit_or]
    simpa [eq] using buildBinary start (List.mem_map.2 ⟨v,hv,rfl⟩) (List.mem_map.2 ⟨w,hw,rfl⟩) c
  · simpa using freeWord row pin hp raw hist hr _ h start

end Petersen1676.Prune
