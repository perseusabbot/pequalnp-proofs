import MemoLayer
import MemoFrontier

namespace Petersen1676.Memo

open PEqualNP.Outside.L_meta_274_aux Petersen1676.Search Petersen1676.PinRules Petersen1676.Prune

abbrev Cut := Nat → List Nat → List Item → Bool

private def ins (a : Nat) : List Nat → List Nat
  | [] => [a]
  | b::r => if a ≤ b then a::b::r else b :: ins a r

def canonical : List Nat → List Nat
  | [] => []
  | a::r => ins a (canonical r)

private theorem insPerm (a : Nat) : ∀ r, (ins a r).Perm (a::r) := by
  intro r
  induction r with
  | nil => exact .refl _
  | cons b r ih =>
    unfold ins; split
    · exact .refl _
    · exact (ih.cons b).trans (.swap _ _ _)

theorem canonicalPerm : ∀ ws, (canonical ws).Perm ws := by
  intro ws
  induction ws with
  | nil => exact .refl _
  | cons a r ih => exact (insPerm a (canonical r)).trans (ih.cons a)

private theorem reorder {m target raw ws is} (valid : Invariant m target raw ws is) :
    Invariant m target raw (canonical ws) is := by
  intro i hi
  obtain ⟨d,h⟩ := valid i hi
  refine ⟨d,builtSubset h ?_⟩
  intro f hf
  exact ((canonicalPerm ws).map (decode d.row)).mem_iff.1 hf

def gen (m : Nat) (raw : List Nat) (cut : Cut) (s : Nat) (ws : List Nat) (is : List Item) : List Node :=
  (children m (s+2-ws.length) ws).filterMap (fun ys =>
    let fresh := advance raw ws ys is
    if cut s ys fresh then some (canonical ys,fresh) else none)

private theorem genGood {m goal raw cut s ws is} (g : Invariant m goal raw ws is) :
    ∀ q ∈ gen m raw cut s ws is, Invariant m goal raw q.1 q.2 := by
  intro q h
  obtain ⟨ys,hy,hq⟩ := List.mem_filterMap.1 h
  simp only at hq
  split at hq
  · cases hq
    exact reorder (advance_sound g (child_edge _ _ _ _ hy))
  · cases hq

private theorem genRun {m goal : Nat} {raw : List Nat} {cut : Cut}
    (sound : ∀ {s ws is}, Invariant m goal raw ws is → NatRun m goal s ws → cut s ws is = true)
    {s ws is} (g : Invariant m goal raw ws is) (hr : NatRun m goal (s+1) ws) :
    ∃ q ∈ gen m raw cut s ws is, NatRun m goal s q.1 := by
  obtain ⟨ys,hy,he,hr'⟩ := child_run hr
  have good := advance_sound g he
  have pass := sound good hr'
  refine ⟨(canonical ys,advance raw ws ys is),List.mem_filterMap.2 ⟨ys,hy,?_⟩,?_⟩
  · simp [pass]
  · exact Run.perm (canonicalPerm _).symm hr'

/-- Reflect the finite search by building one deduplicated layer at a time. -/
def search (m goal : Nat) (raw : List Nat) (cut : Cut) : Nat → Layer → Bool
  | 0, tab => tab.contains [goal]
  | s+1, tab => search m goal raw cut s (nextLayer (gen m raw cut s) tab)

theorem search_of_run {m goal : Nat} {raw : List Nat} {cut : Cut}
    (sound : ∀ {s ws is}, Invariant m goal raw ws is → NatRun m goal s ws → cut s ws is = true) :
    ∀ (s : Nat) (tab : Layer), layerGood m goal raw tab →
      (∃ ws is, tab[ws]? = some is ∧ NatRun m goal s ws) → search m goal raw cut s tab = true := by
  intro s
  induction s with
  | zero =>
    intro tab _ hr
    obtain ⟨ws,is,hv,hr⟩ := hr
    have eqn := zero_done hr rfl
    subst ws
    apply Std.TreeMap.contains_iff_mem.2
    exact Std.TreeMap.mem_iff_isSome_getElem?.2 (by simp [hv])
  | succ s ih =>
    intro tab good hr
    obtain ⟨ws,is,prior,hr⟩ := hr
    obtain ⟨q,hq,hqr⟩ := genRun sound (good _ _ prior) hr
    let nxt := nextLayer (gen m raw cut s) tab
    have memb : q.1 ∈ nxt := nextMember _ _ prior q hq
    apply ih nxt (nextGood _ tab good (fun _ _ hg => genGood hg))
    exact ⟨q.1,nxt[q.1],Std.TreeMap.getElem?_eq_some_getElem memb,hqr⟩

def root (ws : List Nat) (is : List Item) : Layer := (∅ : Layer).insert (canonical ws) is

theorem root_of_run {m goal : Nat} {raw : List Nat} {cut : Cut}
    (sound : ∀ {s ws is}, Invariant m goal raw ws is → NatRun m goal s ws → cut s ws is = true)
    {s ws is} (good : Invariant m goal raw ws is) (hr : NatRun m goal s ws) :
    search m goal raw cut s (root ws is) = true := by
  apply search_of_run sound
  · intro w q hv
    simp only [root,Std.TreeMap.getElem?_insert] at hv
    split at hv
    · rename_i h
      have hw := Std.LawfulEqOrd.compare_eq_iff_eq.1 h
      cases hv
      exact hw ▸ reorder good
    · cases hv
  · refine ⟨canonical ws,is,?_,Run.perm (canonicalPerm _).symm hr⟩
    simp [root]

/-- Allow separate kernel-checkable exclusions for the children of a large
node. Each child receives the budget from its actual move and its sorted list. -/
theorem splitRefute {m goal : Nat} {raw : List Nat} {cut : Cut}
    (sound : ∀ {s ws is}, Invariant m goal raw ws is → NatRun m goal s ws → cut s ws is = true)
    {s ws is} (good : Invariant m goal raw ws is)
    (closed : ∀ q ∈ gen m raw cut s ws is, ¬ NatRun m goal s q.1) :
    ¬ NatRun m goal (s+1) ws := by
  intro h
  obtain ⟨q,hq,hr⟩ := genRun sound good h
  exact closed q hq hr

/-- A partition may instead refer directly to independent Boolean checker
results. The shared-prefix witnesses are inherited from the parent. -/
theorem splitChecked {m goal : Nat} {raw : List Nat} {cut : Cut}
    (sound : ∀ {s ws is}, Invariant m goal raw ws is → NatRun m goal s ws → cut s ws is = true)
    {s ws is} (good : Invariant m goal raw ws is)
    (closed : ∀ q ∈ gen m raw cut s ws is, search m goal raw cut s (root q.1 q.2) = false) :
    ¬ NatRun m goal (s+1) ws := by
  apply splitRefute sound good
  intro q hq run
  have yes := root_of_run sound (genGood good q hq) run
  rw [closed q hq] at yes
  cases yes

/-- One computed and deduplicated partition, in lexicographic order by wire list. -/
def partition (m : Nat) (raw : List Nat) (cut : Cut) (s : Nat) (ws : List Nat) (is : List Item) : List Node :=
  (nextLayer (gen m raw cut s) (root ws is)).toList

theorem partition_of_run {m goal : Nat} {raw : List Nat} {cut : Cut}
    (sound : ∀ {s ws is}, Invariant m goal raw ws is → NatRun m goal s ws → cut s ws is = true)
    {s ws is} (good : Invariant m goal raw ws is) (hr : NatRun m goal (s+1) ws) :
    ∃ q ∈ partition m raw cut s ws is, Invariant m goal raw q.1 q.2 ∧ NatRun m goal s q.1 := by
  have rg : layerGood m goal raw (root ws is) := by
    intro w q hv
    simp only [root,Std.TreeMap.getElem?_insert] at hv
    split at hv
    · rename_i h
      have hw := Std.LawfulEqOrd.compare_eq_iff_eq.1 h
      cases hv
      exact hw ▸ reorder good
    · cases hv
  obtain ⟨q,hq,run⟩ := genRun sound (reorder good) (Run.perm (canonicalPerm ws).symm hr)
  let t := nextLayer (gen m raw cut s) (root ws is)
  have hroot : (root ws is)[canonical ws]? = some is := by simp [root]
  have dm : q.1 ∈ t := nextMember _ _ hroot q hq
  have entry : t[q.1]? = some t[q.1] := Std.TreeMap.getElem?_eq_some_getElem dm
  have g := nextGood (gen m raw cut s) (root ws is) rg (fun _ _ x => genGood x)
  exact ⟨(q.1,t[q.1]),Std.TreeMap.mem_toList_iff_getElem?_eq_some.2 entry,g _ _ entry,run⟩

theorem partition_indices {m goal : Nat} {raw : List Nat} {cut : Cut}
    (sound : ∀ {s ws is}, Invariant m goal raw ws is → NatRun m goal s ws → cut s ws is = true)
    {s ws is} (valid : Invariant m goal raw ws is)
    (done : ∀ i : Fin (partition m raw cut s ws is).length,
      ¬ NatRun m goal s ((partition m raw cut s ws is)[i.val]).1) :
    ¬ NatRun m goal (s+1) ws := by
  intro h
  obtain ⟨q,hq,_,hr⟩ := partition_of_run sound valid h
  obtain ⟨i,hi⟩ := List.mem_iff_get.1 hq
  apply done i
  change NatRun m goal s ((partition m raw cut s ws is).get i).1
  rw [hi]
  exact hr

end Petersen1676.Memo
