import PinRules

namespace Petersen1676.Memo

open PEqualNP.Outside.L_meta_274_aux Petersen1676.PinRules

abbrev Node := List Nat × List Item
abbrev Layer := Std.TreeMap (List Nat) (List Item)

/-- For identical signal lists, each projection may use whichever independently
valid prefix has fewer gates. The pin order is fixed by the initial rules. -/
def combine : List Item → List Item → List Item
  | [], ys => ys
  | xs, [] => xs
  | x::xs, y::ys => (if x.spent ≤ y.spent then x else y) :: combine xs ys

private theorem combineValid {m target : Nat} {raw ws} (xs ys : List Item)
    (hx : Invariant m target raw ws xs) (hy : Invariant m target raw ws ys) :
    Invariant m target raw ws (combine xs ys) := by
  induction xs generalizing ys with
  | nil => exact hy
  | cons x xs ih =>
    cases ys with
    | nil => exact hx
    | cons y ys =>
      intro i hi
      rcases List.mem_cons.1 hi with he | ht
      · split at he <;> subst i
        · exact hx _ List.mem_cons_self
        · exact hy _ List.mem_cons_self
      · exact ih ys (fun _ h => hx _ (List.mem_cons_of_mem _ h))
          (fun _ h => hy _ (List.mem_cons_of_mem _ h)) _ ht

def put (tab : Layer) (q : Node) : Layer :=
  let vs := match tab[q.1]? with
    | none => q.2
    | some old => combine q.2 old
  tab.insert q.1 vs

def layerGood (m target : Nat) (raw : List Nat) (tab : Layer) : Prop :=
  ∀ ws is, tab[ws]? = some is → Invariant m target raw ws is

private theorem putGood {m target raw tab} (old : layerGood m target raw tab) (q : Node)
    (new : Invariant m target raw q.1 q.2) : layerGood m target raw (put tab q) := by
  intro ws is h
  rw [put,Std.TreeMap.getElem?_insert] at h
  by_cases eq : q.1 = ws
  · subst ws
    cases hs : tab[q.1]? with
    | none =>
      simp [hs] at h
      exact h ▸ new
    | some was =>
      have v := combineValid _ _ new (old _ _ hs)
      simp [hs] at h
      exact h ▸ v
  · simp [eq] at h
    exact old _ _ h

private theorem putMember (tab : Layer) (q : Node) (ws : List Nat) :
    ws ∈ put tab q ↔ ws = q.1 ∨ ws ∈ tab := by
  rw [put,Std.TreeMap.mem_insert,Std.LawfulEqOrd.compare_eq_iff_eq,eq_comm (a := q.1)]

private theorem foldGood {m target raw} (qs : List Node) (tab : Layer) (old : layerGood m target raw tab)
    (good : ∀ q ∈ qs, Invariant m target raw q.1 q.2) :
    layerGood m target raw (qs.foldl put tab) := by
  induction qs generalizing tab with
  | nil => exact old
  | cons q qs ih =>
    exact ih _ (putGood old q (good _ List.mem_cons_self))
      (fun q' h => good _ (List.mem_cons_of_mem _ h))

private theorem foldMember (qs : List Node) (tab : Layer) (ws : List Nat) :
    ws ∈ qs.foldl put tab ↔ ws ∈ tab ∨ ∃ q ∈ qs, q.1 = ws := by
  induction qs generalizing tab with
  | nil => simp
  | cons q qs ih =>
    simp only [List.foldl_cons, ih, putMember, List.mem_cons, exists_eq_or_imp]
    grind

/-- Compute a whole frontier without materializing the union of its successor
lists. Canonicalized state keys are supplied by the move generator. -/
def nextLayer (gen : List Nat → List Item → List Node) (tab : Layer) : Layer :=
  tab.foldl (fun acc ws is => (gen ws is).foldl put acc) ∅

private theorem asList (gen : List Nat → List Item → List Node) (tab : Layer) :
    nextLayer gen tab = (tab.toList.flatMap (fun q => gen q.1 q.2)).foldl put ∅ := by
  rw [nextLayer,Std.TreeMap.foldl_eq_foldl_toList]
  simp [List.foldl_flatMap]

theorem nextGood {m target raw} (gen : List Nat → List Item → List Node) (tab : Layer)
    (g : layerGood m target raw tab) (cert : ∀ ws is, Invariant m target raw ws is →
      ∀ q ∈ gen ws is, Invariant m target raw q.1 q.2) :
    layerGood m target raw (nextLayer gen tab) := by
  rw [asList]
  apply foldGood _ _ (by intro ws is hf; simp at hf)
  intro q h
  obtain ⟨⟨ws,is⟩,hq,hi⟩ := List.mem_flatMap.1 h
  exact cert _ _ (g _ _ (Std.TreeMap.mem_toList_iff_getElem?_eq_some.1 hq)) q hi

theorem nextMember (gen : List Nat → List Item → List Node) (tab : Layer)
    {ws : List Nat} {is : List Item} (prior : tab[ws]? = some is) (q : Node) (h : q ∈ gen ws is) :
    q.1 ∈ nextLayer gen tab := by
  rw [asList,foldMember]
  exact Or.inr ⟨q,List.mem_flatMap.2 ⟨(ws,is),Std.TreeMap.mem_toList_iff_getElem?_eq_some.2 prior,h⟩,rfl⟩

end Petersen1676.Memo
