import PEqualNP.MetaComplexity.Helpers.Parity3

namespace Checkpoint118.Eliminate

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.MetaComplexity.Helpers

/-- Set just inputs zero and four to the supplied bits. -/
def test (a b : Bool) (i : Fin 9) : Bool :=
  (decide (i = 0) && a) || (decide (i = 4) && b)

theorem test_agree (a : Bool) (j : ℕ) (hj : j ≠ 4) :
    (List.ofFn (test a false)).getD j false = (List.ofFn (test a true)).getD j false := by
  by_cases h : j < 9
  · let i : Fin 9 := ⟨j, h⟩
    have h4 : i ≠ 4 := fun e => hj (congrArg Fin.val e)
    change (List.ofFn (test a false)).getD i.val false = (List.ofFn (test a true)).getD i.val false
    rw [getD_ofFn, getD_ofFn]
    simp [test, h4]
  · rw [List.getD_eq_default _ _ (by simpa using Nat.le_of_not_gt h),
        List.getD_eq_default _ _ (by simpa using Nat.le_of_not_gt h)]

/-- A gate with a constant earlier input disappears under the pin. -/
def Charged (n : ℕ) (i : Fin (n+1)) (b : Bool) (gs : List Gate) (p : ℕ) : Prop :=
  ∃ g, gs[p]? = some g ∧ ∃ j ∈ g.inputs, j < n+1+p ∧ ∃ c, stF n gs i b j = Stat.const c

theorem savingsByStatus (n : ℕ) (i : Fin (n+1)) (b : Bool) (gs : List Gate)
    (ok : ∀ g ∈ gs, NOk g) (S : Finset ℕ) (charges : ∀ p ∈ S, Charged n i b gs p)
    (out : ℕ) (f : (Fin (n+1) → Bool) → Bool)
    (he : ∀ x, (wiresFrom gs (List.ofFn x)).getD out false = f x)
    (hnc : ∃ y z : Fin n → Bool, f (Fin.insertNth i b y) ≠ f (Fin.insertNth i b z)) :
    ∃ s', HasCircuitSize n (fun y => f (Fin.insertNth i b y)) s' ∧ s' + S.card ≤ gs.length := by
  let acc := (statAt n i b, ([] : List Gate))
  have hcount := elim_count n acc gs ok S (by
    intro p hp
    obtain ⟨g,hg,j,hj,hlt,c,hc⟩ := charges p hp
    exact ⟨g,hg,j,hj,by simpa [acc,statAt_length] using hlt,c,hc⟩)
  have hval (y : Fin n → Bool) :
      ((elim n gs acc).1.getD out (Stat.const false)).val
        (wiresFrom (elim n gs acc).2 (List.ofFn y)) = f (Fin.insertNth i b y) := by
    have hi := inv_elim n _ (by simp) gs _ _ (fun g hg => (ok g hg).1) (inv_at n i b y)
    rw [← he]
    exact (hi.2 out).2
  cases hs : (elim n gs acc).1.getD out (Stat.const false) with
  | const c =>
    obtain ⟨y,z,h⟩ := hnc
    apply False.elim (h ?_)
    rw [← hval y, ← hval z, hs]
    rfl
  | wire k =>
    refine ⟨(elim n gs acc).2.length, ⟨⟨(elim n gs acc).2,k⟩, elim_ok n gs acc (by simp [acc]),
      le_refl _, ?_⟩, by simpa [acc] using hcount⟩
    intro y
    have hy := hval y
    rw [hs] at hy
    exact hy

/-- Every normalized gate directly reading a pinned input disappears under restriction. -/
theorem savings (n : ℕ) (i : Fin (n+1)) (b : Bool) (gs : List Gate)
    (ok : ∀ g ∈ gs, NOk g) (S : Finset ℕ)
    (reads : ∀ p ∈ S, ∃ g, gs[p]? = some g ∧ i.val ∈ g.inputs)
    (out : ℕ) (f : (Fin (n+1) → Bool) → Bool)
    (he : ∀ x, (wiresFrom gs (List.ofFn x)).getD out false = f x)
    (hnc : ∃ y z : Fin n → Bool, f (Fin.insertNth i b y) ≠ f (Fin.insertNth i b z)) :
    ∃ s', HasCircuitSize n (fun y => f (Fin.insertNth i b y)) s' ∧ s' + S.card ≤ gs.length := by
  apply savingsByStatus n i b gs ok S _ out f he hnc
  intro p hp
  obtain ⟨g,hg,hi⟩ := reads p hp
  exact ⟨g,hg,i.val,hi,by omega,b,stF_self n gs i b⟩

private def firstValue (g : Gate) (x : Fin 9 → Bool) : Bool :=
  g.op.eval (g.inputs.map fun j => (List.ofFn x).getD j false)

private theorem twoReaders (gs : List Gate) (out : ℕ) (f : (Fin 9 → Bool) → Bool)
    (first : ∀ y : Fin 9 → Bool, (wiresFrom gs (List.ofFn y)).getD 9 false = (y 0 || y 4))
    (he : ∀ x, (wiresFrom gs (List.ofFn x)).getD out false = f x)
    (hraw : f (test false true) = false)
    (hsep : f (test true false) ≠ f (test true true)) :
    ∃ S : Finset ℕ, S.card = 2 ∧ ∀ p ∈ S, ∃ g, gs[p]? = some g ∧ 4 ∈ g.inputs := by
  have hout : out ≠ 4 := by
    intro e
    have h := he (test false true)
    rw [e, getD_wiresFrom _ _ _ (by simp), hraw] at h
    exact Bool.noConfusion h
  cases gs with
  | nil =>
    have h := first (test false true)
    exact Bool.noConfusion h
  | cons g rest =>
    have firstVal (x : Fin 9 → Bool) : firstValue g x = (x 0 || x 4) := by
      have h := first x
      change (wiresFrom rest (List.ofFn x ++ [firstValue g x])).getD 9 false = _ at h
      rw [getD_wiresFrom _ _ _ (by simp), getD_snoc_len _ _ _ _ (by simp)] at h
      exact h
    have hg : 4 ∈ g.inputs := by
      by_contra h
      have eq : firstValue g (test false false) = firstValue g (test false true) := by
        apply congrArg g.op.eval
        exact List.map_congr_left (fun j hj => test_agree false j (fun e => h (e ▸ hj)))
      rw [firstVal, firstVal] at eq
      exact Bool.noConfusion eq
    have hr : ∃ q ∈ rest, 4 ∈ q.inputs := by
      by_contra! h
      apply hsep
      rw [← he, ← he]
      change (wiresFrom rest (List.ofFn (test true false) ++ [firstValue g (test true false)])).getD out false =
        (wiresFrom rest (List.ofFn (test true true) ++ [firstValue g (test true true)])).getD out false
      rw [firstVal,firstVal]
      change (wiresFrom rest (List.ofFn (test true false) ++ [true])).getD out false =
        (wiresFrom rest (List.ofFn (test true true) ++ [true])).getD out false
      apply agree_except 4 rest _ _ h (by simp) _ out hout
      intro j hj
      by_cases h9 : j = 9
      · subst j
        rw [getD_snoc_len _ _ _ _ (by simp), getD_snoc_len _ _ _ _ (by simp)]
      · rw [getD_snoc_ne _ _ _ _ (by simpa using h9), getD_snoc_ne _ _ _ _ (by simpa using h9)]
        exact test_agree true j hj
    obtain ⟨q,hq,h4⟩ := hr
    obtain ⟨p,hp⟩ := List.mem_iff_getElem?.mp hq
    refine ⟨{0,p+1}, by simp, ?_⟩
    intro k hk
    simp only [Finset.mem_insert,Finset.mem_singleton] at hk
    rcases hk with rfl | rfl
    · exact ⟨g,rfl,hg⟩
    · exact ⟨q,hp,h4⟩

/-- Restricting input four to false saves two gates when the first wire is
input zero OR input four and the whole function still separates those two cases at input zero. -/
theorem twoSaved (f : (Fin 9 → Bool) → Bool) (C : Circuit) (ok : FanInTwo C)
    (first : ∀ y : Fin 9 → Bool, (C.wires (List.ofFn y)).getD 9 false = (y 0 || y 4))
    (he : circuitFun 9 C = f)
    (hraw : f (test false true) = false)
    (hsep : f (test true false) ≠ f (test true true))
    (hnc : ∃ y z : Fin 8 → Bool, f (Fin.insertNth (4 : Fin 9) false y) ≠
      f (Fin.insertNth (4 : Fin 9) false z)) :
    ∃ s', HasCircuitSize 8 (fun y => f (Fin.insertNth (4 : Fin 9) false y)) s' ∧ s' + 2 ≤ C.size := by
  let gs := C.gates.map normGate
  have hok : ∀ g ∈ gs, NOk g := by
    intro g hg
    obtain ⟨g₀,h₀,rfl⟩ := List.mem_map.1 hg
    exact normGate_nok _ (ok _ h₀)
  have hfst (x : Fin 9 → Bool) : (wiresFrom gs (List.ofFn x)).getD 9 false = (x 0 || x 4) := by
    simpa [gs,wiresFrom_norm,← wires_eq] using first x
  have hval (x : Fin 9 → Bool) : (wiresFrom gs (List.ofFn x)).getD C.output false = f x := by
    rw [show wiresFrom gs (List.ofFn x) = C.wires (List.ofFn x) from wiresFrom_norm _ _, ← he]; rfl
  obtain ⟨S,hs,hr⟩ := twoReaders gs C.output f hfst hval hraw hsep
  obtain ⟨s,h,hlen⟩ := savings 8 (4 : Fin 9) false gs hok S hr C.output f hval hnc
  exact ⟨s,h, by simpa [hs,gs,Circuit.size] using hlen⟩

end Checkpoint118.Eliminate
