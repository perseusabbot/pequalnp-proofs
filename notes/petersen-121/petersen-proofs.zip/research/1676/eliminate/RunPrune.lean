import PEqualNP.Outside.L_meta_274

namespace Petersen1676.Prune

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_274_aux

def Constant {n : ℕ} (f : BFn n) : Prop := ∃ c : Bool, f = fun _ => c

noncomputable def charge {n : ℕ} (f : BFn n) : ℕ := by
  classical
  exact if Constant f then 1 else 0

noncomputable def count {n : ℕ} (ws : List (BFn n)) := (ws.map charge).sum

def Legal (gs : List Gate) : Prop := FanInTwo ⟨gs,0⟩

def Have {n : ℕ} (gs : List Gate) (f : BFn n) : Prop :=
  ¬ Constant f → ∃ j, j < n+gs.length ∧ val gs n j = f

def Available {n : ℕ} (gs : List Gate) (ws : List (BFn n)) : Prop := ∀ f ∈ ws, Have gs f

private theorem prior {n : ℕ} {gs : List Gate} (g : Gate) {j : ℕ} (hj : j < n+gs.length) :
    val (gs ++ [g]) n j = val gs n j := by
  funext x
  unfold val
  rw [wiresFrom_append,getD_wiresFrom _ _ _ (by simpa [length_wiresFrom] using hj)]

private theorem keepHave {n : ℕ} {gs : List Gate} (g : Gate) {f : BFn n} (hf : Have gs f) :
    Have (gs ++ [g]) f := by
  intro hn
  obtain ⟨j,hj,hv⟩ := hf hn
  exact ⟨j,by simp; omega,(prior g hj).trans hv⟩

private theorem emit {n : ℕ} (gs : List Gate) (g : Gate) (ok : Legal gs)
    (gok : g.op ∈ ({GateOp.and, GateOp.or, GateOp.not} : Set GateOp) ∧ g.inputs.length ≤ 2)
    (ht : ∀ j ∈ g.inputs, j < n+gs.length) (f : BFn n)
    (hval : ∀ x, g.op.eval (g.inputs.map fun j => val gs n j x) = f x) :
    Legal (gs ++ [g]) ∧ Have (gs ++ [g]) f := by
  refine ⟨?_, ?_⟩
  · intro h hh
    rcases List.mem_append.1 hh with h1 | h2
    · exact ok _ h1
    · simp only [List.mem_singleton] at h2
      subst h; exact gok
  · intro _
    refine ⟨n+gs.length,by simp,?_⟩
    funext x
    rw [val_gate n (gs++[g]) gs.length g List.getElem?_concat_length ht x, ← hval x]
    apply congrArg g.op.eval
    exact List.map_congr_left (fun j hj => congrFun (prior g (ht j hj)) x)

private theorem crKept {n : ℕ} (a : BFn n) (xs : List (BFn n)) (b : Bool) :
    count xs ≤ count (kept b a xs) := by
  cases b <;> simp [kept,count]

private theorem inKept {n : ℕ} (a : BFn n) (xs : List (BFn n)) (b : Bool) (gs : List Gate)
    (ha : Have gs a) (hrs : Available gs xs) : Available gs (kept b a xs) := by
  cases b
  · exact hrs
  · simpa [kept,Available] using And.intro ha hrs

private theorem inHead {n : ℕ} {a : BFn n} {xs} {gs} (ha : Have gs a) (hrs : Available gs xs) :
    Available gs (a :: xs) := by simpa [Available] using And.intro ha hrs

private theorem headTail {n : ℕ} {a : BFn n} {xs} {gs} (h : Available gs (a::xs)) :
    Have gs a ∧ Available gs xs := by simpa [Available] using h

private theorem monoAvail {n : ℕ} (gs : List Gate) (g : Gate) (ws : List (BFn n)) (h : Available gs ws) :
    Available (gs ++ [g]) ws := fun f hf => keepHave g (h f hf)

private theorem count_cons {n : ℕ} (a : BFn n) (xs) :
    count (a::xs) = charge a + count xs := by simp [count]

private theorem constCharge {n} {a : BFn n} (ha : Constant a) : charge a = 1 := by
  classical
  simp [charge,ha]

private theorem nonCharge {n} {a : BFn n} (ha : ¬ Constant a) : charge a = 0 := by
  classical
  simp [charge,ha]

def comb {n : ℕ} (c : Bool) (a b : BFn n) := if c then meetF a b else joinF a b

private theorem bothConst {n : ℕ} (c : Bool) {a b : BFn n} (ha : Constant a) (hb : Constant b) :
    Constant (comb c a b) := by
  obtain ⟨v,rfl⟩ := ha
  obtain ⟨w,rfl⟩ := hb
  cases c <;> exact ⟨_,rfl⟩

private theorem mergeConst {n : ℕ} (gs : List Gate) (c : Bool) {a b : BFn n}
    (ha : Constant a ∨ Constant b) (wa : Have gs a) (wb : Have gs b) :
    Have gs (comb c a b) := by
  have leftConst (u v : BFn n) (hu : Constant u) (wv : Have gs v) : Have gs (comb c u v) := by
    obtain ⟨k,rfl⟩ := hu
    cases c <;> cases k <;>
      first | exact wv | intro hn; exact False.elim (hn ⟨_,rfl⟩)
  rcases ha with h | h
  · exact leftConst a b h wb
  · have eq : comb c a b = comb c b a := by
      funext x
      cases c <;> simp [comb,joinF,meetF,Bool.and_comm,Bool.or_comm]
    rw [eq]; exact leftConst b a h wa

private theorem oneStep {n : ℕ} (gs : List Gate) (ok : Legal gs) (a : BFn n) (r) (save : Bool)
    (hw : Available gs (a::r)) :
    ∃ gs', Legal gs' ∧ Available gs' (invF a :: kept save a r) ∧
      gs'.length + count (a::r) ≤ gs.length + 1 + count (invF a :: kept save a r) := by
  classical
  obtain ⟨wa,wr⟩ := headTail hw
  have kr := crKept a r save
  by_cases hc : Constant a
  · have hc' : Constant (invF a) := by obtain ⟨v,rfl⟩ := hc; exact ⟨_,rfl⟩
    refine ⟨gs,ok,inHead (fun h => False.elim (h hc')) (inKept _ _ _ _ wa wr),?_⟩
    rw [count_cons,count_cons,constCharge hc,constCharge hc']; omega
  · obtain ⟨j,hj,hv⟩ := wa hc
    let g : Gate := ⟨.not,[j]⟩
    obtain ⟨ok',hn⟩ := emit gs g ok (by simp [g]) (by simpa [g] using hj) (invF a)
      (by intro x; simp [g,GateOp.eval,hv])
    refine ⟨gs++[g],ok',inHead hn (monoAvail gs g _ (inKept _ _ _ _ wa wr)),?_⟩
    rw [count_cons,count_cons,nonCharge hc]
    simp only [List.length_append,List.length_singleton]; omega

private theorem twoStep {n : ℕ} (gs : List Gate) (ok : Legal gs) (a b : BFn n) (r) (c ka kb : Bool)
    (hw : Available gs (a::b::r)) :
    ∃ gs', Legal gs' ∧ Available gs' (comb c a b :: kept ka a (kept kb b r)) ∧
      gs'.length + count (a::b::r) ≤ gs.length + 1 + count (comb c a b :: kept ka a (kept kb b r)) := by
  classical
  obtain ⟨wa,wr⟩ := headTail hw
  obtain ⟨wb,wr⟩ := headTail wr
  have keep := inKept a _ ka gs wa (inKept b _ kb gs wb wr)
  have klen := (crKept b r kb).trans (crKept a _ ka)
  by_cases h : Constant a ∨ Constant b
  · refine ⟨gs,ok,inHead (mergeConst gs c h wa wb) keep,?_⟩
    rw [count_cons,count_cons,count_cons]
    by_cases ha : Constant a <;> by_cases hb : Constant b
    · rw [constCharge ha,constCharge hb,constCharge (bothConst c ha hb)]; omega
    · rw [constCharge ha,nonCharge hb]; omega
    · rw [nonCharge ha,constCharge hb]; omega
    · exact False.elim (h.elim ha hb)
  · push Not at h
    obtain ⟨j,hj,hv⟩ := wa h.1
    obtain ⟨k,hk,hkval⟩ := wb h.2
    let g : Gate := ⟨if c then .and else .or,[j,k]⟩
    obtain ⟨ok',hn⟩ := emit gs g ok (by cases c <;> simp [g])
      (by simpa [g] using And.intro hj hk) (comb c a b) (by intro x; cases c <;> simp [g,comb,GateOp.eval,hv,hkval])
    refine ⟨gs++[g],ok',inHead hn (monoAvail gs g _ keep),?_⟩
    rw [count_cons,count_cons,count_cons,nonCharge h.1,nonCharge h.2]
    simp only [List.length_append,List.length_singleton]; omega

/-- A constant live signal can be charged once per occurrence. The target is
nonconstant, and all other signals share one circuit prefix. -/
theorem runPrune {n : ℕ} {y : BFn n} {s : ℕ} {ws : List (BFn n)} (hr : Run invF meetF joinF y s ws)
    (hy : ¬ Constant y) (gs : List Gate) (ok : Legal gs) (hw : Available gs ws) :
    ∃ t, HasCircuitSize n y t ∧ t + count ws ≤ gs.length + s := by
  induction hr using Run.fold generalizing gs with
  | done =>
    obtain ⟨j,_,hj⟩ := (hw y (by simp)) hy
    refine ⟨gs.length, ⟨⟨gs,j⟩,ok,le_refl _, fun x => congrFun hj x⟩,?_⟩
    simp [count,nonCharge hy]
  | perm hp _ ih =>
    have pre : Available gs _ := fun f hf => hw f (hp.mem_iff.1 hf)
    obtain ⟨t,ht,hb⟩ := ih gs ok pre
    exact ⟨t,ht,by simpa [count,(hp.map charge).sum_eq] using hb⟩
  | @one s a r save _ ih =>
    obtain ⟨gs',ok',h',bound⟩ := oneStep gs ok a r save hw
    obtain ⟨t,ht,hb⟩ := ih gs' ok' h'
    exact ⟨t,ht,by omega⟩
  | @two s a b r c ka kb _ ih =>
    obtain ⟨gs',ok',h',bound⟩ := twoStep gs ok a b r c ka kb hw
    obtain ⟨t,ht,hb⟩ := ih gs' ok' h'
    change gs'.length + count (a::b::r) ≤ gs.length + 1 + count ((if c then meetF a b else joinF a b)::_) at bound
    exact ⟨t,ht,by omega⟩

/-- A shared prefix of size at most the supplied budget. -/
def Built {n : ℕ} (b : ℕ) (ws : List (BFn n)) : Prop :=
  ∃ gs : List Gate, Legal gs ∧ gs.length ≤ b ∧ Available gs ws

theorem rawHave {n : ℕ} (gs : List Gate) (i : Fin n) : Have gs (fun x => x i) := by
  intro _
  exact ⟨i.val,by omega,val_input gs n i⟩

theorem constantHave {n : ℕ} (gs : List Gate) {f : BFn n} (h : Constant f) : Have gs f :=
  fun hn => False.elim (hn h)

theorem includeFree {n : ℕ} {b : ℕ} {ws : List (BFn n)} {f : BFn n}
    (h : Built b ws) (hf : Constant f ∨ (∃ i : Fin n, f = fun x => x i) ∨ f ∈ ws) :
    Built b (f::ws) := by
  obtain ⟨gs,legal,hl,hs⟩ := h
  refine ⟨gs,legal,hl,inHead ?_ hs⟩
  rcases hf with hc | ⟨i,rfl⟩ | hin
  · exact constantHave gs hc
  · exact rawHave gs i
  · exact hs _ hin

theorem buildEmpty (n : ℕ) : Built 0 ([] : List (BFn n)) :=
  ⟨[],by intro g hg; simp at hg,le_refl _,by intro g hg; simp at hg⟩

theorem buildUnary {n : ℕ} {budget : ℕ} {ws : List (BFn n)} {a : BFn n}
    (h : Built budget ws) (ha : a ∈ ws) : Built (budget+1) (invF a :: ws) := by
  classical
  obtain ⟨gs,ok,hl,hw⟩ := h
  by_cases hc : Constant a
  · have hc' : Constant (invF a) := by obtain ⟨v,rfl⟩ := hc; exact ⟨_,rfl⟩
    exact ⟨gs,ok,by omega,inHead (constantHave gs hc') hw⟩
  · obtain ⟨j,hj,hv⟩ := hw a ha hc
    let g : Gate := ⟨.not,[j]⟩
    obtain ⟨ok',hn⟩ := emit gs g ok (by simp [g]) (by simpa [g] using hj) (invF a)
      (by intro x; simp [g,GateOp.eval,hv])
    exact ⟨gs++[g],ok',by simp; omega,inHead hn (monoAvail gs g ws hw)⟩

theorem buildBinary {n : ℕ} {budget : ℕ} {ws : List (BFn n)} {a b : BFn n}
    (h : Built budget ws) (ha : a ∈ ws) (hb : b ∈ ws) (c : Bool) :
    Built (budget+1) (comb c a b :: ws) := by
  classical
  obtain ⟨gs,ok,hl,hw⟩ := h
  by_cases hc : Constant a ∨ Constant b
  · exact ⟨gs,ok,by omega,inHead (mergeConst gs c hc (hw a ha) (hw b hb)) hw⟩
  · push Not at hc
    obtain ⟨j,hj,hv⟩ := hw a ha hc.1
    obtain ⟨k,hk,hkval⟩ := hw b hb hc.2
    let g : Gate := ⟨if c then .and else .or,[j,k]⟩
    obtain ⟨ok',hn⟩ := emit gs g ok (by cases c <;> simp [g])
      (by simpa [g] using And.intro hj hk) (comb c a b) (by intro x; cases c <;> simp [g,comb,GateOp.eval,hv,hkval])
    exact ⟨gs++[g],ok',by simp; omega,inHead hn (monoAvail gs g ws hw)⟩

theorem builtSubset {n : ℕ} {budget : ℕ} {xs ys : List (BFn n)}
    (h : Built budget xs) (hys : ∀ f ∈ ys, f ∈ xs) : Built budget ys := by
  obtain ⟨gs,ok,hl,hw⟩ := h
  exact ⟨gs,ok,hl,fun f hf => hw f (hys f hf)⟩

/-- Restrict any live semantic Run by precomposition, including input identifications
and arbitrary simultaneous pins. -/
theorem runPruneMap {m n : ℕ} (σ : (Fin n → Bool) → (Fin m → Bool)) {y : BFn m} {s b : ℕ}
    {ws : List (BFn m)} (hr : Run invF meetF joinF y s ws) (hy : ¬ Constant (y ∘ σ))
    (hb : Built b (ws.map (fun f => f ∘ σ))) :
    ∃ t, HasCircuitSize n (y ∘ σ) t ∧ t + count (ws.map (fun f => f ∘ σ)) ≤ b + s := by
  obtain ⟨gs,ok,hlen,hw⟩ := hb
  have pr := Run.map (fun (f : BFn m) => f ∘ σ) (inv' := invF) (meet' := meetF) (join' := joinF)
    (fun _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl) hr
  obtain ⟨t,ht,hs⟩ := runPrune pr hy gs ok hw
  exact ⟨t,ht,hs.trans (Nat.add_le_add_right hlen s)⟩

end Petersen1676.Prune
