import PinRules

namespace Petersen1676.Memo

open PEqualNP.Outside.L_meta_274_aux Petersen1676.Search Petersen1676.PinRules

/-- Enumerate precisely the positional moves tested by the upstream Boolean
successor function. The newly emitted word stays first until the budget update. -/
def children (mask slack : Nat) (ws : List Nat) : List (List Nat) :=
  ws.flatMap fun a =>
    let ra := ws.erase a
    let w := a ^^^ mask
    (if slack ≥ 1 then [w::ra] ++ (if slack ≥ 2 then [w::a::ra] else []) else []) ++
    ra.flatMap fun b =>
      if a ≤ b then
        let r := ra.erase b
        [false,true].flatMap fun c =>
          let v := if c then a &&& b else a ||| b
          [v::r] ++ (if slack ≥ 1 then [v::a::r,v::b::r] else []) ++
            (if slack ≥ 2 then [v::a::b::r] else [])
      else []

theorem children_any (mask slack : Nat) (ws : List Nat) (f : List Nat → Bool) :
    (children mask slack ws).any f = next mask slack ws f := by
  unfold children next
  simp only [List.any_flatMap, List.any_append]
  apply List.any_congr rfl
  intro a
  apply congrArg₂ Bool.or
  · by_cases h1 : slack ≥ 1 <;> by_cases h2 : slack ≥ 2 <;> simp [h1,h2]
  · apply List.any_congr rfl
    intro b
    by_cases ab : a ≤ b <;> by_cases h1 : slack ≥ 1 <;> by_cases h2 : slack ≥ 2 <;>
      simp [ab,h1,h2,Bool.or_assoc]

theorem child_run {mask goal s : Nat} {ws : List Nat} (h : NatRun mask goal (s+1) ws) :
    ∃ ys ∈ children mask (s+2-ws.length) ws, EdgeStep mask ws ys ∧ NatRun mask goal s ys := by
  classical
  let valid (ys) := decide (EdgeStep mask ws ys ∧ NatRun mask goal s ys)
  have ht := stepComplete h s rfl ws (List.Perm.refl _) _ (fun ys he hr => decide_eq_true (And.intro he hr))
  change next mask (s+2-ws.length) ws valid = true at ht
  rw [← children_any] at ht
  obtain ⟨ys,hm,hy⟩ := List.any_eq_true.1 ht
  exact ⟨ys,hm,of_decide_eq_true hy⟩

theorem child_edge (m slack : Nat) (ws : List Nat) :
    ∀ ys ∈ children m slack ws, EdgeStep m ws ys := by
  intro ys hy
  obtain ⟨a,ha,h⟩ := List.mem_flatMap.1 hy
  rcases List.mem_append.1 h with hu | hb
  · have he : ∀ t ∈ ws.erase a, t ∈ ws := fun _ ht => List.mem_of_mem_erase ht
    split at hu
    · rcases List.mem_append.1 hu with h | h
      · simp only [List.mem_singleton] at h
        subst ys
        exact ⟨.unary ha,he⟩
      · split at h
        · simp only [List.mem_singleton] at h
          subst ys
          exact ⟨.unary ha,fun w hw => (List.mem_cons.1 hw).elim (fun e => e ▸ ha) (he w)⟩
        · simp at h
    · simp at hu
  · obtain ⟨b,hb,h⟩ := List.mem_flatMap.1 hb
    have hb' : b ∈ ws := List.mem_of_mem_erase hb
    have hs : ∀ t ∈ (ws.erase a).erase b, t ∈ ws :=
      fun _ ht => List.mem_of_mem_erase (List.mem_of_mem_erase ht)
    split at h
    · obtain ⟨c,_,h⟩ := List.mem_flatMap.1 h
      have mk := Made.binary (m := m) ha hb' c
      rcases List.mem_append.1 h with h | h
      · rcases List.mem_append.1 h with h | h
        · simp only [List.mem_singleton] at h
          subst ys
          exact ⟨mk,hs⟩
        · split at h
          · simp only [List.mem_cons,List.not_mem_nil,or_false] at h
            rcases h with rfl | rfl
            · exact ⟨mk,fun w hw => (List.mem_cons.1 hw).elim (fun e => e ▸ ha) (hs w)⟩
            · exact ⟨mk,fun w hw => (List.mem_cons.1 hw).elim (fun e => e ▸ hb') (hs w)⟩
          · simp at h
      · split at h
        · simp only [List.mem_singleton] at h
          subst ys
          exact ⟨mk,fun w hw => (List.mem_cons.1 hw).elim (fun e => e ▸ ha)
            (fun hw' => (List.mem_cons.1 hw').elim (fun e => e ▸ hb') (hs w))⟩
        · simp at h
    · simp at h

end Petersen1676.Memo
