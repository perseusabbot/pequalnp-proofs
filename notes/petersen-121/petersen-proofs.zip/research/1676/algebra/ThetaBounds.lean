import DegreePairs
import PEqualNP.Outside.L_meta_517

namespace Petersen1676

open PEqualNP.MetaComplexity

theorem thetaPairLower (i : Fin 9) (s : ℕ)
    (realizes : HasCircuitSize 7 (pinnedPair (deletedPair i).1 (deletedPair i).2) s) : 11 ≤ s :=
  pairLowerOfBase PEqualNP.Outside.L_meta_517 i s realizes

#print axioms Petersen1676.thetaPairLower

end Petersen1676
