import SizeControl
import ConditionalBound
import PEqualNP.Outside.L_meta_1007

namespace Petersen1676

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

theorem degreeTwoLower (v : Fin 9) (hv : v = 4 ∨ v = 6 ∨ v = 7)
    (s : ℕ) (hc : HasCircuitSize 8 (pinned v) s) : 13 ≤ s :=
  pinned_lower PEqualNP.Outside.L_meta_1007 v hv s hc

theorem firstOrLower (C : Circuit) (ok : FanInTwo C)
    (first : ∀ y : Fin 9 → Bool, (C.wires (List.ofFn y)).getD 9 false = (y 0 || y 4))
    (he : circuitFun 9 C = edge9) : 15 ≤ C.size :=
  firstOrLowerOfBase PEqualNP.Outside.L_meta_1007 C ok first he

open PEqualNP.MetaComplexity.Helpers

theorem nonOrSecondReaderLower (C : Circuit) (ok : FanInTwo C)
    (first : ∀ y : Fin 9 → Bool, (C.wires (List.ofFn y)).getD 9 false = (y 0 || y 4))
    (he : circuitFun 9 C = edge9)
    (q : ℕ) (g : Gate) (hq : (C.gates.map normGate)[q]? = some g)
    (hq0 : q ≠ 0) (hr : 4 ∈ g.inputs) (hop : g.op ≠ GateOp.or) : 16 ≤ C.size :=
  firstOrNonOrReaderOfBase PEqualNP.Outside.L_meta_1007 C ok first he q g hq hq0 hr hop

theorem degreeTwoReaderLower (C : Circuit) (ok : FanInTwo C) (he : circuitFun 9 C = edge9)
    (v : Fin 9) (hv : v = 4 ∨ v = 6 ∨ v = 7) (S : Finset ℕ)
    (reads : ∀ q ∈ S, ∃ g, (C.gates.map normGate)[q]? = some g ∧ v.val ∈ g.inputs) :
    13 + S.card ≤ C.size :=
  readerBoundOfBase PEqualNP.Outside.L_meta_1007 C ok he v hv S reads

#print axioms Petersen1676.nonOrSecondReaderLower
#print axioms Petersen1676.degreeTwoReaderLower
#print axioms Petersen1676.firstOrLower
end Petersen1676
