import DegreeTwo
import SecondReader

namespace Petersen1676

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.MetaComplexity.Helpers
open Checkpoint118.Eliminate

theorem firstOrNonOrReaderOfBase (base : ¬ HasCircuitSize 8 edge8 12)
    (C : Circuit) (ok : FanInTwo C)
    (first : ∀ y : Fin 9 → Bool, (C.wires (List.ofFn y)).getD 9 false = (y 0 || y 4))
    (he : circuitFun 9 C = edge9)
    (q : ℕ) (g : Gate) (hq : (C.gates.map normGate)[q]? = some g)
    (hq0 : q ≠ 0) (hr : 4 ∈ g.inputs) (hop : g.op ≠ GateOp.or) : 16 ≤ C.size := by
  obtain ⟨s, hc, hs⟩ := otherReaderSavings edge9 C ok first he (by decide +kernel)
    ⟨fun _ => false, fun _ => true, by decide +kernel⟩ q g hq hq0 hr hop
  have h := pinned_lower base 4 (Or.inl rfl) s hc
  omega

/-- Each raw reader of a degree-two vertex costs a gate over its 13-gate cofactor. -/
theorem readerBoundOfBase (base : ¬ HasCircuitSize 8 edge8 12)
    (C : Circuit) (ok : FanInTwo C) (he : circuitFun 9 C = edge9)
    (v : Fin 9) (hv : v = 4 ∨ v = 6 ∨ v = 7) (S : Finset ℕ)
    (reads : ∀ q ∈ S, ∃ g, (C.gates.map normGate)[q]? = some g ∧ v.val ∈ g.inputs) :
    13 + S.card ≤ C.size := by
  let gs := C.gates.map normGate
  have good : ∀ g ∈ gs, NOk g := by
    intro g hg
    obtain ⟨k, hk, rfl⟩ := List.mem_map.1 hg
    exact normGate_nok k (ok k hk)
  have computes (x : Fin 9 → Bool) : (wiresFrom gs (List.ofFn x)).getD C.output false = edge9 x := by
    rw [show wiresFrom gs (List.ofFn x) = C.wires (List.ofFn x) from wiresFrom_norm _ _, ← he]
    rfl
  have nonconstant : ∃ y z : Fin 8 → Bool, pinned v y ≠ pinned v z := by
    refine ⟨fun _ => false, fun _ => true, ?_⟩
    rcases hv with rfl | rfl | rfl <;> decide +kernel
  obtain ⟨s, hc, hs⟩ := savings 8 v false gs good S reads C.output edge9 computes nonconstant
  have lower := pinned_lower base v hv s hc
  have count : gs.length = C.size := by simp [gs, Circuit.size]
  omega

end Petersen1676
