import DegreeTwo

namespace Petersen1676

open PEqualNP.MetaComplexity

def theta (x : Fin 7 → Bool) : Bool :=
  (x 0 && x 2) || (x 2 && x 1) || (x 0 && x 3) || (x 3 && x 4) ||
  (x 4 && x 1) || (x 0 && x 5) || (x 5 && x 6) || (x 6 && x 1)

/-- Original vertex deleted first, followed by the second vertex's index
in the eight surviving positions. For example (0,3) deletes original 0 and 4. -/
def deletedPair : Fin 9 → Fin 9 × Fin 8 := ![(0, 3), (1, 5), (2, 6), (3, 3), (4, 5), (4, 6), (5, 6), (6, 6), (6, 7)]

def pairRenaming : Fin 9 → Fin 7 → Fin 7 := ![
  ![3, 0, 2, 6, 4, 5, 1],
  ![3, 6, 1, 4, 0, 5, 2],
  ![0, 3, 6, 5, 2, 4, 1],
  ![2, 0, 3, 1, 5, 4, 6],
  ![3, 4, 1, 6, 0, 2, 5],
  ![3, 0, 5, 6, 4, 2, 1],
  ![3, 0, 2, 1, 4, 5, 6],
  ![0, 3, 4, 1, 2, 5, 6],
  ![0, 2, 1, 4, 3, 5, 6]]

def pinnedPair (a : Fin 9) (b : Fin 8) (y : Fin 7 → Bool) :=
  pinned a (b.insertNth false y)

set_option maxRecDepth 4000 in
set_option maxHeartbeats 1000000 in
theorem pair_eq : ∀ i : Fin 9,
    (fun x => pinnedPair (deletedPair i).1 (deletedPair i).2 (x ∘ pairRenaming i)) = theta := by
  decide +kernel

theorem pairLowerOfBase (base : ∀ s : ℕ, HasCircuitSize 7 theta s → 11 ≤ s)
    (i : Fin 9) (s : ℕ)
    (realizes : HasCircuitSize 7 (pinnedPair (deletedPair i).1 (deletedPair i).2) s) : 11 ≤ s := by
  apply base s
  simpa only [pair_eq i] using Relabel.relabel_size (pairRenaming i) _ s realizes

end Petersen1676
