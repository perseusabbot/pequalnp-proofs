import DegreeTwo
import FirstOrElimination

namespace Petersen1676

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity Checkpoint118.Eliminate

theorem firstOrLowerOfBase (base : ¬ HasCircuitSize 8 edge8 12)
    (C : Circuit) (ok : FanInTwo C)
    (first : ∀ y : Fin 9 → Bool, (C.wires (List.ofFn y)).getD 9 false = (y 0 || y 4))
    (he : circuitFun 9 C = edge9) : 15 ≤ C.size := by
  obtain ⟨s, hc, hs⟩ := twoSaved edge9 C ok first he (by decide +kernel)
    (by decide +kernel) ⟨fun _ => false, fun _ => true, by decide +kernel⟩
  have h := pinned_lower base 4 (Or.inl rfl) s hc
  omega

end Petersen1676
