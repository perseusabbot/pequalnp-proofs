import DegreePairs
import RunPrune
import PEqualNP.Outside.L_meta_517

namespace Petersen1676.TruePins

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_274_aux Petersen1676.Prune

/-- Delete the middle of the length-two path of the theta graph. -/
def cycle (x : Fin 6 → Bool) : Bool :=
  (x 0 && x 2) || (x 2 && x 3) || (x 3 && x 1) ||
  (x 0 && x 4) || (x 4 && x 5) || (x 5 && x 1)

private def lift6 : Fin 6 → Fin 7 := ![0,1,3,4,5,6]
private def lifted (x : Fin 7 → Bool) := cycle (x ∘ lift6)
private def input (i : Fin 7) : BFn 7 := fun x => x i

private theorem outputBuilt {n s} {f : BFn n} (h : HasCircuitSize n f s) :
    Built s [f] := by
  obtain ⟨C,ok,len,ev⟩ := h
  refine ⟨C.gates,ok,len,?_⟩
  intro g hg
  obtain rfl := List.mem_singleton.mp hg
  intro hn
  refine ⟨C.output,?_,funext ev⟩
  by_contra! ho
  apply hn
  refine ⟨false,funext fun x => ?_⟩
  rw [← ev x]
  change (wiresFrom C.gates (List.ofFn x)).getD C.output false = false
  exact List.getD_eq_default _ _ (by simpa only [length_wiresFrom,List.length_ofFn] using ho)

private theorem withInput {s} {ws : List (BFn 7)} (h : Built s ws) (i : Fin 7) :
    Built s (input i :: ws) := includeFree h (Or.inr (Or.inl ⟨i,rfl⟩))

/-- Extending a cycle circuit with OR(0,1), its AND with 2, and a final OR
gives the seven-input theta graph. -/
theorem cycleLower (s : ℕ) (hc : HasCircuitSize 6 cycle s) : 8 ≤ s := by
  have h : Built s [lifted] := outputBuilt (Relabel.relabel_size lift6 cycle s hc)
  have inputs := withInput (withInput (withInput h 0) 1) 2
  have a := buildBinary (a := input 0) (b := input 1) inputs (by simp) (by simp) false
  have b := buildBinary (a := comb false (input 0) (input 1)) (b := input 2) a
    (by simp) (by simp) true
  have d := buildBinary (a := lifted) (b := comb true (comb false (input 0) (input 1)) (input 2))
    b (by simp) (by simp) false
  have eq : comb false lifted (comb true (comb false (input 0) (input 1)) (input 2)) = theta := by
    decide +kernel
  rw [eq] at d
  obtain ⟨gs,ok,len,avail⟩ := d
  have nonc : ¬ Constant theta := by
    rintro ⟨v,hv⟩
    have h0 := congrFun hv (fun _ => false)
    have h1 := congrFun hv (fun _ => true)
    change false = v at h0
    change true = v at h1
    simp_all
  obtain ⟨j,_,hj⟩ := avail theta (by simp) nonc
  have ht : HasCircuitSize 7 theta (s+3) := ⟨⟨gs,j⟩,ok,len,fun x => congrFun hj x⟩
  have := PEqualNP.Outside.L_meta_517 (s+3) ht
  omega

private def one (x : Fin 7 → Bool) : Bool := cycle (x ∘ Fin.castSucc) || x 6
private def two (x : Fin 8 → Bool) : Bool := one (x ∘ Fin.castSucc) || x 7

theorem twoLower (s : ℕ) (h : HasCircuitSize 8 two s) : 10 ≤ s := by
  by_contra! hs
  obtain ⟨C,ok,sz,eval⟩ := h
  have h9 : HasCircuitSize 8 two 9 := ⟨C,ok,by omega,eval⟩
  have h8 := Live514.gate_elim 7 two false 8
    ⟨fun _ => false,by decide +kernel⟩
    ⟨fun _ => false,fun _ => true,by decide +kernel⟩ h9
  have e8 : (fun x : Fin 7 → Bool => two (Fin.snoc x false)) = one := by
    decide +kernel
  rw [e8] at h8
  have h7 := Live514.gate_elim 6 one false 7
    ⟨fun _ => false,by decide +kernel⟩
    ⟨fun _ => false,fun _ => true,by decide +kernel⟩ h8
  have e7 : (fun x : Fin 6 → Bool => one (Fin.snoc x false)) = cycle := by
    decide +kernel
  rw [e7] at h7
  have := cycleLower 7 h7
  omega

def highPin (v : Fin 9) (x : Fin 8 → Bool) := edge9 (v.insertNth true x)
def vertex : Fin 3 → Fin 9 := ![4,6,7]
private def rename : Fin 3 → Fin 8 → Fin 8 := ![
  ![6,0,2,7,1,4,3,5],
  ![0,6,1,3,2,4,5,7],
  ![0,2,6,5,4,7,3,1]]

set_option maxRecDepth 4000 in
set_option maxHeartbeats 1000000 in
private theorem pinShape : ∀ i : Fin 3, (fun x => highPin (vertex i) (x ∘ rename i)) = two := by
  decide +kernel

theorem truePinLower (v : Fin 9) (hv : v = 4 ∨ v = 6 ∨ v = 7) (s : ℕ)
    (h : HasCircuitSize 8 (highPin v) s) : 10 ≤ s := by
  have hi : ∃ i : Fin 3, vertex i = v := by
    rcases hv with rfl | rfl | rfl
    · exact ⟨0,rfl⟩
    · exact ⟨1,rfl⟩
    · exact ⟨2,rfl⟩
  obtain ⟨i,rfl⟩ := hi
  apply twoLower s
  simpa only [pinShape i] using Relabel.relabel_size (rename i) _ s h

#print axioms truePinLower

end Petersen1676.TruePins
