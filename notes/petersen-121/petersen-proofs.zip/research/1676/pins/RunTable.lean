import PinRules
import PairedData

namespace Petersen1676.RunTable
open PEqualNP.Outside.L_meta_274_aux Petersen1676.Table Petersen1676.Search Petersen1676.PinRules

def header : Nat := raw[0]?.getD 0 ||| raw[4]?.getD 0

def start (useHeader : Bool) : List Nat := if useHeader then raw ++ [header] else raw

def rules : List (Nat × Nat) :=
  [(16,13),(64,13),(128,13),(1,12),(2,12),(4,12),(8,12),(32,12),(256,12),
   (17,11),(66,11),(132,11),(24,11),(80,11),(144,11),(160,11),(192,11),(320,11)]

def initial (ws : List Nat) : List Item := rules.map fun r =>
  ⟨pinMask r.1, r.2, headerCost (pinMask r.1) raw ws header⟩

def cut (s : Nat) (ws : List Nat) (items : List Item) : Bool :=
  covers kk s ws && legal s ws items

def search (s : Nat) (ws : List Nat) (items : List Item) : Bool :=
  guided allMask goal cut (advance raw) s ws items

private theorem mask_eq : allMask = PEqualNP.Outside.L_meta_274_aux.mask kk := by
  unfold allMask PEqualNP.Outside.L_meta_274_aux.mask PEqualNP.Outside.L_meta_274_aux.lo
  rfl

private theorem goal_eq : Petersen1676.Table.goal = PEqualNP.Outside.L_meta_274_aux.goal kk := by
  unfold Petersen1676.Table.goal PEqualNP.Outside.L_meta_274_aux.goal PEqualNP.Outside.L_meta_274_aux.lo
  rfl

theorem sound {s ws items} (i : Invariant allMask goal raw ws items) (hr : NatRun allMask goal s ws) :
    search s ws items = true := by
  apply guided_of_run (Invariant allMask goal raw) _ _ i hr
  · intro a b d h hr
    have pairs : NatRun (PEqualNP.Outside.L_meta_274_aux.mask kk) (PEqualNP.Outside.L_meta_274_aux.goal kk) a b := by
      rw [← mask_eq, ← goal_eq]
      exact hr
    simp only [cut, Bool.and_eq_true]
    exact ⟨covers_ok (k := kk) pairs, legal_sound h hr⟩
  · intro a b d h e
    exact advance_sound h e

end Petersen1676.RunTable
