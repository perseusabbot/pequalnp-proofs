import RunTable
import MemoSearch

namespace Petersen1676.FastTrial
open PEqualNP.Outside.L_meta_274_aux Petersen1676.PinRules Petersen1676.Prune
open Petersen1676.Table Petersen1676.RunTable

structure Ready where
  orig : Item
  margin : Nat
  previous : List Nat

def prep (s : Nat) (raw ws : List Nat) (i : Item) : Ready :=
  let c := (ws.filter (constantOn i.pin)).length
  ⟨i, i.spent+s-i.lower-c, (raw++ws).map (· &&& i.pin)⟩

def isConst (m t : Nat) := t == 0 || t == m

def urgent (r : Ready) (v a b : Nat) (dropA dropB : Bool) : Bool := Id.run do
  if r.margin >= 2 then return true
  let p := r.orig.pin
  let z := v &&& p
  let saved := (dropA && isConst p (a &&& p)).toNat + (dropB && isConst p (b &&& p)).toNat
  if isConst p z then return r.margin + saved >= 2
  if r.margin + saved >= 1 then return true
  return !(r.previous.contains z)

def updated (r : Ready) (v : Nat) : Item :=
  let z := v &&& r.orig.pin
  { r.orig with spent := r.orig.spent + if isConst r.orig.pin z || r.previous.contains z then 0 else 1 }

def covpair (w : Nat) : Nat × Nat :=
  ⟨w ^^^ (w >>> kk), (w >>> kk) &&& (w ^^^ lo kk)⟩

def covered (flags : Nat) : Bool := flags &&& lo kk == lo kk

def choices (ws : List Nat) (s : Nat) (items : List Item) : List (List Nat × List Item) := Id.run do
  let mut out := []
  if !legal s ws items then return []
  let slack := s+1-ws.length
  let rr := items.map (prep s raw ws)
  let hot := rr.filter (fun r => r.margin < 2)
  for a in ws do
    let ra := ws.erase a
    for peer in none :: ra.map some do
      let unary := peer.isNone
      let b := peer.getD a
      if a > b || (unary && slack < 1) then continue
      let rest := if unary then ra else ra.erase b
      let (ea,ua) := covpair a
      let (eb,ub) := covpair b
      let other := rest.foldl (fun (p : Nat × Nat) w =>
        let z := covpair w
        (p.1 ||| z.1, p.2 ||| z.2)) (0,0)
      let values := if unary then [a ^^^ allMask] else [a &&& b, a ||| b]
      for v in values do
        let zv := covpair v
        let md := other.1 ||| zv.1
        let mu := other.2 ||| zv.2
        let remaining := s-1
        let data := rr.map (fun r => updated r v)
        for keepA in [false,true] do
          for keepB in (if unary then [false] else [false,true]) do
            let cost := unary.toNat + keepA.toNat + keepB.toNat
            if cost > slack then continue
            let cover := if cost == slack then mu ||| (if keepA then ua else 0) ||| (if keepB then ub else 0)
                         else md ||| (if keepA then ea else 0) ||| (if keepB then eb else 0)
            if !covered cover then continue
            if !hot.all (fun r => urgent r v a b (!keepA) (!unary && !keepB)) then continue
            let ys := v :: kept keepA a (kept keepB b rest)
            if ys.length > remaining+1 then continue
            out := (ys,data)::out
  return out

end Petersen1676.FastTrial
