import Mathlib

namespace Petersen1676.Margin

/-- Test one projected gate after allowing all unused slack from the parent. -/
def fits (margin removed : Nat) (constant seen : Bool) : Bool :=
  if 2 ≤ margin then true
  else if constant then decide (2 ≤ margin + removed)
  else if 1 ≤ margin + removed then true else !seen

/-- Count only the constant inputs actually discarded in the transition.
The restricted new wire is free if it is a constant or a previously available value. -/
theorem fits_iff {s lower spent oldCount newCount removed : Nat}
    {constant seen : Bool} (budget : lower + oldCount ≤ spent + (s+1))
    (countStep : newCount + removed = oldCount + constant.toNat) :
    fits (spent + (s+1) - (lower+oldCount)) removed constant seen = true ↔
      lower + newCount ≤ spent + (if constant || seen then 0 else 1) + s := by
  cases constant <;> cases seen <;>
    simp [fits] at * <;> omega

end Petersen1676.Margin
