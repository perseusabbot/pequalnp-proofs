import PEqualNP.Outside.L_meta_274

/- The transition-completeness proof is adapted from the project's L_meta_274,
at revision 62000b704f685bd8f624de03e525174fff152042 under Apache-2.0. -/
namespace Petersen1676.Search
open PEqualNP.Outside.L_meta_274_aux

theorem genericUnary {m y a rest} {save : Bool} {s ws} (p : (a :: rest).Perm ws)
    (h : NatRun m y s ((a ^^^ m) :: kept save a rest))
    (f : List Nat → Bool)
    (hf : ∀ ys, NatRun m y s ys → f ys = true) :
    next m (s + 2 - ws.length) ws f = true := by
  have ha := p.mem_iff.1 List.mem_cons_self
  have pr : rest.Perm (ws.erase a) := (p.trans (List.perm_cons_erase ha)).cons_inv
  have hh := run_len h
  have hl := p.length_eq
  simp only [List.length_cons] at hl hh
  have hsl : 1 ≤ s + 2 - ws.length := by cases save <;> simp [kept] at hh <;> omega
  apply List.any_eq_true.2 ⟨a, ha, ?_⟩
  rw [Bool.or_eq_true]; left
  rw [Bool.and_eq_true]; refine ⟨decide_eq_true hsl, ?_⟩
  have ht := hf _ (Run.perm ((keep_perm pr save a).cons _) h)
  cases save with
  | false => simp [kept] at ht; simp [ht]
  | true =>
    simp [kept] at ht hh
    have hsl2 : 2 ≤ s + 2 - ws.length := by omega
    simp [ht, hsl2]

theorem genericSorted {m y a b rest} {conj ka kb : Bool} {s ws} (hab : a ≤ b)
    (p : (a :: b :: rest).Perm ws)
    (h : NatRun m y s
      ((if conj then a &&& b else a ||| b) :: kept ka a (kept kb b rest)))
    (f : List Nat → Bool)
    (hf : ∀ ys, NatRun m y s ys → f ys = true) :
    next m (s + 2 - ws.length) ws f = true := by
  have ha := p.mem_iff.1 List.mem_cons_self
  have pp := (p.trans (List.perm_cons_erase ha)).cons_inv
  have hb := pp.mem_iff.1 List.mem_cons_self
  have pr := (pp.trans (List.perm_cons_erase hb)).cons_inv
  have hh := run_len h
  have hl := p.length_eq
  simp only [List.length_cons] at hl hh
  apply List.any_eq_true.2 ⟨a, ha, ?_⟩
  rw [Bool.or_eq_true]; right
  apply List.any_eq_true.2 ⟨b, hb, ?_⟩
  rw [Bool.and_eq_true]; refine ⟨decide_eq_true hab, ?_⟩
  apply List.any_eq_true.2 ⟨conj, by cases conj <;> simp, ?_⟩
  have ht := hf _ (Run.perm ((keep_perm (keep_perm pr kb b) ka a).cons _) h)
  cases ka <;> cases kb <;> simp [kept] at ht hh <;>
    simp only [ht, Bool.true_or, Bool.or_true, Bool.and_true] <;>
    first | (simp [show 2 ≤ s + 2 - ws.length by omega]) | (simp [show 1 ≤ s + 2 - ws.length by omega])

theorem genericBinary {m y a b rest} {conj ka kb : Bool} {s ws}
    (p : (a :: b :: rest).Perm ws)
    (h : NatRun m y s
      ((if conj then a &&& b else a ||| b) :: kept ka a (kept kb b rest)))
    (f : List Nat → Bool)
    (hf : ∀ ys, NatRun m y s ys → f ys = true) :
    next m (s + 2 - ws.length) ws f = true := by
  rcases le_total a b with hab | hba
  · exact genericSorted hab p h f hf
  · apply genericSorted (conj := conj) (ka := kb) (kb := ka) hba ((List.Perm.swap _ _ _).trans p) _ f hf
    have he : (if conj then a &&& b else a ||| b) = (if conj then b &&& a else b ||| a) := by
      cases conj <;> simp [Nat.and_comm, Nat.or_comm]
    rw [he] at h
    apply Run.perm (List.Perm.cons _ ?_) h
    cases ka <;> cases kb <;> simp [kept]
    exact List.Perm.swap _ _ _

theorem genericComplete {m y t ws} (h : NatRun m y t ws) :
    ∀ s, t = s + 1 → ∀ zs, ws.Perm zs → ∀ f : List Nat → Bool,
      (∀ ys, NatRun m y s ys → f ys = true) →
      next m (s + 2 - zs.length) zs f = true := by
  induction h using Run.fold with
  | done => simp
  | perm p h ih => intro s he zs q; exact ih s he zs (p.trans q)
  | one save h ih => intro s he zs p f hf; cases he; exact genericUnary p h f hf
  | two conj ka kb h ih => intro s he zs p f hf; cases he; exact genericBinary p h f hf


/-- A sound Boolean cut can use additional input restrictions at each state. -/
def possible (m y : Nat) (cut : Nat → List Nat → Bool) : Nat → List Nat → Bool
  | 0, ws => ws == [y]
  | s+1, ws => cut (s+1) ws && next m (s+2-ws.length) ws (possible m y cut s)

theorem possible_of_run {m y : Nat} {cut : Nat → List Nat → Bool}
    (preserves : ∀ {s ws}, NatRun m y s ws → cut s ws = true) :
    ∀ {s ws}, NatRun m y s ws → possible m y cut s ws = true := by
  intro s
  induction s with
  | zero =>
    intro ws h
    have e := zero_done h rfl
    simp [possible, e]
  | succ s ih =>
    intro ws h
    simp only [possible, Bool.and_eq_true]
    exact ⟨preserves h, genericComplete h s rfl ws (.refl _) _ fun _ hr => ih hr⟩

/-- Select a leaf of an explicit partition only after checking all of its successors. -/
theorem refute_step {m y s : Nat} {ws : List Nat} (accept : List Nat → Bool)
    (hc : next m (s+2-ws.length) ws accept = false)
    (closed : ∀ v, NatRun m y s v → accept v = true) : ¬ NatRun m y (s+1) ws := by
  intro h
  have act := genericComplete h s rfl ws (.refl _) accept closed
  rw [act] at hc
  contradiction

end Petersen1676.Search
