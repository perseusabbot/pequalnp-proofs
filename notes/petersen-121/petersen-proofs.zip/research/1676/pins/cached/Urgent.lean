import FastTrial
import Margin

namespace Petersen1676.Cached
open PEqualNP.Outside.L_meta_274_aux
open Petersen1676.Prune Petersen1676.PinRules Petersen1676.FastTrial

def countConst (p : Nat) (ws : List Nat) := (ws.filter (constantOn p)).length

theorem const_correct (p w : Nat) : isConst p (w &&& p) = constantOn p w := by
  apply Bool.eq_iff_iff.mpr
  simp [isConst,constantOn]

private theorem previous_correct (p w : Nat) (xs : List Nat) :
    ((xs.map (· &&& p)).contains (w &&& p)) =
      xs.any (fun v => decide (w &&& p = v &&& p)) := by
  apply Bool.eq_iff_iff.mpr
  simp only [List.contains_iff_mem, List.mem_map, List.any_eq_true, decide_eq_true_eq]
  constructor <;> rintro ⟨a,ha,hh⟩ <;> exact ⟨a,ha,hh.symm⟩

theorem cached_free (p v : Nat) (raw ws : List Nat) :
    (isConst p (v &&& p) || ((raw++ws).map (· &&& p)).contains (v &&& p)) = freeOn p raw ws v := by
  unfold freeOn
  rw [const_correct, previous_correct]

theorem update_correct (s : Nat) (raw ws : List Nat) (i : Item) (v : Nat) :
    updated (prep s raw ws i) v = update raw ws v i := by
  unfold updated prep update
  dsimp only
  rw [cached_free]

theorem update_all (s : Nat) (raw ws : List Nat) (items : List Item) (v : Nat) (tail : List Nat) :
    (items.map (prep s raw ws)).map (fun r => updated r v) = advance raw ws (v::tail) items := by
  simp [List.map_map, advance, Function.comp_def, update_correct]

theorem count_cons (p x : Nat) (xs : List Nat) :
    countConst p (x::xs) = countConst p xs + (constantOn p x).toNat := by
  cases h : constantOn p x <;> simp [countConst,h]

theorem count_perm (p : Nat) {xs ys : List Nat} (h : xs.Perm ys) :
    countConst p xs = countConst p ys := (h.filter _).length_eq

def removed (p a b : Nat) (keepA hasB keepB : Bool) : Nat :=
  ((!keepA) && isConst p (a &&& p)).toNat +
    ((hasB && !keepB) && isConst p (b &&& p)).toNat

theorem count_step {ws rest : List Nat} {a b : Nat} {hasB : Bool}
    (shape : ws.Perm (a :: kept hasB b rest)) (p v : Nat) (keepA keepB : Bool) :
    countConst p (v :: kept keepA a (kept (hasB && keepB) b rest)) +
      removed p a b keepA hasB keepB = countConst p ws + (constantOn p v).toNat := by
  rw [count_perm p shape]
  cases hasB <;> cases keepA <;> cases keepB <;> simp [removed,kept,count_cons,const_correct] <;> omega

theorem urgent_fits (r : Ready) (v a b : Nat) (da db : Bool) :
    urgent r v a b da db =
      Margin.fits r.margin ((da && isConst r.orig.pin (a &&& r.orig.pin)).toNat +
        (db && isConst r.orig.pin (b &&& r.orig.pin)).toNat)
        (isConst r.orig.pin (v &&& r.orig.pin)) (r.previous.contains (v &&& r.orig.pin)) := by
  rfl

theorem urgent_iff {ws rest : List Nat} {a b : Nat} {hasB : Bool}
    (shape : ws.Perm (a :: kept hasB b rest)) (s : Nat) (raw : List Nat) (i : Item)
    (v : Nat) (keepA keepB : Bool)
    (budget : i.lower + countConst i.pin ws ≤ i.spent + (s+1)) :
    urgent (prep (s+1) raw ws i) v a b (!keepA) (hasB && !keepB) = true ↔
      legal s (v :: kept keepA a (kept (hasB && keepB) b rest)) [update raw ws v i] = true := by
  have e := @Margin.fits_iff s i.lower i.spent (countConst i.pin ws)
    (countConst i.pin (v :: kept keepA a (kept (hasB && keepB) b rest)))
    (removed i.pin a b keepA hasB keepB)
    (constantOn i.pin v) (((raw++ws).map (· &&& i.pin)).contains (v &&& i.pin))
    budget (count_step shape i.pin v keepA keepB)
  have hfree := cached_free i.pin v raw ws
  rw [const_correct] at hfree
  rw [hfree] at e
  simpa only [urgent_fits, prep, legal, List.all_cons, List.all_nil, Bool.and_true,
    decide_eq_true_eq, update, removed, countConst, const_correct, Nat.sub_sub] using e

def hot (s : Nat) (raw ws : List Nat) (items : List Item) : List Ready :=
  (items.map (prep s raw ws)).filter (fun r => r.margin < 2)

theorem urgent_all {ws rest : List Nat} {a b : Nat} {hasB : Bool}
    (shape : ws.Perm (a :: kept hasB b rest)) (s : Nat) (raw : List Nat) (items : List Item)
    (v : Nat) (keepA keepB : Bool) (valid : legal (s+1) ws items = true) :
    (hot (s+1) raw ws items).all (fun r => urgent r v a b (!keepA) (hasB && !keepB)) =
      legal s (v :: kept keepA a (kept (hasB && keepB) b rest))
        (advance raw ws (v :: kept keepA a (kept (hasB && keepB) b rest)) items) := by
  let ys := v :: kept keepA a (kept (hasB && keepB) b rest)
  have budget (i : Item) (hi : i ∈ items) : i.lower + countConst i.pin ws ≤ i.spent+(s+1) :=
    of_decide_eq_true (List.all_eq_true.mp valid i hi)
  have cover (i : Item) (hi : i ∈ items) :=
      urgent_iff shape s raw i v keepA keepB (budget i hi)
  apply Bool.eq_iff_iff.mpr
  constructor
  · intro h
    apply List.all_eq_true.mpr
    intro q hq
    obtain ⟨i,hi,rfl⟩ := List.mem_map.mp hq
    have hu : urgent (prep (s+1) raw ws i) v a b (!keepA) (hasB && !keepB) = true := by
      by_cases low : (prep (s+1) raw ws i).margin < 2
      · exact List.all_eq_true.mp h _ (List.mem_filter.mpr
          ⟨List.mem_map.mpr ⟨i,hi,rfl⟩,decide_eq_true low⟩)
      · simp [urgent_fits, Margin.fits, Nat.le_of_not_gt low]
    simpa [legal] using (cover i hi).mp hu
  · intro h
    apply List.all_eq_true.mpr
    intro r hr
    obtain ⟨i,hi,rfl⟩ := List.mem_map.mp (List.mem_filter.mp hr).1
    apply (cover i hi).mpr
    have hh := List.all_eq_true.mp h (update raw ws v i)
      (List.mem_map.mpr ⟨i,hi,rfl⟩)
    simpa [legal] using hh

end Petersen1676.Cached
