import Urgent
import Annotated

namespace Petersen1676.Cached
open PEqualNP.Outside.L_meta_274_aux Petersen1676.Prune Petersen1676.PinRules
open Petersen1676.FastTrial Petersen1676.Memo Petersen1676.Search

-- Called on a parent known to pass the budget. Precompute its pin projections,
-- margins and active pin list once; only accepted moves construct new budgets.
def genCached (m : Nat) (raw : List Nat) (cover : Nat → List Nat → Bool)
    (s : Nat) (ws : List Nat) (items : List Item) : List Node :=
  let rr := items.map (prep (s+1) raw ws)
  let active := rr.filter (fun r => r.margin < 2)
  (annotated m (s+2-ws.length) ws).filterMap fun q =>
    let ys := q.output
    if cover s ys && active.all (fun r => urgent r q.v q.a q.b (!q.keepA) (q.hasB && !q.keepB))
    then some (canonical ys, rr.map (fun r => updated r q.v)) else none

theorem genCached_eq (m : Nat) (raw : List Nat) (cover : Nat → List Nat → Bool)
    (s : Nat) (ws : List Nat) (items : List Item) (valid : legal (s+1) ws items = true) :
    genCached m raw cover s ws items =
      Memo.gen m raw (fun t ys data => cover t ys && legal t ys data) s ws items := by
  unfold genCached Memo.gen
  rw [← annotated_outputs, List.filterMap_map]
  apply List.filterMap_congr
  intro q hq
  have hshape := annotated_origin m (s+2-ws.length) ws q hq
  have hcheck := urgent_all hshape s raw items q.v q.keepA q.keepB valid
  have hdata := update_all (s+1) raw ws items q.v
      (kept q.keepA q.a (kept (q.hasB && q.keepB) q.b q.rest))
  change (if cover s q.output && (hot (s+1) raw ws items).all _ then
      some (canonical q.output, _) else none) = _
  rw [hcheck,hdata]
  rfl

-- The fallback makes this function extensionally equal to gen even for
-- arbitrary caller-supplied states that already fail the parent budget.
def genExact (m : Nat) (raw : List Nat) (cover : Nat → List Nat → Bool)
    (s : Nat) (ws : List Nat) (items : List Item) : List Node :=
  if legal (s+1) ws items then genCached m raw cover s ws items
  else Memo.gen m raw (fun t ys data => cover t ys && legal t ys data) s ws items

theorem genExact_eq (m : Nat) (raw : List Nat) (cover : Nat → List Nat → Bool)
    (s : Nat) (ws : List Nat) (items : List Item) :
    genExact m raw cover s ws items =
      Memo.gen m raw (fun t ys data => cover t ys && legal t ys data) s ws items := by
  unfold genExact
  split
  · exact genCached_eq _ _ _ _ _ _ (by assumption)
  · rfl

theorem actual_gen (s : Nat) (ws : List Nat) (items : List Item) :
    genExact Table.allMask Table.raw (covers Table.kk) s ws items =
      Memo.gen Table.allMask Table.raw RunTable.cut s ws items :=
  genExact_eq _ _ _ _ _ _

#print axioms genCached_eq
#print axioms actual_gen

end Petersen1676.Cached
