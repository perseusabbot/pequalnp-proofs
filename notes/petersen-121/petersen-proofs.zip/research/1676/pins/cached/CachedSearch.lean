import CachedGen

namespace Petersen1676.Cached
open PEqualNP.Outside.L_meta_274_aux Petersen1676.Search Petersen1676.PinRules
open Petersen1676.Memo

def search : Nat → Layer → Bool
  | 0, tab => tab.contains [Table.goal]
  | s+1, tab => search s (nextLayer (genExact Table.allMask Table.raw (covers Table.kk) s) tab)

theorem search_eq (s : Nat) (tab : Layer) :
    search s tab = Memo.search Table.allMask Table.goal Table.raw RunTable.cut s tab := by
  induction s generalizing tab with
  | zero => rfl
  | succ s ih =>
    have hg : genExact Table.allMask Table.raw (covers Table.kk) s =
        Memo.gen Table.allMask Table.raw RunTable.cut s := by
      funext ws items
      exact actual_gen s ws items
    rw [search, Memo.search, hg, ih]

private theorem mask_eq : Table.allMask = mask Table.kk := by
  unfold Table.allMask mask lo
  rfl

private theorem goal_eq : Table.goal = PEqualNP.Outside.L_meta_274_aux.goal Table.kk := by
  unfold Table.goal PEqualNP.Outside.L_meta_274_aux.goal lo
  rfl

theorem true_of_run {s ws items} (good : Invariant Table.allMask Table.goal Table.raw ws items)
    (existsRun : NatRun Table.allMask Table.goal s ws) :
    search s (root ws items) = true := by
  rw [search_eq]
  apply Memo.root_of_run _ good existsRun
  intro n ys data hy hr
  have proj : NatRun (mask Table.kk) (PEqualNP.Outside.L_meta_274_aux.goal Table.kk) n ys := by
    simpa only [← mask_eq, ← goal_eq] using hr
  simp only [RunTable.cut, Bool.and_eq_true]
  exact ⟨covers_ok (k := Table.kk) proj, legal_sound hy hr⟩

theorem refute {s ws items} (good : Invariant Table.allMask Table.goal Table.raw ws items)
    (checked : search s (root ws items) = false) :
    ¬ NatRun Table.allMask Table.goal s ws := by
  intro h
  simpa [checked] using true_of_run good h

def replay (useHeader : Bool) (s : Nat) : Bool :=
  let ws := RunTable.start useHeader
  search s (root ws (RunTable.initial ws))

#print axioms search_eq
#print axioms refute
end Petersen1676.Cached
