import MemoFrontier

namespace Petersen1676.Cached
open PEqualNP.Outside.L_meta_274_aux Petersen1676.Memo

structure Choice where
  a : Nat
  b : Nat
  v : Nat
  hasB : Bool
  keepA : Bool
  keepB : Bool
  rest : List Nat

def Choice.output (q : Choice) := q.v :: kept q.keepA q.a (kept (q.hasB && q.keepB) q.b q.rest)
def Choice.origin (q : Choice) := q.a :: kept q.hasB q.b q.rest

def singles (s a v : Nat) (r : List Nat) : List Choice :=
  if s ≥ 1 then [⟨a,a,v,false,false,false,r⟩] ++
    (if s ≥ 2 then [⟨a,a,v,false,true,false,r⟩] else []) else []

def doubles (s a b v : Nat) (r : List Nat) : List Choice :=
  [⟨a,b,v,true,false,false,r⟩] ++
    (if s ≥ 1 then [⟨a,b,v,true,true,false,r⟩,⟨a,b,v,true,false,true,r⟩] else []) ++
    (if s ≥ 2 then [⟨a,b,v,true,true,true,r⟩] else [])

def annotated (mask slack : Nat) (ws : List Nat) : List Choice :=
  ws.flatMap fun a =>
    let ra := ws.erase a
    singles slack a (a ^^^ mask) ra ++ ra.flatMap fun b =>
      if a ≤ b then
        let r := ra.erase b
        [false,true].flatMap fun c => doubles slack a b (if c then a &&& b else a ||| b) r
      else []

private theorem singles_out (s a v : Nat) (r : List Nat) :
    (singles s a v r).map Choice.output =
      (if s ≥ 1 then [v::r] ++ (if s ≥ 2 then [v::a::r] else []) else []) := by
  by_cases h : 1 ≤ s <;> by_cases h' : 2 ≤ s <;> simp [singles,Choice.output,kept,h,h']

private theorem doubles_out (s a b v : Nat) (r : List Nat) :
    (doubles s a b v r).map Choice.output = [v::r] ++
      (if s ≥ 1 then [v::a::r,v::b::r] else []) ++
      (if s ≥ 2 then [v::a::b::r] else []) := by
  by_cases h : 1 ≤ s <;> by_cases h' : 2 ≤ s <;> simp [doubles,Choice.output,kept,h,h']

theorem annotated_outputs (mask slack : Nat) (ws : List Nat) :
    (annotated mask slack ws).map Choice.output = children mask slack ws := by
  unfold annotated children
  rw [List.map_flatMap]
  apply List.flatMap_congr
  intro a _
  rw [List.map_append, singles_out,List.map_flatMap]
  congr 1
  apply List.flatMap_congr
  intro b _
  by_cases h : a ≤ b
  · simp only [h, ↓reduceIte, List.map_flatMap]
    apply List.flatMap_congr
    intro c _
    exact doubles_out _ _ _ _ _
  · simp [h]

private theorem single_origin (s a v : Nat) (r : List Nat) (q : Choice)
    (h : q ∈ singles s a v r) : q.origin = a::r := by
  by_cases h1 : 1 ≤ s <;> by_cases h2 : 2 ≤ s <;>
    simp [singles,h1,h2] at h <;> rcases h with rfl | rfl <;> rfl

private theorem double_origin (s a b v : Nat) (r : List Nat) (q : Choice)
    (h : q ∈ doubles s a b v r) : q.origin = a::b::r := by
  by_cases h1 : 1 ≤ s <;> by_cases h2 : 2 ≤ s <;>
    simp [doubles,h1,h2] at h <;> rcases h with rfl | rfl | rfl | rfl <;> rfl

theorem annotated_origin (mask slack : Nat) (ws : List Nat) (q : Choice)
    (h : q ∈ annotated mask slack ws) : ws.Perm q.origin := by
  obtain ⟨a,ha,hr⟩ := List.mem_flatMap.mp h
  obtain hs | hb := List.mem_append.mp hr
  · rw [single_origin _ _ _ _ _ hs]
    exact List.perm_cons_erase ha
  · obtain ⟨b,hb,hr⟩ := List.mem_flatMap.mp hb
    by_cases hab : a ≤ b
    · simp only [hab, ↓reduceIte] at hr
      obtain ⟨c,_,hc⟩ := List.mem_flatMap.mp hr
      rw [double_origin _ _ _ _ _ _ hc]
      exact (List.perm_cons_erase ha).trans ((List.perm_cons_erase hb).cons a)
    · simp [hab] at hr

end Petersen1676.Cached
