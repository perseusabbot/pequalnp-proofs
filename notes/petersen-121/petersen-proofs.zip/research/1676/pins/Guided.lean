import FrontierCheck

namespace Petersen1676.Search
open PEqualNP.Outside.L_meta_274_aux

inductive Made (m : Nat) (ws : List Nat) : Nat → Prop
  | unary {a} : a ∈ ws → Made m ws (a ^^^ m)
  | binary {a b} : a ∈ ws → b ∈ ws → (conj : Bool) →
      Made m ws (if conj then a &&& b else a ||| b)

def EdgeStep (m : Nat) (ws : List Nat) : List Nat → Prop
  | [] => False
  | v :: rest => Made m ws v ∧ ∀ w ∈ rest, w ∈ ws

theorem stepUnary {m y a rest} {save : Bool} {s ws} (p : (a :: rest).Perm ws)
    (h : NatRun m y s ((a ^^^ m) :: kept save a rest))
    (f : List Nat → Bool)
    (hf : ∀ ys, EdgeStep m ws ys → NatRun m y s ys → f ys = true) :
    next m (s + 2 - ws.length) ws f = true := by
  have ha := p.mem_iff.1 List.mem_cons_self
  have pr : rest.Perm (ws.erase a) := (p.trans (List.perm_cons_erase ha)).cons_inv
  have hh := run_len h
  have hl := p.length_eq
  simp only [List.length_cons] at hl hh
  have hsl : 1 ≤ s + 2 - ws.length := by cases save <;> simp [kept] at hh <;> omega
  apply List.any_eq_true.2 ⟨a, ha, ?_⟩
  rw [Bool.or_eq_true]; left
  rw [Bool.and_eq_true]; refine ⟨decide_eq_true hsl, ?_⟩
  have edge : EdgeStep m ws ((a ^^^ m) :: kept save a (ws.erase a)) := by
    refine ⟨.unary ha, ?_⟩
    intro v hv
    rcases (mem_kept _ _ _ _).1 hv with hh | hh
    · exact hh.2 ▸ ha
    · exact List.mem_of_mem_erase hh
  have ht := hf _ edge (Run.perm ((keep_perm pr save a).cons _) h)
  cases save with
  | false => simp [kept] at ht; simp [ht]
  | true =>
    simp [kept] at ht hh
    have hsl2 : 2 ≤ s + 2 - ws.length := by omega
    simp [ht, hsl2]

theorem stepSorted {m y a b rest} {conj ka kb : Bool} {s ws} (hab : a ≤ b)
    (p : (a :: b :: rest).Perm ws)
    (h : NatRun m y s
      ((if conj then a &&& b else a ||| b) :: kept ka a (kept kb b rest)))
    (f : List Nat → Bool)
    (hf : ∀ ys, EdgeStep m ws ys → NatRun m y s ys → f ys = true) :
    next m (s + 2 - ws.length) ws f = true := by
  have ha := p.mem_iff.1 List.mem_cons_self
  have pp := (p.trans (List.perm_cons_erase ha)).cons_inv
  have hb := pp.mem_iff.1 List.mem_cons_self
  have pr := (pp.trans (List.perm_cons_erase hb)).cons_inv
  have hh := run_len h
  have hl := p.length_eq
  simp only [List.length_cons] at hl hh
  apply List.any_eq_true.2 ⟨a, ha, ?_⟩
  rw [Bool.or_eq_true]; right
  apply List.any_eq_true.2 ⟨b, hb, ?_⟩
  rw [Bool.and_eq_true]; refine ⟨decide_eq_true hab, ?_⟩
  apply List.any_eq_true.2 ⟨conj, by cases conj <;> simp, ?_⟩
  have hbw : b ∈ ws := List.mem_of_mem_erase hb
  have edge : EdgeStep m ws ((if conj then a &&& b else a ||| b) ::
      kept ka a (kept kb b ((ws.erase a).erase b))) := by
    refine ⟨.binary ha hbw conj, ?_⟩
    intro v hv
    rcases (mem_kept _ _ _ _).1 hv with hh | hh
    · exact hh.2 ▸ ha
    rcases (mem_kept _ _ _ _).1 hh with hx | hx
    · exact hx.2 ▸ hbw
    · exact List.mem_of_mem_erase (List.mem_of_mem_erase hx)
  have ht := hf _ edge (Run.perm ((keep_perm (keep_perm pr kb b) ka a).cons _) h)
  cases ka <;> cases kb <;> simp [kept] at ht hh <;>
    simp only [ht, Bool.true_or, Bool.or_true, Bool.and_true] <;>
    first | (simp [show 2 ≤ s + 2 - ws.length by omega]) | (simp [show 1 ≤ s + 2 - ws.length by omega])

theorem stepBinary {m y a b rest} {conj ka kb : Bool} {s ws}
    (p : (a :: b :: rest).Perm ws)
    (h : NatRun m y s
      ((if conj then a &&& b else a ||| b) :: kept ka a (kept kb b rest)))
    (f : List Nat → Bool)
    (hf : ∀ ys, EdgeStep m ws ys → NatRun m y s ys → f ys = true) :
    next m (s + 2 - ws.length) ws f = true := by
  rcases le_total a b with hab | hba
  · exact stepSorted hab p h f hf
  · apply stepSorted (conj := conj) (ka := kb) (kb := ka) hba ((List.Perm.swap _ _ _).trans p) _ f hf
    have he : (if conj then a &&& b else a ||| b) = (if conj then b &&& a else b ||| a) := by
      cases conj <;> simp [Nat.and_comm, Nat.or_comm]
    rw [he] at h
    apply Run.perm (List.Perm.cons _ ?_) h
    cases ka <;> cases kb <;> simp [kept]
    exact List.Perm.swap _ _ _

theorem stepComplete {m y t ws} (h : NatRun m y t ws) :
    ∀ s, t = s + 1 → ∀ zs, ws.Perm zs → ∀ f : List Nat → Bool,
      (∀ ys, EdgeStep m zs ys → NatRun m y s ys → f ys = true) →
      next m (s + 2 - zs.length) zs f = true := by
  induction h using Run.fold with
  | done => simp
  | perm p h ih => intro s he zs q; exact ih s he zs (p.trans q)
  | one save h ih => intro s he zs p f hf; cases he; exact stepUnary p h f hf
  | two conj ka kb h ih => intro s he zs p f hf; cases he; exact stepBinary p h f hf



/-- Track a proof invariant along a checked Boolean search. The next state
may carry resources inferred from the preceding state and its new wire. -/
def guided {α : Type} (m y : Nat) (cut : Nat → List Nat → α → Bool)
    (advance : List Nat → List Nat → α → α) : Nat → List Nat → α → Bool
  | 0, ws, _ => ws == [y]
  | s+1, ws, q => cut (s+1) ws q && next m (s+2-ws.length) ws
      (fun zs => guided m y cut advance s zs (advance ws zs q))

theorem guided_of_run {α : Type} {m y : Nat} {cut : Nat → List Nat → α → Bool}
    {advance : List Nat → List Nat → α → α} (good : List Nat → α → Prop)
    (preserves : ∀ {s ws q}, good ws q → NatRun m y s ws → cut s ws q = true)
    (step : ∀ {ws zs q}, good ws q → EdgeStep m ws zs → good zs (advance ws zs q)) :
    ∀ {s ws q}, good ws q → NatRun m y s ws → guided m y cut advance s ws q = true := by
  intro s
  induction s with
  | zero =>
    intro ws q hg h
    simp [guided,zero_done h rfl]
  | succ s ih =>
    intro ws q hw h
    simp only [guided, Bool.and_eq_true]
    exact ⟨preserves hw h, stepComplete h s rfl ws (.refl _) _ fun _ edge hr => ih (step hw edge) hr⟩

end Petersen1676.Search
