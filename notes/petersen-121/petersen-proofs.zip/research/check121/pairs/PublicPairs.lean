import Pair121

namespace Checkpoint121.Pairs
open PEqualNP.Outside.L_meta_274_aux
open PEqualNP.Outside.L_meta_3348_aux.FirstWireRun
open Petersen1676 Petersen1676.Table Checkpoint120.Pair
set_option maxRecDepth 18000
set_option maxHeartbeats 6000000

private theorem identify : ∀ m ∈ ([3,5,9,33,65,129,257,36,132] : List ℕ),
    ∃ k : Fin 9, m = support k := by decide +kernel
private theorem inputsAgree : ∀ k (x : Fin 9 → Bool), Fin.snoc (Fin.snoc x (x 4 || x 6))
    (decide (∃ i : Fin 9, (support k).testBit i.val = true ∧ x i = true)) = extended k x := by decide +kernel
private theorem targetsAgree : ∀ x : Fin 9 → Bool,
    (([1,12,23,34,40,5,16,27,38,57,68,85] : List Nat).any
      (fun e => x (Fin.ofNat 9 (e/10)) && x (Fin.ofNat 9 (e%10)))) = edgeFn x := by decide +kernel

/-- Excluding the nine normalized runs suffices for the exact recorded proposition. -/
theorem printedOfRuns (h : ∀ k, ¬NatRun allMask Table.goal 13 (words k)) :
  have x1 : (Fin (9 : ℕ) → Bool) → Bool := fun (x1 : Fin (9 : ℕ) → Bool) => [(1 : ℕ), (12 : ℕ), (23 : ℕ), (34 : ℕ), (40 : ℕ), (5 : ℕ), (16 : ℕ), (27 : ℕ), (38 : ℕ), (57 : ℕ), (68 : ℕ), (85 : ℕ)].any fun (x2 : ℕ) => x1 (Fin.ofNat (9 : ℕ) (x2 / (10 : ℕ))) && x1 (Fin.ofNat (9 : ℕ) (x2 % (10 : ℕ))); ∀ x2 ∈ [(3 : ℕ), (5 : ℕ), (9 : ℕ), (17 : ℕ), (33 : ℕ), (65 : ℕ), (129 : ℕ), (257 : ℕ), (20 : ℕ), (36 : ℕ), (132 : ℕ), (144 : ℕ)], ∀ (x4 : PEqualNP.CircuitLowerBounds.Circuit), PEqualNP.MetaComplexity.FanInTwo x4 → (∀ (x6 : Fin (9 : ℕ) → Bool), PEqualNP.MetaComplexity.circuitFun (11 : ℕ) x4 (Fin.snoc (Fin.snoc x6 (x6 (4 : Fin (9 : ℕ)) || x6 (6 : Fin (9 : ℕ)))) (Decidable.decide (∃ (x7 : Fin (9 : ℕ)), x2.testBit ↑x7 = Bool.true ∧ x6 x7 = Bool.true))) = x1 x6) → (14 : ℕ) ≤ x4.size := by
  apply PEqualNP.Outside.L_meta_3348_aux.ThreeProper.printedNineSuffice
  dsimp only
  intro m hm D legal spec
  obtain ⟨k,rfl⟩ := identify m hm
  apply physical k (h k) D legal
  intro x
  rw [← inputsAgree]
  exact (spec x).trans (targetsAgree x)

#print axioms printedOfRuns
end Checkpoint121.Pairs
