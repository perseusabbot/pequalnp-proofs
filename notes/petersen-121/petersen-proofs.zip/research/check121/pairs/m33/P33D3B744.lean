import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_744 : batch dict 9 l3 l4 c3 744 4 = true := by decide +kernel
private theorem c3_748 : batch dict 9 l3 l4 c3 748 4 = true := by decide +kernel
private theorem c3_752 : batch dict 9 l3 l4 c3 752 4 = true := by decide +kernel
private theorem c3_756 : batch dict 9 l3 l4 c3 756 4 = true := by decide +kernel
private theorem c3_760 : batch dict 9 l3 l4 c3 760 4 = true := by decide +kernel
private theorem c3_764 : batch dict 9 l3 l4 c3 764 4 = true := by decide +kernel
theorem b3_744 (i : Nat) (lo : 744 ≤ i) (hi : i < 768) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 756
  · by_cases cut : i < 748
    · exact fromBatch c3_744 (by omega) (by omega)
    · by_cases cut : i < 752
      · exact fromBatch c3_748 (by omega) (by omega)
      · exact fromBatch c3_752 (by omega) (by omega)
  · by_cases cut : i < 760
    · exact fromBatch c3_756 (by omega) (by omega)
    · by_cases cut : i < 764
      · exact fromBatch c3_760 (by omega) (by omega)
      · exact fromBatch c3_764 (by omega) (by omega)
end Checkpoint121.Pairs.M33
