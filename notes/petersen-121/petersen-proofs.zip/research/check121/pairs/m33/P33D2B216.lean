import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_216 : batch dict 10 l2 l3 c2 216 4 = true := by decide +kernel
private theorem c2_220 : batch dict 10 l2 l3 c2 220 4 = true := by decide +kernel
private theorem c2_224 : batch dict 10 l2 l3 c2 224 4 = true := by decide +kernel
private theorem c2_228 : batch dict 10 l2 l3 c2 228 4 = true := by decide +kernel
private theorem c2_232 : batch dict 10 l2 l3 c2 232 4 = true := by decide +kernel
private theorem c2_236 : batch dict 10 l2 l3 c2 236 4 = true := by decide +kernel
theorem b2_216 (i : Nat) (lo : 216 ≤ i) (hi : i < 240) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 228
  · by_cases cut : i < 220
    · exact fromBatch c2_216 (by omega) (by omega)
    · by_cases cut : i < 224
      · exact fromBatch c2_220 (by omega) (by omega)
      · exact fromBatch c2_224 (by omega) (by omega)
  · by_cases cut : i < 232
    · exact fromBatch c2_228 (by omega) (by omega)
    · by_cases cut : i < 236
      · exact fromBatch c2_232 (by omega) (by omega)
      · exact fromBatch c2_236 (by omega) (by omega)
end Checkpoint121.Pairs.M33
