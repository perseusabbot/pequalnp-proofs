import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_672 : batch dict 10 l2 l3 c2 672 4 = true := by decide +kernel
private theorem c2_676 : batch dict 10 l2 l3 c2 676 4 = true := by decide +kernel
private theorem c2_680 : batch dict 10 l2 l3 c2 680 4 = true := by decide +kernel
private theorem c2_684 : batch dict 10 l2 l3 c2 684 4 = true := by decide +kernel
private theorem c2_688 : batch dict 10 l2 l3 c2 688 4 = true := by decide +kernel
private theorem c2_692 : batch dict 10 l2 l3 c2 692 4 = true := by decide +kernel
theorem b2_672 (i : Nat) (lo : 672 ≤ i) (hi : i < 696) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 684
  · by_cases cut : i < 676
    · exact fromBatch c2_672 (by omega) (by omega)
    · by_cases cut : i < 680
      · exact fromBatch c2_676 (by omega) (by omega)
      · exact fromBatch c2_680 (by omega) (by omega)
  · by_cases cut : i < 688
    · exact fromBatch c2_684 (by omega) (by omega)
    · by_cases cut : i < 692
      · exact fromBatch c2_688 (by omega) (by omega)
      · exact fromBatch c2_692 (by omega) (by omega)
end Checkpoint121.Pairs.M33
