import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_312 : batch dict 9 l3 l4 c3 312 4 = true := by decide +kernel
private theorem c3_316 : batch dict 9 l3 l4 c3 316 4 = true := by decide +kernel
private theorem c3_320 : batch dict 9 l3 l4 c3 320 4 = true := by decide +kernel
private theorem c3_324 : batch dict 9 l3 l4 c3 324 4 = true := by decide +kernel
private theorem c3_328 : batch dict 9 l3 l4 c3 328 4 = true := by decide +kernel
private theorem c3_332 : batch dict 9 l3 l4 c3 332 4 = true := by decide +kernel
theorem b3_312 (i : Nat) (lo : 312 ≤ i) (hi : i < 336) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 324
  · by_cases cut : i < 316
    · exact fromBatch c3_312 (by omega) (by omega)
    · by_cases cut : i < 320
      · exact fromBatch c3_316 (by omega) (by omega)
      · exact fromBatch c3_320 (by omega) (by omega)
  · by_cases cut : i < 328
    · exact fromBatch c3_324 (by omega) (by omega)
    · by_cases cut : i < 332
      · exact fromBatch c3_328 (by omega) (by omega)
      · exact fromBatch c3_332 (by omega) (by omega)
end Checkpoint121.Pairs.M33
