import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_1056 : batch dict 9 l3 l4 c3 1056 4 = true := by decide +kernel
private theorem c3_1060 : batch dict 9 l3 l4 c3 1060 4 = true := by decide +kernel
private theorem c3_1064 : batch dict 9 l3 l4 c3 1064 3 = true := by decide +kernel
theorem b3_1056 (i : Nat) (lo : 1056 ≤ i) (hi : i < 1067) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 1060
  · exact fromBatch c3_1056 (by omega) (by omega)
  · by_cases cut : i < 1064
    · exact fromBatch c3_1060 (by omega) (by omega)
    · exact fromBatch c3_1064 (by omega) (by omega)
end Checkpoint121.Pairs.M33
