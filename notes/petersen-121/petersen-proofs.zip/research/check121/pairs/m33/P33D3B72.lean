import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_72 : batch dict 9 l3 l4 c3 72 4 = true := by decide +kernel
private theorem c3_76 : batch dict 9 l3 l4 c3 76 4 = true := by decide +kernel
private theorem c3_80 : batch dict 9 l3 l4 c3 80 4 = true := by decide +kernel
private theorem c3_84 : batch dict 9 l3 l4 c3 84 4 = true := by decide +kernel
private theorem c3_88 : batch dict 9 l3 l4 c3 88 4 = true := by decide +kernel
private theorem c3_92 : batch dict 9 l3 l4 c3 92 4 = true := by decide +kernel
theorem b3_72 (i : Nat) (lo : 72 ≤ i) (hi : i < 96) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 84
  · by_cases cut : i < 76
    · exact fromBatch c3_72 (by omega) (by omega)
    · by_cases cut : i < 80
      · exact fromBatch c3_76 (by omega) (by omega)
      · exact fromBatch c3_80 (by omega) (by omega)
  · by_cases cut : i < 88
    · exact fromBatch c3_84 (by omega) (by omega)
    · by_cases cut : i < 92
      · exact fromBatch c3_88 (by omega) (by omega)
      · exact fromBatch c3_92 (by omega) (by omega)
end Checkpoint121.Pairs.M33
