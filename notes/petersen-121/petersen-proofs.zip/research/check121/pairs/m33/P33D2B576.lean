import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_576 : batch dict 10 l2 l3 c2 576 4 = true := by decide +kernel
private theorem c2_580 : batch dict 10 l2 l3 c2 580 4 = true := by decide +kernel
private theorem c2_584 : batch dict 10 l2 l3 c2 584 4 = true := by decide +kernel
private theorem c2_588 : batch dict 10 l2 l3 c2 588 4 = true := by decide +kernel
private theorem c2_592 : batch dict 10 l2 l3 c2 592 4 = true := by decide +kernel
private theorem c2_596 : batch dict 10 l2 l3 c2 596 4 = true := by decide +kernel
theorem b2_576 (i : Nat) (lo : 576 ≤ i) (hi : i < 600) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 588
  · by_cases cut : i < 580
    · exact fromBatch c2_576 (by omega) (by omega)
    · by_cases cut : i < 584
      · exact fromBatch c2_580 (by omega) (by omega)
      · exact fromBatch c2_584 (by omega) (by omega)
  · by_cases cut : i < 592
    · exact fromBatch c2_588 (by omega) (by omega)
    · by_cases cut : i < 596
      · exact fromBatch c2_592 (by omega) (by omega)
      · exact fromBatch c2_596 (by omega) (by omega)
end Checkpoint121.Pairs.M33
