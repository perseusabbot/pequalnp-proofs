import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_528 : batch dict 9 l3 l4 c3 528 4 = true := by decide +kernel
private theorem c3_532 : batch dict 9 l3 l4 c3 532 4 = true := by decide +kernel
private theorem c3_536 : batch dict 9 l3 l4 c3 536 4 = true := by decide +kernel
private theorem c3_540 : batch dict 9 l3 l4 c3 540 4 = true := by decide +kernel
private theorem c3_544 : batch dict 9 l3 l4 c3 544 4 = true := by decide +kernel
private theorem c3_548 : batch dict 9 l3 l4 c3 548 4 = true := by decide +kernel
theorem b3_528 (i : Nat) (lo : 528 ≤ i) (hi : i < 552) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 540
  · by_cases cut : i < 532
    · exact fromBatch c3_528 (by omega) (by omega)
    · by_cases cut : i < 536
      · exact fromBatch c3_532 (by omega) (by omega)
      · exact fromBatch c3_536 (by omega) (by omega)
  · by_cases cut : i < 544
    · exact fromBatch c3_540 (by omega) (by omega)
    · by_cases cut : i < 548
      · exact fromBatch c3_544 (by omega) (by omega)
      · exact fromBatch c3_548 (by omega) (by omega)
end Checkpoint121.Pairs.M33
