import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_960 : batch dict 9 l3 l4 c3 960 4 = true := by decide +kernel
private theorem c3_964 : batch dict 9 l3 l4 c3 964 4 = true := by decide +kernel
private theorem c3_968 : batch dict 9 l3 l4 c3 968 4 = true := by decide +kernel
private theorem c3_972 : batch dict 9 l3 l4 c3 972 4 = true := by decide +kernel
private theorem c3_976 : batch dict 9 l3 l4 c3 976 4 = true := by decide +kernel
private theorem c3_980 : batch dict 9 l3 l4 c3 980 4 = true := by decide +kernel
theorem b3_960 (i : Nat) (lo : 960 ≤ i) (hi : i < 984) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 972
  · by_cases cut : i < 964
    · exact fromBatch c3_960 (by omega) (by omega)
    · by_cases cut : i < 968
      · exact fromBatch c3_964 (by omega) (by omega)
      · exact fromBatch c3_968 (by omega) (by omega)
  · by_cases cut : i < 976
    · exact fromBatch c3_972 (by omega) (by omega)
    · by_cases cut : i < 980
      · exact fromBatch c3_976 (by omega) (by omega)
      · exact fromBatch c3_980 (by omega) (by omega)
end Checkpoint121.Pairs.M33
