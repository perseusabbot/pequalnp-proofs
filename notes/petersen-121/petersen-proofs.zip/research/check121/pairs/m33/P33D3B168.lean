import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_168 : batch dict 9 l3 l4 c3 168 4 = true := by decide +kernel
private theorem c3_172 : batch dict 9 l3 l4 c3 172 4 = true := by decide +kernel
private theorem c3_176 : batch dict 9 l3 l4 c3 176 4 = true := by decide +kernel
private theorem c3_180 : batch dict 9 l3 l4 c3 180 4 = true := by decide +kernel
private theorem c3_184 : batch dict 9 l3 l4 c3 184 4 = true := by decide +kernel
private theorem c3_188 : batch dict 9 l3 l4 c3 188 4 = true := by decide +kernel
theorem b3_168 (i : Nat) (lo : 168 ≤ i) (hi : i < 192) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 180
  · by_cases cut : i < 172
    · exact fromBatch c3_168 (by omega) (by omega)
    · by_cases cut : i < 176
      · exact fromBatch c3_172 (by omega) (by omega)
      · exact fromBatch c3_176 (by omega) (by omega)
  · by_cases cut : i < 184
    · exact fromBatch c3_180 (by omega) (by omega)
    · by_cases cut : i < 188
      · exact fromBatch c3_184 (by omega) (by omega)
      · exact fromBatch c3_188 (by omega) (by omega)
end Checkpoint121.Pairs.M33
