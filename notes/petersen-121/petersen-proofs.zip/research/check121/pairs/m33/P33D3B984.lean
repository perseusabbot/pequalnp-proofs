import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_984 : batch dict 9 l3 l4 c3 984 4 = true := by decide +kernel
private theorem c3_988 : batch dict 9 l3 l4 c3 988 4 = true := by decide +kernel
private theorem c3_992 : batch dict 9 l3 l4 c3 992 4 = true := by decide +kernel
private theorem c3_996 : batch dict 9 l3 l4 c3 996 4 = true := by decide +kernel
private theorem c3_1000 : batch dict 9 l3 l4 c3 1000 4 = true := by decide +kernel
private theorem c3_1004 : batch dict 9 l3 l4 c3 1004 4 = true := by decide +kernel
theorem b3_984 (i : Nat) (lo : 984 ≤ i) (hi : i < 1008) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 996
  · by_cases cut : i < 988
    · exact fromBatch c3_984 (by omega) (by omega)
    · by_cases cut : i < 992
      · exact fromBatch c3_988 (by omega) (by omega)
      · exact fromBatch c3_992 (by omega) (by omega)
  · by_cases cut : i < 1000
    · exact fromBatch c3_996 (by omega) (by omega)
    · by_cases cut : i < 1004
      · exact fromBatch c3_1000 (by omega) (by omega)
      · exact fromBatch c3_1004 (by omega) (by omega)
end Checkpoint121.Pairs.M33
