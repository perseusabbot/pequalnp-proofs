import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_888 : batch dict 9 l3 l4 c3 888 4 = true := by decide +kernel
private theorem c3_892 : batch dict 9 l3 l4 c3 892 4 = true := by decide +kernel
private theorem c3_896 : batch dict 9 l3 l4 c3 896 4 = true := by decide +kernel
private theorem c3_900 : batch dict 9 l3 l4 c3 900 4 = true := by decide +kernel
private theorem c3_904 : batch dict 9 l3 l4 c3 904 4 = true := by decide +kernel
private theorem c3_908 : batch dict 9 l3 l4 c3 908 4 = true := by decide +kernel
theorem b3_888 (i : Nat) (lo : 888 ≤ i) (hi : i < 912) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 900
  · by_cases cut : i < 892
    · exact fromBatch c3_888 (by omega) (by omega)
    · by_cases cut : i < 896
      · exact fromBatch c3_892 (by omega) (by omega)
      · exact fromBatch c3_896 (by omega) (by omega)
  · by_cases cut : i < 904
    · exact fromBatch c3_900 (by omega) (by omega)
    · by_cases cut : i < 908
      · exact fromBatch c3_904 (by omega) (by omega)
      · exact fromBatch c3_908 (by omega) (by omega)
end Checkpoint121.Pairs.M33
