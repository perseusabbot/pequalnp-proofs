import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_504 : batch dict 10 l2 l3 c2 504 4 = true := by decide +kernel
private theorem c2_508 : batch dict 10 l2 l3 c2 508 4 = true := by decide +kernel
private theorem c2_512 : batch dict 10 l2 l3 c2 512 4 = true := by decide +kernel
private theorem c2_516 : batch dict 10 l2 l3 c2 516 4 = true := by decide +kernel
private theorem c2_520 : batch dict 10 l2 l3 c2 520 4 = true := by decide +kernel
private theorem c2_524 : batch dict 10 l2 l3 c2 524 4 = true := by decide +kernel
theorem b2_504 (i : Nat) (lo : 504 ≤ i) (hi : i < 528) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 516
  · by_cases cut : i < 508
    · exact fromBatch c2_504 (by omega) (by omega)
    · by_cases cut : i < 512
      · exact fromBatch c2_508 (by omega) (by omega)
      · exact fromBatch c2_512 (by omega) (by omega)
  · by_cases cut : i < 520
    · exact fromBatch c2_516 (by omega) (by omega)
    · by_cases cut : i < 524
      · exact fromBatch c2_520 (by omega) (by omega)
      · exact fromBatch c2_524 (by omega) (by omega)
end Checkpoint121.Pairs.M33
