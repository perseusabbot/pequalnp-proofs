import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_1032 : batch dict 9 l3 l4 c3 1032 4 = true := by decide +kernel
private theorem c3_1036 : batch dict 9 l3 l4 c3 1036 4 = true := by decide +kernel
private theorem c3_1040 : batch dict 9 l3 l4 c3 1040 4 = true := by decide +kernel
private theorem c3_1044 : batch dict 9 l3 l4 c3 1044 4 = true := by decide +kernel
private theorem c3_1048 : batch dict 9 l3 l4 c3 1048 4 = true := by decide +kernel
private theorem c3_1052 : batch dict 9 l3 l4 c3 1052 4 = true := by decide +kernel
theorem b3_1032 (i : Nat) (lo : 1032 ≤ i) (hi : i < 1056) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 1044
  · by_cases cut : i < 1036
    · exact fromBatch c3_1032 (by omega) (by omega)
    · by_cases cut : i < 1040
      · exact fromBatch c3_1036 (by omega) (by omega)
      · exact fromBatch c3_1040 (by omega) (by omega)
  · by_cases cut : i < 1048
    · exact fromBatch c3_1044 (by omega) (by omega)
    · by_cases cut : i < 1052
      · exact fromBatch c3_1048 (by omega) (by omega)
      · exact fromBatch c3_1052 (by omega) (by omega)
end Checkpoint121.Pairs.M33
