import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_672 : batch dict 9 l3 l4 c3 672 4 = true := by decide +kernel
private theorem c3_676 : batch dict 9 l3 l4 c3 676 4 = true := by decide +kernel
private theorem c3_680 : batch dict 9 l3 l4 c3 680 4 = true := by decide +kernel
private theorem c3_684 : batch dict 9 l3 l4 c3 684 4 = true := by decide +kernel
private theorem c3_688 : batch dict 9 l3 l4 c3 688 4 = true := by decide +kernel
private theorem c3_692 : batch dict 9 l3 l4 c3 692 4 = true := by decide +kernel
theorem b3_672 (i : Nat) (lo : 672 ≤ i) (hi : i < 696) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 684
  · by_cases cut : i < 676
    · exact fromBatch c3_672 (by omega) (by omega)
    · by_cases cut : i < 680
      · exact fromBatch c3_676 (by omega) (by omega)
      · exact fromBatch c3_680 (by omega) (by omega)
  · by_cases cut : i < 688
    · exact fromBatch c3_684 (by omega) (by omega)
    · by_cases cut : i < 692
      · exact fromBatch c3_688 (by omega) (by omega)
      · exact fromBatch c3_692 (by omega) (by omega)
end Checkpoint121.Pairs.M33
