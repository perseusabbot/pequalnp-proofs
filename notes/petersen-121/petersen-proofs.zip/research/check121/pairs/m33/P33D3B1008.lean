import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_1008 : batch dict 9 l3 l4 c3 1008 4 = true := by decide +kernel
private theorem c3_1012 : batch dict 9 l3 l4 c3 1012 4 = true := by decide +kernel
private theorem c3_1016 : batch dict 9 l3 l4 c3 1016 4 = true := by decide +kernel
private theorem c3_1020 : batch dict 9 l3 l4 c3 1020 4 = true := by decide +kernel
private theorem c3_1024 : batch dict 9 l3 l4 c3 1024 4 = true := by decide +kernel
private theorem c3_1028 : batch dict 9 l3 l4 c3 1028 4 = true := by decide +kernel
theorem b3_1008 (i : Nat) (lo : 1008 ≤ i) (hi : i < 1032) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 1020
  · by_cases cut : i < 1012
    · exact fromBatch c3_1008 (by omega) (by omega)
    · by_cases cut : i < 1016
      · exact fromBatch c3_1012 (by omega) (by omega)
      · exact fromBatch c3_1016 (by omega) (by omega)
  · by_cases cut : i < 1024
    · exact fromBatch c3_1020 (by omega) (by omega)
    · by_cases cut : i < 1028
      · exact fromBatch c3_1024 (by omega) (by omega)
      · exact fromBatch c3_1028 (by omega) (by omega)
end Checkpoint121.Pairs.M33
