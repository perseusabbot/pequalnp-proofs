import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_600 : batch dict 10 l2 l3 c2 600 4 = true := by decide +kernel
private theorem c2_604 : batch dict 10 l2 l3 c2 604 4 = true := by decide +kernel
private theorem c2_608 : batch dict 10 l2 l3 c2 608 4 = true := by decide +kernel
private theorem c2_612 : batch dict 10 l2 l3 c2 612 4 = true := by decide +kernel
private theorem c2_616 : batch dict 10 l2 l3 c2 616 4 = true := by decide +kernel
private theorem c2_620 : batch dict 10 l2 l3 c2 620 4 = true := by decide +kernel
theorem b2_600 (i : Nat) (lo : 600 ≤ i) (hi : i < 624) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 612
  · by_cases cut : i < 604
    · exact fromBatch c2_600 (by omega) (by omega)
    · by_cases cut : i < 608
      · exact fromBatch c2_604 (by omega) (by omega)
      · exact fromBatch c2_608 (by omega) (by omega)
  · by_cases cut : i < 616
    · exact fromBatch c2_612 (by omega) (by omega)
    · by_cases cut : i < 620
      · exact fromBatch c2_616 (by omega) (by omega)
      · exact fromBatch c2_620 (by omega) (by omega)
end Checkpoint121.Pairs.M33
