import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_600 : batch dict 9 l3 l4 c3 600 4 = true := by decide +kernel
private theorem c3_604 : batch dict 9 l3 l4 c3 604 4 = true := by decide +kernel
private theorem c3_608 : batch dict 9 l3 l4 c3 608 4 = true := by decide +kernel
private theorem c3_612 : batch dict 9 l3 l4 c3 612 4 = true := by decide +kernel
private theorem c3_616 : batch dict 9 l3 l4 c3 616 4 = true := by decide +kernel
private theorem c3_620 : batch dict 9 l3 l4 c3 620 4 = true := by decide +kernel
theorem b3_600 (i : Nat) (lo : 600 ≤ i) (hi : i < 624) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 612
  · by_cases cut : i < 604
    · exact fromBatch c3_600 (by omega) (by omega)
    · by_cases cut : i < 608
      · exact fromBatch c3_604 (by omega) (by omega)
      · exact fromBatch c3_608 (by omega) (by omega)
  · by_cases cut : i < 616
    · exact fromBatch c3_612 (by omega) (by omega)
    · by_cases cut : i < 620
      · exact fromBatch c3_616 (by omega) (by omega)
      · exact fromBatch c3_620 (by omega) (by omega)
end Checkpoint121.Pairs.M33
