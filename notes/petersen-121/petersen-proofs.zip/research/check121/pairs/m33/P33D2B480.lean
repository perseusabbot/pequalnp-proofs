import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_480 : batch dict 10 l2 l3 c2 480 4 = true := by decide +kernel
private theorem c2_484 : batch dict 10 l2 l3 c2 484 4 = true := by decide +kernel
private theorem c2_488 : batch dict 10 l2 l3 c2 488 4 = true := by decide +kernel
private theorem c2_492 : batch dict 10 l2 l3 c2 492 4 = true := by decide +kernel
private theorem c2_496 : batch dict 10 l2 l3 c2 496 4 = true := by decide +kernel
private theorem c2_500 : batch dict 10 l2 l3 c2 500 4 = true := by decide +kernel
theorem b2_480 (i : Nat) (lo : 480 ≤ i) (hi : i < 504) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 492
  · by_cases cut : i < 484
    · exact fromBatch c2_480 (by omega) (by omega)
    · by_cases cut : i < 488
      · exact fromBatch c2_484 (by omega) (by omega)
      · exact fromBatch c2_488 (by omega) (by omega)
  · by_cases cut : i < 496
    · exact fromBatch c2_492 (by omega) (by omega)
    · by_cases cut : i < 500
      · exact fromBatch c2_496 (by omega) (by omega)
      · exact fromBatch c2_500 (by omega) (by omega)
end Checkpoint121.Pairs.M33
