import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c1_24 : batch dict 11 l1 l2 c1 24 4 = true := by decide +kernel
private theorem c1_28 : batch dict 11 l1 l2 c1 28 4 = true := by decide +kernel
private theorem c1_32 : batch dict 11 l1 l2 c1 32 4 = true := by decide +kernel
private theorem c1_36 : batch dict 11 l1 l2 c1 36 4 = true := by decide +kernel
private theorem c1_40 : batch dict 11 l1 l2 c1 40 4 = true := by decide +kernel
private theorem c1_44 : batch dict 11 l1 l2 c1 44 4 = true := by decide +kernel
theorem b1_24 (i : Nat) (lo : 24 ≤ i) (hi : i < 48) : checkRow dict 11 (l1[i]?.getD default) l2 (c1[i]?.getD 0) = true := by
  by_cases cut : i < 36
  · by_cases cut : i < 28
    · exact fromBatch c1_24 (by omega) (by omega)
    · by_cases cut : i < 32
      · exact fromBatch c1_28 (by omega) (by omega)
      · exact fromBatch c1_32 (by omega) (by omega)
  · by_cases cut : i < 40
    · exact fromBatch c1_36 (by omega) (by omega)
    · by_cases cut : i < 44
      · exact fromBatch c1_40 (by omega) (by omega)
      · exact fromBatch c1_44 (by omega) (by omega)
end Checkpoint121.Pairs.M33
