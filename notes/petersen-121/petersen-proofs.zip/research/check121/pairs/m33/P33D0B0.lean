import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c0_0 : batch dict 12 l0 l1 c0 0 1 = true := by decide +kernel
theorem b0_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 1) : checkRow dict 12 (l0[i]?.getD default) l1 (c0[i]?.getD 0) = true := by
  exact fromBatch c0_0 (by omega) (by omega)
end Checkpoint121.Pairs.M33
