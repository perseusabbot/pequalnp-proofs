import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_456 : batch dict 10 l2 l3 c2 456 4 = true := by decide +kernel
private theorem c2_460 : batch dict 10 l2 l3 c2 460 4 = true := by decide +kernel
private theorem c2_464 : batch dict 10 l2 l3 c2 464 4 = true := by decide +kernel
private theorem c2_468 : batch dict 10 l2 l3 c2 468 4 = true := by decide +kernel
private theorem c2_472 : batch dict 10 l2 l3 c2 472 4 = true := by decide +kernel
private theorem c2_476 : batch dict 10 l2 l3 c2 476 4 = true := by decide +kernel
theorem b2_456 (i : Nat) (lo : 456 ≤ i) (hi : i < 480) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 468
  · by_cases cut : i < 460
    · exact fromBatch c2_456 (by omega) (by omega)
    · by_cases cut : i < 464
      · exact fromBatch c2_460 (by omega) (by omega)
      · exact fromBatch c2_464 (by omega) (by omega)
  · by_cases cut : i < 472
    · exact fromBatch c2_468 (by omega) (by omega)
    · by_cases cut : i < 476
      · exact fromBatch c2_472 (by omega) (by omega)
      · exact fromBatch c2_476 (by omega) (by omega)
end Checkpoint121.Pairs.M33
