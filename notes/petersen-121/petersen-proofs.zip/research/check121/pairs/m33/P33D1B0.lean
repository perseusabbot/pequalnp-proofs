import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c1_0 : batch dict 11 l1 l2 c1 0 4 = true := by decide +kernel
private theorem c1_4 : batch dict 11 l1 l2 c1 4 4 = true := by decide +kernel
private theorem c1_8 : batch dict 11 l1 l2 c1 8 4 = true := by decide +kernel
private theorem c1_12 : batch dict 11 l1 l2 c1 12 4 = true := by decide +kernel
private theorem c1_16 : batch dict 11 l1 l2 c1 16 4 = true := by decide +kernel
private theorem c1_20 : batch dict 11 l1 l2 c1 20 4 = true := by decide +kernel
theorem b1_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 24) : checkRow dict 11 (l1[i]?.getD default) l2 (c1[i]?.getD 0) = true := by
  by_cases cut : i < 12
  · by_cases cut : i < 4
    · exact fromBatch c1_0 (by omega) (by omega)
    · by_cases cut : i < 8
      · exact fromBatch c1_4 (by omega) (by omega)
      · exact fromBatch c1_8 (by omega) (by omega)
  · by_cases cut : i < 16
    · exact fromBatch c1_12 (by omega) (by omega)
    · by_cases cut : i < 20
      · exact fromBatch c1_16 (by omega) (by omega)
      · exact fromBatch c1_20 (by omega) (by omega)
end Checkpoint121.Pairs.M33
