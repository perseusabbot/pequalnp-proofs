import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_696 : batch dict 10 l2 l3 c2 696 4 = true := by decide +kernel
private theorem c2_700 : batch dict 10 l2 l3 c2 700 4 = true := by decide +kernel
private theorem c2_704 : batch dict 10 l2 l3 c2 704 4 = true := by decide +kernel
private theorem c2_708 : batch dict 10 l2 l3 c2 708 4 = true := by decide +kernel
private theorem c2_712 : batch dict 10 l2 l3 c2 712 4 = true := by decide +kernel
theorem b2_696 (i : Nat) (lo : 696 ≤ i) (hi : i < 716) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 704
  · by_cases cut : i < 700
    · exact fromBatch c2_696 (by omega) (by omega)
    · exact fromBatch c2_700 (by omega) (by omega)
  · by_cases cut : i < 708
    · exact fromBatch c2_704 (by omega) (by omega)
    · by_cases cut : i < 712
      · exact fromBatch c2_708 (by omega) (by omega)
      · exact fromBatch c2_712 (by omega) (by omega)
end Checkpoint121.Pairs.M33
