import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_816 : batch dict 9 l3 l4 c3 816 4 = true := by decide +kernel
private theorem c3_820 : batch dict 9 l3 l4 c3 820 4 = true := by decide +kernel
private theorem c3_824 : batch dict 9 l3 l4 c3 824 4 = true := by decide +kernel
private theorem c3_828 : batch dict 9 l3 l4 c3 828 4 = true := by decide +kernel
private theorem c3_832 : batch dict 9 l3 l4 c3 832 4 = true := by decide +kernel
private theorem c3_836 : batch dict 9 l3 l4 c3 836 4 = true := by decide +kernel
theorem b3_816 (i : Nat) (lo : 816 ≤ i) (hi : i < 840) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 828
  · by_cases cut : i < 820
    · exact fromBatch c3_816 (by omega) (by omega)
    · by_cases cut : i < 824
      · exact fromBatch c3_820 (by omega) (by omega)
      · exact fromBatch c3_824 (by omega) (by omega)
  · by_cases cut : i < 832
    · exact fromBatch c3_828 (by omega) (by omega)
    · by_cases cut : i < 836
      · exact fromBatch c3_832 (by omega) (by omega)
      · exact fromBatch c3_836 (by omega) (by omega)
end Checkpoint121.Pairs.M33
