import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_96 : batch dict 10 l2 l3 c2 96 4 = true := by decide +kernel
private theorem c2_100 : batch dict 10 l2 l3 c2 100 4 = true := by decide +kernel
private theorem c2_104 : batch dict 10 l2 l3 c2 104 4 = true := by decide +kernel
private theorem c2_108 : batch dict 10 l2 l3 c2 108 4 = true := by decide +kernel
private theorem c2_112 : batch dict 10 l2 l3 c2 112 4 = true := by decide +kernel
private theorem c2_116 : batch dict 10 l2 l3 c2 116 4 = true := by decide +kernel
theorem b2_96 (i : Nat) (lo : 96 ≤ i) (hi : i < 120) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 108
  · by_cases cut : i < 100
    · exact fromBatch c2_96 (by omega) (by omega)
    · by_cases cut : i < 104
      · exact fromBatch c2_100 (by omega) (by omega)
      · exact fromBatch c2_104 (by omega) (by omega)
  · by_cases cut : i < 112
    · exact fromBatch c2_108 (by omega) (by omega)
    · by_cases cut : i < 116
      · exact fromBatch c2_112 (by omega) (by omega)
      · exact fromBatch c2_116 (by omega) (by omega)
end Checkpoint121.Pairs.M33
