import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_648 : batch dict 9 l3 l4 c3 648 4 = true := by decide +kernel
private theorem c3_652 : batch dict 9 l3 l4 c3 652 4 = true := by decide +kernel
private theorem c3_656 : batch dict 9 l3 l4 c3 656 4 = true := by decide +kernel
private theorem c3_660 : batch dict 9 l3 l4 c3 660 4 = true := by decide +kernel
private theorem c3_664 : batch dict 9 l3 l4 c3 664 4 = true := by decide +kernel
private theorem c3_668 : batch dict 9 l3 l4 c3 668 4 = true := by decide +kernel
theorem b3_648 (i : Nat) (lo : 648 ≤ i) (hi : i < 672) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 660
  · by_cases cut : i < 652
    · exact fromBatch c3_648 (by omega) (by omega)
    · by_cases cut : i < 656
      · exact fromBatch c3_652 (by omega) (by omega)
      · exact fromBatch c3_656 (by omega) (by omega)
  · by_cases cut : i < 664
    · exact fromBatch c3_660 (by omega) (by omega)
    · by_cases cut : i < 668
      · exact fromBatch c3_664 (by omega) (by omega)
      · exact fromBatch c3_668 (by omega) (by omega)
end Checkpoint121.Pairs.M33
