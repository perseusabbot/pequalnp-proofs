import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c4_120 : batch dict 8 l4 l5 c4 120 4 = true := by decide +kernel
private theorem c4_124 : batch dict 8 l4 l5 c4 124 4 = true := by decide +kernel
private theorem c4_128 : batch dict 8 l4 l5 c4 128 4 = true := by decide +kernel
private theorem c4_132 : batch dict 8 l4 l5 c4 132 4 = true := by decide +kernel
private theorem c4_136 : batch dict 8 l4 l5 c4 136 4 = true := by decide +kernel
private theorem c4_140 : batch dict 8 l4 l5 c4 140 4 = true := by decide +kernel
theorem b4_120 (i : Nat) (lo : 120 ≤ i) (hi : i < 144) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 132
  · by_cases cut : i < 124
    · exact fromBatch c4_120 (by omega) (by omega)
    · by_cases cut : i < 128
      · exact fromBatch c4_124 (by omega) (by omega)
      · exact fromBatch c4_128 (by omega) (by omega)
  · by_cases cut : i < 136
    · exact fromBatch c4_132 (by omega) (by omega)
    · by_cases cut : i < 140
      · exact fromBatch c4_136 (by omega) (by omega)
      · exact fromBatch c4_140 (by omega) (by omega)
end Checkpoint121.Pairs.M33
