import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_792 : batch dict 9 l3 l4 c3 792 4 = true := by decide +kernel
private theorem c3_796 : batch dict 9 l3 l4 c3 796 4 = true := by decide +kernel
private theorem c3_800 : batch dict 9 l3 l4 c3 800 4 = true := by decide +kernel
private theorem c3_804 : batch dict 9 l3 l4 c3 804 4 = true := by decide +kernel
private theorem c3_808 : batch dict 9 l3 l4 c3 808 4 = true := by decide +kernel
private theorem c3_812 : batch dict 9 l3 l4 c3 812 4 = true := by decide +kernel
theorem b3_792 (i : Nat) (lo : 792 ≤ i) (hi : i < 816) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 804
  · by_cases cut : i < 796
    · exact fromBatch c3_792 (by omega) (by omega)
    · by_cases cut : i < 800
      · exact fromBatch c3_796 (by omega) (by omega)
      · exact fromBatch c3_800 (by omega) (by omega)
  · by_cases cut : i < 808
    · exact fromBatch c3_804 (by omega) (by omega)
    · by_cases cut : i < 812
      · exact fromBatch c3_808 (by omega) (by omega)
      · exact fromBatch c3_812 (by omega) (by omega)
end Checkpoint121.Pairs.M33
