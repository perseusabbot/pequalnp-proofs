import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_120 : batch dict 10 l2 l3 c2 120 4 = true := by decide +kernel
private theorem c2_124 : batch dict 10 l2 l3 c2 124 4 = true := by decide +kernel
private theorem c2_128 : batch dict 10 l2 l3 c2 128 4 = true := by decide +kernel
private theorem c2_132 : batch dict 10 l2 l3 c2 132 4 = true := by decide +kernel
private theorem c2_136 : batch dict 10 l2 l3 c2 136 4 = true := by decide +kernel
private theorem c2_140 : batch dict 10 l2 l3 c2 140 4 = true := by decide +kernel
theorem b2_120 (i : Nat) (lo : 120 ≤ i) (hi : i < 144) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 132
  · by_cases cut : i < 124
    · exact fromBatch c2_120 (by omega) (by omega)
    · by_cases cut : i < 128
      · exact fromBatch c2_124 (by omega) (by omega)
      · exact fromBatch c2_128 (by omega) (by omega)
  · by_cases cut : i < 136
    · exact fromBatch c2_132 (by omega) (by omega)
    · by_cases cut : i < 140
      · exact fromBatch c2_136 (by omega) (by omega)
      · exact fromBatch c2_140 (by omega) (by omega)
end Checkpoint121.Pairs.M33
