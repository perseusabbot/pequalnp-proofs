import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_288 : batch dict 9 l3 l4 c3 288 4 = true := by decide +kernel
private theorem c3_292 : batch dict 9 l3 l4 c3 292 4 = true := by decide +kernel
private theorem c3_296 : batch dict 9 l3 l4 c3 296 4 = true := by decide +kernel
private theorem c3_300 : batch dict 9 l3 l4 c3 300 4 = true := by decide +kernel
private theorem c3_304 : batch dict 9 l3 l4 c3 304 4 = true := by decide +kernel
private theorem c3_308 : batch dict 9 l3 l4 c3 308 4 = true := by decide +kernel
theorem b3_288 (i : Nat) (lo : 288 ≤ i) (hi : i < 312) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 300
  · by_cases cut : i < 292
    · exact fromBatch c3_288 (by omega) (by omega)
    · by_cases cut : i < 296
      · exact fromBatch c3_292 (by omega) (by omega)
      · exact fromBatch c3_296 (by omega) (by omega)
  · by_cases cut : i < 304
    · exact fromBatch c3_300 (by omega) (by omega)
    · by_cases cut : i < 308
      · exact fromBatch c3_304 (by omega) (by omega)
      · exact fromBatch c3_308 (by omega) (by omega)
end Checkpoint121.Pairs.M33
