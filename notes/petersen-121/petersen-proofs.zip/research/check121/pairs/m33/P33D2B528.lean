import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_528 : batch dict 10 l2 l3 c2 528 4 = true := by decide +kernel
private theorem c2_532 : batch dict 10 l2 l3 c2 532 4 = true := by decide +kernel
private theorem c2_536 : batch dict 10 l2 l3 c2 536 4 = true := by decide +kernel
private theorem c2_540 : batch dict 10 l2 l3 c2 540 4 = true := by decide +kernel
private theorem c2_544 : batch dict 10 l2 l3 c2 544 4 = true := by decide +kernel
private theorem c2_548 : batch dict 10 l2 l3 c2 548 4 = true := by decide +kernel
theorem b2_528 (i : Nat) (lo : 528 ≤ i) (hi : i < 552) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 540
  · by_cases cut : i < 532
    · exact fromBatch c2_528 (by omega) (by omega)
    · by_cases cut : i < 536
      · exact fromBatch c2_532 (by omega) (by omega)
      · exact fromBatch c2_536 (by omega) (by omega)
  · by_cases cut : i < 544
    · exact fromBatch c2_540 (by omega) (by omega)
    · by_cases cut : i < 548
      · exact fromBatch c2_544 (by omega) (by omega)
      · exact fromBatch c2_548 (by omega) (by omega)
end Checkpoint121.Pairs.M33
