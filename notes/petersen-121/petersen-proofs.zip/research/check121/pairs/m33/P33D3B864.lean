import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_864 : batch dict 9 l3 l4 c3 864 4 = true := by decide +kernel
private theorem c3_868 : batch dict 9 l3 l4 c3 868 4 = true := by decide +kernel
private theorem c3_872 : batch dict 9 l3 l4 c3 872 4 = true := by decide +kernel
private theorem c3_876 : batch dict 9 l3 l4 c3 876 4 = true := by decide +kernel
private theorem c3_880 : batch dict 9 l3 l4 c3 880 4 = true := by decide +kernel
private theorem c3_884 : batch dict 9 l3 l4 c3 884 4 = true := by decide +kernel
theorem b3_864 (i : Nat) (lo : 864 ≤ i) (hi : i < 888) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 876
  · by_cases cut : i < 868
    · exact fromBatch c3_864 (by omega) (by omega)
    · by_cases cut : i < 872
      · exact fromBatch c3_868 (by omega) (by omega)
      · exact fromBatch c3_872 (by omega) (by omega)
  · by_cases cut : i < 880
    · exact fromBatch c3_876 (by omega) (by omega)
    · by_cases cut : i < 884
      · exact fromBatch c3_880 (by omega) (by omega)
      · exact fromBatch c3_884 (by omega) (by omega)
end Checkpoint121.Pairs.M33
