import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_936 : batch dict 9 l3 l4 c3 936 4 = true := by decide +kernel
private theorem c3_940 : batch dict 9 l3 l4 c3 940 4 = true := by decide +kernel
private theorem c3_944 : batch dict 9 l3 l4 c3 944 4 = true := by decide +kernel
private theorem c3_948 : batch dict 9 l3 l4 c3 948 4 = true := by decide +kernel
private theorem c3_952 : batch dict 9 l3 l4 c3 952 4 = true := by decide +kernel
private theorem c3_956 : batch dict 9 l3 l4 c3 956 4 = true := by decide +kernel
theorem b3_936 (i : Nat) (lo : 936 ≤ i) (hi : i < 960) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 948
  · by_cases cut : i < 940
    · exact fromBatch c3_936 (by omega) (by omega)
    · by_cases cut : i < 944
      · exact fromBatch c3_940 (by omega) (by omega)
      · exact fromBatch c3_944 (by omega) (by omega)
  · by_cases cut : i < 952
    · exact fromBatch c3_948 (by omega) (by omega)
    · by_cases cut : i < 956
      · exact fromBatch c3_952 (by omega) (by omega)
      · exact fromBatch c3_956 (by omega) (by omega)
end Checkpoint121.Pairs.M33
