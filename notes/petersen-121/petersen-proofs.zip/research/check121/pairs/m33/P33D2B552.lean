import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_552 : batch dict 10 l2 l3 c2 552 4 = true := by decide +kernel
private theorem c2_556 : batch dict 10 l2 l3 c2 556 4 = true := by decide +kernel
private theorem c2_560 : batch dict 10 l2 l3 c2 560 4 = true := by decide +kernel
private theorem c2_564 : batch dict 10 l2 l3 c2 564 4 = true := by decide +kernel
private theorem c2_568 : batch dict 10 l2 l3 c2 568 4 = true := by decide +kernel
private theorem c2_572 : batch dict 10 l2 l3 c2 572 4 = true := by decide +kernel
theorem b2_552 (i : Nat) (lo : 552 ≤ i) (hi : i < 576) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 564
  · by_cases cut : i < 556
    · exact fromBatch c2_552 (by omega) (by omega)
    · by_cases cut : i < 560
      · exact fromBatch c2_556 (by omega) (by omega)
      · exact fromBatch c2_560 (by omega) (by omega)
  · by_cases cut : i < 568
    · exact fromBatch c2_564 (by omega) (by omega)
    · by_cases cut : i < 572
      · exact fromBatch c2_568 (by omega) (by omega)
      · exact fromBatch c2_572 (by omega) (by omega)
end Checkpoint121.Pairs.M33
