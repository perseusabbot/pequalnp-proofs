import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_24 : batch dict 9 l3 l4 c3 24 4 = true := by decide +kernel
private theorem c3_28 : batch dict 9 l3 l4 c3 28 4 = true := by decide +kernel
private theorem c3_32 : batch dict 9 l3 l4 c3 32 4 = true := by decide +kernel
private theorem c3_36 : batch dict 9 l3 l4 c3 36 4 = true := by decide +kernel
private theorem c3_40 : batch dict 9 l3 l4 c3 40 4 = true := by decide +kernel
private theorem c3_44 : batch dict 9 l3 l4 c3 44 4 = true := by decide +kernel
theorem b3_24 (i : Nat) (lo : 24 ≤ i) (hi : i < 48) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 36
  · by_cases cut : i < 28
    · exact fromBatch c3_24 (by omega) (by omega)
    · by_cases cut : i < 32
      · exact fromBatch c3_28 (by omega) (by omega)
      · exact fromBatch c3_32 (by omega) (by omega)
  · by_cases cut : i < 40
    · exact fromBatch c3_36 (by omega) (by omega)
    · by_cases cut : i < 44
      · exact fromBatch c3_40 (by omega) (by omega)
      · exact fromBatch c3_44 (by omega) (by omega)
end Checkpoint121.Pairs.M33
