import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_648 : batch dict 10 l2 l3 c2 648 4 = true := by decide +kernel
private theorem c2_652 : batch dict 10 l2 l3 c2 652 4 = true := by decide +kernel
private theorem c2_656 : batch dict 10 l2 l3 c2 656 4 = true := by decide +kernel
private theorem c2_660 : batch dict 10 l2 l3 c2 660 4 = true := by decide +kernel
private theorem c2_664 : batch dict 10 l2 l3 c2 664 4 = true := by decide +kernel
private theorem c2_668 : batch dict 10 l2 l3 c2 668 4 = true := by decide +kernel
theorem b2_648 (i : Nat) (lo : 648 ≤ i) (hi : i < 672) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 660
  · by_cases cut : i < 652
    · exact fromBatch c2_648 (by omega) (by omega)
    · by_cases cut : i < 656
      · exact fromBatch c2_652 (by omega) (by omega)
      · exact fromBatch c2_656 (by omega) (by omega)
  · by_cases cut : i < 664
    · exact fromBatch c2_660 (by omega) (by omega)
    · by_cases cut : i < 668
      · exact fromBatch c2_664 (by omega) (by omega)
      · exact fromBatch c2_668 (by omega) (by omega)
end Checkpoint121.Pairs.M33
