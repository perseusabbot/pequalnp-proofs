import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c2_624 : batch dict 10 l2 l3 c2 624 4 = true := by decide +kernel
private theorem c2_628 : batch dict 10 l2 l3 c2 628 4 = true := by decide +kernel
private theorem c2_632 : batch dict 10 l2 l3 c2 632 4 = true := by decide +kernel
private theorem c2_636 : batch dict 10 l2 l3 c2 636 4 = true := by decide +kernel
private theorem c2_640 : batch dict 10 l2 l3 c2 640 4 = true := by decide +kernel
private theorem c2_644 : batch dict 10 l2 l3 c2 644 4 = true := by decide +kernel
theorem b2_624 (i : Nat) (lo : 624 ≤ i) (hi : i < 648) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 636
  · by_cases cut : i < 628
    · exact fromBatch c2_624 (by omega) (by omega)
    · by_cases cut : i < 632
      · exact fromBatch c2_628 (by omega) (by omega)
      · exact fromBatch c2_632 (by omega) (by omega)
  · by_cases cut : i < 640
    · exact fromBatch c2_636 (by omega) (by omega)
    · by_cases cut : i < 644
      · exact fromBatch c2_640 (by omega) (by omega)
      · exact fromBatch c2_644 (by omega) (by omega)
end Checkpoint121.Pairs.M33
