import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_696 : batch dict 9 l3 l4 c3 696 4 = true := by decide +kernel
private theorem c3_700 : batch dict 9 l3 l4 c3 700 4 = true := by decide +kernel
private theorem c3_704 : batch dict 9 l3 l4 c3 704 4 = true := by decide +kernel
private theorem c3_708 : batch dict 9 l3 l4 c3 708 4 = true := by decide +kernel
private theorem c3_712 : batch dict 9 l3 l4 c3 712 4 = true := by decide +kernel
private theorem c3_716 : batch dict 9 l3 l4 c3 716 4 = true := by decide +kernel
theorem b3_696 (i : Nat) (lo : 696 ≤ i) (hi : i < 720) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 708
  · by_cases cut : i < 700
    · exact fromBatch c3_696 (by omega) (by omega)
    · by_cases cut : i < 704
      · exact fromBatch c3_700 (by omega) (by omega)
      · exact fromBatch c3_704 (by omega) (by omega)
  · by_cases cut : i < 712
    · exact fromBatch c3_708 (by omega) (by omega)
    · by_cases cut : i < 716
      · exact fromBatch c3_712 (by omega) (by omega)
      · exact fromBatch c3_716 (by omega) (by omega)
end Checkpoint121.Pairs.M33
