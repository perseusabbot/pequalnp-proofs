import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_720 : batch dict 9 l3 l4 c3 720 4 = true := by decide +kernel
private theorem c3_724 : batch dict 9 l3 l4 c3 724 4 = true := by decide +kernel
private theorem c3_728 : batch dict 9 l3 l4 c3 728 4 = true := by decide +kernel
private theorem c3_732 : batch dict 9 l3 l4 c3 732 4 = true := by decide +kernel
private theorem c3_736 : batch dict 9 l3 l4 c3 736 4 = true := by decide +kernel
private theorem c3_740 : batch dict 9 l3 l4 c3 740 4 = true := by decide +kernel
theorem b3_720 (i : Nat) (lo : 720 ≤ i) (hi : i < 744) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 732
  · by_cases cut : i < 724
    · exact fromBatch c3_720 (by omega) (by omega)
    · by_cases cut : i < 728
      · exact fromBatch c3_724 (by omega) (by omega)
      · exact fromBatch c3_728 (by omega) (by omega)
  · by_cases cut : i < 736
    · exact fromBatch c3_732 (by omega) (by omega)
    · by_cases cut : i < 740
      · exact fromBatch c3_736 (by omega) (by omega)
      · exact fromBatch c3_740 (by omega) (by omega)
end Checkpoint121.Pairs.M33
