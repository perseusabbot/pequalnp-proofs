import P33Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M33
private theorem c3_216 : batch dict 9 l3 l4 c3 216 4 = true := by decide +kernel
private theorem c3_220 : batch dict 9 l3 l4 c3 220 4 = true := by decide +kernel
private theorem c3_224 : batch dict 9 l3 l4 c3 224 4 = true := by decide +kernel
private theorem c3_228 : batch dict 9 l3 l4 c3 228 4 = true := by decide +kernel
private theorem c3_232 : batch dict 9 l3 l4 c3 232 4 = true := by decide +kernel
private theorem c3_236 : batch dict 9 l3 l4 c3 236 4 = true := by decide +kernel
theorem b3_216 (i : Nat) (lo : 216 ≤ i) (hi : i < 240) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 228
  · by_cases cut : i < 220
    · exact fromBatch c3_216 (by omega) (by omega)
    · by_cases cut : i < 224
      · exact fromBatch c3_220 (by omega) (by omega)
      · exact fromBatch c3_224 (by omega) (by omega)
  · by_cases cut : i < 232
    · exact fromBatch c3_228 (by omega) (by omega)
    · by_cases cut : i < 236
      · exact fromBatch c3_232 (by omega) (by omega)
      · exact fromBatch c3_236 (by omega) (by omega)
end Checkpoint121.Pairs.M33
