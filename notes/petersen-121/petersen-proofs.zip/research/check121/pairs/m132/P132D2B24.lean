import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_24 : chunk dict 10 l2 l3 24 4 = true := by decide +kernel
private theorem c2_28 : chunk dict 10 l2 l3 28 4 = true := by decide +kernel
private theorem c2_32 : chunk dict 10 l2 l3 32 4 = true := by decide +kernel
private theorem c2_36 : chunk dict 10 l2 l3 36 4 = true := by decide +kernel
private theorem c2_40 : chunk dict 10 l2 l3 40 4 = true := by decide +kernel
private theorem c2_44 : chunk dict 10 l2 l3 44 4 = true := by decide +kernel
theorem b2_24 (i : Nat) (lo : 24 ≤ i) (hi : i < 48) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 36
  · by_cases cut : i < 28
    · exact fromChunk c2_24 (by omega) (by omega)
    · by_cases cut : i < 32
      · exact fromChunk c2_28 (by omega) (by omega)
      · exact fromChunk c2_32 (by omega) (by omega)
  · by_cases cut : i < 40
    · exact fromChunk c2_36 (by omega) (by omega)
    · by_cases cut : i < 44
      · exact fromChunk c2_40 (by omega) (by omega)
      · exact fromChunk c2_44 (by omega) (by omega)
end Checkpoint121.Pairs.M132
