import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_72 : chunk dict 8 l4 l5 72 4 = true := by decide +kernel
private theorem c4_76 : chunk dict 8 l4 l5 76 4 = true := by decide +kernel
private theorem c4_80 : chunk dict 8 l4 l5 80 4 = true := by decide +kernel
private theorem c4_84 : chunk dict 8 l4 l5 84 4 = true := by decide +kernel
private theorem c4_88 : chunk dict 8 l4 l5 88 4 = true := by decide +kernel
private theorem c4_92 : chunk dict 8 l4 l5 92 4 = true := by decide +kernel
theorem b4_72 (i : Nat) (lo : 72 ≤ i) (hi : i < 96) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 84
  · by_cases cut : i < 76
    · exact fromChunk c4_72 (by omega) (by omega)
    · by_cases cut : i < 80
      · exact fromChunk c4_76 (by omega) (by omega)
      · exact fromChunk c4_80 (by omega) (by omega)
  · by_cases cut : i < 88
    · exact fromChunk c4_84 (by omega) (by omega)
    · by_cases cut : i < 92
      · exact fromChunk c4_88 (by omega) (by omega)
      · exact fromChunk c4_92 (by omega) (by omega)
end Checkpoint121.Pairs.M132
