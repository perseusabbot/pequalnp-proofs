import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_336 : chunk dict 9 l3 l4 336 4 = true := by decide +kernel
private theorem c3_340 : chunk dict 9 l3 l4 340 4 = true := by decide +kernel
private theorem c3_344 : chunk dict 9 l3 l4 344 4 = true := by decide +kernel
private theorem c3_348 : chunk dict 9 l3 l4 348 4 = true := by decide +kernel
private theorem c3_352 : chunk dict 9 l3 l4 352 4 = true := by decide +kernel
private theorem c3_356 : chunk dict 9 l3 l4 356 4 = true := by decide +kernel
theorem b3_336 (i : Nat) (lo : 336 ≤ i) (hi : i < 360) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 348
  · by_cases cut : i < 340
    · exact fromChunk c3_336 (by omega) (by omega)
    · by_cases cut : i < 344
      · exact fromChunk c3_340 (by omega) (by omega)
      · exact fromChunk c3_344 (by omega) (by omega)
  · by_cases cut : i < 352
    · exact fromChunk c3_348 (by omega) (by omega)
    · by_cases cut : i < 356
      · exact fromChunk c3_352 (by omega) (by omega)
      · exact fromChunk c3_356 (by omega) (by omega)
end Checkpoint121.Pairs.M132
