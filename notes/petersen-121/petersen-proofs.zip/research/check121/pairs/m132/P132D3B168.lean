import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_168 : chunk dict 9 l3 l4 168 4 = true := by decide +kernel
private theorem c3_172 : chunk dict 9 l3 l4 172 4 = true := by decide +kernel
private theorem c3_176 : chunk dict 9 l3 l4 176 4 = true := by decide +kernel
private theorem c3_180 : chunk dict 9 l3 l4 180 4 = true := by decide +kernel
private theorem c3_184 : chunk dict 9 l3 l4 184 4 = true := by decide +kernel
private theorem c3_188 : chunk dict 9 l3 l4 188 4 = true := by decide +kernel
theorem b3_168 (i : Nat) (lo : 168 ≤ i) (hi : i < 192) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 180
  · by_cases cut : i < 172
    · exact fromChunk c3_168 (by omega) (by omega)
    · by_cases cut : i < 176
      · exact fromChunk c3_172 (by omega) (by omega)
      · exact fromChunk c3_176 (by omega) (by omega)
  · by_cases cut : i < 184
    · exact fromChunk c3_180 (by omega) (by omega)
    · by_cases cut : i < 188
      · exact fromChunk c3_184 (by omega) (by omega)
      · exact fromChunk c3_188 (by omega) (by omega)
end Checkpoint121.Pairs.M132
