import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_192 : chunk dict 10 l2 l3 192 4 = true := by decide +kernel
private theorem c2_196 : chunk dict 10 l2 l3 196 4 = true := by decide +kernel
private theorem c2_200 : chunk dict 10 l2 l3 200 4 = true := by decide +kernel
private theorem c2_204 : chunk dict 10 l2 l3 204 4 = true := by decide +kernel
private theorem c2_208 : chunk dict 10 l2 l3 208 4 = true := by decide +kernel
private theorem c2_212 : chunk dict 10 l2 l3 212 4 = true := by decide +kernel
theorem b2_192 (i : Nat) (lo : 192 ≤ i) (hi : i < 216) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 204
  · by_cases cut : i < 196
    · exact fromChunk c2_192 (by omega) (by omega)
    · by_cases cut : i < 200
      · exact fromChunk c2_196 (by omega) (by omega)
      · exact fromChunk c2_200 (by omega) (by omega)
  · by_cases cut : i < 208
    · exact fromChunk c2_204 (by omega) (by omega)
    · by_cases cut : i < 212
      · exact fromChunk c2_208 (by omega) (by omega)
      · exact fromChunk c2_212 (by omega) (by omega)
end Checkpoint121.Pairs.M132
