import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_408 : chunk dict 9 l3 l4 408 4 = true := by decide +kernel
private theorem c3_412 : chunk dict 9 l3 l4 412 4 = true := by decide +kernel
private theorem c3_416 : chunk dict 9 l3 l4 416 4 = true := by decide +kernel
private theorem c3_420 : chunk dict 9 l3 l4 420 4 = true := by decide +kernel
private theorem c3_424 : chunk dict 9 l3 l4 424 4 = true := by decide +kernel
private theorem c3_428 : chunk dict 9 l3 l4 428 4 = true := by decide +kernel
theorem b3_408 (i : Nat) (lo : 408 ≤ i) (hi : i < 432) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 420
  · by_cases cut : i < 412
    · exact fromChunk c3_408 (by omega) (by omega)
    · by_cases cut : i < 416
      · exact fromChunk c3_412 (by omega) (by omega)
      · exact fromChunk c3_416 (by omega) (by omega)
  · by_cases cut : i < 424
    · exact fromChunk c3_420 (by omega) (by omega)
    · by_cases cut : i < 428
      · exact fromChunk c3_424 (by omega) (by omega)
      · exact fromChunk c3_428 (by omega) (by omega)
end Checkpoint121.Pairs.M132
