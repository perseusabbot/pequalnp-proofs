import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_216 : chunk dict 8 l4 l5 216 4 = true := by decide +kernel
private theorem c4_220 : chunk dict 8 l4 l5 220 4 = true := by decide +kernel
private theorem c4_224 : chunk dict 8 l4 l5 224 4 = true := by decide +kernel
private theorem c4_228 : chunk dict 8 l4 l5 228 4 = true := by decide +kernel
private theorem c4_232 : chunk dict 8 l4 l5 232 4 = true := by decide +kernel
private theorem c4_236 : chunk dict 8 l4 l5 236 4 = true := by decide +kernel
theorem b4_216 (i : Nat) (lo : 216 ≤ i) (hi : i < 240) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 228
  · by_cases cut : i < 220
    · exact fromChunk c4_216 (by omega) (by omega)
    · by_cases cut : i < 224
      · exact fromChunk c4_220 (by omega) (by omega)
      · exact fromChunk c4_224 (by omega) (by omega)
  · by_cases cut : i < 232
    · exact fromChunk c4_228 (by omega) (by omega)
    · by_cases cut : i < 236
      · exact fromChunk c4_232 (by omega) (by omega)
      · exact fromChunk c4_236 (by omega) (by omega)
end Checkpoint121.Pairs.M132
