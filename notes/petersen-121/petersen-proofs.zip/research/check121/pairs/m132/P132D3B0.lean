import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_0 : chunk dict 9 l3 l4 0 4 = true := by decide +kernel
private theorem c3_4 : chunk dict 9 l3 l4 4 4 = true := by decide +kernel
private theorem c3_8 : chunk dict 9 l3 l4 8 4 = true := by decide +kernel
private theorem c3_12 : chunk dict 9 l3 l4 12 4 = true := by decide +kernel
private theorem c3_16 : chunk dict 9 l3 l4 16 4 = true := by decide +kernel
private theorem c3_20 : chunk dict 9 l3 l4 20 4 = true := by decide +kernel
theorem b3_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 24) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 12
  · by_cases cut : i < 4
    · exact fromChunk c3_0 (by omega) (by omega)
    · by_cases cut : i < 8
      · exact fromChunk c3_4 (by omega) (by omega)
      · exact fromChunk c3_8 (by omega) (by omega)
  · by_cases cut : i < 16
    · exact fromChunk c3_12 (by omega) (by omega)
    · by_cases cut : i < 20
      · exact fromChunk c3_16 (by omega) (by omega)
      · exact fromChunk c3_20 (by omega) (by omega)
end Checkpoint121.Pairs.M132
