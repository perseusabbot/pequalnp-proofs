import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_240 : chunk dict 10 l2 l3 240 4 = true := by decide +kernel
private theorem c2_244 : chunk dict 10 l2 l3 244 4 = true := by decide +kernel
private theorem c2_248 : chunk dict 10 l2 l3 248 4 = true := by decide +kernel
private theorem c2_252 : chunk dict 10 l2 l3 252 4 = true := by decide +kernel
private theorem c2_256 : chunk dict 10 l2 l3 256 4 = true := by decide +kernel
private theorem c2_260 : chunk dict 10 l2 l3 260 4 = true := by decide +kernel
theorem b2_240 (i : Nat) (lo : 240 ≤ i) (hi : i < 264) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 252
  · by_cases cut : i < 244
    · exact fromChunk c2_240 (by omega) (by omega)
    · by_cases cut : i < 248
      · exact fromChunk c2_244 (by omega) (by omega)
      · exact fromChunk c2_248 (by omega) (by omega)
  · by_cases cut : i < 256
    · exact fromChunk c2_252 (by omega) (by omega)
    · by_cases cut : i < 260
      · exact fromChunk c2_256 (by omega) (by omega)
      · exact fromChunk c2_260 (by omega) (by omega)
end Checkpoint121.Pairs.M132
