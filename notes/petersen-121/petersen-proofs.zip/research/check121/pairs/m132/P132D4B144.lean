import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_144 : chunk dict 8 l4 l5 144 4 = true := by decide +kernel
private theorem c4_148 : chunk dict 8 l4 l5 148 4 = true := by decide +kernel
private theorem c4_152 : chunk dict 8 l4 l5 152 4 = true := by decide +kernel
private theorem c4_156 : chunk dict 8 l4 l5 156 4 = true := by decide +kernel
private theorem c4_160 : chunk dict 8 l4 l5 160 4 = true := by decide +kernel
private theorem c4_164 : chunk dict 8 l4 l5 164 4 = true := by decide +kernel
theorem b4_144 (i : Nat) (lo : 144 ≤ i) (hi : i < 168) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 156
  · by_cases cut : i < 148
    · exact fromChunk c4_144 (by omega) (by omega)
    · by_cases cut : i < 152
      · exact fromChunk c4_148 (by omega) (by omega)
      · exact fromChunk c4_152 (by omega) (by omega)
  · by_cases cut : i < 160
    · exact fromChunk c4_156 (by omega) (by omega)
    · by_cases cut : i < 164
      · exact fromChunk c4_160 (by omega) (by omega)
      · exact fromChunk c4_164 (by omega) (by omega)
end Checkpoint121.Pairs.M132
