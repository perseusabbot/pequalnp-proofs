import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_96 : chunk dict 9 l3 l4 96 4 = true := by decide +kernel
private theorem c3_100 : chunk dict 9 l3 l4 100 4 = true := by decide +kernel
private theorem c3_104 : chunk dict 9 l3 l4 104 4 = true := by decide +kernel
private theorem c3_108 : chunk dict 9 l3 l4 108 4 = true := by decide +kernel
private theorem c3_112 : chunk dict 9 l3 l4 112 4 = true := by decide +kernel
private theorem c3_116 : chunk dict 9 l3 l4 116 4 = true := by decide +kernel
theorem b3_96 (i : Nat) (lo : 96 ≤ i) (hi : i < 120) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 108
  · by_cases cut : i < 100
    · exact fromChunk c3_96 (by omega) (by omega)
    · by_cases cut : i < 104
      · exact fromChunk c3_100 (by omega) (by omega)
      · exact fromChunk c3_104 (by omega) (by omega)
  · by_cases cut : i < 112
    · exact fromChunk c3_108 (by omega) (by omega)
    · by_cases cut : i < 116
      · exact fromChunk c3_112 (by omega) (by omega)
      · exact fromChunk c3_116 (by omega) (by omega)
end Checkpoint121.Pairs.M132
