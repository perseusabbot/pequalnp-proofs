import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c5_0 : chunk dict 7 l5 l6 0 3 = true := by decide +kernel
theorem b5_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 3) : localCheck dict 7 (l5[i]?.getD default) l6 = true := by
  exact fromChunk c5_0 (by omega) (by omega)
end Checkpoint121.Pairs.M132
