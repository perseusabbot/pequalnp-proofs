import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_0 : chunk dict 10 l2 l3 0 4 = true := by decide +kernel
private theorem c2_4 : chunk dict 10 l2 l3 4 4 = true := by decide +kernel
private theorem c2_8 : chunk dict 10 l2 l3 8 4 = true := by decide +kernel
private theorem c2_12 : chunk dict 10 l2 l3 12 4 = true := by decide +kernel
private theorem c2_16 : chunk dict 10 l2 l3 16 4 = true := by decide +kernel
private theorem c2_20 : chunk dict 10 l2 l3 20 4 = true := by decide +kernel
theorem b2_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 24) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 12
  · by_cases cut : i < 4
    · exact fromChunk c2_0 (by omega) (by omega)
    · by_cases cut : i < 8
      · exact fromChunk c2_4 (by omega) (by omega)
      · exact fromChunk c2_8 (by omega) (by omega)
  · by_cases cut : i < 16
    · exact fromChunk c2_12 (by omega) (by omega)
    · by_cases cut : i < 20
      · exact fromChunk c2_16 (by omega) (by omega)
      · exact fromChunk c2_20 (by omega) (by omega)
end Checkpoint121.Pairs.M132
