import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_528 : chunk dict 9 l3 l4 528 4 = true := by decide +kernel
private theorem c3_532 : chunk dict 9 l3 l4 532 4 = true := by decide +kernel
private theorem c3_536 : chunk dict 9 l3 l4 536 4 = true := by decide +kernel
private theorem c3_540 : chunk dict 9 l3 l4 540 4 = true := by decide +kernel
private theorem c3_544 : chunk dict 9 l3 l4 544 4 = true := by decide +kernel
private theorem c3_548 : chunk dict 9 l3 l4 548 4 = true := by decide +kernel
theorem b3_528 (i : Nat) (lo : 528 ≤ i) (hi : i < 552) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 540
  · by_cases cut : i < 532
    · exact fromChunk c3_528 (by omega) (by omega)
    · by_cases cut : i < 536
      · exact fromChunk c3_532 (by omega) (by omega)
      · exact fromChunk c3_536 (by omega) (by omega)
  · by_cases cut : i < 544
    · exact fromChunk c3_540 (by omega) (by omega)
    · by_cases cut : i < 548
      · exact fromChunk c3_544 (by omega) (by omega)
      · exact fromChunk c3_548 (by omega) (by omega)
end Checkpoint121.Pairs.M132
