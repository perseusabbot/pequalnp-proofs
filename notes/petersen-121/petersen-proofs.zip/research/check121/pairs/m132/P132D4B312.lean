import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_312 : chunk dict 8 l4 l5 312 4 = true := by decide +kernel
private theorem c4_316 : chunk dict 8 l4 l5 316 4 = true := by decide +kernel
private theorem c4_320 : chunk dict 8 l4 l5 320 4 = true := by decide +kernel
private theorem c4_324 : chunk dict 8 l4 l5 324 4 = true := by decide +kernel
private theorem c4_328 : chunk dict 8 l4 l5 328 4 = true := by decide +kernel
private theorem c4_332 : chunk dict 8 l4 l5 332 4 = true := by decide +kernel
theorem b4_312 (i : Nat) (lo : 312 ≤ i) (hi : i < 336) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 324
  · by_cases cut : i < 316
    · exact fromChunk c4_312 (by omega) (by omega)
    · by_cases cut : i < 320
      · exact fromChunk c4_316 (by omega) (by omega)
      · exact fromChunk c4_320 (by omega) (by omega)
  · by_cases cut : i < 328
    · exact fromChunk c4_324 (by omega) (by omega)
    · by_cases cut : i < 332
      · exact fromChunk c4_328 (by omega) (by omega)
      · exact fromChunk c4_332 (by omega) (by omega)
end Checkpoint121.Pairs.M132
