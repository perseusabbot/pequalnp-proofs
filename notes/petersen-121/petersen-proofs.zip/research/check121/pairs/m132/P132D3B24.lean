import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_24 : chunk dict 9 l3 l4 24 4 = true := by decide +kernel
private theorem c3_28 : chunk dict 9 l3 l4 28 4 = true := by decide +kernel
private theorem c3_32 : chunk dict 9 l3 l4 32 4 = true := by decide +kernel
private theorem c3_36 : chunk dict 9 l3 l4 36 4 = true := by decide +kernel
private theorem c3_40 : chunk dict 9 l3 l4 40 4 = true := by decide +kernel
private theorem c3_44 : chunk dict 9 l3 l4 44 4 = true := by decide +kernel
theorem b3_24 (i : Nat) (lo : 24 ≤ i) (hi : i < 48) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 36
  · by_cases cut : i < 28
    · exact fromChunk c3_24 (by omega) (by omega)
    · by_cases cut : i < 32
      · exact fromChunk c3_28 (by omega) (by omega)
      · exact fromChunk c3_32 (by omega) (by omega)
  · by_cases cut : i < 40
    · exact fromChunk c3_36 (by omega) (by omega)
    · by_cases cut : i < 44
      · exact fromChunk c3_40 (by omega) (by omega)
      · exact fromChunk c3_44 (by omega) (by omega)
end Checkpoint121.Pairs.M132
