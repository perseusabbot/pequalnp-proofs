import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_312 : chunk dict 9 l3 l4 312 4 = true := by decide +kernel
private theorem c3_316 : chunk dict 9 l3 l4 316 4 = true := by decide +kernel
private theorem c3_320 : chunk dict 9 l3 l4 320 4 = true := by decide +kernel
private theorem c3_324 : chunk dict 9 l3 l4 324 4 = true := by decide +kernel
private theorem c3_328 : chunk dict 9 l3 l4 328 4 = true := by decide +kernel
private theorem c3_332 : chunk dict 9 l3 l4 332 4 = true := by decide +kernel
theorem b3_312 (i : Nat) (lo : 312 ≤ i) (hi : i < 336) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 324
  · by_cases cut : i < 316
    · exact fromChunk c3_312 (by omega) (by omega)
    · by_cases cut : i < 320
      · exact fromChunk c3_316 (by omega) (by omega)
      · exact fromChunk c3_320 (by omega) (by omega)
  · by_cases cut : i < 328
    · exact fromChunk c3_324 (by omega) (by omega)
    · by_cases cut : i < 332
      · exact fromChunk c3_328 (by omega) (by omega)
      · exact fromChunk c3_332 (by omega) (by omega)
end Checkpoint121.Pairs.M132
