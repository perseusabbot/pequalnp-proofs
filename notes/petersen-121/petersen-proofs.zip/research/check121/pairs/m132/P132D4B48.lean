import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_48 : chunk dict 8 l4 l5 48 4 = true := by decide +kernel
private theorem c4_52 : chunk dict 8 l4 l5 52 4 = true := by decide +kernel
private theorem c4_56 : chunk dict 8 l4 l5 56 4 = true := by decide +kernel
private theorem c4_60 : chunk dict 8 l4 l5 60 4 = true := by decide +kernel
private theorem c4_64 : chunk dict 8 l4 l5 64 4 = true := by decide +kernel
private theorem c4_68 : chunk dict 8 l4 l5 68 4 = true := by decide +kernel
theorem b4_48 (i : Nat) (lo : 48 ≤ i) (hi : i < 72) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 60
  · by_cases cut : i < 52
    · exact fromChunk c4_48 (by omega) (by omega)
    · by_cases cut : i < 56
      · exact fromChunk c4_52 (by omega) (by omega)
      · exact fromChunk c4_56 (by omega) (by omega)
  · by_cases cut : i < 64
    · exact fromChunk c4_60 (by omega) (by omega)
    · by_cases cut : i < 68
      · exact fromChunk c4_64 (by omega) (by omega)
      · exact fromChunk c4_68 (by omega) (by omega)
end Checkpoint121.Pairs.M132
