import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_48 : chunk dict 9 l3 l4 48 4 = true := by decide +kernel
private theorem c3_52 : chunk dict 9 l3 l4 52 4 = true := by decide +kernel
private theorem c3_56 : chunk dict 9 l3 l4 56 4 = true := by decide +kernel
private theorem c3_60 : chunk dict 9 l3 l4 60 4 = true := by decide +kernel
private theorem c3_64 : chunk dict 9 l3 l4 64 4 = true := by decide +kernel
private theorem c3_68 : chunk dict 9 l3 l4 68 4 = true := by decide +kernel
theorem b3_48 (i : Nat) (lo : 48 ≤ i) (hi : i < 72) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 60
  · by_cases cut : i < 52
    · exact fromChunk c3_48 (by omega) (by omega)
    · by_cases cut : i < 56
      · exact fromChunk c3_52 (by omega) (by omega)
      · exact fromChunk c3_56 (by omega) (by omega)
  · by_cases cut : i < 64
    · exact fromChunk c3_60 (by omega) (by omega)
    · by_cases cut : i < 68
      · exact fromChunk c3_64 (by omega) (by omega)
      · exact fromChunk c3_68 (by omega) (by omega)
end Checkpoint121.Pairs.M132
