import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_96 : chunk dict 10 l2 l3 96 4 = true := by decide +kernel
private theorem c2_100 : chunk dict 10 l2 l3 100 4 = true := by decide +kernel
private theorem c2_104 : chunk dict 10 l2 l3 104 4 = true := by decide +kernel
private theorem c2_108 : chunk dict 10 l2 l3 108 4 = true := by decide +kernel
private theorem c2_112 : chunk dict 10 l2 l3 112 4 = true := by decide +kernel
private theorem c2_116 : chunk dict 10 l2 l3 116 4 = true := by decide +kernel
theorem b2_96 (i : Nat) (lo : 96 ≤ i) (hi : i < 120) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 108
  · by_cases cut : i < 100
    · exact fromChunk c2_96 (by omega) (by omega)
    · by_cases cut : i < 104
      · exact fromChunk c2_100 (by omega) (by omega)
      · exact fromChunk c2_104 (by omega) (by omega)
  · by_cases cut : i < 112
    · exact fromChunk c2_108 (by omega) (by omega)
    · by_cases cut : i < 116
      · exact fromChunk c2_112 (by omega) (by omega)
      · exact fromChunk c2_116 (by omega) (by omega)
end Checkpoint121.Pairs.M132
