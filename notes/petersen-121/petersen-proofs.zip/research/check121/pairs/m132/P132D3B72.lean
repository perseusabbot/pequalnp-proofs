import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_72 : chunk dict 9 l3 l4 72 4 = true := by decide +kernel
private theorem c3_76 : chunk dict 9 l3 l4 76 4 = true := by decide +kernel
private theorem c3_80 : chunk dict 9 l3 l4 80 4 = true := by decide +kernel
private theorem c3_84 : chunk dict 9 l3 l4 84 4 = true := by decide +kernel
private theorem c3_88 : chunk dict 9 l3 l4 88 4 = true := by decide +kernel
private theorem c3_92 : chunk dict 9 l3 l4 92 4 = true := by decide +kernel
theorem b3_72 (i : Nat) (lo : 72 ≤ i) (hi : i < 96) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 84
  · by_cases cut : i < 76
    · exact fromChunk c3_72 (by omega) (by omega)
    · by_cases cut : i < 80
      · exact fromChunk c3_76 (by omega) (by omega)
      · exact fromChunk c3_80 (by omega) (by omega)
  · by_cases cut : i < 88
    · exact fromChunk c3_84 (by omega) (by omega)
    · by_cases cut : i < 92
      · exact fromChunk c3_88 (by omega) (by omega)
      · exact fromChunk c3_92 (by omega) (by omega)
end Checkpoint121.Pairs.M132
