import P132D0B0
import P132D1B0
import P132D1B24
import P132D2B0
import P132D2B24
import P132D2B48
import P132D2B72
import P132D2B96
import P132D2B120
import P132D2B144
import P132D2B168
import P132D2B192
import P132D2B216
import P132D2B240
import P132D2B264
import P132D2B288
import P132D2B312
import P132D2B336
import P132D2B360
import P132D2B384
import P132D3B0
import P132D3B24
import P132D3B48
import P132D3B72
import P132D3B96
import P132D3B120
import P132D3B144
import P132D3B168
import P132D3B192
import P132D3B216
import P132D3B240
import P132D3B264
import P132D3B288
import P132D3B312
import P132D3B336
import P132D3B360
import P132D3B384
import P132D3B408
import P132D3B432
import P132D3B456
import P132D3B480
import P132D3B504
import P132D3B528
import P132D3B552
import P132D3B576
import P132D3B600
import P132D4B0
import P132D4B24
import P132D4B48
import P132D4B72
import P132D4B96
import P132D4B120
import P132D4B144
import P132D4B168
import P132D4B192
import P132D4B216
import P132D4B240
import P132D4B264
import P132D4B288
import P132D4B312
import P132D4B336
import P132D5B0

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem z6 : Closed dict 7 l6 := by
  intro i
  have lt := i.isLt
  change i.val < 0 at lt
  omega
private theorem z5 : Closed dict 8 l5 := by
  apply prior _ _ _ _ _ z6
  intro idx
  let i := idx.val
  have bound : i < 3 := by exact idx.isLt
  have ok : localCheck dict 7 (l5[i]?.getD default) l6 = true := by
    exact b5_0 i (by omega) (by omega)
  simpa only [i,Fin.getElem_fin,Array.getElem?_eq_getElem idx.isLt,Option.getD_some] using ok
private theorem z4 : Closed dict 9 l4 := by
  apply prior _ _ _ _ _ z5
  intro idx
  let i := idx.val
  have bound : i < 342 := by exact idx.isLt
  have ok : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
    by_cases cut : i < 168
    · by_cases cut : i < 72
      · by_cases cut : i < 24
        · exact b4_0 i (by omega) (by omega)
        · by_cases cut : i < 48
          · exact b4_24 i (by omega) (by omega)
          · exact b4_48 i (by omega) (by omega)
      · by_cases cut : i < 120
        · by_cases cut : i < 96
          · exact b4_72 i (by omega) (by omega)
          · exact b4_96 i (by omega) (by omega)
        · by_cases cut : i < 144
          · exact b4_120 i (by omega) (by omega)
          · exact b4_144 i (by omega) (by omega)
    · by_cases cut : i < 264
      · by_cases cut : i < 216
        · by_cases cut : i < 192
          · exact b4_168 i (by omega) (by omega)
          · exact b4_192 i (by omega) (by omega)
        · by_cases cut : i < 240
          · exact b4_216 i (by omega) (by omega)
          · exact b4_240 i (by omega) (by omega)
      · by_cases cut : i < 312
        · by_cases cut : i < 288
          · exact b4_264 i (by omega) (by omega)
          · exact b4_288 i (by omega) (by omega)
        · by_cases cut : i < 336
          · exact b4_312 i (by omega) (by omega)
          · exact b4_336 i (by omega) (by omega)
  simpa only [i,Fin.getElem_fin,Array.getElem?_eq_getElem idx.isLt,Option.getD_some] using ok
private theorem z3 : Closed dict 10 l3 := by
  apply prior _ _ _ _ _ z4
  intro idx
  let i := idx.val
  have bound : i < 601 := by exact idx.isLt
  have ok : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
    by_cases cut : i < 312
    · by_cases cut : i < 144
      · by_cases cut : i < 72
        · by_cases cut : i < 24
          · exact b3_0 i (by omega) (by omega)
          · by_cases cut : i < 48
            · exact b3_24 i (by omega) (by omega)
            · exact b3_48 i (by omega) (by omega)
        · by_cases cut : i < 96
          · exact b3_72 i (by omega) (by omega)
          · by_cases cut : i < 120
            · exact b3_96 i (by omega) (by omega)
            · exact b3_120 i (by omega) (by omega)
      · by_cases cut : i < 216
        · by_cases cut : i < 168
          · exact b3_144 i (by omega) (by omega)
          · by_cases cut : i < 192
            · exact b3_168 i (by omega) (by omega)
            · exact b3_192 i (by omega) (by omega)
        · by_cases cut : i < 264
          · by_cases cut : i < 240
            · exact b3_216 i (by omega) (by omega)
            · exact b3_240 i (by omega) (by omega)
          · by_cases cut : i < 288
            · exact b3_264 i (by omega) (by omega)
            · exact b3_288 i (by omega) (by omega)
    · by_cases cut : i < 456
      · by_cases cut : i < 384
        · by_cases cut : i < 336
          · exact b3_312 i (by omega) (by omega)
          · by_cases cut : i < 360
            · exact b3_336 i (by omega) (by omega)
            · exact b3_360 i (by omega) (by omega)
        · by_cases cut : i < 408
          · exact b3_384 i (by omega) (by omega)
          · by_cases cut : i < 432
            · exact b3_408 i (by omega) (by omega)
            · exact b3_432 i (by omega) (by omega)
      · by_cases cut : i < 528
        · by_cases cut : i < 480
          · exact b3_456 i (by omega) (by omega)
          · by_cases cut : i < 504
            · exact b3_480 i (by omega) (by omega)
            · exact b3_504 i (by omega) (by omega)
        · by_cases cut : i < 576
          · by_cases cut : i < 552
            · exact b3_528 i (by omega) (by omega)
            · exact b3_552 i (by omega) (by omega)
          · by_cases cut : i < 600
            · exact b3_576 i (by omega) (by omega)
            · exact b3_600 i (by omega) (by omega)
  simpa only [i,Fin.getElem_fin,Array.getElem?_eq_getElem idx.isLt,Option.getD_some] using ok
private theorem z2 : Closed dict 11 l2 := by
  apply prior _ _ _ _ _ z3
  intro idx
  let i := idx.val
  have bound : i < 397 := by exact idx.isLt
  have ok : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
    by_cases cut : i < 192
    · by_cases cut : i < 96
      · by_cases cut : i < 48
        · by_cases cut : i < 24
          · exact b2_0 i (by omega) (by omega)
          · exact b2_24 i (by omega) (by omega)
        · by_cases cut : i < 72
          · exact b2_48 i (by omega) (by omega)
          · exact b2_72 i (by omega) (by omega)
      · by_cases cut : i < 144
        · by_cases cut : i < 120
          · exact b2_96 i (by omega) (by omega)
          · exact b2_120 i (by omega) (by omega)
        · by_cases cut : i < 168
          · exact b2_144 i (by omega) (by omega)
          · exact b2_168 i (by omega) (by omega)
    · by_cases cut : i < 288
      · by_cases cut : i < 240
        · by_cases cut : i < 216
          · exact b2_192 i (by omega) (by omega)
          · exact b2_216 i (by omega) (by omega)
        · by_cases cut : i < 264
          · exact b2_240 i (by omega) (by omega)
          · exact b2_264 i (by omega) (by omega)
      · by_cases cut : i < 336
        · by_cases cut : i < 312
          · exact b2_288 i (by omega) (by omega)
          · exact b2_312 i (by omega) (by omega)
        · by_cases cut : i < 360
          · exact b2_336 i (by omega) (by omega)
          · by_cases cut : i < 384
            · exact b2_360 i (by omega) (by omega)
            · exact b2_384 i (by omega) (by omega)
  simpa only [i,Fin.getElem_fin,Array.getElem?_eq_getElem idx.isLt,Option.getD_some] using ok
private theorem z1 : Closed dict 12 l1 := by
  apply prior _ _ _ _ _ z2
  intro idx
  let i := idx.val
  have bound : i < 33 := by exact idx.isLt
  have ok : localCheck dict 11 (l1[i]?.getD default) l2 = true := by
    by_cases cut : i < 24
    · exact b1_0 i (by omega) (by omega)
    · exact b1_24 i (by omega) (by omega)
  simpa only [i,Fin.getElem_fin,Array.getElem?_eq_getElem idx.isLt,Option.getD_some] using ok
private theorem z0 : Closed dict 13 l0 := by
  apply prior _ _ _ _ _ z1
  intro idx
  let i := idx.val
  have bound : i < 1 := by exact idx.isLt
  have ok : localCheck dict 12 (l0[i]?.getD default) l1 = true := by
    exact b0_0 i (by omega) (by omega)
  simpa only [i,Fin.getElem_fin,Array.getElem?_eq_getElem idx.isLt,Option.getD_some] using ok
private theorem root_eq : decodeNode dict l0[0] = (Checkpoint120.Pair.words 8, Checkpoint121.Pairs.budget 8) := by decide +kernel
theorem excluded : ¬ PEqualNP.Outside.L_meta_274_aux.NatRun Petersen1676.Table.allMask Petersen1676.Table.goal 13 (Checkpoint120.Pair.words 8) := by
  have h := z0 ⟨0,by decide +kernel⟩
  change Petersen1676.PinRules.Invariant _ _ _ (decodeNode dict l0[0]).1 (decodeNode dict l0[0]).2 → ¬ PEqualNP.Outside.L_meta_274_aux.NatRun _ _ 13 (decodeNode dict l0[0]).1 at h
  rw [root_eq] at h
  exact h (Checkpoint121.Pairs.valid _)
#print axioms excluded
end Checkpoint121.Pairs.M132
