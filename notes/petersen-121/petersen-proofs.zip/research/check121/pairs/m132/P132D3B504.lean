import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_504 : chunk dict 9 l3 l4 504 4 = true := by decide +kernel
private theorem c3_508 : chunk dict 9 l3 l4 508 4 = true := by decide +kernel
private theorem c3_512 : chunk dict 9 l3 l4 512 4 = true := by decide +kernel
private theorem c3_516 : chunk dict 9 l3 l4 516 4 = true := by decide +kernel
private theorem c3_520 : chunk dict 9 l3 l4 520 4 = true := by decide +kernel
private theorem c3_524 : chunk dict 9 l3 l4 524 4 = true := by decide +kernel
theorem b3_504 (i : Nat) (lo : 504 ≤ i) (hi : i < 528) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 516
  · by_cases cut : i < 508
    · exact fromChunk c3_504 (by omega) (by omega)
    · by_cases cut : i < 512
      · exact fromChunk c3_508 (by omega) (by omega)
      · exact fromChunk c3_512 (by omega) (by omega)
  · by_cases cut : i < 520
    · exact fromChunk c3_516 (by omega) (by omega)
    · by_cases cut : i < 524
      · exact fromChunk c3_520 (by omega) (by omega)
      · exact fromChunk c3_524 (by omega) (by omega)
end Checkpoint121.Pairs.M132
