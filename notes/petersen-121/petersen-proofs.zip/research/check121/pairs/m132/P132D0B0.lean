import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c0_0 : chunk dict 12 l0 l1 0 1 = true := by decide +kernel
theorem b0_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 1) : localCheck dict 12 (l0[i]?.getD default) l1 = true := by
  exact fromChunk c0_0 (by omega) (by omega)
end Checkpoint121.Pairs.M132
