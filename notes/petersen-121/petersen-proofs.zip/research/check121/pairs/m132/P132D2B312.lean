import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_312 : chunk dict 10 l2 l3 312 4 = true := by decide +kernel
private theorem c2_316 : chunk dict 10 l2 l3 316 4 = true := by decide +kernel
private theorem c2_320 : chunk dict 10 l2 l3 320 4 = true := by decide +kernel
private theorem c2_324 : chunk dict 10 l2 l3 324 4 = true := by decide +kernel
private theorem c2_328 : chunk dict 10 l2 l3 328 4 = true := by decide +kernel
private theorem c2_332 : chunk dict 10 l2 l3 332 4 = true := by decide +kernel
theorem b2_312 (i : Nat) (lo : 312 ≤ i) (hi : i < 336) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 324
  · by_cases cut : i < 316
    · exact fromChunk c2_312 (by omega) (by omega)
    · by_cases cut : i < 320
      · exact fromChunk c2_316 (by omega) (by omega)
      · exact fromChunk c2_320 (by omega) (by omega)
  · by_cases cut : i < 328
    · exact fromChunk c2_324 (by omega) (by omega)
    · by_cases cut : i < 332
      · exact fromChunk c2_328 (by omega) (by omega)
      · exact fromChunk c2_332 (by omega) (by omega)
end Checkpoint121.Pairs.M132
