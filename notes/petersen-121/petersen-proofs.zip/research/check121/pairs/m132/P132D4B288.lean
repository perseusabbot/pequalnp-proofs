import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_288 : chunk dict 8 l4 l5 288 4 = true := by decide +kernel
private theorem c4_292 : chunk dict 8 l4 l5 292 4 = true := by decide +kernel
private theorem c4_296 : chunk dict 8 l4 l5 296 4 = true := by decide +kernel
private theorem c4_300 : chunk dict 8 l4 l5 300 4 = true := by decide +kernel
private theorem c4_304 : chunk dict 8 l4 l5 304 4 = true := by decide +kernel
private theorem c4_308 : chunk dict 8 l4 l5 308 4 = true := by decide +kernel
theorem b4_288 (i : Nat) (lo : 288 ≤ i) (hi : i < 312) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 300
  · by_cases cut : i < 292
    · exact fromChunk c4_288 (by omega) (by omega)
    · by_cases cut : i < 296
      · exact fromChunk c4_292 (by omega) (by omega)
      · exact fromChunk c4_296 (by omega) (by omega)
  · by_cases cut : i < 304
    · exact fromChunk c4_300 (by omega) (by omega)
    · by_cases cut : i < 308
      · exact fromChunk c4_304 (by omega) (by omega)
      · exact fromChunk c4_308 (by omega) (by omega)
end Checkpoint121.Pairs.M132
