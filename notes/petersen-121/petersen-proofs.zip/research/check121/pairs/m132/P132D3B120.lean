import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_120 : chunk dict 9 l3 l4 120 4 = true := by decide +kernel
private theorem c3_124 : chunk dict 9 l3 l4 124 4 = true := by decide +kernel
private theorem c3_128 : chunk dict 9 l3 l4 128 4 = true := by decide +kernel
private theorem c3_132 : chunk dict 9 l3 l4 132 4 = true := by decide +kernel
private theorem c3_136 : chunk dict 9 l3 l4 136 4 = true := by decide +kernel
private theorem c3_140 : chunk dict 9 l3 l4 140 4 = true := by decide +kernel
theorem b3_120 (i : Nat) (lo : 120 ≤ i) (hi : i < 144) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 132
  · by_cases cut : i < 124
    · exact fromChunk c3_120 (by omega) (by omega)
    · by_cases cut : i < 128
      · exact fromChunk c3_124 (by omega) (by omega)
      · exact fromChunk c3_128 (by omega) (by omega)
  · by_cases cut : i < 136
    · exact fromChunk c3_132 (by omega) (by omega)
    · by_cases cut : i < 140
      · exact fromChunk c3_136 (by omega) (by omega)
      · exact fromChunk c3_140 (by omega) (by omega)
end Checkpoint121.Pairs.M132
