import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_120 : chunk dict 8 l4 l5 120 4 = true := by decide +kernel
private theorem c4_124 : chunk dict 8 l4 l5 124 4 = true := by decide +kernel
private theorem c4_128 : chunk dict 8 l4 l5 128 4 = true := by decide +kernel
private theorem c4_132 : chunk dict 8 l4 l5 132 4 = true := by decide +kernel
private theorem c4_136 : chunk dict 8 l4 l5 136 4 = true := by decide +kernel
private theorem c4_140 : chunk dict 8 l4 l5 140 4 = true := by decide +kernel
theorem b4_120 (i : Nat) (lo : 120 ≤ i) (hi : i < 144) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 132
  · by_cases cut : i < 124
    · exact fromChunk c4_120 (by omega) (by omega)
    · by_cases cut : i < 128
      · exact fromChunk c4_124 (by omega) (by omega)
      · exact fromChunk c4_128 (by omega) (by omega)
  · by_cases cut : i < 136
    · exact fromChunk c4_132 (by omega) (by omega)
    · by_cases cut : i < 140
      · exact fromChunk c4_136 (by omega) (by omega)
      · exact fromChunk c4_140 (by omega) (by omega)
end Checkpoint121.Pairs.M132
