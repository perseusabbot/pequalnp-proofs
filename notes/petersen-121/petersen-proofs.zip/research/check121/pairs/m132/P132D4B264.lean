import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_264 : chunk dict 8 l4 l5 264 4 = true := by decide +kernel
private theorem c4_268 : chunk dict 8 l4 l5 268 4 = true := by decide +kernel
private theorem c4_272 : chunk dict 8 l4 l5 272 4 = true := by decide +kernel
private theorem c4_276 : chunk dict 8 l4 l5 276 4 = true := by decide +kernel
private theorem c4_280 : chunk dict 8 l4 l5 280 4 = true := by decide +kernel
private theorem c4_284 : chunk dict 8 l4 l5 284 4 = true := by decide +kernel
theorem b4_264 (i : Nat) (lo : 264 ≤ i) (hi : i < 288) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 276
  · by_cases cut : i < 268
    · exact fromChunk c4_264 (by omega) (by omega)
    · by_cases cut : i < 272
      · exact fromChunk c4_268 (by omega) (by omega)
      · exact fromChunk c4_272 (by omega) (by omega)
  · by_cases cut : i < 280
    · exact fromChunk c4_276 (by omega) (by omega)
    · by_cases cut : i < 284
      · exact fromChunk c4_280 (by omega) (by omega)
      · exact fromChunk c4_284 (by omega) (by omega)
end Checkpoint121.Pairs.M132
