import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_384 : chunk dict 10 l2 l3 384 4 = true := by decide +kernel
private theorem c2_388 : chunk dict 10 l2 l3 388 4 = true := by decide +kernel
private theorem c2_392 : chunk dict 10 l2 l3 392 4 = true := by decide +kernel
private theorem c2_396 : chunk dict 10 l2 l3 396 1 = true := by decide +kernel
theorem b2_384 (i : Nat) (lo : 384 ≤ i) (hi : i < 397) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 392
  · by_cases cut : i < 388
    · exact fromChunk c2_384 (by omega) (by omega)
    · exact fromChunk c2_388 (by omega) (by omega)
  · by_cases cut : i < 396
    · exact fromChunk c2_392 (by omega) (by omega)
    · exact fromChunk c2_396 (by omega) (by omega)
end Checkpoint121.Pairs.M132
