import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_456 : chunk dict 9 l3 l4 456 4 = true := by decide +kernel
private theorem c3_460 : chunk dict 9 l3 l4 460 4 = true := by decide +kernel
private theorem c3_464 : chunk dict 9 l3 l4 464 4 = true := by decide +kernel
private theorem c3_468 : chunk dict 9 l3 l4 468 4 = true := by decide +kernel
private theorem c3_472 : chunk dict 9 l3 l4 472 4 = true := by decide +kernel
private theorem c3_476 : chunk dict 9 l3 l4 476 4 = true := by decide +kernel
theorem b3_456 (i : Nat) (lo : 456 ≤ i) (hi : i < 480) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 468
  · by_cases cut : i < 460
    · exact fromChunk c3_456 (by omega) (by omega)
    · by_cases cut : i < 464
      · exact fromChunk c3_460 (by omega) (by omega)
      · exact fromChunk c3_464 (by omega) (by omega)
  · by_cases cut : i < 472
    · exact fromChunk c3_468 (by omega) (by omega)
    · by_cases cut : i < 476
      · exact fromChunk c3_472 (by omega) (by omega)
      · exact fromChunk c3_476 (by omega) (by omega)
end Checkpoint121.Pairs.M132
