import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_336 : chunk dict 10 l2 l3 336 4 = true := by decide +kernel
private theorem c2_340 : chunk dict 10 l2 l3 340 4 = true := by decide +kernel
private theorem c2_344 : chunk dict 10 l2 l3 344 4 = true := by decide +kernel
private theorem c2_348 : chunk dict 10 l2 l3 348 4 = true := by decide +kernel
private theorem c2_352 : chunk dict 10 l2 l3 352 4 = true := by decide +kernel
private theorem c2_356 : chunk dict 10 l2 l3 356 4 = true := by decide +kernel
theorem b2_336 (i : Nat) (lo : 336 ≤ i) (hi : i < 360) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 348
  · by_cases cut : i < 340
    · exact fromChunk c2_336 (by omega) (by omega)
    · by_cases cut : i < 344
      · exact fromChunk c2_340 (by omega) (by omega)
      · exact fromChunk c2_344 (by omega) (by omega)
  · by_cases cut : i < 352
    · exact fromChunk c2_348 (by omega) (by omega)
    · by_cases cut : i < 356
      · exact fromChunk c2_352 (by omega) (by omega)
      · exact fromChunk c2_356 (by omega) (by omega)
end Checkpoint121.Pairs.M132
