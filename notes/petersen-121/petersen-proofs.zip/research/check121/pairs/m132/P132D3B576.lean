import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_576 : chunk dict 9 l3 l4 576 4 = true := by decide +kernel
private theorem c3_580 : chunk dict 9 l3 l4 580 4 = true := by decide +kernel
private theorem c3_584 : chunk dict 9 l3 l4 584 4 = true := by decide +kernel
private theorem c3_588 : chunk dict 9 l3 l4 588 4 = true := by decide +kernel
private theorem c3_592 : chunk dict 9 l3 l4 592 4 = true := by decide +kernel
private theorem c3_596 : chunk dict 9 l3 l4 596 4 = true := by decide +kernel
theorem b3_576 (i : Nat) (lo : 576 ≤ i) (hi : i < 600) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 588
  · by_cases cut : i < 580
    · exact fromChunk c3_576 (by omega) (by omega)
    · by_cases cut : i < 584
      · exact fromChunk c3_580 (by omega) (by omega)
      · exact fromChunk c3_584 (by omega) (by omega)
  · by_cases cut : i < 592
    · exact fromChunk c3_588 (by omega) (by omega)
    · by_cases cut : i < 596
      · exact fromChunk c3_592 (by omega) (by omega)
      · exact fromChunk c3_596 (by omega) (by omega)
end Checkpoint121.Pairs.M132
