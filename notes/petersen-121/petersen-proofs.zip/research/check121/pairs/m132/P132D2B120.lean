import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_120 : chunk dict 10 l2 l3 120 4 = true := by decide +kernel
private theorem c2_124 : chunk dict 10 l2 l3 124 4 = true := by decide +kernel
private theorem c2_128 : chunk dict 10 l2 l3 128 4 = true := by decide +kernel
private theorem c2_132 : chunk dict 10 l2 l3 132 4 = true := by decide +kernel
private theorem c2_136 : chunk dict 10 l2 l3 136 4 = true := by decide +kernel
private theorem c2_140 : chunk dict 10 l2 l3 140 4 = true := by decide +kernel
theorem b2_120 (i : Nat) (lo : 120 ≤ i) (hi : i < 144) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 132
  · by_cases cut : i < 124
    · exact fromChunk c2_120 (by omega) (by omega)
    · by_cases cut : i < 128
      · exact fromChunk c2_124 (by omega) (by omega)
      · exact fromChunk c2_128 (by omega) (by omega)
  · by_cases cut : i < 136
    · exact fromChunk c2_132 (by omega) (by omega)
    · by_cases cut : i < 140
      · exact fromChunk c2_136 (by omega) (by omega)
      · exact fromChunk c2_140 (by omega) (by omega)
end Checkpoint121.Pairs.M132
