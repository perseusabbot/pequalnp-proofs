import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_192 : chunk dict 8 l4 l5 192 4 = true := by decide +kernel
private theorem c4_196 : chunk dict 8 l4 l5 196 4 = true := by decide +kernel
private theorem c4_200 : chunk dict 8 l4 l5 200 4 = true := by decide +kernel
private theorem c4_204 : chunk dict 8 l4 l5 204 4 = true := by decide +kernel
private theorem c4_208 : chunk dict 8 l4 l5 208 4 = true := by decide +kernel
private theorem c4_212 : chunk dict 8 l4 l5 212 4 = true := by decide +kernel
theorem b4_192 (i : Nat) (lo : 192 ≤ i) (hi : i < 216) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 204
  · by_cases cut : i < 196
    · exact fromChunk c4_192 (by omega) (by omega)
    · by_cases cut : i < 200
      · exact fromChunk c4_196 (by omega) (by omega)
      · exact fromChunk c4_200 (by omega) (by omega)
  · by_cases cut : i < 208
    · exact fromChunk c4_204 (by omega) (by omega)
    · by_cases cut : i < 212
      · exact fromChunk c4_208 (by omega) (by omega)
      · exact fromChunk c4_212 (by omega) (by omega)
end Checkpoint121.Pairs.M132
