import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_552 : chunk dict 9 l3 l4 552 4 = true := by decide +kernel
private theorem c3_556 : chunk dict 9 l3 l4 556 4 = true := by decide +kernel
private theorem c3_560 : chunk dict 9 l3 l4 560 4 = true := by decide +kernel
private theorem c3_564 : chunk dict 9 l3 l4 564 4 = true := by decide +kernel
private theorem c3_568 : chunk dict 9 l3 l4 568 4 = true := by decide +kernel
private theorem c3_572 : chunk dict 9 l3 l4 572 4 = true := by decide +kernel
theorem b3_552 (i : Nat) (lo : 552 ≤ i) (hi : i < 576) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 564
  · by_cases cut : i < 556
    · exact fromChunk c3_552 (by omega) (by omega)
    · by_cases cut : i < 560
      · exact fromChunk c3_556 (by omega) (by omega)
      · exact fromChunk c3_560 (by omega) (by omega)
  · by_cases cut : i < 568
    · exact fromChunk c3_564 (by omega) (by omega)
    · by_cases cut : i < 572
      · exact fromChunk c3_568 (by omega) (by omega)
      · exact fromChunk c3_572 (by omega) (by omega)
end Checkpoint121.Pairs.M132
