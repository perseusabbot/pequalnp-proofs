import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c1_24 : chunk dict 11 l1 l2 24 4 = true := by decide +kernel
private theorem c1_28 : chunk dict 11 l1 l2 28 4 = true := by decide +kernel
private theorem c1_32 : chunk dict 11 l1 l2 32 1 = true := by decide +kernel
theorem b1_24 (i : Nat) (lo : 24 ≤ i) (hi : i < 33) : localCheck dict 11 (l1[i]?.getD default) l2 = true := by
  by_cases cut : i < 28
  · exact fromChunk c1_24 (by omega) (by omega)
  · by_cases cut : i < 32
    · exact fromChunk c1_28 (by omega) (by omega)
    · exact fromChunk c1_32 (by omega) (by omega)
end Checkpoint121.Pairs.M132
