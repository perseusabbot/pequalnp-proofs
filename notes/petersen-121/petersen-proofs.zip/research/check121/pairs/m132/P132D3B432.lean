import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_432 : chunk dict 9 l3 l4 432 4 = true := by decide +kernel
private theorem c3_436 : chunk dict 9 l3 l4 436 4 = true := by decide +kernel
private theorem c3_440 : chunk dict 9 l3 l4 440 4 = true := by decide +kernel
private theorem c3_444 : chunk dict 9 l3 l4 444 4 = true := by decide +kernel
private theorem c3_448 : chunk dict 9 l3 l4 448 4 = true := by decide +kernel
private theorem c3_452 : chunk dict 9 l3 l4 452 4 = true := by decide +kernel
theorem b3_432 (i : Nat) (lo : 432 ≤ i) (hi : i < 456) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 444
  · by_cases cut : i < 436
    · exact fromChunk c3_432 (by omega) (by omega)
    · by_cases cut : i < 440
      · exact fromChunk c3_436 (by omega) (by omega)
      · exact fromChunk c3_440 (by omega) (by omega)
  · by_cases cut : i < 448
    · exact fromChunk c3_444 (by omega) (by omega)
    · by_cases cut : i < 452
      · exact fromChunk c3_448 (by omega) (by omega)
      · exact fromChunk c3_452 (by omega) (by omega)
end Checkpoint121.Pairs.M132
