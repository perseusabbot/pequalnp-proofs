import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_240 : chunk dict 9 l3 l4 240 4 = true := by decide +kernel
private theorem c3_244 : chunk dict 9 l3 l4 244 4 = true := by decide +kernel
private theorem c3_248 : chunk dict 9 l3 l4 248 4 = true := by decide +kernel
private theorem c3_252 : chunk dict 9 l3 l4 252 4 = true := by decide +kernel
private theorem c3_256 : chunk dict 9 l3 l4 256 4 = true := by decide +kernel
private theorem c3_260 : chunk dict 9 l3 l4 260 4 = true := by decide +kernel
theorem b3_240 (i : Nat) (lo : 240 ≤ i) (hi : i < 264) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 252
  · by_cases cut : i < 244
    · exact fromChunk c3_240 (by omega) (by omega)
    · by_cases cut : i < 248
      · exact fromChunk c3_244 (by omega) (by omega)
      · exact fromChunk c3_248 (by omega) (by omega)
  · by_cases cut : i < 256
    · exact fromChunk c3_252 (by omega) (by omega)
    · by_cases cut : i < 260
      · exact fromChunk c3_256 (by omega) (by omega)
      · exact fromChunk c3_260 (by omega) (by omega)
end Checkpoint121.Pairs.M132
