import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c1_0 : chunk dict 11 l1 l2 0 4 = true := by decide +kernel
private theorem c1_4 : chunk dict 11 l1 l2 4 4 = true := by decide +kernel
private theorem c1_8 : chunk dict 11 l1 l2 8 4 = true := by decide +kernel
private theorem c1_12 : chunk dict 11 l1 l2 12 4 = true := by decide +kernel
private theorem c1_16 : chunk dict 11 l1 l2 16 4 = true := by decide +kernel
private theorem c1_20 : chunk dict 11 l1 l2 20 4 = true := by decide +kernel
theorem b1_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 24) : localCheck dict 11 (l1[i]?.getD default) l2 = true := by
  by_cases cut : i < 12
  · by_cases cut : i < 4
    · exact fromChunk c1_0 (by omega) (by omega)
    · by_cases cut : i < 8
      · exact fromChunk c1_4 (by omega) (by omega)
      · exact fromChunk c1_8 (by omega) (by omega)
  · by_cases cut : i < 16
    · exact fromChunk c1_12 (by omega) (by omega)
    · by_cases cut : i < 20
      · exact fromChunk c1_16 (by omega) (by omega)
      · exact fromChunk c1_20 (by omega) (by omega)
end Checkpoint121.Pairs.M132
