import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_48 : chunk dict 10 l2 l3 48 4 = true := by decide +kernel
private theorem c2_52 : chunk dict 10 l2 l3 52 4 = true := by decide +kernel
private theorem c2_56 : chunk dict 10 l2 l3 56 4 = true := by decide +kernel
private theorem c2_60 : chunk dict 10 l2 l3 60 4 = true := by decide +kernel
private theorem c2_64 : chunk dict 10 l2 l3 64 4 = true := by decide +kernel
private theorem c2_68 : chunk dict 10 l2 l3 68 4 = true := by decide +kernel
theorem b2_48 (i : Nat) (lo : 48 ≤ i) (hi : i < 72) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 60
  · by_cases cut : i < 52
    · exact fromChunk c2_48 (by omega) (by omega)
    · by_cases cut : i < 56
      · exact fromChunk c2_52 (by omega) (by omega)
      · exact fromChunk c2_56 (by omega) (by omega)
  · by_cases cut : i < 64
    · exact fromChunk c2_60 (by omega) (by omega)
    · by_cases cut : i < 68
      · exact fromChunk c2_64 (by omega) (by omega)
      · exact fromChunk c2_68 (by omega) (by omega)
end Checkpoint121.Pairs.M132
