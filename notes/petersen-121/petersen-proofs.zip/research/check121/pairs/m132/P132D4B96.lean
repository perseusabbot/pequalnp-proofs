import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_96 : chunk dict 8 l4 l5 96 4 = true := by decide +kernel
private theorem c4_100 : chunk dict 8 l4 l5 100 4 = true := by decide +kernel
private theorem c4_104 : chunk dict 8 l4 l5 104 4 = true := by decide +kernel
private theorem c4_108 : chunk dict 8 l4 l5 108 4 = true := by decide +kernel
private theorem c4_112 : chunk dict 8 l4 l5 112 4 = true := by decide +kernel
private theorem c4_116 : chunk dict 8 l4 l5 116 4 = true := by decide +kernel
theorem b4_96 (i : Nat) (lo : 96 ≤ i) (hi : i < 120) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 108
  · by_cases cut : i < 100
    · exact fromChunk c4_96 (by omega) (by omega)
    · by_cases cut : i < 104
      · exact fromChunk c4_100 (by omega) (by omega)
      · exact fromChunk c4_104 (by omega) (by omega)
  · by_cases cut : i < 112
    · exact fromChunk c4_108 (by omega) (by omega)
    · by_cases cut : i < 116
      · exact fromChunk c4_112 (by omega) (by omega)
      · exact fromChunk c4_116 (by omega) (by omega)
end Checkpoint121.Pairs.M132
