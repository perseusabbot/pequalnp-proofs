import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_336 : chunk dict 8 l4 l5 336 4 = true := by decide +kernel
private theorem c4_340 : chunk dict 8 l4 l5 340 2 = true := by decide +kernel
theorem b4_336 (i : Nat) (lo : 336 ≤ i) (hi : i < 342) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 340
  · exact fromChunk c4_336 (by omega) (by omega)
  · exact fromChunk c4_340 (by omega) (by omega)
end Checkpoint121.Pairs.M132
