import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_24 : chunk dict 8 l4 l5 24 4 = true := by decide +kernel
private theorem c4_28 : chunk dict 8 l4 l5 28 4 = true := by decide +kernel
private theorem c4_32 : chunk dict 8 l4 l5 32 4 = true := by decide +kernel
private theorem c4_36 : chunk dict 8 l4 l5 36 4 = true := by decide +kernel
private theorem c4_40 : chunk dict 8 l4 l5 40 4 = true := by decide +kernel
private theorem c4_44 : chunk dict 8 l4 l5 44 4 = true := by decide +kernel
theorem b4_24 (i : Nat) (lo : 24 ≤ i) (hi : i < 48) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 36
  · by_cases cut : i < 28
    · exact fromChunk c4_24 (by omega) (by omega)
    · by_cases cut : i < 32
      · exact fromChunk c4_28 (by omega) (by omega)
      · exact fromChunk c4_32 (by omega) (by omega)
  · by_cases cut : i < 40
    · exact fromChunk c4_36 (by omega) (by omega)
    · by_cases cut : i < 44
      · exact fromChunk c4_40 (by omega) (by omega)
      · exact fromChunk c4_44 (by omega) (by omega)
end Checkpoint121.Pairs.M132
