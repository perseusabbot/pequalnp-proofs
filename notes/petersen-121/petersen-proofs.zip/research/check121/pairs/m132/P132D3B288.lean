import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_288 : chunk dict 9 l3 l4 288 4 = true := by decide +kernel
private theorem c3_292 : chunk dict 9 l3 l4 292 4 = true := by decide +kernel
private theorem c3_296 : chunk dict 9 l3 l4 296 4 = true := by decide +kernel
private theorem c3_300 : chunk dict 9 l3 l4 300 4 = true := by decide +kernel
private theorem c3_304 : chunk dict 9 l3 l4 304 4 = true := by decide +kernel
private theorem c3_308 : chunk dict 9 l3 l4 308 4 = true := by decide +kernel
theorem b3_288 (i : Nat) (lo : 288 ≤ i) (hi : i < 312) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 300
  · by_cases cut : i < 292
    · exact fromChunk c3_288 (by omega) (by omega)
    · by_cases cut : i < 296
      · exact fromChunk c3_292 (by omega) (by omega)
      · exact fromChunk c3_296 (by omega) (by omega)
  · by_cases cut : i < 304
    · exact fromChunk c3_300 (by omega) (by omega)
    · by_cases cut : i < 308
      · exact fromChunk c3_304 (by omega) (by omega)
      · exact fromChunk c3_308 (by omega) (by omega)
end Checkpoint121.Pairs.M132
