import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_360 : chunk dict 9 l3 l4 360 4 = true := by decide +kernel
private theorem c3_364 : chunk dict 9 l3 l4 364 4 = true := by decide +kernel
private theorem c3_368 : chunk dict 9 l3 l4 368 4 = true := by decide +kernel
private theorem c3_372 : chunk dict 9 l3 l4 372 4 = true := by decide +kernel
private theorem c3_376 : chunk dict 9 l3 l4 376 4 = true := by decide +kernel
private theorem c3_380 : chunk dict 9 l3 l4 380 4 = true := by decide +kernel
theorem b3_360 (i : Nat) (lo : 360 ≤ i) (hi : i < 384) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 372
  · by_cases cut : i < 364
    · exact fromChunk c3_360 (by omega) (by omega)
    · by_cases cut : i < 368
      · exact fromChunk c3_364 (by omega) (by omega)
      · exact fromChunk c3_368 (by omega) (by omega)
  · by_cases cut : i < 376
    · exact fromChunk c3_372 (by omega) (by omega)
    · by_cases cut : i < 380
      · exact fromChunk c3_376 (by omega) (by omega)
      · exact fromChunk c3_380 (by omega) (by omega)
end Checkpoint121.Pairs.M132
