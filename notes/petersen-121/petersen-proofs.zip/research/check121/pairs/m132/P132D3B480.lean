import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_480 : chunk dict 9 l3 l4 480 4 = true := by decide +kernel
private theorem c3_484 : chunk dict 9 l3 l4 484 4 = true := by decide +kernel
private theorem c3_488 : chunk dict 9 l3 l4 488 4 = true := by decide +kernel
private theorem c3_492 : chunk dict 9 l3 l4 492 4 = true := by decide +kernel
private theorem c3_496 : chunk dict 9 l3 l4 496 4 = true := by decide +kernel
private theorem c3_500 : chunk dict 9 l3 l4 500 4 = true := by decide +kernel
theorem b3_480 (i : Nat) (lo : 480 ≤ i) (hi : i < 504) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 492
  · by_cases cut : i < 484
    · exact fromChunk c3_480 (by omega) (by omega)
    · by_cases cut : i < 488
      · exact fromChunk c3_484 (by omega) (by omega)
      · exact fromChunk c3_488 (by omega) (by omega)
  · by_cases cut : i < 496
    · exact fromChunk c3_492 (by omega) (by omega)
    · by_cases cut : i < 500
      · exact fromChunk c3_496 (by omega) (by omega)
      · exact fromChunk c3_500 (by omega) (by omega)
end Checkpoint121.Pairs.M132
