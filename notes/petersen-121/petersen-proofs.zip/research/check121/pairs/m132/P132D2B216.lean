import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_216 : chunk dict 10 l2 l3 216 4 = true := by decide +kernel
private theorem c2_220 : chunk dict 10 l2 l3 220 4 = true := by decide +kernel
private theorem c2_224 : chunk dict 10 l2 l3 224 4 = true := by decide +kernel
private theorem c2_228 : chunk dict 10 l2 l3 228 4 = true := by decide +kernel
private theorem c2_232 : chunk dict 10 l2 l3 232 4 = true := by decide +kernel
private theorem c2_236 : chunk dict 10 l2 l3 236 4 = true := by decide +kernel
theorem b2_216 (i : Nat) (lo : 216 ≤ i) (hi : i < 240) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 228
  · by_cases cut : i < 220
    · exact fromChunk c2_216 (by omega) (by omega)
    · by_cases cut : i < 224
      · exact fromChunk c2_220 (by omega) (by omega)
      · exact fromChunk c2_224 (by omega) (by omega)
  · by_cases cut : i < 232
    · exact fromChunk c2_228 (by omega) (by omega)
    · by_cases cut : i < 236
      · exact fromChunk c2_232 (by omega) (by omega)
      · exact fromChunk c2_236 (by omega) (by omega)
end Checkpoint121.Pairs.M132
