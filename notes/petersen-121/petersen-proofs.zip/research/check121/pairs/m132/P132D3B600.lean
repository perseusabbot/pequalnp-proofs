import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_600 : chunk dict 9 l3 l4 600 1 = true := by decide +kernel
theorem b3_600 (i : Nat) (lo : 600 ≤ i) (hi : i < 601) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  exact fromChunk c3_600 (by omega) (by omega)
end Checkpoint121.Pairs.M132
