import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_240 : chunk dict 8 l4 l5 240 4 = true := by decide +kernel
private theorem c4_244 : chunk dict 8 l4 l5 244 4 = true := by decide +kernel
private theorem c4_248 : chunk dict 8 l4 l5 248 4 = true := by decide +kernel
private theorem c4_252 : chunk dict 8 l4 l5 252 4 = true := by decide +kernel
private theorem c4_256 : chunk dict 8 l4 l5 256 4 = true := by decide +kernel
private theorem c4_260 : chunk dict 8 l4 l5 260 4 = true := by decide +kernel
theorem b4_240 (i : Nat) (lo : 240 ≤ i) (hi : i < 264) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 252
  · by_cases cut : i < 244
    · exact fromChunk c4_240 (by omega) (by omega)
    · by_cases cut : i < 248
      · exact fromChunk c4_244 (by omega) (by omega)
      · exact fromChunk c4_248 (by omega) (by omega)
  · by_cases cut : i < 256
    · exact fromChunk c4_252 (by omega) (by omega)
    · by_cases cut : i < 260
      · exact fromChunk c4_256 (by omega) (by omega)
      · exact fromChunk c4_260 (by omega) (by omega)
end Checkpoint121.Pairs.M132
