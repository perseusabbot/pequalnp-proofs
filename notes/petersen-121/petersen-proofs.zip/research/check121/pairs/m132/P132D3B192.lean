import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_192 : chunk dict 9 l3 l4 192 4 = true := by decide +kernel
private theorem c3_196 : chunk dict 9 l3 l4 196 4 = true := by decide +kernel
private theorem c3_200 : chunk dict 9 l3 l4 200 4 = true := by decide +kernel
private theorem c3_204 : chunk dict 9 l3 l4 204 4 = true := by decide +kernel
private theorem c3_208 : chunk dict 9 l3 l4 208 4 = true := by decide +kernel
private theorem c3_212 : chunk dict 9 l3 l4 212 4 = true := by decide +kernel
theorem b3_192 (i : Nat) (lo : 192 ≤ i) (hi : i < 216) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 204
  · by_cases cut : i < 196
    · exact fromChunk c3_192 (by omega) (by omega)
    · by_cases cut : i < 200
      · exact fromChunk c3_196 (by omega) (by omega)
      · exact fromChunk c3_200 (by omega) (by omega)
  · by_cases cut : i < 208
    · exact fromChunk c3_204 (by omega) (by omega)
    · by_cases cut : i < 212
      · exact fromChunk c3_208 (by omega) (by omega)
      · exact fromChunk c3_212 (by omega) (by omega)
end Checkpoint121.Pairs.M132
