import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_168 : chunk dict 10 l2 l3 168 4 = true := by decide +kernel
private theorem c2_172 : chunk dict 10 l2 l3 172 4 = true := by decide +kernel
private theorem c2_176 : chunk dict 10 l2 l3 176 4 = true := by decide +kernel
private theorem c2_180 : chunk dict 10 l2 l3 180 4 = true := by decide +kernel
private theorem c2_184 : chunk dict 10 l2 l3 184 4 = true := by decide +kernel
private theorem c2_188 : chunk dict 10 l2 l3 188 4 = true := by decide +kernel
theorem b2_168 (i : Nat) (lo : 168 ≤ i) (hi : i < 192) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 180
  · by_cases cut : i < 172
    · exact fromChunk c2_168 (by omega) (by omega)
    · by_cases cut : i < 176
      · exact fromChunk c2_172 (by omega) (by omega)
      · exact fromChunk c2_176 (by omega) (by omega)
  · by_cases cut : i < 184
    · exact fromChunk c2_180 (by omega) (by omega)
    · by_cases cut : i < 188
      · exact fromChunk c2_184 (by omega) (by omega)
      · exact fromChunk c2_188 (by omega) (by omega)
end Checkpoint121.Pairs.M132
