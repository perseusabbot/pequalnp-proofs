import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_168 : chunk dict 8 l4 l5 168 4 = true := by decide +kernel
private theorem c4_172 : chunk dict 8 l4 l5 172 4 = true := by decide +kernel
private theorem c4_176 : chunk dict 8 l4 l5 176 4 = true := by decide +kernel
private theorem c4_180 : chunk dict 8 l4 l5 180 4 = true := by decide +kernel
private theorem c4_184 : chunk dict 8 l4 l5 184 4 = true := by decide +kernel
private theorem c4_188 : chunk dict 8 l4 l5 188 4 = true := by decide +kernel
theorem b4_168 (i : Nat) (lo : 168 ≤ i) (hi : i < 192) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 180
  · by_cases cut : i < 172
    · exact fromChunk c4_168 (by omega) (by omega)
    · by_cases cut : i < 176
      · exact fromChunk c4_172 (by omega) (by omega)
      · exact fromChunk c4_176 (by omega) (by omega)
  · by_cases cut : i < 184
    · exact fromChunk c4_180 (by omega) (by omega)
    · by_cases cut : i < 188
      · exact fromChunk c4_184 (by omega) (by omega)
      · exact fromChunk c4_188 (by omega) (by omega)
end Checkpoint121.Pairs.M132
