import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_72 : chunk dict 10 l2 l3 72 4 = true := by decide +kernel
private theorem c2_76 : chunk dict 10 l2 l3 76 4 = true := by decide +kernel
private theorem c2_80 : chunk dict 10 l2 l3 80 4 = true := by decide +kernel
private theorem c2_84 : chunk dict 10 l2 l3 84 4 = true := by decide +kernel
private theorem c2_88 : chunk dict 10 l2 l3 88 4 = true := by decide +kernel
private theorem c2_92 : chunk dict 10 l2 l3 92 4 = true := by decide +kernel
theorem b2_72 (i : Nat) (lo : 72 ≤ i) (hi : i < 96) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 84
  · by_cases cut : i < 76
    · exact fromChunk c2_72 (by omega) (by omega)
    · by_cases cut : i < 80
      · exact fromChunk c2_76 (by omega) (by omega)
      · exact fromChunk c2_80 (by omega) (by omega)
  · by_cases cut : i < 88
    · exact fromChunk c2_84 (by omega) (by omega)
    · by_cases cut : i < 92
      · exact fromChunk c2_88 (by omega) (by omega)
      · exact fromChunk c2_92 (by omega) (by omega)
end Checkpoint121.Pairs.M132
