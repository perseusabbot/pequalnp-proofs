import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_264 : chunk dict 10 l2 l3 264 4 = true := by decide +kernel
private theorem c2_268 : chunk dict 10 l2 l3 268 4 = true := by decide +kernel
private theorem c2_272 : chunk dict 10 l2 l3 272 4 = true := by decide +kernel
private theorem c2_276 : chunk dict 10 l2 l3 276 4 = true := by decide +kernel
private theorem c2_280 : chunk dict 10 l2 l3 280 4 = true := by decide +kernel
private theorem c2_284 : chunk dict 10 l2 l3 284 4 = true := by decide +kernel
theorem b2_264 (i : Nat) (lo : 264 ≤ i) (hi : i < 288) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 276
  · by_cases cut : i < 268
    · exact fromChunk c2_264 (by omega) (by omega)
    · by_cases cut : i < 272
      · exact fromChunk c2_268 (by omega) (by omega)
      · exact fromChunk c2_272 (by omega) (by omega)
  · by_cases cut : i < 280
    · exact fromChunk c2_276 (by omega) (by omega)
    · by_cases cut : i < 284
      · exact fromChunk c2_280 (by omega) (by omega)
      · exact fromChunk c2_284 (by omega) (by omega)
end Checkpoint121.Pairs.M132
