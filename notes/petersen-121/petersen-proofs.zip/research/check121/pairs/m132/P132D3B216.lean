import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_216 : chunk dict 9 l3 l4 216 4 = true := by decide +kernel
private theorem c3_220 : chunk dict 9 l3 l4 220 4 = true := by decide +kernel
private theorem c3_224 : chunk dict 9 l3 l4 224 4 = true := by decide +kernel
private theorem c3_228 : chunk dict 9 l3 l4 228 4 = true := by decide +kernel
private theorem c3_232 : chunk dict 9 l3 l4 232 4 = true := by decide +kernel
private theorem c3_236 : chunk dict 9 l3 l4 236 4 = true := by decide +kernel
theorem b3_216 (i : Nat) (lo : 216 ≤ i) (hi : i < 240) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 228
  · by_cases cut : i < 220
    · exact fromChunk c3_216 (by omega) (by omega)
    · by_cases cut : i < 224
      · exact fromChunk c3_220 (by omega) (by omega)
      · exact fromChunk c3_224 (by omega) (by omega)
  · by_cases cut : i < 232
    · exact fromChunk c3_228 (by omega) (by omega)
    · by_cases cut : i < 236
      · exact fromChunk c3_232 (by omega) (by omega)
      · exact fromChunk c3_236 (by omega) (by omega)
end Checkpoint121.Pairs.M132
