import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_264 : chunk dict 9 l3 l4 264 4 = true := by decide +kernel
private theorem c3_268 : chunk dict 9 l3 l4 268 4 = true := by decide +kernel
private theorem c3_272 : chunk dict 9 l3 l4 272 4 = true := by decide +kernel
private theorem c3_276 : chunk dict 9 l3 l4 276 4 = true := by decide +kernel
private theorem c3_280 : chunk dict 9 l3 l4 280 4 = true := by decide +kernel
private theorem c3_284 : chunk dict 9 l3 l4 284 4 = true := by decide +kernel
theorem b3_264 (i : Nat) (lo : 264 ≤ i) (hi : i < 288) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 276
  · by_cases cut : i < 268
    · exact fromChunk c3_264 (by omega) (by omega)
    · by_cases cut : i < 272
      · exact fromChunk c3_268 (by omega) (by omega)
      · exact fromChunk c3_272 (by omega) (by omega)
  · by_cases cut : i < 280
    · exact fromChunk c3_276 (by omega) (by omega)
    · by_cases cut : i < 284
      · exact fromChunk c3_280 (by omega) (by omega)
      · exact fromChunk c3_284 (by omega) (by omega)
end Checkpoint121.Pairs.M132
