import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_288 : chunk dict 10 l2 l3 288 4 = true := by decide +kernel
private theorem c2_292 : chunk dict 10 l2 l3 292 4 = true := by decide +kernel
private theorem c2_296 : chunk dict 10 l2 l3 296 4 = true := by decide +kernel
private theorem c2_300 : chunk dict 10 l2 l3 300 4 = true := by decide +kernel
private theorem c2_304 : chunk dict 10 l2 l3 304 4 = true := by decide +kernel
private theorem c2_308 : chunk dict 10 l2 l3 308 4 = true := by decide +kernel
theorem b2_288 (i : Nat) (lo : 288 ≤ i) (hi : i < 312) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 300
  · by_cases cut : i < 292
    · exact fromChunk c2_288 (by omega) (by omega)
    · by_cases cut : i < 296
      · exact fromChunk c2_292 (by omega) (by omega)
      · exact fromChunk c2_296 (by omega) (by omega)
  · by_cases cut : i < 304
    · exact fromChunk c2_300 (by omega) (by omega)
    · by_cases cut : i < 308
      · exact fromChunk c2_304 (by omega) (by omega)
      · exact fromChunk c2_308 (by omega) (by omega)
end Checkpoint121.Pairs.M132
