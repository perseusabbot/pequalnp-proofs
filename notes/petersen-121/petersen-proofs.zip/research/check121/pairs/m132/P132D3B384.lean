import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_384 : chunk dict 9 l3 l4 384 4 = true := by decide +kernel
private theorem c3_388 : chunk dict 9 l3 l4 388 4 = true := by decide +kernel
private theorem c3_392 : chunk dict 9 l3 l4 392 4 = true := by decide +kernel
private theorem c3_396 : chunk dict 9 l3 l4 396 4 = true := by decide +kernel
private theorem c3_400 : chunk dict 9 l3 l4 400 4 = true := by decide +kernel
private theorem c3_404 : chunk dict 9 l3 l4 404 4 = true := by decide +kernel
theorem b3_384 (i : Nat) (lo : 384 ≤ i) (hi : i < 408) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 396
  · by_cases cut : i < 388
    · exact fromChunk c3_384 (by omega) (by omega)
    · by_cases cut : i < 392
      · exact fromChunk c3_388 (by omega) (by omega)
      · exact fromChunk c3_392 (by omega) (by omega)
  · by_cases cut : i < 400
    · exact fromChunk c3_396 (by omega) (by omega)
    · by_cases cut : i < 404
      · exact fromChunk c3_400 (by omega) (by omega)
      · exact fromChunk c3_404 (by omega) (by omega)
end Checkpoint121.Pairs.M132
