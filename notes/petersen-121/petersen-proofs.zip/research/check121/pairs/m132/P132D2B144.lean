import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_144 : chunk dict 10 l2 l3 144 4 = true := by decide +kernel
private theorem c2_148 : chunk dict 10 l2 l3 148 4 = true := by decide +kernel
private theorem c2_152 : chunk dict 10 l2 l3 152 4 = true := by decide +kernel
private theorem c2_156 : chunk dict 10 l2 l3 156 4 = true := by decide +kernel
private theorem c2_160 : chunk dict 10 l2 l3 160 4 = true := by decide +kernel
private theorem c2_164 : chunk dict 10 l2 l3 164 4 = true := by decide +kernel
theorem b2_144 (i : Nat) (lo : 144 ≤ i) (hi : i < 168) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 156
  · by_cases cut : i < 148
    · exact fromChunk c2_144 (by omega) (by omega)
    · by_cases cut : i < 152
      · exact fromChunk c2_148 (by omega) (by omega)
      · exact fromChunk c2_152 (by omega) (by omega)
  · by_cases cut : i < 160
    · exact fromChunk c2_156 (by omega) (by omega)
    · by_cases cut : i < 164
      · exact fromChunk c2_160 (by omega) (by omega)
      · exact fromChunk c2_164 (by omega) (by omega)
end Checkpoint121.Pairs.M132
