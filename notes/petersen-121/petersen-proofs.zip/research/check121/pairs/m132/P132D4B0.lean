import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c4_0 : chunk dict 8 l4 l5 0 4 = true := by decide +kernel
private theorem c4_4 : chunk dict 8 l4 l5 4 4 = true := by decide +kernel
private theorem c4_8 : chunk dict 8 l4 l5 8 4 = true := by decide +kernel
private theorem c4_12 : chunk dict 8 l4 l5 12 4 = true := by decide +kernel
private theorem c4_16 : chunk dict 8 l4 l5 16 4 = true := by decide +kernel
private theorem c4_20 : chunk dict 8 l4 l5 20 4 = true := by decide +kernel
theorem b4_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 24) : localCheck dict 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut : i < 12
  · by_cases cut : i < 4
    · exact fromChunk c4_0 (by omega) (by omega)
    · by_cases cut : i < 8
      · exact fromChunk c4_4 (by omega) (by omega)
      · exact fromChunk c4_8 (by omega) (by omega)
  · by_cases cut : i < 16
    · exact fromChunk c4_12 (by omega) (by omega)
    · by_cases cut : i < 20
      · exact fromChunk c4_16 (by omega) (by omega)
      · exact fromChunk c4_20 (by omega) (by omega)
end Checkpoint121.Pairs.M132
