import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c2_360 : chunk dict 10 l2 l3 360 4 = true := by decide +kernel
private theorem c2_364 : chunk dict 10 l2 l3 364 4 = true := by decide +kernel
private theorem c2_368 : chunk dict 10 l2 l3 368 4 = true := by decide +kernel
private theorem c2_372 : chunk dict 10 l2 l3 372 4 = true := by decide +kernel
private theorem c2_376 : chunk dict 10 l2 l3 376 4 = true := by decide +kernel
private theorem c2_380 : chunk dict 10 l2 l3 380 4 = true := by decide +kernel
theorem b2_360 (i : Nat) (lo : 360 ≤ i) (hi : i < 384) : localCheck dict 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut : i < 372
  · by_cases cut : i < 364
    · exact fromChunk c2_360 (by omega) (by omega)
    · by_cases cut : i < 368
      · exact fromChunk c2_364 (by omega) (by omega)
      · exact fromChunk c2_368 (by omega) (by omega)
  · by_cases cut : i < 376
    · exact fromChunk c2_372 (by omega) (by omega)
    · by_cases cut : i < 380
      · exact fromChunk c2_376 (by omega) (by omega)
      · exact fromChunk c2_380 (by omega) (by omega)
end Checkpoint121.Pairs.M132
