import P132Data

open Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M132
private theorem c3_144 : chunk dict 9 l3 l4 144 4 = true := by decide +kernel
private theorem c3_148 : chunk dict 9 l3 l4 148 4 = true := by decide +kernel
private theorem c3_152 : chunk dict 9 l3 l4 152 4 = true := by decide +kernel
private theorem c3_156 : chunk dict 9 l3 l4 156 4 = true := by decide +kernel
private theorem c3_160 : chunk dict 9 l3 l4 160 4 = true := by decide +kernel
private theorem c3_164 : chunk dict 9 l3 l4 164 4 = true := by decide +kernel
theorem b3_144 (i : Nat) (lo : 144 ≤ i) (hi : i < 168) : localCheck dict 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut : i < 156
  · by_cases cut : i < 148
    · exact fromChunk c3_144 (by omega) (by omega)
    · by_cases cut : i < 152
      · exact fromChunk c3_148 (by omega) (by omega)
      · exact fromChunk c3_152 (by omega) (by omega)
  · by_cases cut : i < 160
    · exact fromChunk c3_156 (by omega) (by omega)
    · by_cases cut : i < 164
      · exact fromChunk c3_160 (by omega) (by omega)
      · exact fromChunk c3_164 (by omega) (by omega)
end Checkpoint121.Pairs.M132
