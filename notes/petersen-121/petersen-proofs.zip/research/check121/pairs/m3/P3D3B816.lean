import P3Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem c3_816 : batch dict 9 l3 l4 c3 816 4 = true := by decide +kernel
private theorem c3_820 : batch dict 9 l3 l4 c3 820 4 = true := by decide +kernel
private theorem c3_824 : batch dict 9 l3 l4 c3 824 4 = true := by decide +kernel
private theorem c3_828 : batch dict 9 l3 l4 c3 828 4 = true := by decide +kernel
private theorem c3_832 : batch dict 9 l3 l4 c3 832 4 = true := by decide +kernel
private theorem c3_836 : batch dict 9 l3 l4 c3 836 4 = true := by decide +kernel
private theorem c3_840 : batch dict 9 l3 l4 c3 840 4 = true := by decide +kernel
private theorem c3_844 : batch dict 9 l3 l4 c3 844 4 = true := by decide +kernel
private theorem c3_848 : batch dict 9 l3 l4 c3 848 4 = true := by decide +kernel
private theorem c3_852 : batch dict 9 l3 l4 c3 852 4 = true := by decide +kernel
private theorem c3_856 : batch dict 9 l3 l4 c3 856 4 = true := by decide +kernel
private theorem c3_860 : batch dict 9 l3 l4 c3 860 4 = true := by decide +kernel
theorem b3_816 (i : Nat) (lo : 816 ≤ i) (hi : i < 864) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 840
  · by_cases cut : i < 828
    · by_cases cut : i < 820
      · exact fromBatch c3_816 (by omega) (by omega)
      · by_cases cut : i < 824
        · exact fromBatch c3_820 (by omega) (by omega)
        · exact fromBatch c3_824 (by omega) (by omega)
    · by_cases cut : i < 832
      · exact fromBatch c3_828 (by omega) (by omega)
      · by_cases cut : i < 836
        · exact fromBatch c3_832 (by omega) (by omega)
        · exact fromBatch c3_836 (by omega) (by omega)
  · by_cases cut : i < 852
    · by_cases cut : i < 844
      · exact fromBatch c3_840 (by omega) (by omega)
      · by_cases cut : i < 848
        · exact fromBatch c3_844 (by omega) (by omega)
        · exact fromBatch c3_848 (by omega) (by omega)
    · by_cases cut : i < 856
      · exact fromBatch c3_852 (by omega) (by omega)
      · by_cases cut : i < 860
        · exact fromBatch c3_856 (by omega) (by omega)
        · exact fromBatch c3_860 (by omega) (by omega)
end Checkpoint121.Pairs.M3
