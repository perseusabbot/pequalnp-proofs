import P3Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem c2_576 : batch dict 10 l2 l3 c2 576 4 = true := by decide +kernel
private theorem c2_580 : batch dict 10 l2 l3 c2 580 4 = true := by decide +kernel
private theorem c2_584 : batch dict 10 l2 l3 c2 584 4 = true := by decide +kernel
private theorem c2_588 : batch dict 10 l2 l3 c2 588 4 = true := by decide +kernel
private theorem c2_592 : batch dict 10 l2 l3 c2 592 4 = true := by decide +kernel
private theorem c2_596 : batch dict 10 l2 l3 c2 596 4 = true := by decide +kernel
private theorem c2_600 : batch dict 10 l2 l3 c2 600 4 = true := by decide +kernel
private theorem c2_604 : batch dict 10 l2 l3 c2 604 4 = true := by decide +kernel
private theorem c2_608 : batch dict 10 l2 l3 c2 608 4 = true := by decide +kernel
private theorem c2_612 : batch dict 10 l2 l3 c2 612 4 = true := by decide +kernel
private theorem c2_616 : batch dict 10 l2 l3 c2 616 4 = true := by decide +kernel
private theorem c2_620 : batch dict 10 l2 l3 c2 620 4 = true := by decide +kernel
theorem b2_576 (i : Nat) (lo : 576 ≤ i) (hi : i < 624) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 600
  · by_cases cut : i < 588
    · by_cases cut : i < 580
      · exact fromBatch c2_576 (by omega) (by omega)
      · by_cases cut : i < 584
        · exact fromBatch c2_580 (by omega) (by omega)
        · exact fromBatch c2_584 (by omega) (by omega)
    · by_cases cut : i < 592
      · exact fromBatch c2_588 (by omega) (by omega)
      · by_cases cut : i < 596
        · exact fromBatch c2_592 (by omega) (by omega)
        · exact fromBatch c2_596 (by omega) (by omega)
  · by_cases cut : i < 612
    · by_cases cut : i < 604
      · exact fromBatch c2_600 (by omega) (by omega)
      · by_cases cut : i < 608
        · exact fromBatch c2_604 (by omega) (by omega)
        · exact fromBatch c2_608 (by omega) (by omega)
    · by_cases cut : i < 616
      · exact fromBatch c2_612 (by omega) (by omega)
      · by_cases cut : i < 620
        · exact fromBatch c2_616 (by omega) (by omega)
        · exact fromBatch c2_620 (by omega) (by omega)
end Checkpoint121.Pairs.M3
