import P3Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem c3_912 : batch dict 9 l3 l4 c3 912 4 = true := by decide +kernel
private theorem c3_916 : batch dict 9 l3 l4 c3 916 4 = true := by decide +kernel
private theorem c3_920 : batch dict 9 l3 l4 c3 920 4 = true := by decide +kernel
private theorem c3_924 : batch dict 9 l3 l4 c3 924 4 = true := by decide +kernel
private theorem c3_928 : batch dict 9 l3 l4 c3 928 4 = true := by decide +kernel
private theorem c3_932 : batch dict 9 l3 l4 c3 932 4 = true := by decide +kernel
private theorem c3_936 : batch dict 9 l3 l4 c3 936 4 = true := by decide +kernel
private theorem c3_940 : batch dict 9 l3 l4 c3 940 4 = true := by decide +kernel
private theorem c3_944 : batch dict 9 l3 l4 c3 944 4 = true := by decide +kernel
private theorem c3_948 : batch dict 9 l3 l4 c3 948 4 = true := by decide +kernel
private theorem c3_952 : batch dict 9 l3 l4 c3 952 4 = true := by decide +kernel
private theorem c3_956 : batch dict 9 l3 l4 c3 956 4 = true := by decide +kernel
theorem b3_912 (i : Nat) (lo : 912 ≤ i) (hi : i < 960) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 936
  · by_cases cut : i < 924
    · by_cases cut : i < 916
      · exact fromBatch c3_912 (by omega) (by omega)
      · by_cases cut : i < 920
        · exact fromBatch c3_916 (by omega) (by omega)
        · exact fromBatch c3_920 (by omega) (by omega)
    · by_cases cut : i < 928
      · exact fromBatch c3_924 (by omega) (by omega)
      · by_cases cut : i < 932
        · exact fromBatch c3_928 (by omega) (by omega)
        · exact fromBatch c3_932 (by omega) (by omega)
  · by_cases cut : i < 948
    · by_cases cut : i < 940
      · exact fromBatch c3_936 (by omega) (by omega)
      · by_cases cut : i < 944
        · exact fromBatch c3_940 (by omega) (by omega)
        · exact fromBatch c3_944 (by omega) (by omega)
    · by_cases cut : i < 952
      · exact fromBatch c3_948 (by omega) (by omega)
      · by_cases cut : i < 956
        · exact fromBatch c3_952 (by omega) (by omega)
        · exact fromBatch c3_956 (by omega) (by omega)
end Checkpoint121.Pairs.M3
