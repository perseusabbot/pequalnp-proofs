import P3Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem c2_384 : batch dict 10 l2 l3 c2 384 4 = true := by decide +kernel
private theorem c2_388 : batch dict 10 l2 l3 c2 388 4 = true := by decide +kernel
private theorem c2_392 : batch dict 10 l2 l3 c2 392 4 = true := by decide +kernel
private theorem c2_396 : batch dict 10 l2 l3 c2 396 4 = true := by decide +kernel
private theorem c2_400 : batch dict 10 l2 l3 c2 400 4 = true := by decide +kernel
private theorem c2_404 : batch dict 10 l2 l3 c2 404 4 = true := by decide +kernel
private theorem c2_408 : batch dict 10 l2 l3 c2 408 4 = true := by decide +kernel
private theorem c2_412 : batch dict 10 l2 l3 c2 412 4 = true := by decide +kernel
private theorem c2_416 : batch dict 10 l2 l3 c2 416 4 = true := by decide +kernel
private theorem c2_420 : batch dict 10 l2 l3 c2 420 4 = true := by decide +kernel
private theorem c2_424 : batch dict 10 l2 l3 c2 424 4 = true := by decide +kernel
private theorem c2_428 : batch dict 10 l2 l3 c2 428 4 = true := by decide +kernel
theorem b2_384 (i : Nat) (lo : 384 ≤ i) (hi : i < 432) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 408
  · by_cases cut : i < 396
    · by_cases cut : i < 388
      · exact fromBatch c2_384 (by omega) (by omega)
      · by_cases cut : i < 392
        · exact fromBatch c2_388 (by omega) (by omega)
        · exact fromBatch c2_392 (by omega) (by omega)
    · by_cases cut : i < 400
      · exact fromBatch c2_396 (by omega) (by omega)
      · by_cases cut : i < 404
        · exact fromBatch c2_400 (by omega) (by omega)
        · exact fromBatch c2_404 (by omega) (by omega)
  · by_cases cut : i < 420
    · by_cases cut : i < 412
      · exact fromBatch c2_408 (by omega) (by omega)
      · by_cases cut : i < 416
        · exact fromBatch c2_412 (by omega) (by omega)
        · exact fromBatch c2_416 (by omega) (by omega)
    · by_cases cut : i < 424
      · exact fromBatch c2_420 (by omega) (by omega)
      · by_cases cut : i < 428
        · exact fromBatch c2_424 (by omega) (by omega)
        · exact fromBatch c2_428 (by omega) (by omega)
end Checkpoint121.Pairs.M3
