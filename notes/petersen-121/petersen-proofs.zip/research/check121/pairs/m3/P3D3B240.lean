import P3Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem c3_240 : batch dict 9 l3 l4 c3 240 4 = true := by decide +kernel
private theorem c3_244 : batch dict 9 l3 l4 c3 244 4 = true := by decide +kernel
private theorem c3_248 : batch dict 9 l3 l4 c3 248 4 = true := by decide +kernel
private theorem c3_252 : batch dict 9 l3 l4 c3 252 4 = true := by decide +kernel
private theorem c3_256 : batch dict 9 l3 l4 c3 256 4 = true := by decide +kernel
private theorem c3_260 : batch dict 9 l3 l4 c3 260 4 = true := by decide +kernel
private theorem c3_264 : batch dict 9 l3 l4 c3 264 4 = true := by decide +kernel
private theorem c3_268 : batch dict 9 l3 l4 c3 268 4 = true := by decide +kernel
private theorem c3_272 : batch dict 9 l3 l4 c3 272 4 = true := by decide +kernel
private theorem c3_276 : batch dict 9 l3 l4 c3 276 4 = true := by decide +kernel
private theorem c3_280 : batch dict 9 l3 l4 c3 280 4 = true := by decide +kernel
private theorem c3_284 : batch dict 9 l3 l4 c3 284 4 = true := by decide +kernel
theorem b3_240 (i : Nat) (lo : 240 ≤ i) (hi : i < 288) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 264
  · by_cases cut : i < 252
    · by_cases cut : i < 244
      · exact fromBatch c3_240 (by omega) (by omega)
      · by_cases cut : i < 248
        · exact fromBatch c3_244 (by omega) (by omega)
        · exact fromBatch c3_248 (by omega) (by omega)
    · by_cases cut : i < 256
      · exact fromBatch c3_252 (by omega) (by omega)
      · by_cases cut : i < 260
        · exact fromBatch c3_256 (by omega) (by omega)
        · exact fromBatch c3_260 (by omega) (by omega)
  · by_cases cut : i < 276
    · by_cases cut : i < 268
      · exact fromBatch c3_264 (by omega) (by omega)
      · by_cases cut : i < 272
        · exact fromBatch c3_268 (by omega) (by omega)
        · exact fromBatch c3_272 (by omega) (by omega)
    · by_cases cut : i < 280
      · exact fromBatch c3_276 (by omega) (by omega)
      · by_cases cut : i < 284
        · exact fromBatch c3_280 (by omega) (by omega)
        · exact fromBatch c3_284 (by omega) (by omega)
end Checkpoint121.Pairs.M3
