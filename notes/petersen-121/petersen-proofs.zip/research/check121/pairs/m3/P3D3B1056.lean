import P3Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem c3_1056 : batch dict 9 l3 l4 c3 1056 4 = true := by decide +kernel
private theorem c3_1060 : batch dict 9 l3 l4 c3 1060 4 = true := by decide +kernel
private theorem c3_1064 : batch dict 9 l3 l4 c3 1064 4 = true := by decide +kernel
private theorem c3_1068 : batch dict 9 l3 l4 c3 1068 4 = true := by decide +kernel
private theorem c3_1072 : batch dict 9 l3 l4 c3 1072 4 = true := by decide +kernel
private theorem c3_1076 : batch dict 9 l3 l4 c3 1076 4 = true := by decide +kernel
private theorem c3_1080 : batch dict 9 l3 l4 c3 1080 4 = true := by decide +kernel
private theorem c3_1084 : batch dict 9 l3 l4 c3 1084 4 = true := by decide +kernel
private theorem c3_1088 : batch dict 9 l3 l4 c3 1088 4 = true := by decide +kernel
private theorem c3_1092 : batch dict 9 l3 l4 c3 1092 4 = true := by decide +kernel
private theorem c3_1096 : batch dict 9 l3 l4 c3 1096 1 = true := by decide +kernel
theorem b3_1056 (i : Nat) (lo : 1056 ≤ i) (hi : i < 1097) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 1076
  · by_cases cut : i < 1064
    · by_cases cut : i < 1060
      · exact fromBatch c3_1056 (by omega) (by omega)
      · exact fromBatch c3_1060 (by omega) (by omega)
    · by_cases cut : i < 1068
      · exact fromBatch c3_1064 (by omega) (by omega)
      · by_cases cut : i < 1072
        · exact fromBatch c3_1068 (by omega) (by omega)
        · exact fromBatch c3_1072 (by omega) (by omega)
  · by_cases cut : i < 1088
    · by_cases cut : i < 1080
      · exact fromBatch c3_1076 (by omega) (by omega)
      · by_cases cut : i < 1084
        · exact fromBatch c3_1080 (by omega) (by omega)
        · exact fromBatch c3_1084 (by omega) (by omega)
    · by_cases cut : i < 1092
      · exact fromBatch c3_1088 (by omega) (by omega)
      · by_cases cut : i < 1096
        · exact fromBatch c3_1092 (by omega) (by omega)
        · exact fromBatch c3_1096 (by omega) (by omega)
end Checkpoint121.Pairs.M3
