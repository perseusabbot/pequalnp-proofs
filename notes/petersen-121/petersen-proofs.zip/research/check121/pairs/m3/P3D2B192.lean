import P3Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem c2_192 : batch dict 10 l2 l3 c2 192 4 = true := by decide +kernel
private theorem c2_196 : batch dict 10 l2 l3 c2 196 4 = true := by decide +kernel
private theorem c2_200 : batch dict 10 l2 l3 c2 200 4 = true := by decide +kernel
private theorem c2_204 : batch dict 10 l2 l3 c2 204 4 = true := by decide +kernel
private theorem c2_208 : batch dict 10 l2 l3 c2 208 4 = true := by decide +kernel
private theorem c2_212 : batch dict 10 l2 l3 c2 212 4 = true := by decide +kernel
private theorem c2_216 : batch dict 10 l2 l3 c2 216 4 = true := by decide +kernel
private theorem c2_220 : batch dict 10 l2 l3 c2 220 4 = true := by decide +kernel
private theorem c2_224 : batch dict 10 l2 l3 c2 224 4 = true := by decide +kernel
private theorem c2_228 : batch dict 10 l2 l3 c2 228 4 = true := by decide +kernel
private theorem c2_232 : batch dict 10 l2 l3 c2 232 4 = true := by decide +kernel
private theorem c2_236 : batch dict 10 l2 l3 c2 236 4 = true := by decide +kernel
theorem b2_192 (i : Nat) (lo : 192 ≤ i) (hi : i < 240) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 216
  · by_cases cut : i < 204
    · by_cases cut : i < 196
      · exact fromBatch c2_192 (by omega) (by omega)
      · by_cases cut : i < 200
        · exact fromBatch c2_196 (by omega) (by omega)
        · exact fromBatch c2_200 (by omega) (by omega)
    · by_cases cut : i < 208
      · exact fromBatch c2_204 (by omega) (by omega)
      · by_cases cut : i < 212
        · exact fromBatch c2_208 (by omega) (by omega)
        · exact fromBatch c2_212 (by omega) (by omega)
  · by_cases cut : i < 228
    · by_cases cut : i < 220
      · exact fromBatch c2_216 (by omega) (by omega)
      · by_cases cut : i < 224
        · exact fromBatch c2_220 (by omega) (by omega)
        · exact fromBatch c2_224 (by omega) (by omega)
    · by_cases cut : i < 232
      · exact fromBatch c2_228 (by omega) (by omega)
      · by_cases cut : i < 236
        · exact fromBatch c2_232 (by omega) (by omega)
        · exact fromBatch c2_236 (by omega) (by omega)
end Checkpoint121.Pairs.M3
