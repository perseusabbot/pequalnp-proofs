import P3D0B0
import P3D1B0
import P3D2B0
import P3D2B48
import P3D2B96
import P3D2B144
import P3D2B192
import P3D2B240
import P3D2B288
import P3D2B336
import P3D2B384
import P3D2B432
import P3D2B480
import P3D2B528
import P3D2B576
import P3D2B624
import P3D3B0
import P3D3B48
import P3D3B96
import P3D3B144
import P3D3B192
import P3D3B240
import P3D3B288
import P3D3B336
import P3D3B384
import P3D3B432
import P3D3B480
import P3D3B528
import P3D3B576
import P3D3B624
import P3D3B672
import P3D3B720
import P3D3B768
import P3D3B816
import P3D3B864
import P3D3B912
import P3D3B960
import P3D3B1008
import P3D3B1056
import P3D4B0
import P3D4B48
import P3D4B96
import P3D4B144
import P3D4B192
import P3D4B240
import P3D5B0

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem z6 : Closed dict 7 l6 := by
  intro i
  have lt := i.isLt
  change i.val < 0 at lt
  omega
private theorem z5 : Closed dict 8 l5 := by
  apply priorScored _ _ _ _ c5 _ z6
  intro idx
  let i := idx.val
  have bound : i < 13 := by exact idx.isLt
  have ok : checkRow dict 7 (l5[i]?.getD default) l6 (c5[i]?.getD 0) = true := by
    exact b5_0 i (by omega) (by omega)
  simpa only [i,Fin.getElem_fin,Array.getElem?_eq_getElem idx.isLt,Option.getD_some] using ok
private theorem z4 : Closed dict 9 l4 := by
  apply priorScored _ _ _ _ c4 _ z5
  intro idx
  let i := idx.val
  have bound : i < 252 := by exact idx.isLt
  have ok : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
    by_cases cut : i < 144
    · by_cases cut : i < 48
      · exact b4_0 i (by omega) (by omega)
      · by_cases cut : i < 96
        · exact b4_48 i (by omega) (by omega)
        · exact b4_96 i (by omega) (by omega)
    · by_cases cut : i < 192
      · exact b4_144 i (by omega) (by omega)
      · by_cases cut : i < 240
        · exact b4_192 i (by omega) (by omega)
        · exact b4_240 i (by omega) (by omega)
  simpa only [i,Fin.getElem_fin,Array.getElem?_eq_getElem idx.isLt,Option.getD_some] using ok
private theorem z3 : Closed dict 10 l3 := by
  apply priorScored _ _ _ _ c3 _ z4
  intro idx
  let i := idx.val
  have bound : i < 1097 := by exact idx.isLt
  have ok : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
    by_cases cut : i < 528
    · by_cases cut : i < 240
      · by_cases cut : i < 96
        · by_cases cut : i < 48
          · exact b3_0 i (by omega) (by omega)
          · exact b3_48 i (by omega) (by omega)
        · by_cases cut : i < 144
          · exact b3_96 i (by omega) (by omega)
          · by_cases cut : i < 192
            · exact b3_144 i (by omega) (by omega)
            · exact b3_192 i (by omega) (by omega)
      · by_cases cut : i < 384
        · by_cases cut : i < 288
          · exact b3_240 i (by omega) (by omega)
          · by_cases cut : i < 336
            · exact b3_288 i (by omega) (by omega)
            · exact b3_336 i (by omega) (by omega)
        · by_cases cut : i < 432
          · exact b3_384 i (by omega) (by omega)
          · by_cases cut : i < 480
            · exact b3_432 i (by omega) (by omega)
            · exact b3_480 i (by omega) (by omega)
    · by_cases cut : i < 816
      · by_cases cut : i < 672
        · by_cases cut : i < 576
          · exact b3_528 i (by omega) (by omega)
          · by_cases cut : i < 624
            · exact b3_576 i (by omega) (by omega)
            · exact b3_624 i (by omega) (by omega)
        · by_cases cut : i < 720
          · exact b3_672 i (by omega) (by omega)
          · by_cases cut : i < 768
            · exact b3_720 i (by omega) (by omega)
            · exact b3_768 i (by omega) (by omega)
      · by_cases cut : i < 960
        · by_cases cut : i < 864
          · exact b3_816 i (by omega) (by omega)
          · by_cases cut : i < 912
            · exact b3_864 i (by omega) (by omega)
            · exact b3_912 i (by omega) (by omega)
        · by_cases cut : i < 1008
          · exact b3_960 i (by omega) (by omega)
          · by_cases cut : i < 1056
            · exact b3_1008 i (by omega) (by omega)
            · exact b3_1056 i (by omega) (by omega)
  simpa only [i,Fin.getElem_fin,Array.getElem?_eq_getElem idx.isLt,Option.getD_some] using ok
private theorem z2 : Closed dict 11 l2 := by
  apply priorScored _ _ _ _ c2 _ z3
  intro idx
  let i := idx.val
  have bound : i < 671 := by exact idx.isLt
  have ok : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
    by_cases cut : i < 336
    · by_cases cut : i < 144
      · by_cases cut : i < 48
        · exact b2_0 i (by omega) (by omega)
        · by_cases cut : i < 96
          · exact b2_48 i (by omega) (by omega)
          · exact b2_96 i (by omega) (by omega)
      · by_cases cut : i < 240
        · by_cases cut : i < 192
          · exact b2_144 i (by omega) (by omega)
          · exact b2_192 i (by omega) (by omega)
        · by_cases cut : i < 288
          · exact b2_240 i (by omega) (by omega)
          · exact b2_288 i (by omega) (by omega)
    · by_cases cut : i < 480
      · by_cases cut : i < 384
        · exact b2_336 i (by omega) (by omega)
        · by_cases cut : i < 432
          · exact b2_384 i (by omega) (by omega)
          · exact b2_432 i (by omega) (by omega)
      · by_cases cut : i < 576
        · by_cases cut : i < 528
          · exact b2_480 i (by omega) (by omega)
          · exact b2_528 i (by omega) (by omega)
        · by_cases cut : i < 624
          · exact b2_576 i (by omega) (by omega)
          · exact b2_624 i (by omega) (by omega)
  simpa only [i,Fin.getElem_fin,Array.getElem?_eq_getElem idx.isLt,Option.getD_some] using ok
private theorem z1 : Closed dict 12 l1 := by
  apply priorScored _ _ _ _ c1 _ z2
  intro idx
  let i := idx.val
  have bound : i < 47 := by exact idx.isLt
  have ok : checkRow dict 11 (l1[i]?.getD default) l2 (c1[i]?.getD 0) = true := by
    exact b1_0 i (by omega) (by omega)
  simpa only [i,Fin.getElem_fin,Array.getElem?_eq_getElem idx.isLt,Option.getD_some] using ok
private theorem z0 : Closed dict 13 l0 := by
  apply priorScored _ _ _ _ c0 _ z1
  intro idx
  let i := idx.val
  have bound : i < 1 := by exact idx.isLt
  have ok : checkRow dict 12 (l0[i]?.getD default) l1 (c0[i]?.getD 0) = true := by
    exact b0_0 i (by omega) (by omega)
  simpa only [i,Fin.getElem_fin,Array.getElem?_eq_getElem idx.isLt,Option.getD_some] using ok
private theorem root_eq : decodeNode dict l0[0] = (Checkpoint120.Pair.words 0, Checkpoint121.Pairs.budget 0) := by decide +kernel
theorem excluded : ¬ PEqualNP.Outside.L_meta_274_aux.NatRun Petersen1676.Table.allMask Petersen1676.Table.goal 13 (Checkpoint120.Pair.words 0) := by
  have h := z0 ⟨0,by decide +kernel⟩
  change Petersen1676.PinRules.Invariant _ _ _ (decodeNode dict l0[0]).1 (decodeNode dict l0[0]).2 → ¬ PEqualNP.Outside.L_meta_274_aux.NatRun _ _ 13 (decodeNode dict l0[0]).1 at h
  rw [root_eq] at h
  exact h (Checkpoint121.Pairs.valid _)
#print axioms excluded
end Checkpoint121.Pairs.M3
