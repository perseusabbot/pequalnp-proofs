import P3Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem c4_144 : batch dict 8 l4 l5 c4 144 4 = true := by decide +kernel
private theorem c4_148 : batch dict 8 l4 l5 c4 148 4 = true := by decide +kernel
private theorem c4_152 : batch dict 8 l4 l5 c4 152 4 = true := by decide +kernel
private theorem c4_156 : batch dict 8 l4 l5 c4 156 4 = true := by decide +kernel
private theorem c4_160 : batch dict 8 l4 l5 c4 160 4 = true := by decide +kernel
private theorem c4_164 : batch dict 8 l4 l5 c4 164 4 = true := by decide +kernel
private theorem c4_168 : batch dict 8 l4 l5 c4 168 4 = true := by decide +kernel
private theorem c4_172 : batch dict 8 l4 l5 c4 172 4 = true := by decide +kernel
private theorem c4_176 : batch dict 8 l4 l5 c4 176 4 = true := by decide +kernel
private theorem c4_180 : batch dict 8 l4 l5 c4 180 4 = true := by decide +kernel
private theorem c4_184 : batch dict 8 l4 l5 c4 184 4 = true := by decide +kernel
private theorem c4_188 : batch dict 8 l4 l5 c4 188 4 = true := by decide +kernel
theorem b4_144 (i : Nat) (lo : 144 ≤ i) (hi : i < 192) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 168
  · by_cases cut : i < 156
    · by_cases cut : i < 148
      · exact fromBatch c4_144 (by omega) (by omega)
      · by_cases cut : i < 152
        · exact fromBatch c4_148 (by omega) (by omega)
        · exact fromBatch c4_152 (by omega) (by omega)
    · by_cases cut : i < 160
      · exact fromBatch c4_156 (by omega) (by omega)
      · by_cases cut : i < 164
        · exact fromBatch c4_160 (by omega) (by omega)
        · exact fromBatch c4_164 (by omega) (by omega)
  · by_cases cut : i < 180
    · by_cases cut : i < 172
      · exact fromBatch c4_168 (by omega) (by omega)
      · by_cases cut : i < 176
        · exact fromBatch c4_172 (by omega) (by omega)
        · exact fromBatch c4_176 (by omega) (by omega)
    · by_cases cut : i < 184
      · exact fromBatch c4_180 (by omega) (by omega)
      · by_cases cut : i < 188
        · exact fromBatch c4_184 (by omega) (by omega)
        · exact fromBatch c4_188 (by omega) (by omega)
end Checkpoint121.Pairs.M3
