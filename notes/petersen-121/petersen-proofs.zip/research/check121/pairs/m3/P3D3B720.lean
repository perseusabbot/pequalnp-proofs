import P3Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem c3_720 : batch dict 9 l3 l4 c3 720 4 = true := by decide +kernel
private theorem c3_724 : batch dict 9 l3 l4 c3 724 4 = true := by decide +kernel
private theorem c3_728 : batch dict 9 l3 l4 c3 728 4 = true := by decide +kernel
private theorem c3_732 : batch dict 9 l3 l4 c3 732 4 = true := by decide +kernel
private theorem c3_736 : batch dict 9 l3 l4 c3 736 4 = true := by decide +kernel
private theorem c3_740 : batch dict 9 l3 l4 c3 740 4 = true := by decide +kernel
private theorem c3_744 : batch dict 9 l3 l4 c3 744 4 = true := by decide +kernel
private theorem c3_748 : batch dict 9 l3 l4 c3 748 4 = true := by decide +kernel
private theorem c3_752 : batch dict 9 l3 l4 c3 752 4 = true := by decide +kernel
private theorem c3_756 : batch dict 9 l3 l4 c3 756 4 = true := by decide +kernel
private theorem c3_760 : batch dict 9 l3 l4 c3 760 4 = true := by decide +kernel
private theorem c3_764 : batch dict 9 l3 l4 c3 764 4 = true := by decide +kernel
theorem b3_720 (i : Nat) (lo : 720 ≤ i) (hi : i < 768) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 744
  · by_cases cut : i < 732
    · by_cases cut : i < 724
      · exact fromBatch c3_720 (by omega) (by omega)
      · by_cases cut : i < 728
        · exact fromBatch c3_724 (by omega) (by omega)
        · exact fromBatch c3_728 (by omega) (by omega)
    · by_cases cut : i < 736
      · exact fromBatch c3_732 (by omega) (by omega)
      · by_cases cut : i < 740
        · exact fromBatch c3_736 (by omega) (by omega)
        · exact fromBatch c3_740 (by omega) (by omega)
  · by_cases cut : i < 756
    · by_cases cut : i < 748
      · exact fromBatch c3_744 (by omega) (by omega)
      · by_cases cut : i < 752
        · exact fromBatch c3_748 (by omega) (by omega)
        · exact fromBatch c3_752 (by omega) (by omega)
    · by_cases cut : i < 760
      · exact fromBatch c3_756 (by omega) (by omega)
      · by_cases cut : i < 764
        · exact fromBatch c3_760 (by omega) (by omega)
        · exact fromBatch c3_764 (by omega) (by omega)
end Checkpoint121.Pairs.M3
