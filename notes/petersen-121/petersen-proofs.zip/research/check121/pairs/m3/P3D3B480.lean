import P3Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem c3_480 : batch dict 9 l3 l4 c3 480 4 = true := by decide +kernel
private theorem c3_484 : batch dict 9 l3 l4 c3 484 4 = true := by decide +kernel
private theorem c3_488 : batch dict 9 l3 l4 c3 488 4 = true := by decide +kernel
private theorem c3_492 : batch dict 9 l3 l4 c3 492 4 = true := by decide +kernel
private theorem c3_496 : batch dict 9 l3 l4 c3 496 4 = true := by decide +kernel
private theorem c3_500 : batch dict 9 l3 l4 c3 500 4 = true := by decide +kernel
private theorem c3_504 : batch dict 9 l3 l4 c3 504 4 = true := by decide +kernel
private theorem c3_508 : batch dict 9 l3 l4 c3 508 4 = true := by decide +kernel
private theorem c3_512 : batch dict 9 l3 l4 c3 512 4 = true := by decide +kernel
private theorem c3_516 : batch dict 9 l3 l4 c3 516 4 = true := by decide +kernel
private theorem c3_520 : batch dict 9 l3 l4 c3 520 4 = true := by decide +kernel
private theorem c3_524 : batch dict 9 l3 l4 c3 524 4 = true := by decide +kernel
theorem b3_480 (i : Nat) (lo : 480 ≤ i) (hi : i < 528) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 504
  · by_cases cut : i < 492
    · by_cases cut : i < 484
      · exact fromBatch c3_480 (by omega) (by omega)
      · by_cases cut : i < 488
        · exact fromBatch c3_484 (by omega) (by omega)
        · exact fromBatch c3_488 (by omega) (by omega)
    · by_cases cut : i < 496
      · exact fromBatch c3_492 (by omega) (by omega)
      · by_cases cut : i < 500
        · exact fromBatch c3_496 (by omega) (by omega)
        · exact fromBatch c3_500 (by omega) (by omega)
  · by_cases cut : i < 516
    · by_cases cut : i < 508
      · exact fromBatch c3_504 (by omega) (by omega)
      · by_cases cut : i < 512
        · exact fromBatch c3_508 (by omega) (by omega)
        · exact fromBatch c3_512 (by omega) (by omega)
    · by_cases cut : i < 520
      · exact fromBatch c3_516 (by omega) (by omega)
      · by_cases cut : i < 524
        · exact fromBatch c3_520 (by omega) (by omega)
        · exact fromBatch c3_524 (by omega) (by omega)
end Checkpoint121.Pairs.M3
