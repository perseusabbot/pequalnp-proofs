import P3Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem c4_240 : batch dict 8 l4 l5 c4 240 4 = true := by decide +kernel
private theorem c4_244 : batch dict 8 l4 l5 c4 244 4 = true := by decide +kernel
private theorem c4_248 : batch dict 8 l4 l5 c4 248 4 = true := by decide +kernel
theorem b4_240 (i : Nat) (lo : 240 ≤ i) (hi : i < 252) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 244
  · exact fromBatch c4_240 (by omega) (by omega)
  · by_cases cut : i < 248
    · exact fromBatch c4_244 (by omega) (by omega)
    · exact fromBatch c4_248 (by omega) (by omega)
end Checkpoint121.Pairs.M3
