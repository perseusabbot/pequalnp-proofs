import P3Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M3
private theorem c2_528 : batch dict 10 l2 l3 c2 528 4 = true := by decide +kernel
private theorem c2_532 : batch dict 10 l2 l3 c2 532 4 = true := by decide +kernel
private theorem c2_536 : batch dict 10 l2 l3 c2 536 4 = true := by decide +kernel
private theorem c2_540 : batch dict 10 l2 l3 c2 540 4 = true := by decide +kernel
private theorem c2_544 : batch dict 10 l2 l3 c2 544 4 = true := by decide +kernel
private theorem c2_548 : batch dict 10 l2 l3 c2 548 4 = true := by decide +kernel
private theorem c2_552 : batch dict 10 l2 l3 c2 552 4 = true := by decide +kernel
private theorem c2_556 : batch dict 10 l2 l3 c2 556 4 = true := by decide +kernel
private theorem c2_560 : batch dict 10 l2 l3 c2 560 4 = true := by decide +kernel
private theorem c2_564 : batch dict 10 l2 l3 c2 564 4 = true := by decide +kernel
private theorem c2_568 : batch dict 10 l2 l3 c2 568 4 = true := by decide +kernel
private theorem c2_572 : batch dict 10 l2 l3 c2 572 4 = true := by decide +kernel
theorem b2_528 (i : Nat) (lo : 528 ≤ i) (hi : i < 576) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 552
  · by_cases cut : i < 540
    · by_cases cut : i < 532
      · exact fromBatch c2_528 (by omega) (by omega)
      · by_cases cut : i < 536
        · exact fromBatch c2_532 (by omega) (by omega)
        · exact fromBatch c2_536 (by omega) (by omega)
    · by_cases cut : i < 544
      · exact fromBatch c2_540 (by omega) (by omega)
      · by_cases cut : i < 548
        · exact fromBatch c2_544 (by omega) (by omega)
        · exact fromBatch c2_548 (by omega) (by omega)
  · by_cases cut : i < 564
    · by_cases cut : i < 556
      · exact fromBatch c2_552 (by omega) (by omega)
      · by_cases cut : i < 560
        · exact fromBatch c2_556 (by omega) (by omega)
        · exact fromBatch c2_560 (by omega) (by omega)
    · by_cases cut : i < 568
      · exact fromBatch c2_564 (by omega) (by omega)
      · by_cases cut : i < 572
        · exact fromBatch c2_568 (by omega) (by omega)
        · exact fromBatch c2_572 (by omega) (by omega)
end Checkpoint121.Pairs.M3
