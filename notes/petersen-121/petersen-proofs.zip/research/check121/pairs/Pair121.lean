import PairChecks
import LayerCheck

namespace Checkpoint121.Pairs
open PEqualNP.Outside.L_meta_274_aux
open Petersen1676 Petersen1676.Table Petersen1676.Actual Petersen1676.Prune Petersen1676.PinRules
open Checkpoint120.Pair
open Petersen120
open Petersen1676.Search
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000

def extra (k : Fin 9) (q : Fin 4) : Item :=
  update raw (Table46.start true) (pairWord k) (Other.headItem q)

def budget (k : Fin 9) := items k ++ List.ofFn (extra k)

private theorem base (k : Fin 9) (q : Fin 4) : Valid allMask Table.goal raw (words k) (extra k q) := by
  have mem : ∀ i : Fin 9, rawWord i ∈ raw := by decide +kernel
  have start : Valid allMask Table.goal raw (Table46.start true) (Other.headItem q) := by
    apply headerValid (Triple.model q) (rawWord 4) (rawWord 6) (mem 4) (mem 6)
    simp [Table46.start,or_comm,Table46.header,rawWord]
  have edge : EdgeStep allMask (Table46.start true) (full k) := by
    constructor
    · apply Made.binary (a := rawWord (left k)) (b := rawWord (right k)) (conj := false)
      · simp [Table46.start,mem]
      · simp [Table46.start,mem]
    · intro w hw
      simpa [full] using hw
  obtain ⟨d,hd⟩ := advance_one start edge
  refine ⟨d,builtSubset hd ?_⟩
  have sub : ∀ (k : Fin 9), ∀ w ∈ words k, w ∈ full k := by decide +kernel
  intro f hf
  obtain ⟨w, hw, rfl⟩ := List.mem_map.mp hf
  exact List.mem_map_of_mem (sub k w hw)

theorem valid (k : Fin 9) : Invariant allMask Table.goal raw (words k) (budget k) := by
  intro it hi
  rcases List.mem_append.mp hi with old | more
  · exact invariant k it old
  · obtain ⟨q,rfl⟩ := List.mem_ofFn.mp more
    exact base k q

theorem physical (k : Fin 9) (excluded : ¬NatRun allMask Table.goal 13 (words k))
    (D : PEqualNP.CircuitLowerBounds.Circuit) (legal : PEqualNP.MetaComplexity.FanInTwo D)
    (spec : ∀ x, PEqualNP.MetaComplexity.circuitFun 11 D (extended k x) = PEqualNP.Outside.L_meta_3348_aux.FirstWireRun.edgeFn x) :
    14 ≤ D.size := by
  by_contra! cheap
  exact excluded (liveRun (by omega) legal spec)

#print axioms valid
#print axioms physical
end Checkpoint121.Pairs
