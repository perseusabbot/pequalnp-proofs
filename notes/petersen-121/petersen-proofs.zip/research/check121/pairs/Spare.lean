import Pair121

namespace Checkpoint121.Spare
open PEqualNP.Outside.L_meta_274_aux

/-- With only one gate above the binary-tree count, retaining a wire makes the
remaining run tight and positive. A NOT uses the spare gate itself. -/
theorem noOneSpare {m y s ws p n} (run : NatRun m y s ws) (cheap : s ≤ ws.length)
    (order : ∀ w ∈ ws, w.testBit p ≤ w.testBit n) (goal : ¬y.testBit p ≤ y.testBit n)
    (v : Nat → Nat) (neg : ∀ w, v (w ^^^ m) ≤ v w)
    (band : ∀ a b, v (a &&& b) ≤ v a + v b) (bor : ∀ a b, v (a ||| b) ≤ v a + v b)
    (short : (ws.map v).sum < v y) : False := by
  induction run using Run.fold with
  | done => exact goal (order _ (by simp))
  | perm hp _ ih =>
    exact ih (hp.length_eq ▸ cheap) (fun w hw => order _ (hp.mem_iff.mp hw)) ((hp.map v).sum_eq ▸ short)
  | @one s a rest save h ih =>
    have len := run_len h
    cases save <;> simp only [kept,Bool.false_eq_true,ite_false,ite_true,List.length_cons] at len cheap
    case true => omega
    case false =>
      have tight : ((a ^^^ m) :: kept false a rest).length=s+1 := by simp [kept]; omega
      have lb := score_bound h tight v band bor
      have cost := neg a
      simp only [kept,Bool.false_eq_true,ite_false,List.map_cons,List.sum_cons] at lb short
      omega
  | @two s a b rest op ka kb h ih =>
    let x := if op then a &&& b else a ||| b
    have ao := order a (by simp)
    have bo := order b (by simp)
    have xo : x.testBit p ≤ x.testBit n := by
      cases op <;> simp [x,Nat.testBit_or,Nat.testBit_and]
      · exact (show ∀ x y z t : Bool, x ≤ y → z ≤ t → (x || z) ≤ (y || t) by decide) _ _ _ _ ao bo
      · exact (show ∀ x y z t : Bool, x ≤ y → z ≤ t → (x && z) ≤ (y && t) by decide) _ _ _ _ ao bo
    have next : ∀ w ∈ x :: kept ka a (kept kb b rest), w.testBit p ≤ w.testBit n := by
      intro w hw
      cases ka <;> cases kb <;> simp [kept] at hw <;> grind
    have len := run_len h
    by_cases reused : ka || kb = true
    · have tight : (x :: kept ka a (kept kb b rest)).length=s+1 := by
        cases ka <;> cases kb <;> simp_all [kept,x] <;> omega
      exact goal (bits_le h tight p n next)
    · have ka0 : ka = false := by cases ka <;> simp_all
      have kb0 : kb = false := by cases kb <;> simp_all
      subst ka kb
      apply ih
      · simp only [kept,Bool.false_eq_true,ite_false,List.length_cons] at cheap ⊢; omega
      · exact next
      · have cost : v x ≤ v a+v b := by cases op <;> first | exact band a b | exact bor a b
        simp only [kept,Bool.false_eq_true,ite_false,List.map_cons,List.sum_cons] at short ⊢
        change v x + _ < v y
        omega

def signed (a b c d e f : Bool) : Nat :=
  max (value6 a b c d e f) (value6 (!a) (!b) (!c) (!d) (!e) (!f))

def sample (a b c d e f w : Nat) :=
  signed (w.testBit a) (w.testBit b) (w.testBit c) (w.testBit d) (w.testBit e) (w.testBit f)

private theorem sand : ∀ a b c d e f g h i j k l,
    signed (a && g) (b && h) (c && i) (d && j) (e && k) (f && l) ≤
      signed a b c d e f + signed g h i j k l := by decide +kernel
private theorem sor : ∀ a b c d e f g h i j k l,
    signed (a || g) (b || h) (c || i) (d || j) (e || k) (f || l) ≤
      signed a b c d e f + signed g h i j k l := by decide +kernel
private theorem snot : ∀ a b c d e f,
    signed (!a) (!b) (!c) (!d) (!e) (!f) = signed a b c d e f := by decide +kernel

theorem excluded {m y s ws p n a b c d e f} (mask : ∀ j ∈ [a,b,c,d,e,f], m.testBit j = true)
    (cheap : s ≤ ws.length) (order : ∀ w ∈ ws, w.testBit p ≤ w.testBit n)
    (goal : ¬y.testBit p ≤ y.testBit n)
    (short : (ws.map (sample a b c d e f)).sum < sample a b c d e f y) :
    ¬NatRun m y s ws := by
  intro run
  apply noOneSpare run cheap order goal _ _ _ _ short
  · intro w
    have ha := mask a (by simp)
    have hb := mask b (by simp)
    have hc := mask c (by simp)
    have hd := mask d (by simp)
    have he := mask e (by simp)
    have hf := mask f (by simp)
    simp [sample,Nat.testBit_xor,ha,hb,hc,hd,he,hf,snot]
  · intro u v
    simpa only [sample,Nat.testBit_and] using sand (u.testBit a) (u.testBit b)
      (u.testBit c) (u.testBit d) (u.testBit e) (u.testBit f) (v.testBit a)
      (v.testBit b) (v.testBit c) (v.testBit d) (v.testBit e) (v.testBit f)
  · intro u v
    simpa only [sample,Nat.testBit_or] using sor (u.testBit a) (u.testBit b)
      (u.testBit c) (u.testBit d) (u.testBit e) (u.testBit f) (v.testBit a)
      (v.testBit b) (v.testBit c) (v.testBit d) (v.testBit e) (v.testBit f)

#print axioms excluded
end Checkpoint121.Spare
