import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c4_192 : batch dict 8 l4 l5 c4 192 4 = true := by decide +kernel
private theorem c4_196 : batch dict 8 l4 l5 c4 196 4 = true := by decide +kernel
private theorem c4_200 : batch dict 8 l4 l5 c4 200 4 = true := by decide +kernel
private theorem c4_204 : batch dict 8 l4 l5 c4 204 4 = true := by decide +kernel
private theorem c4_208 : batch dict 8 l4 l5 c4 208 4 = true := by decide +kernel
private theorem c4_212 : batch dict 8 l4 l5 c4 212 4 = true := by decide +kernel
private theorem c4_216 : batch dict 8 l4 l5 c4 216 4 = true := by decide +kernel
private theorem c4_220 : batch dict 8 l4 l5 c4 220 4 = true := by decide +kernel
private theorem c4_224 : batch dict 8 l4 l5 c4 224 4 = true := by decide +kernel
private theorem c4_228 : batch dict 8 l4 l5 c4 228 4 = true := by decide +kernel
private theorem c4_232 : batch dict 8 l4 l5 c4 232 4 = true := by decide +kernel
private theorem c4_236 : batch dict 8 l4 l5 c4 236 4 = true := by decide +kernel
theorem b4_192 (i : Nat) (lo : 192 ≤ i) (hi : i < 240) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 216
  · by_cases cut : i < 204
    · by_cases cut : i < 196
      · exact fromBatch c4_192 (by omega) (by omega)
      · by_cases cut : i < 200
        · exact fromBatch c4_196 (by omega) (by omega)
        · exact fromBatch c4_200 (by omega) (by omega)
    · by_cases cut : i < 208
      · exact fromBatch c4_204 (by omega) (by omega)
      · by_cases cut : i < 212
        · exact fromBatch c4_208 (by omega) (by omega)
        · exact fromBatch c4_212 (by omega) (by omega)
  · by_cases cut : i < 228
    · by_cases cut : i < 220
      · exact fromBatch c4_216 (by omega) (by omega)
      · by_cases cut : i < 224
        · exact fromBatch c4_220 (by omega) (by omega)
        · exact fromBatch c4_224 (by omega) (by omega)
    · by_cases cut : i < 232
      · exact fromBatch c4_228 (by omega) (by omega)
      · by_cases cut : i < 236
        · exact fromBatch c4_232 (by omega) (by omega)
        · exact fromBatch c4_236 (by omega) (by omega)
end Checkpoint121.Pairs.M257
