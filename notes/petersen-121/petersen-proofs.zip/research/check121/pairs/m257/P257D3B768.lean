import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c3_768 : batch dict 9 l3 l4 c3 768 4 = true := by decide +kernel
private theorem c3_772 : batch dict 9 l3 l4 c3 772 4 = true := by decide +kernel
private theorem c3_776 : batch dict 9 l3 l4 c3 776 4 = true := by decide +kernel
private theorem c3_780 : batch dict 9 l3 l4 c3 780 4 = true := by decide +kernel
private theorem c3_784 : batch dict 9 l3 l4 c3 784 4 = true := by decide +kernel
private theorem c3_788 : batch dict 9 l3 l4 c3 788 4 = true := by decide +kernel
private theorem c3_792 : batch dict 9 l3 l4 c3 792 4 = true := by decide +kernel
private theorem c3_796 : batch dict 9 l3 l4 c3 796 4 = true := by decide +kernel
private theorem c3_800 : batch dict 9 l3 l4 c3 800 4 = true := by decide +kernel
private theorem c3_804 : batch dict 9 l3 l4 c3 804 4 = true := by decide +kernel
private theorem c3_808 : batch dict 9 l3 l4 c3 808 4 = true := by decide +kernel
private theorem c3_812 : batch dict 9 l3 l4 c3 812 4 = true := by decide +kernel
theorem b3_768 (i : Nat) (lo : 768 ≤ i) (hi : i < 816) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 792
  · by_cases cut : i < 780
    · by_cases cut : i < 772
      · exact fromBatch c3_768 (by omega) (by omega)
      · by_cases cut : i < 776
        · exact fromBatch c3_772 (by omega) (by omega)
        · exact fromBatch c3_776 (by omega) (by omega)
    · by_cases cut : i < 784
      · exact fromBatch c3_780 (by omega) (by omega)
      · by_cases cut : i < 788
        · exact fromBatch c3_784 (by omega) (by omega)
        · exact fromBatch c3_788 (by omega) (by omega)
  · by_cases cut : i < 804
    · by_cases cut : i < 796
      · exact fromBatch c3_792 (by omega) (by omega)
      · by_cases cut : i < 800
        · exact fromBatch c3_796 (by omega) (by omega)
        · exact fromBatch c3_800 (by omega) (by omega)
    · by_cases cut : i < 808
      · exact fromBatch c3_804 (by omega) (by omega)
      · by_cases cut : i < 812
        · exact fromBatch c3_808 (by omega) (by omega)
        · exact fromBatch c3_812 (by omega) (by omega)
end Checkpoint121.Pairs.M257
