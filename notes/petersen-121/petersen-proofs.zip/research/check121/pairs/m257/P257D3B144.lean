import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c3_144 : batch dict 9 l3 l4 c3 144 4 = true := by decide +kernel
private theorem c3_148 : batch dict 9 l3 l4 c3 148 4 = true := by decide +kernel
private theorem c3_152 : batch dict 9 l3 l4 c3 152 4 = true := by decide +kernel
private theorem c3_156 : batch dict 9 l3 l4 c3 156 4 = true := by decide +kernel
private theorem c3_160 : batch dict 9 l3 l4 c3 160 4 = true := by decide +kernel
private theorem c3_164 : batch dict 9 l3 l4 c3 164 4 = true := by decide +kernel
private theorem c3_168 : batch dict 9 l3 l4 c3 168 4 = true := by decide +kernel
private theorem c3_172 : batch dict 9 l3 l4 c3 172 4 = true := by decide +kernel
private theorem c3_176 : batch dict 9 l3 l4 c3 176 4 = true := by decide +kernel
private theorem c3_180 : batch dict 9 l3 l4 c3 180 4 = true := by decide +kernel
private theorem c3_184 : batch dict 9 l3 l4 c3 184 4 = true := by decide +kernel
private theorem c3_188 : batch dict 9 l3 l4 c3 188 4 = true := by decide +kernel
theorem b3_144 (i : Nat) (lo : 144 ≤ i) (hi : i < 192) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 168
  · by_cases cut : i < 156
    · by_cases cut : i < 148
      · exact fromBatch c3_144 (by omega) (by omega)
      · by_cases cut : i < 152
        · exact fromBatch c3_148 (by omega) (by omega)
        · exact fromBatch c3_152 (by omega) (by omega)
    · by_cases cut : i < 160
      · exact fromBatch c3_156 (by omega) (by omega)
      · by_cases cut : i < 164
        · exact fromBatch c3_160 (by omega) (by omega)
        · exact fromBatch c3_164 (by omega) (by omega)
  · by_cases cut : i < 180
    · by_cases cut : i < 172
      · exact fromBatch c3_168 (by omega) (by omega)
      · by_cases cut : i < 176
        · exact fromBatch c3_172 (by omega) (by omega)
        · exact fromBatch c3_176 (by omega) (by omega)
    · by_cases cut : i < 184
      · exact fromBatch c3_180 (by omega) (by omega)
      · by_cases cut : i < 188
        · exact fromBatch c3_184 (by omega) (by omega)
        · exact fromBatch c3_188 (by omega) (by omega)
end Checkpoint121.Pairs.M257
