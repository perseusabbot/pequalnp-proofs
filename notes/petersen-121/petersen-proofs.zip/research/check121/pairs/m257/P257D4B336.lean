import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c4_336 : batch dict 8 l4 l5 c4 336 4 = true := by decide +kernel
private theorem c4_340 : batch dict 8 l4 l5 c4 340 4 = true := by decide +kernel
private theorem c4_344 : batch dict 8 l4 l5 c4 344 4 = true := by decide +kernel
private theorem c4_348 : batch dict 8 l4 l5 c4 348 4 = true := by decide +kernel
private theorem c4_352 : batch dict 8 l4 l5 c4 352 4 = true := by decide +kernel
private theorem c4_356 : batch dict 8 l4 l5 c4 356 4 = true := by decide +kernel
private theorem c4_360 : batch dict 8 l4 l5 c4 360 4 = true := by decide +kernel
private theorem c4_364 : batch dict 8 l4 l5 c4 364 4 = true := by decide +kernel
private theorem c4_368 : batch dict 8 l4 l5 c4 368 4 = true := by decide +kernel
private theorem c4_372 : batch dict 8 l4 l5 c4 372 4 = true := by decide +kernel
private theorem c4_376 : batch dict 8 l4 l5 c4 376 4 = true := by decide +kernel
private theorem c4_380 : batch dict 8 l4 l5 c4 380 4 = true := by decide +kernel
theorem b4_336 (i : Nat) (lo : 336 ≤ i) (hi : i < 384) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 360
  · by_cases cut : i < 348
    · by_cases cut : i < 340
      · exact fromBatch c4_336 (by omega) (by omega)
      · by_cases cut : i < 344
        · exact fromBatch c4_340 (by omega) (by omega)
        · exact fromBatch c4_344 (by omega) (by omega)
    · by_cases cut : i < 352
      · exact fromBatch c4_348 (by omega) (by omega)
      · by_cases cut : i < 356
        · exact fromBatch c4_352 (by omega) (by omega)
        · exact fromBatch c4_356 (by omega) (by omega)
  · by_cases cut : i < 372
    · by_cases cut : i < 364
      · exact fromBatch c4_360 (by omega) (by omega)
      · by_cases cut : i < 368
        · exact fromBatch c4_364 (by omega) (by omega)
        · exact fromBatch c4_368 (by omega) (by omega)
    · by_cases cut : i < 376
      · exact fromBatch c4_372 (by omega) (by omega)
      · by_cases cut : i < 380
        · exact fromBatch c4_376 (by omega) (by omega)
        · exact fromBatch c4_380 (by omega) (by omega)
end Checkpoint121.Pairs.M257
