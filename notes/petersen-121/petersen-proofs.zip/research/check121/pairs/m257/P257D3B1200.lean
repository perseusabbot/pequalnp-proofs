import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c3_1200 : batch dict 9 l3 l4 c3 1200 4 = true := by decide +kernel
private theorem c3_1204 : batch dict 9 l3 l4 c3 1204 4 = true := by decide +kernel
private theorem c3_1208 : batch dict 9 l3 l4 c3 1208 4 = true := by decide +kernel
private theorem c3_1212 : batch dict 9 l3 l4 c3 1212 4 = true := by decide +kernel
private theorem c3_1216 : batch dict 9 l3 l4 c3 1216 4 = true := by decide +kernel
private theorem c3_1220 : batch dict 9 l3 l4 c3 1220 4 = true := by decide +kernel
private theorem c3_1224 : batch dict 9 l3 l4 c3 1224 4 = true := by decide +kernel
private theorem c3_1228 : batch dict 9 l3 l4 c3 1228 4 = true := by decide +kernel
private theorem c3_1232 : batch dict 9 l3 l4 c3 1232 4 = true := by decide +kernel
private theorem c3_1236 : batch dict 9 l3 l4 c3 1236 4 = true := by decide +kernel
private theorem c3_1240 : batch dict 9 l3 l4 c3 1240 4 = true := by decide +kernel
private theorem c3_1244 : batch dict 9 l3 l4 c3 1244 4 = true := by decide +kernel
theorem b3_1200 (i : Nat) (lo : 1200 ≤ i) (hi : i < 1248) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 1224
  · by_cases cut : i < 1212
    · by_cases cut : i < 1204
      · exact fromBatch c3_1200 (by omega) (by omega)
      · by_cases cut : i < 1208
        · exact fromBatch c3_1204 (by omega) (by omega)
        · exact fromBatch c3_1208 (by omega) (by omega)
    · by_cases cut : i < 1216
      · exact fromBatch c3_1212 (by omega) (by omega)
      · by_cases cut : i < 1220
        · exact fromBatch c3_1216 (by omega) (by omega)
        · exact fromBatch c3_1220 (by omega) (by omega)
  · by_cases cut : i < 1236
    · by_cases cut : i < 1228
      · exact fromBatch c3_1224 (by omega) (by omega)
      · by_cases cut : i < 1232
        · exact fromBatch c3_1228 (by omega) (by omega)
        · exact fromBatch c3_1232 (by omega) (by omega)
    · by_cases cut : i < 1240
      · exact fromBatch c3_1236 (by omega) (by omega)
      · by_cases cut : i < 1244
        · exact fromBatch c3_1240 (by omega) (by omega)
        · exact fromBatch c3_1244 (by omega) (by omega)
end Checkpoint121.Pairs.M257
