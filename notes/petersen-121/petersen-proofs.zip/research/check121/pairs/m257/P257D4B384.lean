import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c4_384 : batch dict 8 l4 l5 c4 384 4 = true := by decide +kernel
private theorem c4_388 : batch dict 8 l4 l5 c4 388 4 = true := by decide +kernel
private theorem c4_392 : batch dict 8 l4 l5 c4 392 4 = true := by decide +kernel
private theorem c4_396 : batch dict 8 l4 l5 c4 396 4 = true := by decide +kernel
private theorem c4_400 : batch dict 8 l4 l5 c4 400 4 = true := by decide +kernel
private theorem c4_404 : batch dict 8 l4 l5 c4 404 4 = true := by decide +kernel
private theorem c4_408 : batch dict 8 l4 l5 c4 408 4 = true := by decide +kernel
private theorem c4_412 : batch dict 8 l4 l5 c4 412 1 = true := by decide +kernel
theorem b4_384 (i : Nat) (lo : 384 ≤ i) (hi : i < 413) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 400
  · by_cases cut : i < 392
    · by_cases cut : i < 388
      · exact fromBatch c4_384 (by omega) (by omega)
      · exact fromBatch c4_388 (by omega) (by omega)
    · by_cases cut : i < 396
      · exact fromBatch c4_392 (by omega) (by omega)
      · exact fromBatch c4_396 (by omega) (by omega)
  · by_cases cut : i < 408
    · by_cases cut : i < 404
      · exact fromBatch c4_400 (by omega) (by omega)
      · exact fromBatch c4_404 (by omega) (by omega)
    · by_cases cut : i < 412
      · exact fromBatch c4_408 (by omega) (by omega)
      · exact fromBatch c4_412 (by omega) (by omega)
end Checkpoint121.Pairs.M257
