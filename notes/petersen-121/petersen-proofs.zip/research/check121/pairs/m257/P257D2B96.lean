import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c2_96 : batch dict 10 l2 l3 c2 96 4 = true := by decide +kernel
private theorem c2_100 : batch dict 10 l2 l3 c2 100 4 = true := by decide +kernel
private theorem c2_104 : batch dict 10 l2 l3 c2 104 4 = true := by decide +kernel
private theorem c2_108 : batch dict 10 l2 l3 c2 108 4 = true := by decide +kernel
private theorem c2_112 : batch dict 10 l2 l3 c2 112 4 = true := by decide +kernel
private theorem c2_116 : batch dict 10 l2 l3 c2 116 4 = true := by decide +kernel
private theorem c2_120 : batch dict 10 l2 l3 c2 120 4 = true := by decide +kernel
private theorem c2_124 : batch dict 10 l2 l3 c2 124 4 = true := by decide +kernel
private theorem c2_128 : batch dict 10 l2 l3 c2 128 4 = true := by decide +kernel
private theorem c2_132 : batch dict 10 l2 l3 c2 132 4 = true := by decide +kernel
private theorem c2_136 : batch dict 10 l2 l3 c2 136 4 = true := by decide +kernel
private theorem c2_140 : batch dict 10 l2 l3 c2 140 4 = true := by decide +kernel
theorem b2_96 (i : Nat) (lo : 96 ≤ i) (hi : i < 144) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 120
  · by_cases cut : i < 108
    · by_cases cut : i < 100
      · exact fromBatch c2_96 (by omega) (by omega)
      · by_cases cut : i < 104
        · exact fromBatch c2_100 (by omega) (by omega)
        · exact fromBatch c2_104 (by omega) (by omega)
    · by_cases cut : i < 112
      · exact fromBatch c2_108 (by omega) (by omega)
      · by_cases cut : i < 116
        · exact fromBatch c2_112 (by omega) (by omega)
        · exact fromBatch c2_116 (by omega) (by omega)
  · by_cases cut : i < 132
    · by_cases cut : i < 124
      · exact fromBatch c2_120 (by omega) (by omega)
      · by_cases cut : i < 128
        · exact fromBatch c2_124 (by omega) (by omega)
        · exact fromBatch c2_128 (by omega) (by omega)
    · by_cases cut : i < 136
      · exact fromBatch c2_132 (by omega) (by omega)
      · by_cases cut : i < 140
        · exact fromBatch c2_136 (by omega) (by omega)
        · exact fromBatch c2_140 (by omega) (by omega)
end Checkpoint121.Pairs.M257
