import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c3_1152 : batch dict 9 l3 l4 c3 1152 4 = true := by decide +kernel
private theorem c3_1156 : batch dict 9 l3 l4 c3 1156 4 = true := by decide +kernel
private theorem c3_1160 : batch dict 9 l3 l4 c3 1160 4 = true := by decide +kernel
private theorem c3_1164 : batch dict 9 l3 l4 c3 1164 4 = true := by decide +kernel
private theorem c3_1168 : batch dict 9 l3 l4 c3 1168 4 = true := by decide +kernel
private theorem c3_1172 : batch dict 9 l3 l4 c3 1172 4 = true := by decide +kernel
private theorem c3_1176 : batch dict 9 l3 l4 c3 1176 4 = true := by decide +kernel
private theorem c3_1180 : batch dict 9 l3 l4 c3 1180 4 = true := by decide +kernel
private theorem c3_1184 : batch dict 9 l3 l4 c3 1184 4 = true := by decide +kernel
private theorem c3_1188 : batch dict 9 l3 l4 c3 1188 4 = true := by decide +kernel
private theorem c3_1192 : batch dict 9 l3 l4 c3 1192 4 = true := by decide +kernel
private theorem c3_1196 : batch dict 9 l3 l4 c3 1196 4 = true := by decide +kernel
theorem b3_1152 (i : Nat) (lo : 1152 ≤ i) (hi : i < 1200) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 1176
  · by_cases cut : i < 1164
    · by_cases cut : i < 1156
      · exact fromBatch c3_1152 (by omega) (by omega)
      · by_cases cut : i < 1160
        · exact fromBatch c3_1156 (by omega) (by omega)
        · exact fromBatch c3_1160 (by omega) (by omega)
    · by_cases cut : i < 1168
      · exact fromBatch c3_1164 (by omega) (by omega)
      · by_cases cut : i < 1172
        · exact fromBatch c3_1168 (by omega) (by omega)
        · exact fromBatch c3_1172 (by omega) (by omega)
  · by_cases cut : i < 1188
    · by_cases cut : i < 1180
      · exact fromBatch c3_1176 (by omega) (by omega)
      · by_cases cut : i < 1184
        · exact fromBatch c3_1180 (by omega) (by omega)
        · exact fromBatch c3_1184 (by omega) (by omega)
    · by_cases cut : i < 1192
      · exact fromBatch c3_1188 (by omega) (by omega)
      · by_cases cut : i < 1196
        · exact fromBatch c3_1192 (by omega) (by omega)
        · exact fromBatch c3_1196 (by omega) (by omega)
end Checkpoint121.Pairs.M257
