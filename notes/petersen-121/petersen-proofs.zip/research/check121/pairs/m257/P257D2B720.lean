import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c2_720 : batch dict 10 l2 l3 c2 720 4 = true := by decide +kernel
private theorem c2_724 : batch dict 10 l2 l3 c2 724 4 = true := by decide +kernel
private theorem c2_728 : batch dict 10 l2 l3 c2 728 4 = true := by decide +kernel
private theorem c2_732 : batch dict 10 l2 l3 c2 732 4 = true := by decide +kernel
private theorem c2_736 : batch dict 10 l2 l3 c2 736 4 = true := by decide +kernel
private theorem c2_740 : batch dict 10 l2 l3 c2 740 4 = true := by decide +kernel
private theorem c2_744 : batch dict 10 l2 l3 c2 744 4 = true := by decide +kernel
private theorem c2_748 : batch dict 10 l2 l3 c2 748 1 = true := by decide +kernel
theorem b2_720 (i : Nat) (lo : 720 ≤ i) (hi : i < 749) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 736
  · by_cases cut : i < 728
    · by_cases cut : i < 724
      · exact fromBatch c2_720 (by omega) (by omega)
      · exact fromBatch c2_724 (by omega) (by omega)
    · by_cases cut : i < 732
      · exact fromBatch c2_728 (by omega) (by omega)
      · exact fromBatch c2_732 (by omega) (by omega)
  · by_cases cut : i < 744
    · by_cases cut : i < 740
      · exact fromBatch c2_736 (by omega) (by omega)
      · exact fromBatch c2_740 (by omega) (by omega)
    · by_cases cut : i < 748
      · exact fromBatch c2_744 (by omega) (by omega)
      · exact fromBatch c2_748 (by omega) (by omega)
end Checkpoint121.Pairs.M257
