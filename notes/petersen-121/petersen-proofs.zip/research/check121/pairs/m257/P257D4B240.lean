import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c4_240 : batch dict 8 l4 l5 c4 240 4 = true := by decide +kernel
private theorem c4_244 : batch dict 8 l4 l5 c4 244 4 = true := by decide +kernel
private theorem c4_248 : batch dict 8 l4 l5 c4 248 4 = true := by decide +kernel
private theorem c4_252 : batch dict 8 l4 l5 c4 252 4 = true := by decide +kernel
private theorem c4_256 : batch dict 8 l4 l5 c4 256 4 = true := by decide +kernel
private theorem c4_260 : batch dict 8 l4 l5 c4 260 4 = true := by decide +kernel
private theorem c4_264 : batch dict 8 l4 l5 c4 264 4 = true := by decide +kernel
private theorem c4_268 : batch dict 8 l4 l5 c4 268 4 = true := by decide +kernel
private theorem c4_272 : batch dict 8 l4 l5 c4 272 4 = true := by decide +kernel
private theorem c4_276 : batch dict 8 l4 l5 c4 276 4 = true := by decide +kernel
private theorem c4_280 : batch dict 8 l4 l5 c4 280 4 = true := by decide +kernel
private theorem c4_284 : batch dict 8 l4 l5 c4 284 4 = true := by decide +kernel
theorem b4_240 (i : Nat) (lo : 240 ≤ i) (hi : i < 288) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 264
  · by_cases cut : i < 252
    · by_cases cut : i < 244
      · exact fromBatch c4_240 (by omega) (by omega)
      · by_cases cut : i < 248
        · exact fromBatch c4_244 (by omega) (by omega)
        · exact fromBatch c4_248 (by omega) (by omega)
    · by_cases cut : i < 256
      · exact fromBatch c4_252 (by omega) (by omega)
      · by_cases cut : i < 260
        · exact fromBatch c4_256 (by omega) (by omega)
        · exact fromBatch c4_260 (by omega) (by omega)
  · by_cases cut : i < 276
    · by_cases cut : i < 268
      · exact fromBatch c4_264 (by omega) (by omega)
      · by_cases cut : i < 272
        · exact fromBatch c4_268 (by omega) (by omega)
        · exact fromBatch c4_272 (by omega) (by omega)
    · by_cases cut : i < 280
      · exact fromBatch c4_276 (by omega) (by omega)
      · by_cases cut : i < 284
        · exact fromBatch c4_280 (by omega) (by omega)
        · exact fromBatch c4_284 (by omega) (by omega)
end Checkpoint121.Pairs.M257
