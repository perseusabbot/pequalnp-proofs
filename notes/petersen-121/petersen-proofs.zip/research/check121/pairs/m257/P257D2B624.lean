import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c2_624 : batch dict 10 l2 l3 c2 624 4 = true := by decide +kernel
private theorem c2_628 : batch dict 10 l2 l3 c2 628 4 = true := by decide +kernel
private theorem c2_632 : batch dict 10 l2 l3 c2 632 4 = true := by decide +kernel
private theorem c2_636 : batch dict 10 l2 l3 c2 636 4 = true := by decide +kernel
private theorem c2_640 : batch dict 10 l2 l3 c2 640 4 = true := by decide +kernel
private theorem c2_644 : batch dict 10 l2 l3 c2 644 4 = true := by decide +kernel
private theorem c2_648 : batch dict 10 l2 l3 c2 648 4 = true := by decide +kernel
private theorem c2_652 : batch dict 10 l2 l3 c2 652 4 = true := by decide +kernel
private theorem c2_656 : batch dict 10 l2 l3 c2 656 4 = true := by decide +kernel
private theorem c2_660 : batch dict 10 l2 l3 c2 660 4 = true := by decide +kernel
private theorem c2_664 : batch dict 10 l2 l3 c2 664 4 = true := by decide +kernel
private theorem c2_668 : batch dict 10 l2 l3 c2 668 4 = true := by decide +kernel
theorem b2_624 (i : Nat) (lo : 624 ≤ i) (hi : i < 672) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 648
  · by_cases cut : i < 636
    · by_cases cut : i < 628
      · exact fromBatch c2_624 (by omega) (by omega)
      · by_cases cut : i < 632
        · exact fromBatch c2_628 (by omega) (by omega)
        · exact fromBatch c2_632 (by omega) (by omega)
    · by_cases cut : i < 640
      · exact fromBatch c2_636 (by omega) (by omega)
      · by_cases cut : i < 644
        · exact fromBatch c2_640 (by omega) (by omega)
        · exact fromBatch c2_644 (by omega) (by omega)
  · by_cases cut : i < 660
    · by_cases cut : i < 652
      · exact fromBatch c2_648 (by omega) (by omega)
      · by_cases cut : i < 656
        · exact fromBatch c2_652 (by omega) (by omega)
        · exact fromBatch c2_656 (by omega) (by omega)
    · by_cases cut : i < 664
      · exact fromBatch c2_660 (by omega) (by omega)
      · by_cases cut : i < 668
        · exact fromBatch c2_664 (by omega) (by omega)
        · exact fromBatch c2_668 (by omega) (by omega)
end Checkpoint121.Pairs.M257
