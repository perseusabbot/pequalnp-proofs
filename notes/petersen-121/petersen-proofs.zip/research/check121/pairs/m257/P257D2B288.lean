import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c2_288 : batch dict 10 l2 l3 c2 288 4 = true := by decide +kernel
private theorem c2_292 : batch dict 10 l2 l3 c2 292 4 = true := by decide +kernel
private theorem c2_296 : batch dict 10 l2 l3 c2 296 4 = true := by decide +kernel
private theorem c2_300 : batch dict 10 l2 l3 c2 300 4 = true := by decide +kernel
private theorem c2_304 : batch dict 10 l2 l3 c2 304 4 = true := by decide +kernel
private theorem c2_308 : batch dict 10 l2 l3 c2 308 4 = true := by decide +kernel
private theorem c2_312 : batch dict 10 l2 l3 c2 312 4 = true := by decide +kernel
private theorem c2_316 : batch dict 10 l2 l3 c2 316 4 = true := by decide +kernel
private theorem c2_320 : batch dict 10 l2 l3 c2 320 4 = true := by decide +kernel
private theorem c2_324 : batch dict 10 l2 l3 c2 324 4 = true := by decide +kernel
private theorem c2_328 : batch dict 10 l2 l3 c2 328 4 = true := by decide +kernel
private theorem c2_332 : batch dict 10 l2 l3 c2 332 4 = true := by decide +kernel
theorem b2_288 (i : Nat) (lo : 288 ≤ i) (hi : i < 336) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 312
  · by_cases cut : i < 300
    · by_cases cut : i < 292
      · exact fromBatch c2_288 (by omega) (by omega)
      · by_cases cut : i < 296
        · exact fromBatch c2_292 (by omega) (by omega)
        · exact fromBatch c2_296 (by omega) (by omega)
    · by_cases cut : i < 304
      · exact fromBatch c2_300 (by omega) (by omega)
      · by_cases cut : i < 308
        · exact fromBatch c2_304 (by omega) (by omega)
        · exact fromBatch c2_308 (by omega) (by omega)
  · by_cases cut : i < 324
    · by_cases cut : i < 316
      · exact fromBatch c2_312 (by omega) (by omega)
      · by_cases cut : i < 320
        · exact fromBatch c2_316 (by omega) (by omega)
        · exact fromBatch c2_320 (by omega) (by omega)
    · by_cases cut : i < 328
      · exact fromBatch c2_324 (by omega) (by omega)
      · by_cases cut : i < 332
        · exact fromBatch c2_328 (by omega) (by omega)
        · exact fromBatch c2_332 (by omega) (by omega)
end Checkpoint121.Pairs.M257
