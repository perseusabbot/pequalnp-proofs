import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c3_1344 : batch dict 9 l3 l4 c3 1344 4 = true := by decide +kernel
private theorem c3_1348 : batch dict 9 l3 l4 c3 1348 4 = true := by decide +kernel
private theorem c3_1352 : batch dict 9 l3 l4 c3 1352 4 = true := by decide +kernel
private theorem c3_1356 : batch dict 9 l3 l4 c3 1356 4 = true := by decide +kernel
private theorem c3_1360 : batch dict 9 l3 l4 c3 1360 4 = true := by decide +kernel
private theorem c3_1364 : batch dict 9 l3 l4 c3 1364 4 = true := by decide +kernel
private theorem c3_1368 : batch dict 9 l3 l4 c3 1368 4 = true := by decide +kernel
private theorem c3_1372 : batch dict 9 l3 l4 c3 1372 4 = true := by decide +kernel
private theorem c3_1376 : batch dict 9 l3 l4 c3 1376 4 = true := by decide +kernel
private theorem c3_1380 : batch dict 9 l3 l4 c3 1380 4 = true := by decide +kernel
private theorem c3_1384 : batch dict 9 l3 l4 c3 1384 4 = true := by decide +kernel
private theorem c3_1388 : batch dict 9 l3 l4 c3 1388 4 = true := by decide +kernel
theorem b3_1344 (i : Nat) (lo : 1344 ≤ i) (hi : i < 1392) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 1368
  · by_cases cut : i < 1356
    · by_cases cut : i < 1348
      · exact fromBatch c3_1344 (by omega) (by omega)
      · by_cases cut : i < 1352
        · exact fromBatch c3_1348 (by omega) (by omega)
        · exact fromBatch c3_1352 (by omega) (by omega)
    · by_cases cut : i < 1360
      · exact fromBatch c3_1356 (by omega) (by omega)
      · by_cases cut : i < 1364
        · exact fromBatch c3_1360 (by omega) (by omega)
        · exact fromBatch c3_1364 (by omega) (by omega)
  · by_cases cut : i < 1380
    · by_cases cut : i < 1372
      · exact fromBatch c3_1368 (by omega) (by omega)
      · by_cases cut : i < 1376
        · exact fromBatch c3_1372 (by omega) (by omega)
        · exact fromBatch c3_1376 (by omega) (by omega)
    · by_cases cut : i < 1384
      · exact fromBatch c3_1380 (by omega) (by omega)
      · by_cases cut : i < 1388
        · exact fromBatch c3_1384 (by omega) (by omega)
        · exact fromBatch c3_1388 (by omega) (by omega)
end Checkpoint121.Pairs.M257
