import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c3_624 : batch dict 9 l3 l4 c3 624 4 = true := by decide +kernel
private theorem c3_628 : batch dict 9 l3 l4 c3 628 4 = true := by decide +kernel
private theorem c3_632 : batch dict 9 l3 l4 c3 632 4 = true := by decide +kernel
private theorem c3_636 : batch dict 9 l3 l4 c3 636 4 = true := by decide +kernel
private theorem c3_640 : batch dict 9 l3 l4 c3 640 4 = true := by decide +kernel
private theorem c3_644 : batch dict 9 l3 l4 c3 644 4 = true := by decide +kernel
private theorem c3_648 : batch dict 9 l3 l4 c3 648 4 = true := by decide +kernel
private theorem c3_652 : batch dict 9 l3 l4 c3 652 4 = true := by decide +kernel
private theorem c3_656 : batch dict 9 l3 l4 c3 656 4 = true := by decide +kernel
private theorem c3_660 : batch dict 9 l3 l4 c3 660 4 = true := by decide +kernel
private theorem c3_664 : batch dict 9 l3 l4 c3 664 4 = true := by decide +kernel
private theorem c3_668 : batch dict 9 l3 l4 c3 668 4 = true := by decide +kernel
theorem b3_624 (i : Nat) (lo : 624 ≤ i) (hi : i < 672) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 648
  · by_cases cut : i < 636
    · by_cases cut : i < 628
      · exact fromBatch c3_624 (by omega) (by omega)
      · by_cases cut : i < 632
        · exact fromBatch c3_628 (by omega) (by omega)
        · exact fromBatch c3_632 (by omega) (by omega)
    · by_cases cut : i < 640
      · exact fromBatch c3_636 (by omega) (by omega)
      · by_cases cut : i < 644
        · exact fromBatch c3_640 (by omega) (by omega)
        · exact fromBatch c3_644 (by omega) (by omega)
  · by_cases cut : i < 660
    · by_cases cut : i < 652
      · exact fromBatch c3_648 (by omega) (by omega)
      · by_cases cut : i < 656
        · exact fromBatch c3_652 (by omega) (by omega)
        · exact fromBatch c3_656 (by omega) (by omega)
    · by_cases cut : i < 664
      · exact fromBatch c3_660 (by omega) (by omega)
      · by_cases cut : i < 668
        · exact fromBatch c3_664 (by omega) (by omega)
        · exact fromBatch c3_668 (by omega) (by omega)
end Checkpoint121.Pairs.M257
