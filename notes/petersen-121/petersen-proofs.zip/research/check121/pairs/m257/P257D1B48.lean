import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c1_48 : batch dict 11 l1 l2 c1 48 1 = true := by decide +kernel
theorem b1_48 (i : Nat) (lo : 48 ≤ i) (hi : i < 49) : checkRow dict 11 (l1[i]?.getD default) l2 (c1[i]?.getD 0) = true := by
  exact fromBatch c1_48 (by omega) (by omega)
end Checkpoint121.Pairs.M257
