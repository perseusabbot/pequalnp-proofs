import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c3_0 : batch dict 9 l3 l4 c3 0 4 = true := by decide +kernel
private theorem c3_4 : batch dict 9 l3 l4 c3 4 4 = true := by decide +kernel
private theorem c3_8 : batch dict 9 l3 l4 c3 8 4 = true := by decide +kernel
private theorem c3_12 : batch dict 9 l3 l4 c3 12 4 = true := by decide +kernel
private theorem c3_16 : batch dict 9 l3 l4 c3 16 4 = true := by decide +kernel
private theorem c3_20 : batch dict 9 l3 l4 c3 20 4 = true := by decide +kernel
private theorem c3_24 : batch dict 9 l3 l4 c3 24 4 = true := by decide +kernel
private theorem c3_28 : batch dict 9 l3 l4 c3 28 4 = true := by decide +kernel
private theorem c3_32 : batch dict 9 l3 l4 c3 32 4 = true := by decide +kernel
private theorem c3_36 : batch dict 9 l3 l4 c3 36 4 = true := by decide +kernel
private theorem c3_40 : batch dict 9 l3 l4 c3 40 4 = true := by decide +kernel
private theorem c3_44 : batch dict 9 l3 l4 c3 44 4 = true := by decide +kernel
theorem b3_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 48) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 24
  · by_cases cut : i < 12
    · by_cases cut : i < 4
      · exact fromBatch c3_0 (by omega) (by omega)
      · by_cases cut : i < 8
        · exact fromBatch c3_4 (by omega) (by omega)
        · exact fromBatch c3_8 (by omega) (by omega)
    · by_cases cut : i < 16
      · exact fromBatch c3_12 (by omega) (by omega)
      · by_cases cut : i < 20
        · exact fromBatch c3_16 (by omega) (by omega)
        · exact fromBatch c3_20 (by omega) (by omega)
  · by_cases cut : i < 36
    · by_cases cut : i < 28
      · exact fromBatch c3_24 (by omega) (by omega)
      · by_cases cut : i < 32
        · exact fromBatch c3_28 (by omega) (by omega)
        · exact fromBatch c3_32 (by omega) (by omega)
    · by_cases cut : i < 40
      · exact fromBatch c3_36 (by omega) (by omega)
      · by_cases cut : i < 44
        · exact fromBatch c3_40 (by omega) (by omega)
        · exact fromBatch c3_44 (by omega) (by omega)
end Checkpoint121.Pairs.M257
