import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c3_1296 : batch dict 9 l3 l4 c3 1296 4 = true := by decide +kernel
private theorem c3_1300 : batch dict 9 l3 l4 c3 1300 4 = true := by decide +kernel
private theorem c3_1304 : batch dict 9 l3 l4 c3 1304 4 = true := by decide +kernel
private theorem c3_1308 : batch dict 9 l3 l4 c3 1308 4 = true := by decide +kernel
private theorem c3_1312 : batch dict 9 l3 l4 c3 1312 4 = true := by decide +kernel
private theorem c3_1316 : batch dict 9 l3 l4 c3 1316 4 = true := by decide +kernel
private theorem c3_1320 : batch dict 9 l3 l4 c3 1320 4 = true := by decide +kernel
private theorem c3_1324 : batch dict 9 l3 l4 c3 1324 4 = true := by decide +kernel
private theorem c3_1328 : batch dict 9 l3 l4 c3 1328 4 = true := by decide +kernel
private theorem c3_1332 : batch dict 9 l3 l4 c3 1332 4 = true := by decide +kernel
private theorem c3_1336 : batch dict 9 l3 l4 c3 1336 4 = true := by decide +kernel
private theorem c3_1340 : batch dict 9 l3 l4 c3 1340 4 = true := by decide +kernel
theorem b3_1296 (i : Nat) (lo : 1296 ≤ i) (hi : i < 1344) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 1320
  · by_cases cut : i < 1308
    · by_cases cut : i < 1300
      · exact fromBatch c3_1296 (by omega) (by omega)
      · by_cases cut : i < 1304
        · exact fromBatch c3_1300 (by omega) (by omega)
        · exact fromBatch c3_1304 (by omega) (by omega)
    · by_cases cut : i < 1312
      · exact fromBatch c3_1308 (by omega) (by omega)
      · by_cases cut : i < 1316
        · exact fromBatch c3_1312 (by omega) (by omega)
        · exact fromBatch c3_1316 (by omega) (by omega)
  · by_cases cut : i < 1332
    · by_cases cut : i < 1324
      · exact fromBatch c3_1320 (by omega) (by omega)
      · by_cases cut : i < 1328
        · exact fromBatch c3_1324 (by omega) (by omega)
        · exact fromBatch c3_1328 (by omega) (by omega)
    · by_cases cut : i < 1336
      · exact fromBatch c3_1332 (by omega) (by omega)
      · by_cases cut : i < 1340
        · exact fromBatch c3_1336 (by omega) (by omega)
        · exact fromBatch c3_1340 (by omega) (by omega)
end Checkpoint121.Pairs.M257
