import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c2_336 : batch dict 10 l2 l3 c2 336 4 = true := by decide +kernel
private theorem c2_340 : batch dict 10 l2 l3 c2 340 4 = true := by decide +kernel
private theorem c2_344 : batch dict 10 l2 l3 c2 344 4 = true := by decide +kernel
private theorem c2_348 : batch dict 10 l2 l3 c2 348 4 = true := by decide +kernel
private theorem c2_352 : batch dict 10 l2 l3 c2 352 4 = true := by decide +kernel
private theorem c2_356 : batch dict 10 l2 l3 c2 356 4 = true := by decide +kernel
private theorem c2_360 : batch dict 10 l2 l3 c2 360 4 = true := by decide +kernel
private theorem c2_364 : batch dict 10 l2 l3 c2 364 4 = true := by decide +kernel
private theorem c2_368 : batch dict 10 l2 l3 c2 368 4 = true := by decide +kernel
private theorem c2_372 : batch dict 10 l2 l3 c2 372 4 = true := by decide +kernel
private theorem c2_376 : batch dict 10 l2 l3 c2 376 4 = true := by decide +kernel
private theorem c2_380 : batch dict 10 l2 l3 c2 380 4 = true := by decide +kernel
theorem b2_336 (i : Nat) (lo : 336 ≤ i) (hi : i < 384) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 360
  · by_cases cut : i < 348
    · by_cases cut : i < 340
      · exact fromBatch c2_336 (by omega) (by omega)
      · by_cases cut : i < 344
        · exact fromBatch c2_340 (by omega) (by omega)
        · exact fromBatch c2_344 (by omega) (by omega)
    · by_cases cut : i < 352
      · exact fromBatch c2_348 (by omega) (by omega)
      · by_cases cut : i < 356
        · exact fromBatch c2_352 (by omega) (by omega)
        · exact fromBatch c2_356 (by omega) (by omega)
  · by_cases cut : i < 372
    · by_cases cut : i < 364
      · exact fromBatch c2_360 (by omega) (by omega)
      · by_cases cut : i < 368
        · exact fromBatch c2_364 (by omega) (by omega)
        · exact fromBatch c2_368 (by omega) (by omega)
    · by_cases cut : i < 376
      · exact fromBatch c2_372 (by omega) (by omega)
      · by_cases cut : i < 380
        · exact fromBatch c2_376 (by omega) (by omega)
        · exact fromBatch c2_380 (by omega) (by omega)
end Checkpoint121.Pairs.M257
