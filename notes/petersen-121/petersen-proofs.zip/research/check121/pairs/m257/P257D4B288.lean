import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c4_288 : batch dict 8 l4 l5 c4 288 4 = true := by decide +kernel
private theorem c4_292 : batch dict 8 l4 l5 c4 292 4 = true := by decide +kernel
private theorem c4_296 : batch dict 8 l4 l5 c4 296 4 = true := by decide +kernel
private theorem c4_300 : batch dict 8 l4 l5 c4 300 4 = true := by decide +kernel
private theorem c4_304 : batch dict 8 l4 l5 c4 304 4 = true := by decide +kernel
private theorem c4_308 : batch dict 8 l4 l5 c4 308 4 = true := by decide +kernel
private theorem c4_312 : batch dict 8 l4 l5 c4 312 4 = true := by decide +kernel
private theorem c4_316 : batch dict 8 l4 l5 c4 316 4 = true := by decide +kernel
private theorem c4_320 : batch dict 8 l4 l5 c4 320 4 = true := by decide +kernel
private theorem c4_324 : batch dict 8 l4 l5 c4 324 4 = true := by decide +kernel
private theorem c4_328 : batch dict 8 l4 l5 c4 328 4 = true := by decide +kernel
private theorem c4_332 : batch dict 8 l4 l5 c4 332 4 = true := by decide +kernel
theorem b4_288 (i : Nat) (lo : 288 ≤ i) (hi : i < 336) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 312
  · by_cases cut : i < 300
    · by_cases cut : i < 292
      · exact fromBatch c4_288 (by omega) (by omega)
      · by_cases cut : i < 296
        · exact fromBatch c4_292 (by omega) (by omega)
        · exact fromBatch c4_296 (by omega) (by omega)
    · by_cases cut : i < 304
      · exact fromBatch c4_300 (by omega) (by omega)
      · by_cases cut : i < 308
        · exact fromBatch c4_304 (by omega) (by omega)
        · exact fromBatch c4_308 (by omega) (by omega)
  · by_cases cut : i < 324
    · by_cases cut : i < 316
      · exact fromBatch c4_312 (by omega) (by omega)
      · by_cases cut : i < 320
        · exact fromBatch c4_316 (by omega) (by omega)
        · exact fromBatch c4_320 (by omega) (by omega)
    · by_cases cut : i < 328
      · exact fromBatch c4_324 (by omega) (by omega)
      · by_cases cut : i < 332
        · exact fromBatch c4_328 (by omega) (by omega)
        · exact fromBatch c4_332 (by omega) (by omega)
end Checkpoint121.Pairs.M257
