import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c3_1248 : batch dict 9 l3 l4 c3 1248 4 = true := by decide +kernel
private theorem c3_1252 : batch dict 9 l3 l4 c3 1252 4 = true := by decide +kernel
private theorem c3_1256 : batch dict 9 l3 l4 c3 1256 4 = true := by decide +kernel
private theorem c3_1260 : batch dict 9 l3 l4 c3 1260 4 = true := by decide +kernel
private theorem c3_1264 : batch dict 9 l3 l4 c3 1264 4 = true := by decide +kernel
private theorem c3_1268 : batch dict 9 l3 l4 c3 1268 4 = true := by decide +kernel
private theorem c3_1272 : batch dict 9 l3 l4 c3 1272 4 = true := by decide +kernel
private theorem c3_1276 : batch dict 9 l3 l4 c3 1276 4 = true := by decide +kernel
private theorem c3_1280 : batch dict 9 l3 l4 c3 1280 4 = true := by decide +kernel
private theorem c3_1284 : batch dict 9 l3 l4 c3 1284 4 = true := by decide +kernel
private theorem c3_1288 : batch dict 9 l3 l4 c3 1288 4 = true := by decide +kernel
private theorem c3_1292 : batch dict 9 l3 l4 c3 1292 4 = true := by decide +kernel
theorem b3_1248 (i : Nat) (lo : 1248 ≤ i) (hi : i < 1296) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 1272
  · by_cases cut : i < 1260
    · by_cases cut : i < 1252
      · exact fromBatch c3_1248 (by omega) (by omega)
      · by_cases cut : i < 1256
        · exact fromBatch c3_1252 (by omega) (by omega)
        · exact fromBatch c3_1256 (by omega) (by omega)
    · by_cases cut : i < 1264
      · exact fromBatch c3_1260 (by omega) (by omega)
      · by_cases cut : i < 1268
        · exact fromBatch c3_1264 (by omega) (by omega)
        · exact fromBatch c3_1268 (by omega) (by omega)
  · by_cases cut : i < 1284
    · by_cases cut : i < 1276
      · exact fromBatch c3_1272 (by omega) (by omega)
      · by_cases cut : i < 1280
        · exact fromBatch c3_1276 (by omega) (by omega)
        · exact fromBatch c3_1280 (by omega) (by omega)
    · by_cases cut : i < 1288
      · exact fromBatch c3_1284 (by omega) (by omega)
      · by_cases cut : i < 1292
        · exact fromBatch c3_1288 (by omega) (by omega)
        · exact fromBatch c3_1292 (by omega) (by omega)
end Checkpoint121.Pairs.M257
