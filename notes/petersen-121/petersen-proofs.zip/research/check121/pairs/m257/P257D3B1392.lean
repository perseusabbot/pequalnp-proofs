import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c3_1392 : batch dict 9 l3 l4 c3 1392 4 = true := by decide +kernel
private theorem c3_1396 : batch dict 9 l3 l4 c3 1396 4 = true := by decide +kernel
private theorem c3_1400 : batch dict 9 l3 l4 c3 1400 4 = true := by decide +kernel
private theorem c3_1404 : batch dict 9 l3 l4 c3 1404 4 = true := by decide +kernel
private theorem c3_1408 : batch dict 9 l3 l4 c3 1408 4 = true := by decide +kernel
private theorem c3_1412 : batch dict 9 l3 l4 c3 1412 4 = true := by decide +kernel
private theorem c3_1416 : batch dict 9 l3 l4 c3 1416 4 = true := by decide +kernel
private theorem c3_1420 : batch dict 9 l3 l4 c3 1420 3 = true := by decide +kernel
theorem b3_1392 (i : Nat) (lo : 1392 ≤ i) (hi : i < 1423) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 1408
  · by_cases cut : i < 1400
    · by_cases cut : i < 1396
      · exact fromBatch c3_1392 (by omega) (by omega)
      · exact fromBatch c3_1396 (by omega) (by omega)
    · by_cases cut : i < 1404
      · exact fromBatch c3_1400 (by omega) (by omega)
      · exact fromBatch c3_1404 (by omega) (by omega)
  · by_cases cut : i < 1416
    · by_cases cut : i < 1412
      · exact fromBatch c3_1408 (by omega) (by omega)
      · exact fromBatch c3_1412 (by omega) (by omega)
    · by_cases cut : i < 1420
      · exact fromBatch c3_1416 (by omega) (by omega)
      · exact fromBatch c3_1420 (by omega) (by omega)
end Checkpoint121.Pairs.M257
