import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c5_0 : batch dict 7 l5 l6 c5 0 4 = true := by decide +kernel
private theorem c5_4 : batch dict 7 l5 l6 c5 4 4 = true := by decide +kernel
private theorem c5_8 : batch dict 7 l5 l6 c5 8 4 = true := by decide +kernel
private theorem c5_12 : batch dict 7 l5 l6 c5 12 4 = true := by decide +kernel
private theorem c5_16 : batch dict 7 l5 l6 c5 16 4 = true := by decide +kernel
theorem b5_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 20) : checkRow dict 7 (l5[i]?.getD default) l6 (c5[i]?.getD 0) = true := by
  by_cases cut : i < 8
  · by_cases cut : i < 4
    · exact fromBatch c5_0 (by omega) (by omega)
    · exact fromBatch c5_4 (by omega) (by omega)
  · by_cases cut : i < 12
    · exact fromBatch c5_8 (by omega) (by omega)
    · by_cases cut : i < 16
      · exact fromBatch c5_12 (by omega) (by omega)
      · exact fromBatch c5_16 (by omega) (by omega)
end Checkpoint121.Pairs.M257
