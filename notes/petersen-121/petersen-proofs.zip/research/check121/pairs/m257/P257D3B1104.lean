import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c3_1104 : batch dict 9 l3 l4 c3 1104 4 = true := by decide +kernel
private theorem c3_1108 : batch dict 9 l3 l4 c3 1108 4 = true := by decide +kernel
private theorem c3_1112 : batch dict 9 l3 l4 c3 1112 4 = true := by decide +kernel
private theorem c3_1116 : batch dict 9 l3 l4 c3 1116 4 = true := by decide +kernel
private theorem c3_1120 : batch dict 9 l3 l4 c3 1120 4 = true := by decide +kernel
private theorem c3_1124 : batch dict 9 l3 l4 c3 1124 4 = true := by decide +kernel
private theorem c3_1128 : batch dict 9 l3 l4 c3 1128 4 = true := by decide +kernel
private theorem c3_1132 : batch dict 9 l3 l4 c3 1132 4 = true := by decide +kernel
private theorem c3_1136 : batch dict 9 l3 l4 c3 1136 4 = true := by decide +kernel
private theorem c3_1140 : batch dict 9 l3 l4 c3 1140 4 = true := by decide +kernel
private theorem c3_1144 : batch dict 9 l3 l4 c3 1144 4 = true := by decide +kernel
private theorem c3_1148 : batch dict 9 l3 l4 c3 1148 4 = true := by decide +kernel
theorem b3_1104 (i : Nat) (lo : 1104 ≤ i) (hi : i < 1152) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 1128
  · by_cases cut : i < 1116
    · by_cases cut : i < 1108
      · exact fromBatch c3_1104 (by omega) (by omega)
      · by_cases cut : i < 1112
        · exact fromBatch c3_1108 (by omega) (by omega)
        · exact fromBatch c3_1112 (by omega) (by omega)
    · by_cases cut : i < 1120
      · exact fromBatch c3_1116 (by omega) (by omega)
      · by_cases cut : i < 1124
        · exact fromBatch c3_1120 (by omega) (by omega)
        · exact fromBatch c3_1124 (by omega) (by omega)
  · by_cases cut : i < 1140
    · by_cases cut : i < 1132
      · exact fromBatch c3_1128 (by omega) (by omega)
      · by_cases cut : i < 1136
        · exact fromBatch c3_1132 (by omega) (by omega)
        · exact fromBatch c3_1136 (by omega) (by omega)
    · by_cases cut : i < 1144
      · exact fromBatch c3_1140 (by omega) (by omega)
      · by_cases cut : i < 1148
        · exact fromBatch c3_1144 (by omega) (by omega)
        · exact fromBatch c3_1148 (by omega) (by omega)
end Checkpoint121.Pairs.M257
