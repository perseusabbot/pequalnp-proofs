import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c3_576 : batch dict 9 l3 l4 c3 576 4 = true := by decide +kernel
private theorem c3_580 : batch dict 9 l3 l4 c3 580 4 = true := by decide +kernel
private theorem c3_584 : batch dict 9 l3 l4 c3 584 4 = true := by decide +kernel
private theorem c3_588 : batch dict 9 l3 l4 c3 588 4 = true := by decide +kernel
private theorem c3_592 : batch dict 9 l3 l4 c3 592 4 = true := by decide +kernel
private theorem c3_596 : batch dict 9 l3 l4 c3 596 4 = true := by decide +kernel
private theorem c3_600 : batch dict 9 l3 l4 c3 600 4 = true := by decide +kernel
private theorem c3_604 : batch dict 9 l3 l4 c3 604 4 = true := by decide +kernel
private theorem c3_608 : batch dict 9 l3 l4 c3 608 4 = true := by decide +kernel
private theorem c3_612 : batch dict 9 l3 l4 c3 612 4 = true := by decide +kernel
private theorem c3_616 : batch dict 9 l3 l4 c3 616 4 = true := by decide +kernel
private theorem c3_620 : batch dict 9 l3 l4 c3 620 4 = true := by decide +kernel
theorem b3_576 (i : Nat) (lo : 576 ≤ i) (hi : i < 624) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 600
  · by_cases cut : i < 588
    · by_cases cut : i < 580
      · exact fromBatch c3_576 (by omega) (by omega)
      · by_cases cut : i < 584
        · exact fromBatch c3_580 (by omega) (by omega)
        · exact fromBatch c3_584 (by omega) (by omega)
    · by_cases cut : i < 592
      · exact fromBatch c3_588 (by omega) (by omega)
      · by_cases cut : i < 596
        · exact fromBatch c3_592 (by omega) (by omega)
        · exact fromBatch c3_596 (by omega) (by omega)
  · by_cases cut : i < 612
    · by_cases cut : i < 604
      · exact fromBatch c3_600 (by omega) (by omega)
      · by_cases cut : i < 608
        · exact fromBatch c3_604 (by omega) (by omega)
        · exact fromBatch c3_608 (by omega) (by omega)
    · by_cases cut : i < 616
      · exact fromBatch c3_612 (by omega) (by omega)
      · by_cases cut : i < 620
        · exact fromBatch c3_616 (by omega) (by omega)
        · exact fromBatch c3_620 (by omega) (by omega)
end Checkpoint121.Pairs.M257
