import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c2_672 : batch dict 10 l2 l3 c2 672 4 = true := by decide +kernel
private theorem c2_676 : batch dict 10 l2 l3 c2 676 4 = true := by decide +kernel
private theorem c2_680 : batch dict 10 l2 l3 c2 680 4 = true := by decide +kernel
private theorem c2_684 : batch dict 10 l2 l3 c2 684 4 = true := by decide +kernel
private theorem c2_688 : batch dict 10 l2 l3 c2 688 4 = true := by decide +kernel
private theorem c2_692 : batch dict 10 l2 l3 c2 692 4 = true := by decide +kernel
private theorem c2_696 : batch dict 10 l2 l3 c2 696 4 = true := by decide +kernel
private theorem c2_700 : batch dict 10 l2 l3 c2 700 4 = true := by decide +kernel
private theorem c2_704 : batch dict 10 l2 l3 c2 704 4 = true := by decide +kernel
private theorem c2_708 : batch dict 10 l2 l3 c2 708 4 = true := by decide +kernel
private theorem c2_712 : batch dict 10 l2 l3 c2 712 4 = true := by decide +kernel
private theorem c2_716 : batch dict 10 l2 l3 c2 716 4 = true := by decide +kernel
theorem b2_672 (i : Nat) (lo : 672 ≤ i) (hi : i < 720) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 696
  · by_cases cut : i < 684
    · by_cases cut : i < 676
      · exact fromBatch c2_672 (by omega) (by omega)
      · by_cases cut : i < 680
        · exact fromBatch c2_676 (by omega) (by omega)
        · exact fromBatch c2_680 (by omega) (by omega)
    · by_cases cut : i < 688
      · exact fromBatch c2_684 (by omega) (by omega)
      · by_cases cut : i < 692
        · exact fromBatch c2_688 (by omega) (by omega)
        · exact fromBatch c2_692 (by omega) (by omega)
  · by_cases cut : i < 708
    · by_cases cut : i < 700
      · exact fromBatch c2_696 (by omega) (by omega)
      · by_cases cut : i < 704
        · exact fromBatch c2_700 (by omega) (by omega)
        · exact fromBatch c2_704 (by omega) (by omega)
    · by_cases cut : i < 712
      · exact fromBatch c2_708 (by omega) (by omega)
      · by_cases cut : i < 716
        · exact fromBatch c2_712 (by omega) (by omega)
        · exact fromBatch c2_716 (by omega) (by omega)
end Checkpoint121.Pairs.M257
