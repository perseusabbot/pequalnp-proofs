import P257Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.MultiScore
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M257
private theorem c2_240 : batch dict 10 l2 l3 c2 240 4 = true := by decide +kernel
private theorem c2_244 : batch dict 10 l2 l3 c2 244 4 = true := by decide +kernel
private theorem c2_248 : batch dict 10 l2 l3 c2 248 4 = true := by decide +kernel
private theorem c2_252 : batch dict 10 l2 l3 c2 252 4 = true := by decide +kernel
private theorem c2_256 : batch dict 10 l2 l3 c2 256 4 = true := by decide +kernel
private theorem c2_260 : batch dict 10 l2 l3 c2 260 4 = true := by decide +kernel
private theorem c2_264 : batch dict 10 l2 l3 c2 264 4 = true := by decide +kernel
private theorem c2_268 : batch dict 10 l2 l3 c2 268 4 = true := by decide +kernel
private theorem c2_272 : batch dict 10 l2 l3 c2 272 4 = true := by decide +kernel
private theorem c2_276 : batch dict 10 l2 l3 c2 276 4 = true := by decide +kernel
private theorem c2_280 : batch dict 10 l2 l3 c2 280 4 = true := by decide +kernel
private theorem c2_284 : batch dict 10 l2 l3 c2 284 4 = true := by decide +kernel
theorem b2_240 (i : Nat) (lo : 240 ≤ i) (hi : i < 288) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 264
  · by_cases cut : i < 252
    · by_cases cut : i < 244
      · exact fromBatch c2_240 (by omega) (by omega)
      · by_cases cut : i < 248
        · exact fromBatch c2_244 (by omega) (by omega)
        · exact fromBatch c2_248 (by omega) (by omega)
    · by_cases cut : i < 256
      · exact fromBatch c2_252 (by omega) (by omega)
      · by_cases cut : i < 260
        · exact fromBatch c2_256 (by omega) (by omega)
        · exact fromBatch c2_260 (by omega) (by omega)
  · by_cases cut : i < 276
    · by_cases cut : i < 268
      · exact fromBatch c2_264 (by omega) (by omega)
      · by_cases cut : i < 272
        · exact fromBatch c2_268 (by omega) (by omega)
        · exact fromBatch c2_272 (by omega) (by omega)
    · by_cases cut : i < 280
      · exact fromBatch c2_276 (by omega) (by omega)
      · by_cases cut : i < 284
        · exact fromBatch c2_280 (by omega) (by omega)
        · exact fromBatch c2_284 (by omega) (by omega)
end Checkpoint121.Pairs.M257
