import Pair121

namespace Checkpoint121.Scored
open PEqualNP.Outside.L_meta_274_aux
open Petersen1676 Petersen1676.Table Petersen1676.Prune Petersen1676.PinRules
open Petersen120.Mask81.LayerCheck

/-- Six positions in the 1,376-row paired truth table. For a tight run, each
binary operation is subadditive for this six-row score (project lemma 274). -/
def loss (code : Nat) (ws : List Nat) (s : Nat) : Bool :=
  let atRow (i : Nat) := (code >>> (11*i)) &&& 2047
  let weight := eval6 (atRow 0) (atRow 1) (atRow 2) (atRow 3) (atRow 4) (atRow 5)
  ws.length == s+1 && (ws.map weight).sum < weight Table.goal

theorem loss_impossible {code ws s} (test : loss code ws s = true)
    (run : NatRun allMask Table.goal s ws) : False := by
  simp only [loss,Bool.and_eq_true,beq_iff_eq,decide_eq_true_eq] at test
  obtain ⟨tight,short⟩ := test
  exact (Nat.not_lt_of_ge (eval6_bound run tight _ _ _ _ _ _)) short

def checkRow (words : Array Nat) (s : Nat) (r : Entry) (next : Array Entry) (code : Nat) : Bool :=
  if code = 0 then localCheck words s r next else loss code (decodeNode words r).1 (s+1)

def batch (words : Array Nat) (s : Nat) (cur next : Array Entry) (codes : Array Nat)
    (offset size : Nat) : Bool :=
  (List.range size).all fun j =>
    checkRow words s (cur[offset+j]?.getD default) next (codes[offset+j]?.getD 0)

theorem fromBatch {words s cur next codes offset size i}
    (checked : batch words s cur next codes offset size = true)
    (lower : offset ≤ i) (upper : i < offset+size) :
    checkRow words s (cur[i]?.getD default) next (codes[i]?.getD 0) = true := by
  have j : i-offset < size := by omega
  have h := List.all_eq_true.mp checked (i-offset) (List.mem_range.mpr j)
  simpa only [show offset+(i-offset)=i from by omega] using h

theorem priorScored (words : Array Nat) (s : Nat) (cur next : Array Entry) (codes : Array Nat)
    (ok : ∀ i : Fin cur.size, checkRow words s cur[i] next (codes[i.val]?.getD 0) = true)
    (after : Closed words s next) : Closed words (s+1) cur := by
  intro i
  dsimp only
  intro inv
  have yes := ok i
  unfold checkRow at yes
  split at yes
  · have single : Closed words (s+1) #[cur[i]] := by
      apply prior _ _ _ _ _ after
      intro j
      have eq : j = 0 := Fin.eq_zero j
      subst j
      exact yes
    exact single ⟨0,by simp⟩ inv
  · exact fun run => loss_impossible yes run

#print axioms loss_impossible
#print axioms priorScored
end Checkpoint121.Scored
