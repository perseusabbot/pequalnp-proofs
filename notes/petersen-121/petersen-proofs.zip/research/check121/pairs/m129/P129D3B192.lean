import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c3_192 : batch dict 9 l3 l4 c3 192 4 = true := by decide +kernel
private theorem c3_196 : batch dict 9 l3 l4 c3 196 4 = true := by decide +kernel
private theorem c3_200 : batch dict 9 l3 l4 c3 200 4 = true := by decide +kernel
private theorem c3_204 : batch dict 9 l3 l4 c3 204 4 = true := by decide +kernel
private theorem c3_208 : batch dict 9 l3 l4 c3 208 4 = true := by decide +kernel
private theorem c3_212 : batch dict 9 l3 l4 c3 212 4 = true := by decide +kernel
theorem b3_192 (i : Nat) (lo : 192 ≤ i) (hi : i < 216) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 204
  · by_cases cut : i < 196
    · exact fromBatch c3_192 (by omega) (by omega)
    · by_cases cut : i < 200
      · exact fromBatch c3_196 (by omega) (by omega)
      · exact fromBatch c3_200 (by omega) (by omega)
  · by_cases cut : i < 208
    · exact fromBatch c3_204 (by omega) (by omega)
    · by_cases cut : i < 212
      · exact fromBatch c3_208 (by omega) (by omega)
      · exact fromBatch c3_212 (by omega) (by omega)
end Checkpoint121.Pairs.M129
