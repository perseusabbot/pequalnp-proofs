import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c2_192 : batch dict 10 l2 l3 c2 192 4 = true := by decide +kernel
private theorem c2_196 : batch dict 10 l2 l3 c2 196 4 = true := by decide +kernel
private theorem c2_200 : batch dict 10 l2 l3 c2 200 4 = true := by decide +kernel
private theorem c2_204 : batch dict 10 l2 l3 c2 204 4 = true := by decide +kernel
private theorem c2_208 : batch dict 10 l2 l3 c2 208 4 = true := by decide +kernel
private theorem c2_212 : batch dict 10 l2 l3 c2 212 4 = true := by decide +kernel
theorem b2_192 (i : Nat) (lo : 192 ≤ i) (hi : i < 216) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 204
  · by_cases cut : i < 196
    · exact fromBatch c2_192 (by omega) (by omega)
    · by_cases cut : i < 200
      · exact fromBatch c2_196 (by omega) (by omega)
      · exact fromBatch c2_200 (by omega) (by omega)
  · by_cases cut : i < 208
    · exact fromBatch c2_204 (by omega) (by omega)
    · by_cases cut : i < 212
      · exact fromBatch c2_208 (by omega) (by omega)
      · exact fromBatch c2_212 (by omega) (by omega)
end Checkpoint121.Pairs.M129
