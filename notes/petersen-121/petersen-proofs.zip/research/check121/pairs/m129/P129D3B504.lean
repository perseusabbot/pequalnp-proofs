import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c3_504 : batch dict 9 l3 l4 c3 504 4 = true := by decide +kernel
private theorem c3_508 : batch dict 9 l3 l4 c3 508 4 = true := by decide +kernel
private theorem c3_512 : batch dict 9 l3 l4 c3 512 4 = true := by decide +kernel
private theorem c3_516 : batch dict 9 l3 l4 c3 516 4 = true := by decide +kernel
private theorem c3_520 : batch dict 9 l3 l4 c3 520 4 = true := by decide +kernel
private theorem c3_524 : batch dict 9 l3 l4 c3 524 4 = true := by decide +kernel
theorem b3_504 (i : Nat) (lo : 504 ≤ i) (hi : i < 528) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 516
  · by_cases cut : i < 508
    · exact fromBatch c3_504 (by omega) (by omega)
    · by_cases cut : i < 512
      · exact fromBatch c3_508 (by omega) (by omega)
      · exact fromBatch c3_512 (by omega) (by omega)
  · by_cases cut : i < 520
    · exact fromBatch c3_516 (by omega) (by omega)
    · by_cases cut : i < 524
      · exact fromBatch c3_520 (by omega) (by omega)
      · exact fromBatch c3_524 (by omega) (by omega)
end Checkpoint121.Pairs.M129
