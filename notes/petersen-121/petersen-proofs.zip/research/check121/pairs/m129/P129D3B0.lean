import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c3_0 : batch dict 9 l3 l4 c3 0 4 = true := by decide +kernel
private theorem c3_4 : batch dict 9 l3 l4 c3 4 4 = true := by decide +kernel
private theorem c3_8 : batch dict 9 l3 l4 c3 8 4 = true := by decide +kernel
private theorem c3_12 : batch dict 9 l3 l4 c3 12 4 = true := by decide +kernel
private theorem c3_16 : batch dict 9 l3 l4 c3 16 4 = true := by decide +kernel
private theorem c3_20 : batch dict 9 l3 l4 c3 20 4 = true := by decide +kernel
theorem b3_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 24) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 12
  · by_cases cut : i < 4
    · exact fromBatch c3_0 (by omega) (by omega)
    · by_cases cut : i < 8
      · exact fromBatch c3_4 (by omega) (by omega)
      · exact fromBatch c3_8 (by omega) (by omega)
  · by_cases cut : i < 16
    · exact fromBatch c3_12 (by omega) (by omega)
    · by_cases cut : i < 20
      · exact fromBatch c3_16 (by omega) (by omega)
      · exact fromBatch c3_20 (by omega) (by omega)
end Checkpoint121.Pairs.M129
