import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c2_168 : batch dict 10 l2 l3 c2 168 4 = true := by decide +kernel
private theorem c2_172 : batch dict 10 l2 l3 c2 172 4 = true := by decide +kernel
private theorem c2_176 : batch dict 10 l2 l3 c2 176 4 = true := by decide +kernel
private theorem c2_180 : batch dict 10 l2 l3 c2 180 4 = true := by decide +kernel
private theorem c2_184 : batch dict 10 l2 l3 c2 184 4 = true := by decide +kernel
private theorem c2_188 : batch dict 10 l2 l3 c2 188 4 = true := by decide +kernel
theorem b2_168 (i : Nat) (lo : 168 ≤ i) (hi : i < 192) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 180
  · by_cases cut : i < 172
    · exact fromBatch c2_168 (by omega) (by omega)
    · by_cases cut : i < 176
      · exact fromBatch c2_172 (by omega) (by omega)
      · exact fromBatch c2_176 (by omega) (by omega)
  · by_cases cut : i < 184
    · exact fromBatch c2_180 (by omega) (by omega)
    · by_cases cut : i < 188
      · exact fromBatch c2_184 (by omega) (by omega)
      · exact fromBatch c2_188 (by omega) (by omega)
end Checkpoint121.Pairs.M129
