import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c4_96 : batch dict 8 l4 l5 c4 96 4 = true := by decide +kernel
private theorem c4_100 : batch dict 8 l4 l5 c4 100 4 = true := by decide +kernel
private theorem c4_104 : batch dict 8 l4 l5 c4 104 4 = true := by decide +kernel
private theorem c4_108 : batch dict 8 l4 l5 c4 108 4 = true := by decide +kernel
private theorem c4_112 : batch dict 8 l4 l5 c4 112 4 = true := by decide +kernel
private theorem c4_116 : batch dict 8 l4 l5 c4 116 4 = true := by decide +kernel
theorem b4_96 (i : Nat) (lo : 96 ≤ i) (hi : i < 120) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 108
  · by_cases cut : i < 100
    · exact fromBatch c4_96 (by omega) (by omega)
    · by_cases cut : i < 104
      · exact fromBatch c4_100 (by omega) (by omega)
      · exact fromBatch c4_104 (by omega) (by omega)
  · by_cases cut : i < 112
    · exact fromBatch c4_108 (by omega) (by omega)
    · by_cases cut : i < 116
      · exact fromBatch c4_112 (by omega) (by omega)
      · exact fromBatch c4_116 (by omega) (by omega)
end Checkpoint121.Pairs.M129
