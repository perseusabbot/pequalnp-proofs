import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c3_48 : batch dict 9 l3 l4 c3 48 4 = true := by decide +kernel
private theorem c3_52 : batch dict 9 l3 l4 c3 52 4 = true := by decide +kernel
private theorem c3_56 : batch dict 9 l3 l4 c3 56 4 = true := by decide +kernel
private theorem c3_60 : batch dict 9 l3 l4 c3 60 4 = true := by decide +kernel
private theorem c3_64 : batch dict 9 l3 l4 c3 64 4 = true := by decide +kernel
private theorem c3_68 : batch dict 9 l3 l4 c3 68 4 = true := by decide +kernel
theorem b3_48 (i : Nat) (lo : 48 ≤ i) (hi : i < 72) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 60
  · by_cases cut : i < 52
    · exact fromBatch c3_48 (by omega) (by omega)
    · by_cases cut : i < 56
      · exact fromBatch c3_52 (by omega) (by omega)
      · exact fromBatch c3_56 (by omega) (by omega)
  · by_cases cut : i < 64
    · exact fromBatch c3_60 (by omega) (by omega)
    · by_cases cut : i < 68
      · exact fromBatch c3_64 (by omega) (by omega)
      · exact fromBatch c3_68 (by omega) (by omega)
end Checkpoint121.Pairs.M129
