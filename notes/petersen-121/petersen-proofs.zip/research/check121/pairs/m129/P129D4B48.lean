import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c4_48 : batch dict 8 l4 l5 c4 48 4 = true := by decide +kernel
private theorem c4_52 : batch dict 8 l4 l5 c4 52 4 = true := by decide +kernel
private theorem c4_56 : batch dict 8 l4 l5 c4 56 4 = true := by decide +kernel
private theorem c4_60 : batch dict 8 l4 l5 c4 60 4 = true := by decide +kernel
private theorem c4_64 : batch dict 8 l4 l5 c4 64 4 = true := by decide +kernel
private theorem c4_68 : batch dict 8 l4 l5 c4 68 4 = true := by decide +kernel
theorem b4_48 (i : Nat) (lo : 48 ≤ i) (hi : i < 72) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 60
  · by_cases cut : i < 52
    · exact fromBatch c4_48 (by omega) (by omega)
    · by_cases cut : i < 56
      · exact fromBatch c4_52 (by omega) (by omega)
      · exact fromBatch c4_56 (by omega) (by omega)
  · by_cases cut : i < 64
    · exact fromBatch c4_60 (by omega) (by omega)
    · by_cases cut : i < 68
      · exact fromBatch c4_64 (by omega) (by omega)
      · exact fromBatch c4_68 (by omega) (by omega)
end Checkpoint121.Pairs.M129
