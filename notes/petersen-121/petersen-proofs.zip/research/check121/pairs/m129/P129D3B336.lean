import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c3_336 : batch dict 9 l3 l4 c3 336 4 = true := by decide +kernel
private theorem c3_340 : batch dict 9 l3 l4 c3 340 4 = true := by decide +kernel
private theorem c3_344 : batch dict 9 l3 l4 c3 344 4 = true := by decide +kernel
private theorem c3_348 : batch dict 9 l3 l4 c3 348 4 = true := by decide +kernel
private theorem c3_352 : batch dict 9 l3 l4 c3 352 4 = true := by decide +kernel
private theorem c3_356 : batch dict 9 l3 l4 c3 356 4 = true := by decide +kernel
theorem b3_336 (i : Nat) (lo : 336 ≤ i) (hi : i < 360) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 348
  · by_cases cut : i < 340
    · exact fromBatch c3_336 (by omega) (by omega)
    · by_cases cut : i < 344
      · exact fromBatch c3_340 (by omega) (by omega)
      · exact fromBatch c3_344 (by omega) (by omega)
  · by_cases cut : i < 352
    · exact fromBatch c3_348 (by omega) (by omega)
    · by_cases cut : i < 356
      · exact fromBatch c3_352 (by omega) (by omega)
      · exact fromBatch c3_356 (by omega) (by omega)
end Checkpoint121.Pairs.M129
