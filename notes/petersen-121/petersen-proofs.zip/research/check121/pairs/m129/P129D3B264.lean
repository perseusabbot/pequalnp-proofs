import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c3_264 : batch dict 9 l3 l4 c3 264 4 = true := by decide +kernel
private theorem c3_268 : batch dict 9 l3 l4 c3 268 4 = true := by decide +kernel
private theorem c3_272 : batch dict 9 l3 l4 c3 272 4 = true := by decide +kernel
private theorem c3_276 : batch dict 9 l3 l4 c3 276 4 = true := by decide +kernel
private theorem c3_280 : batch dict 9 l3 l4 c3 280 4 = true := by decide +kernel
private theorem c3_284 : batch dict 9 l3 l4 c3 284 4 = true := by decide +kernel
theorem b3_264 (i : Nat) (lo : 264 ≤ i) (hi : i < 288) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 276
  · by_cases cut : i < 268
    · exact fromBatch c3_264 (by omega) (by omega)
    · by_cases cut : i < 272
      · exact fromBatch c3_268 (by omega) (by omega)
      · exact fromBatch c3_272 (by omega) (by omega)
  · by_cases cut : i < 280
    · exact fromBatch c3_276 (by omega) (by omega)
    · by_cases cut : i < 284
      · exact fromBatch c3_280 (by omega) (by omega)
      · exact fromBatch c3_284 (by omega) (by omega)
end Checkpoint121.Pairs.M129
