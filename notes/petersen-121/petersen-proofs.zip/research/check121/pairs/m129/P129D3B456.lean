import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c3_456 : batch dict 9 l3 l4 c3 456 4 = true := by decide +kernel
private theorem c3_460 : batch dict 9 l3 l4 c3 460 4 = true := by decide +kernel
private theorem c3_464 : batch dict 9 l3 l4 c3 464 4 = true := by decide +kernel
private theorem c3_468 : batch dict 9 l3 l4 c3 468 4 = true := by decide +kernel
private theorem c3_472 : batch dict 9 l3 l4 c3 472 4 = true := by decide +kernel
private theorem c3_476 : batch dict 9 l3 l4 c3 476 4 = true := by decide +kernel
theorem b3_456 (i : Nat) (lo : 456 ≤ i) (hi : i < 480) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 468
  · by_cases cut : i < 460
    · exact fromBatch c3_456 (by omega) (by omega)
    · by_cases cut : i < 464
      · exact fromBatch c3_460 (by omega) (by omega)
      · exact fromBatch c3_464 (by omega) (by omega)
  · by_cases cut : i < 472
    · exact fromBatch c3_468 (by omega) (by omega)
    · by_cases cut : i < 476
      · exact fromBatch c3_472 (by omega) (by omega)
      · exact fromBatch c3_476 (by omega) (by omega)
end Checkpoint121.Pairs.M129
