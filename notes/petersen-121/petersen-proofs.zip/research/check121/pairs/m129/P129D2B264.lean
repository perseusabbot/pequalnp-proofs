import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c2_264 : batch dict 10 l2 l3 c2 264 4 = true := by decide +kernel
private theorem c2_268 : batch dict 10 l2 l3 c2 268 4 = true := by decide +kernel
private theorem c2_272 : batch dict 10 l2 l3 c2 272 4 = true := by decide +kernel
private theorem c2_276 : batch dict 10 l2 l3 c2 276 4 = true := by decide +kernel
private theorem c2_280 : batch dict 10 l2 l3 c2 280 4 = true := by decide +kernel
private theorem c2_284 : batch dict 10 l2 l3 c2 284 4 = true := by decide +kernel
theorem b2_264 (i : Nat) (lo : 264 ≤ i) (hi : i < 288) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 276
  · by_cases cut : i < 268
    · exact fromBatch c2_264 (by omega) (by omega)
    · by_cases cut : i < 272
      · exact fromBatch c2_268 (by omega) (by omega)
      · exact fromBatch c2_272 (by omega) (by omega)
  · by_cases cut : i < 280
    · exact fromBatch c2_276 (by omega) (by omega)
    · by_cases cut : i < 284
      · exact fromBatch c2_280 (by omega) (by omega)
      · exact fromBatch c2_284 (by omega) (by omega)
end Checkpoint121.Pairs.M129
