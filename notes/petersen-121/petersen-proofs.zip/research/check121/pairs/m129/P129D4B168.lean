import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c4_168 : batch dict 8 l4 l5 c4 168 4 = true := by decide +kernel
private theorem c4_172 : batch dict 8 l4 l5 c4 172 4 = true := by decide +kernel
private theorem c4_176 : batch dict 8 l4 l5 c4 176 2 = true := by decide +kernel
theorem b4_168 (i : Nat) (lo : 168 ≤ i) (hi : i < 178) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 172
  · exact fromBatch c4_168 (by omega) (by omega)
  · by_cases cut : i < 176
    · exact fromBatch c4_172 (by omega) (by omega)
    · exact fromBatch c4_176 (by omega) (by omega)
end Checkpoint121.Pairs.M129
