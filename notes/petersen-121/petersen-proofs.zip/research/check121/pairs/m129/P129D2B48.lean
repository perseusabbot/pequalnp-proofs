import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c2_48 : batch dict 10 l2 l3 c2 48 4 = true := by decide +kernel
private theorem c2_52 : batch dict 10 l2 l3 c2 52 4 = true := by decide +kernel
private theorem c2_56 : batch dict 10 l2 l3 c2 56 4 = true := by decide +kernel
private theorem c2_60 : batch dict 10 l2 l3 c2 60 4 = true := by decide +kernel
private theorem c2_64 : batch dict 10 l2 l3 c2 64 4 = true := by decide +kernel
private theorem c2_68 : batch dict 10 l2 l3 c2 68 4 = true := by decide +kernel
theorem b2_48 (i : Nat) (lo : 48 ≤ i) (hi : i < 72) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 60
  · by_cases cut : i < 52
    · exact fromBatch c2_48 (by omega) (by omega)
    · by_cases cut : i < 56
      · exact fromBatch c2_52 (by omega) (by omega)
      · exact fromBatch c2_56 (by omega) (by omega)
  · by_cases cut : i < 64
    · exact fromBatch c2_60 (by omega) (by omega)
    · by_cases cut : i < 68
      · exact fromBatch c2_64 (by omega) (by omega)
      · exact fromBatch c2_68 (by omega) (by omega)
end Checkpoint121.Pairs.M129
