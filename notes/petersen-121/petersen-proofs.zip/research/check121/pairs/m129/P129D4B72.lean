import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c4_72 : batch dict 8 l4 l5 c4 72 4 = true := by decide +kernel
private theorem c4_76 : batch dict 8 l4 l5 c4 76 4 = true := by decide +kernel
private theorem c4_80 : batch dict 8 l4 l5 c4 80 4 = true := by decide +kernel
private theorem c4_84 : batch dict 8 l4 l5 c4 84 4 = true := by decide +kernel
private theorem c4_88 : batch dict 8 l4 l5 c4 88 4 = true := by decide +kernel
private theorem c4_92 : batch dict 8 l4 l5 c4 92 4 = true := by decide +kernel
theorem b4_72 (i : Nat) (lo : 72 ≤ i) (hi : i < 96) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 84
  · by_cases cut : i < 76
    · exact fromBatch c4_72 (by omega) (by omega)
    · by_cases cut : i < 80
      · exact fromBatch c4_76 (by omega) (by omega)
      · exact fromBatch c4_80 (by omega) (by omega)
  · by_cases cut : i < 88
    · exact fromBatch c4_84 (by omega) (by omega)
    · by_cases cut : i < 92
      · exact fromBatch c4_88 (by omega) (by omega)
      · exact fromBatch c4_92 (by omega) (by omega)
end Checkpoint121.Pairs.M129
