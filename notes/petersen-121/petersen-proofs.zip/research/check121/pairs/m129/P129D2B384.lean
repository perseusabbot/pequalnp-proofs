import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c2_384 : batch dict 10 l2 l3 c2 384 4 = true := by decide +kernel
private theorem c2_388 : batch dict 10 l2 l3 c2 388 4 = true := by decide +kernel
private theorem c2_392 : batch dict 10 l2 l3 c2 392 4 = true := by decide +kernel
private theorem c2_396 : batch dict 10 l2 l3 c2 396 4 = true := by decide +kernel
private theorem c2_400 : batch dict 10 l2 l3 c2 400 4 = true := by decide +kernel
private theorem c2_404 : batch dict 10 l2 l3 c2 404 4 = true := by decide +kernel
theorem b2_384 (i : Nat) (lo : 384 ≤ i) (hi : i < 408) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 396
  · by_cases cut : i < 388
    · exact fromBatch c2_384 (by omega) (by omega)
    · by_cases cut : i < 392
      · exact fromBatch c2_388 (by omega) (by omega)
      · exact fromBatch c2_392 (by omega) (by omega)
  · by_cases cut : i < 400
    · exact fromBatch c2_396 (by omega) (by omega)
    · by_cases cut : i < 404
      · exact fromBatch c2_400 (by omega) (by omega)
      · exact fromBatch c2_404 (by omega) (by omega)
end Checkpoint121.Pairs.M129
