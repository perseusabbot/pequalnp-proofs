import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c2_408 : batch dict 10 l2 l3 c2 408 4 = true := by decide +kernel
private theorem c2_412 : batch dict 10 l2 l3 c2 412 4 = true := by decide +kernel
private theorem c2_416 : batch dict 10 l2 l3 c2 416 4 = true := by decide +kernel
private theorem c2_420 : batch dict 10 l2 l3 c2 420 4 = true := by decide +kernel
private theorem c2_424 : batch dict 10 l2 l3 c2 424 4 = true := by decide +kernel
private theorem c2_428 : batch dict 10 l2 l3 c2 428 4 = true := by decide +kernel
theorem b2_408 (i : Nat) (lo : 408 ≤ i) (hi : i < 432) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 420
  · by_cases cut : i < 412
    · exact fromBatch c2_408 (by omega) (by omega)
    · by_cases cut : i < 416
      · exact fromBatch c2_412 (by omega) (by omega)
      · exact fromBatch c2_416 (by omega) (by omega)
  · by_cases cut : i < 424
    · exact fromBatch c2_420 (by omega) (by omega)
    · by_cases cut : i < 428
      · exact fromBatch c2_424 (by omega) (by omega)
      · exact fromBatch c2_428 (by omega) (by omega)
end Checkpoint121.Pairs.M129
