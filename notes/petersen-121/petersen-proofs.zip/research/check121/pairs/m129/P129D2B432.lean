import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c2_432 : batch dict 10 l2 l3 c2 432 4 = true := by decide +kernel
private theorem c2_436 : batch dict 10 l2 l3 c2 436 4 = true := by decide +kernel
private theorem c2_440 : batch dict 10 l2 l3 c2 440 4 = true := by decide +kernel
private theorem c2_444 : batch dict 10 l2 l3 c2 444 4 = true := by decide +kernel
private theorem c2_448 : batch dict 10 l2 l3 c2 448 4 = true := by decide +kernel
private theorem c2_452 : batch dict 10 l2 l3 c2 452 1 = true := by decide +kernel
theorem b2_432 (i : Nat) (lo : 432 ≤ i) (hi : i < 453) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 444
  · by_cases cut : i < 436
    · exact fromBatch c2_432 (by omega) (by omega)
    · by_cases cut : i < 440
      · exact fromBatch c2_436 (by omega) (by omega)
      · exact fromBatch c2_440 (by omega) (by omega)
  · by_cases cut : i < 448
    · exact fromBatch c2_444 (by omega) (by omega)
    · by_cases cut : i < 452
      · exact fromBatch c2_448 (by omega) (by omega)
      · exact fromBatch c2_452 (by omega) (by omega)
end Checkpoint121.Pairs.M129
