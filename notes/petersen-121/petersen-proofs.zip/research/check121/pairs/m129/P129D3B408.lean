import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c3_408 : batch dict 9 l3 l4 c3 408 4 = true := by decide +kernel
private theorem c3_412 : batch dict 9 l3 l4 c3 412 4 = true := by decide +kernel
private theorem c3_416 : batch dict 9 l3 l4 c3 416 4 = true := by decide +kernel
private theorem c3_420 : batch dict 9 l3 l4 c3 420 4 = true := by decide +kernel
private theorem c3_424 : batch dict 9 l3 l4 c3 424 4 = true := by decide +kernel
private theorem c3_428 : batch dict 9 l3 l4 c3 428 4 = true := by decide +kernel
theorem b3_408 (i : Nat) (lo : 408 ≤ i) (hi : i < 432) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 420
  · by_cases cut : i < 412
    · exact fromBatch c3_408 (by omega) (by omega)
    · by_cases cut : i < 416
      · exact fromBatch c3_412 (by omega) (by omega)
      · exact fromBatch c3_416 (by omega) (by omega)
  · by_cases cut : i < 424
    · exact fromBatch c3_420 (by omega) (by omega)
    · by_cases cut : i < 428
      · exact fromBatch c3_424 (by omega) (by omega)
      · exact fromBatch c3_428 (by omega) (by omega)
end Checkpoint121.Pairs.M129
