import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c3_384 : batch dict 9 l3 l4 c3 384 4 = true := by decide +kernel
private theorem c3_388 : batch dict 9 l3 l4 c3 388 4 = true := by decide +kernel
private theorem c3_392 : batch dict 9 l3 l4 c3 392 4 = true := by decide +kernel
private theorem c3_396 : batch dict 9 l3 l4 c3 396 4 = true := by decide +kernel
private theorem c3_400 : batch dict 9 l3 l4 c3 400 4 = true := by decide +kernel
private theorem c3_404 : batch dict 9 l3 l4 c3 404 4 = true := by decide +kernel
theorem b3_384 (i : Nat) (lo : 384 ≤ i) (hi : i < 408) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 396
  · by_cases cut : i < 388
    · exact fromBatch c3_384 (by omega) (by omega)
    · by_cases cut : i < 392
      · exact fromBatch c3_388 (by omega) (by omega)
      · exact fromBatch c3_392 (by omega) (by omega)
  · by_cases cut : i < 400
    · exact fromBatch c3_396 (by omega) (by omega)
    · by_cases cut : i < 404
      · exact fromBatch c3_400 (by omega) (by omega)
      · exact fromBatch c3_404 (by omega) (by omega)
end Checkpoint121.Pairs.M129
