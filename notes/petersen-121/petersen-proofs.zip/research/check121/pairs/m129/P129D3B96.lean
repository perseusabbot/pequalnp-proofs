import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c3_96 : batch dict 9 l3 l4 c3 96 4 = true := by decide +kernel
private theorem c3_100 : batch dict 9 l3 l4 c3 100 4 = true := by decide +kernel
private theorem c3_104 : batch dict 9 l3 l4 c3 104 4 = true := by decide +kernel
private theorem c3_108 : batch dict 9 l3 l4 c3 108 4 = true := by decide +kernel
private theorem c3_112 : batch dict 9 l3 l4 c3 112 4 = true := by decide +kernel
private theorem c3_116 : batch dict 9 l3 l4 c3 116 4 = true := by decide +kernel
theorem b3_96 (i : Nat) (lo : 96 ≤ i) (hi : i < 120) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 108
  · by_cases cut : i < 100
    · exact fromBatch c3_96 (by omega) (by omega)
    · by_cases cut : i < 104
      · exact fromBatch c3_100 (by omega) (by omega)
      · exact fromBatch c3_104 (by omega) (by omega)
  · by_cases cut : i < 112
    · exact fromBatch c3_108 (by omega) (by omega)
    · by_cases cut : i < 116
      · exact fromBatch c3_112 (by omega) (by omega)
      · exact fromBatch c3_116 (by omega) (by omega)
end Checkpoint121.Pairs.M129
