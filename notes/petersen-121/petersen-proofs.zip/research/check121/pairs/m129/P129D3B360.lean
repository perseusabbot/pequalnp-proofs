import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c3_360 : batch dict 9 l3 l4 c3 360 4 = true := by decide +kernel
private theorem c3_364 : batch dict 9 l3 l4 c3 364 4 = true := by decide +kernel
private theorem c3_368 : batch dict 9 l3 l4 c3 368 4 = true := by decide +kernel
private theorem c3_372 : batch dict 9 l3 l4 c3 372 4 = true := by decide +kernel
private theorem c3_376 : batch dict 9 l3 l4 c3 376 4 = true := by decide +kernel
private theorem c3_380 : batch dict 9 l3 l4 c3 380 4 = true := by decide +kernel
theorem b3_360 (i : Nat) (lo : 360 ≤ i) (hi : i < 384) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 372
  · by_cases cut : i < 364
    · exact fromBatch c3_360 (by omega) (by omega)
    · by_cases cut : i < 368
      · exact fromBatch c3_364 (by omega) (by omega)
      · exact fromBatch c3_368 (by omega) (by omega)
  · by_cases cut : i < 376
    · exact fromBatch c3_372 (by omega) (by omega)
    · by_cases cut : i < 380
      · exact fromBatch c3_376 (by omega) (by omega)
      · exact fromBatch c3_380 (by omega) (by omega)
end Checkpoint121.Pairs.M129
