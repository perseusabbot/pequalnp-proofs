import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c3_432 : batch dict 9 l3 l4 c3 432 4 = true := by decide +kernel
private theorem c3_436 : batch dict 9 l3 l4 c3 436 4 = true := by decide +kernel
private theorem c3_440 : batch dict 9 l3 l4 c3 440 4 = true := by decide +kernel
private theorem c3_444 : batch dict 9 l3 l4 c3 444 4 = true := by decide +kernel
private theorem c3_448 : batch dict 9 l3 l4 c3 448 4 = true := by decide +kernel
private theorem c3_452 : batch dict 9 l3 l4 c3 452 4 = true := by decide +kernel
theorem b3_432 (i : Nat) (lo : 432 ≤ i) (hi : i < 456) : checkRow dict 9 (l3[i]?.getD default) l4 (c3[i]?.getD 0) = true := by
  by_cases cut : i < 444
  · by_cases cut : i < 436
    · exact fromBatch c3_432 (by omega) (by omega)
    · by_cases cut : i < 440
      · exact fromBatch c3_436 (by omega) (by omega)
      · exact fromBatch c3_440 (by omega) (by omega)
  · by_cases cut : i < 448
    · exact fromBatch c3_444 (by omega) (by omega)
    · by_cases cut : i < 452
      · exact fromBatch c3_448 (by omega) (by omega)
      · exact fromBatch c3_452 (by omega) (by omega)
end Checkpoint121.Pairs.M129
