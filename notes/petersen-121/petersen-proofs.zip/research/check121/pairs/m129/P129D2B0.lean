import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c2_0 : batch dict 10 l2 l3 c2 0 4 = true := by decide +kernel
private theorem c2_4 : batch dict 10 l2 l3 c2 4 4 = true := by decide +kernel
private theorem c2_8 : batch dict 10 l2 l3 c2 8 4 = true := by decide +kernel
private theorem c2_12 : batch dict 10 l2 l3 c2 12 4 = true := by decide +kernel
private theorem c2_16 : batch dict 10 l2 l3 c2 16 4 = true := by decide +kernel
private theorem c2_20 : batch dict 10 l2 l3 c2 20 4 = true := by decide +kernel
theorem b2_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 24) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 12
  · by_cases cut : i < 4
    · exact fromBatch c2_0 (by omega) (by omega)
    · by_cases cut : i < 8
      · exact fromBatch c2_4 (by omega) (by omega)
      · exact fromBatch c2_8 (by omega) (by omega)
  · by_cases cut : i < 16
    · exact fromBatch c2_12 (by omega) (by omega)
    · by_cases cut : i < 20
      · exact fromBatch c2_16 (by omega) (by omega)
      · exact fromBatch c2_20 (by omega) (by omega)
end Checkpoint121.Pairs.M129
