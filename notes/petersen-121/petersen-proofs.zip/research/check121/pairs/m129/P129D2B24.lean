import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c2_24 : batch dict 10 l2 l3 c2 24 4 = true := by decide +kernel
private theorem c2_28 : batch dict 10 l2 l3 c2 28 4 = true := by decide +kernel
private theorem c2_32 : batch dict 10 l2 l3 c2 32 4 = true := by decide +kernel
private theorem c2_36 : batch dict 10 l2 l3 c2 36 4 = true := by decide +kernel
private theorem c2_40 : batch dict 10 l2 l3 c2 40 4 = true := by decide +kernel
private theorem c2_44 : batch dict 10 l2 l3 c2 44 4 = true := by decide +kernel
theorem b2_24 (i : Nat) (lo : 24 ≤ i) (hi : i < 48) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 36
  · by_cases cut : i < 28
    · exact fromBatch c2_24 (by omega) (by omega)
    · by_cases cut : i < 32
      · exact fromBatch c2_28 (by omega) (by omega)
      · exact fromBatch c2_32 (by omega) (by omega)
  · by_cases cut : i < 40
    · exact fromBatch c2_36 (by omega) (by omega)
    · by_cases cut : i < 44
      · exact fromBatch c2_40 (by omega) (by omega)
      · exact fromBatch c2_44 (by omega) (by omega)
end Checkpoint121.Pairs.M129
