import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c4_24 : batch dict 8 l4 l5 c4 24 4 = true := by decide +kernel
private theorem c4_28 : batch dict 8 l4 l5 c4 28 4 = true := by decide +kernel
private theorem c4_32 : batch dict 8 l4 l5 c4 32 4 = true := by decide +kernel
private theorem c4_36 : batch dict 8 l4 l5 c4 36 4 = true := by decide +kernel
private theorem c4_40 : batch dict 8 l4 l5 c4 40 4 = true := by decide +kernel
private theorem c4_44 : batch dict 8 l4 l5 c4 44 4 = true := by decide +kernel
theorem b4_24 (i : Nat) (lo : 24 ≤ i) (hi : i < 48) : checkRow dict 8 (l4[i]?.getD default) l5 (c4[i]?.getD 0) = true := by
  by_cases cut : i < 36
  · by_cases cut : i < 28
    · exact fromBatch c4_24 (by omega) (by omega)
    · by_cases cut : i < 32
      · exact fromBatch c4_28 (by omega) (by omega)
      · exact fromBatch c4_32 (by omega) (by omega)
  · by_cases cut : i < 40
    · exact fromBatch c4_36 (by omega) (by omega)
    · by_cases cut : i < 44
      · exact fromBatch c4_40 (by omega) (by omega)
      · exact fromBatch c4_44 (by omega) (by omega)
end Checkpoint121.Pairs.M129
