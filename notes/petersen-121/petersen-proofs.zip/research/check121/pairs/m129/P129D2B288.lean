import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c2_288 : batch dict 10 l2 l3 c2 288 4 = true := by decide +kernel
private theorem c2_292 : batch dict 10 l2 l3 c2 292 4 = true := by decide +kernel
private theorem c2_296 : batch dict 10 l2 l3 c2 296 4 = true := by decide +kernel
private theorem c2_300 : batch dict 10 l2 l3 c2 300 4 = true := by decide +kernel
private theorem c2_304 : batch dict 10 l2 l3 c2 304 4 = true := by decide +kernel
private theorem c2_308 : batch dict 10 l2 l3 c2 308 4 = true := by decide +kernel
theorem b2_288 (i : Nat) (lo : 288 ≤ i) (hi : i < 312) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 300
  · by_cases cut : i < 292
    · exact fromBatch c2_288 (by omega) (by omega)
    · by_cases cut : i < 296
      · exact fromBatch c2_292 (by omega) (by omega)
      · exact fromBatch c2_296 (by omega) (by omega)
  · by_cases cut : i < 304
    · exact fromBatch c2_300 (by omega) (by omega)
    · by_cases cut : i < 308
      · exact fromBatch c2_304 (by omega) (by omega)
      · exact fromBatch c2_308 (by omega) (by omega)
end Checkpoint121.Pairs.M129
