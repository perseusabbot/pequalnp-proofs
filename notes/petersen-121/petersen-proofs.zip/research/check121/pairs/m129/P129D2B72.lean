import P129Data

open Petersen120.Mask81.LayerCheck
open Checkpoint121.Scored
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Checkpoint121.Pairs.M129
private theorem c2_72 : batch dict 10 l2 l3 c2 72 4 = true := by decide +kernel
private theorem c2_76 : batch dict 10 l2 l3 c2 76 4 = true := by decide +kernel
private theorem c2_80 : batch dict 10 l2 l3 c2 80 4 = true := by decide +kernel
private theorem c2_84 : batch dict 10 l2 l3 c2 84 4 = true := by decide +kernel
private theorem c2_88 : batch dict 10 l2 l3 c2 88 4 = true := by decide +kernel
private theorem c2_92 : batch dict 10 l2 l3 c2 92 4 = true := by decide +kernel
theorem b2_72 (i : Nat) (lo : 72 ≤ i) (hi : i < 96) : checkRow dict 10 (l2[i]?.getD default) l3 (c2[i]?.getD 0) = true := by
  by_cases cut : i < 84
  · by_cases cut : i < 76
    · exact fromBatch c2_72 (by omega) (by omega)
    · by_cases cut : i < 80
      · exact fromBatch c2_76 (by omega) (by omega)
      · exact fromBatch c2_80 (by omega) (by omega)
  · by_cases cut : i < 88
    · exact fromBatch c2_84 (by omega) (by omega)
    · by_cases cut : i < 92
      · exact fromBatch c2_88 (by omega) (by omega)
      · exact fromBatch c2_92 (by omega) (by omega)
end Checkpoint121.Pairs.M129
