import Pair121

namespace Checkpoint121.Binate
open PEqualNP.Outside.L_meta_274_aux
open Petersen1676.Table

/-- Two positive-negative assignment pairs represented on a single wire. -/
structure Four where
  p : Bool
  n : Bool
  q : Bool
  r : Bool
deriving DecidableEq, Fintype

def flip (u : Four) : Four := ⟨!u.p,!u.n,!u.q,!u.r⟩
def meet (u v : Four) : Four := ⟨u.p && v.p,u.n && v.n,u.q && v.q,u.r && v.r⟩
def join (u v : Four) : Four := ⟨u.p || v.p,u.n || v.n,u.q || v.q,u.r || v.r⟩
def combine (op : Bool) (u v : Four) := if op then meet u v else join u v
def mass (u : Four) : ℕ := if u.p = u.n ∧ u.q = u.r then 0 else 1
def polar (u : Four) : Prop := u.n ≤ u.p ∧ u.q ≤ u.r
instance (u : Four) : Decidable (polar u) := inferInstanceAs (Decidable (_ ∧ _))
def target : Four := ⟨true,false,true,false⟩

private theorem combBound : ∀ op u v, mass (combine op u v) ≤ mass u + mass v := by decide +kernel
private theorem combPolar : ∀ op u v, polar u → polar v → polar (combine op u v) := by decide +kernel
private theorem flat : ∀ u, mass u = 0 → u.p = u.n ∧ u.q = u.r := by decide +kernel
private theorem goodQ : ∀ u, polar u → u.q ≤ u.r := by decide +kernel

private theorem mono {s ws y} (h : Run flip meet join y s ws) (tight : ws.length=s+1)
    (f g : Four → Bool)
    (bin : ∀ op u v, f u ≤ g u → f v ≤ g v → f (combine op u v) ≤ g (combine op u v))
    (base : ∀ w ∈ ws, f w ≤ g w) : f y ≤ g y := by
  induction h using Run.fold with
  | done => exact base _ (by simp)
  | perm hp _ ih => exact ih (hp.length_eq.trans tight) (fun w hw => base w (hp.mem_iff.mp hw))
  | one save h ih =>
    have hlen := run_len h
    cases save <;> simp [kept] at hlen tight <;> omega
  | two op ka kb h ih =>
    have hlen := run_len h
    cases ka <;> cases kb <;> simp [kept] at hlen tight <;> try omega
    apply ih (by simp [kept]; omega)
    intro w hw
    simp only [kept,Bool.false_eq_true,ite_false,List.mem_cons] at hw
    rcases hw with rfl | hw
    · exact bin op _ _ (base _ (by simp)) (base _ (by simp))
    · exact base _ (by simp [hw])

private theorem binP : ∀ op u v, u.p ≤ u.n → v.p ≤ v.n →
    (combine op u v).p ≤ (combine op u v).n := by decide +kernel
private theorem binQ : ∀ op u v, u.q ≤ u.r → v.q ≤ v.r →
    (combine op u v).q ≤ (combine op u v).r := by decide +kernel

private theorem impossible {s ws} (h : Run flip meet join target s ws)
    (cheap : s ≤ ws.length) (base : ∀ w ∈ ws, polar w) (one : (ws.map mass).sum ≤ 1) : False := by
  induction h using Run.fold with
  | done => exact (by decide : ¬polar target) (base target (by simp))
  | perm hp _ ih =>
    exact ih (hp.length_eq ▸ cheap) (fun w hw => base _ (hp.mem_iff.mp hw))
      ((hp.map mass).sum_eq ▸ one)
  | @one s a rest save run ih =>
    have sz := run_len run
    cases save <;> simp only [kept,Bool.false_eq_true,ite_false,ite_true,List.length_cons] at sz cheap
    case true => omega
    case false =>
      have tight : (flip a::rest).length=s+1 := by simp; omega
      have endQ : ¬target.q ≤ target.r := by decide
      have endP : ¬target.p ≤ target.n := by decide
      have aok := base a (by simp)
      by_cases same : a.q = a.r
      · apply endQ (mono run tight Four.q Four.r binQ ?_)
        intro w hw
        simp only [kept,Bool.false_eq_true,ite_false,List.mem_cons] at hw
        rcases hw with rfl | hw
        · simp [flip,same]
        · exact (base _ (by simp [hw])).2
      · apply endP (mono run tight Four.p Four.n binP ?_)
        intro w hw
        simp only [kept,Bool.false_eq_true,ite_false,List.mem_cons] at hw
        rcases hw with rfl | hw
        · exact (show ∀ u : Four, polar u → (flip u).p ≤ (flip u).n by decide +kernel) a aok
        · have hpos : mass a = 1 := by simp [mass,same]
          simp only [List.map_cons,List.sum_cons,hpos] at one
          have incl : mass w ∈ rest.map mass := List.mem_map_of_mem hw
          have le := List.le_sum_of_mem incl
          have zero : mass w=0 := by omega
          exact (flat w zero).1.le
  | @two s a b rest op ka kb run ih =>
    let v := combine op a b
    have vok : polar v := combPolar op a b (base _ (by simp)) (base _ (by simp))
    have rOk (w) (hw : w ∈ rest) : polar w := base _ (by simp [hw])
    have sz := run_len run
    have next : ∀ w ∈ v :: kept ka a (kept kb b rest), polar w := by
      cases ka <;> cases kb <;> simp_all [kept]
    by_cases reuse : ka || kb = true
    · have tight : (v :: kept ka a (kept kb b rest)).length=s+1 := by
        cases ka <;> cases kb <;> simp_all [kept,v,combine] <;> omega
      exact (by decide : ¬target.q ≤ target.r)
        (mono run tight Four.q Four.r binQ (fun w hw => (next w hw).2))
    · have a0 : ka = false := by cases ka <;> simp_all
      have b0 : kb = false := by cases kb <;> simp_all
      subst ka kb
      apply ih
      · simp only [kept,Bool.false_eq_true,ite_false,List.length_cons] at cheap ⊢
        omega
      · exact next
      · have bound := combBound op a b
        change (mass v) ≤ mass a + mass b at bound
        simp only [kept,Bool.false_eq_true,ite_false,List.map_cons,List.sum_cons] at one ⊢
        change mass v + _ ≤ 1
        omega

def sample (p n q r w : Nat) : Four := ⟨w.testBit p,w.testBit n,w.testBit q,w.testBit r⟩

theorem noRun {m y s p n q r : Nat} {words : List Nat}
    (mask : sample p n q r m = ⟨true,true,true,true⟩) (goal : sample p n q r y = target)
    (cheap : s ≤ words.length) (base : ∀ w ∈ words, polar (sample p n q r w))
    (one : (words.map (mass ∘ sample p n q r)).sum ≤ 1) : ¬NatRun m y s words := by
  intro run
  have trans := Run.map (sample p n q r) (inv' := flip) (meet' := meet) (join' := join)
    (by
      intro a
      have hp := congrArg Four.p mask
      have hn := congrArg Four.n mask
      have hq := congrArg Four.q mask
      have hr := congrArg Four.r mask
      simp only [sample] at hp hn hq hr
      simp [sample,flip,Nat.testBit_xor,hp,hn,hq,hr])
    (by intro a b; simp [sample,meet,Nat.testBit_and])
    (by intro a b; simp [sample,join,Nat.testBit_or]) run
  rw [goal] at trans
  apply impossible trans (by simpa using cheap)
  · simpa only [List.forall_mem_map] using base
  · simpa only [List.map_map] using one

#print axioms noRun
end Checkpoint121.Binate
