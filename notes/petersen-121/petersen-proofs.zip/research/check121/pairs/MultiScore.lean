import Scored
import Binate
import Spare

namespace Checkpoint121.MultiScore
open PEqualNP.Outside.L_meta_274_aux
open Petersen1676 Petersen1676.Table Petersen1676.Prune Petersen1676.PinRules
open Petersen120.Mask81.LayerCheck

def row (code i : Nat) := (code >>> (11*i)) &&& 2047

def fourTest (code s : Nat) (ws : List Nat) : Bool :=
  let atBits := Binate.sample (row code 0) (row code 1) (row code 2) (row code 3)
  decide (atBits allMask = ⟨true,true,true,true⟩ ∧ atBits Table.goal = Binate.target ∧
    s ≤ ws.length ∧ (∀ w ∈ ws, Binate.polar (atBits w)) ∧
    (ws.map (Binate.mass ∘ atBits)).sum ≤ 1)

theorem fourNo {code s ws} (h : fourTest code s ws = true) : ¬NatRun allMask Table.goal s ws := by
  obtain ⟨mask,goal,cheap,base,one⟩ := of_decide_eq_true h
  exact Binate.noRun mask goal cheap base one

def signedTest (code s : Nat) (ws : List Nat) : Bool :=
  let rb := row code
  let score := Spare.sample (rb 0) (rb 1) (rb 2) (rb 3) (rb 4) (rb 5)
  decide ((∀ j ∈ [rb 0,rb 1,rb 2,rb 3,rb 4,rb 5], allMask.testBit j = true) ∧
    s ≤ ws.length ∧ (∀ w ∈ ws, w.testBit (rb 6) ≤ w.testBit (rb 7)) ∧
    ¬ Table.goal.testBit (rb 6) ≤ Table.goal.testBit (rb 7)) &&
    (ws.map score).sum < score Table.goal

theorem signedNo {code s ws} (h : signedTest code s ws = true) : ¬NatRun allMask Table.goal s ws := by
  simp only [signedTest,Bool.and_eq_true,decide_eq_true_eq] at h
  exact Spare.excluded h.1.1 h.1.2.1 h.1.2.2.1 h.1.2.2.2 h.2

def checkRow (words : Array Nat) (s : Nat) (r : Entry) (next : Array Entry) (code : Nat) : Bool :=
  if code >>> 88 = 1 then fourTest code (s+1) (decodeNode words r).1
  else if code >>> 88 = 2 then signedTest code (s+1) (decodeNode words r).1
  else Scored.checkRow words s r next code

def batch (words : Array Nat) (s : Nat) (cur next : Array Entry) (codes : Array Nat)
    (offset size : Nat) : Bool :=
  (List.range size).all fun j =>
    checkRow words s (cur[offset+j]?.getD default) next (codes[offset+j]?.getD 0)

theorem fromBatch {words s cur next codes offset size i}
    (checked : batch words s cur next codes offset size = true)
    (lower : offset ≤ i) (upper : i < offset+size) :
    checkRow words s (cur[i]?.getD default) next (codes[i]?.getD 0) = true := by
  have j : i-offset < size := by omega
  have h := List.all_eq_true.mp checked (i-offset) (List.mem_range.mpr j)
  simpa only [show offset+(i-offset)=i from by omega] using h

theorem priorScored (words : Array Nat) (s : Nat) (cur next : Array Entry) (codes : Array Nat)
    (ok : ∀ i : Fin cur.size, checkRow words s cur[i] next (codes[i.val]?.getD 0) = true)
    (after : Closed words s next) : Closed words (s+1) cur := by
  intro i
  dsimp only
  intro inv
  have yes := ok i
  unfold checkRow at yes
  split at yes
  · exact fourNo yes
  split at yes
  · exact signedNo yes
  · let code := codes[i.val]?.getD 0
    have single : Closed words (s+1) #[cur[i]] := by
      apply Scored.priorScored _ _ _ _ #[code] _ after
      intro j
      have eq : j = 0 := Fin.eq_zero j
      subst j
      exact yes
    exact single ⟨0,by simp⟩ inv

#print axioms priorScored
end Checkpoint121.MultiScore
