import RepCheck

namespace Petersen120.Triple
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

private theorem check4 : test 4 = false := by decide +kernel

theorem noRep4 : ¬ NatRun allMask Table.goal 12 (starts.getD 4 []) :=
  refute 4 (by decide +kernel) check4

#print axioms noRep4
end Petersen120.Triple
