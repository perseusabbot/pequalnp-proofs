import RepCheck

namespace Petersen120.Triple
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

private theorem check1 : test 1 = false := by decide +kernel

theorem noRep1 : ¬ NatRun allMask Table.goal 12 (starts.getD 1 []) :=
  refute 1 (by decide +kernel) check1

#print axioms noRep1
end Petersen120.Triple
