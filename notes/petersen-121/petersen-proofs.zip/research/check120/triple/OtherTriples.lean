import TripleModels

namespace Petersen120.Other
open PEqualNP.Outside.L_meta_274_aux
open Petersen1676 Petersen1676.Table Petersen1676.Actual Petersen1676.Triples46
open Petersen1676.Prune Petersen1676.PinRules Petersen1676.Search

set_option maxRecDepth 16000
set_option maxHeartbeats 1000000
set_option exponentiation.threshold 900

def headItem (q : Fin 4) : Item :=
  ⟨Triple.pin q,8,headerCost (Triple.pin q) raw (Table46.start true) Table46.header⟩

def item (k : Fin 3) (q : Fin 4) : Item :=
  if freeOn (Triple.pin q) raw raw (triple k) then ⟨Triple.pin q,8,0⟩
  else update raw (Table46.start true) (triple k) (headItem q)

def initial (k : Fin 3) := budget k ++ List.ofFn (item k)

private theorem permValid {i k} (h : Valid allMask Table.goal raw (triple k :: raw) i) :
    Valid allMask Table.goal raw (tripleSignals k) i := by
  obtain ⟨d,b⟩ := h
  refine ⟨d,builtSubset b ?_⟩
  simp [tripleSignals,or_comm]

private theorem item_ok (k : Fin 3) (q : Fin 4) : Valid allMask Table.goal raw (tripleSignals k) (item k q) := by
  apply permValid
  unfold item
  split
  · rename_i free
    let d := Triple.model q
    have base := rawBuilt d.row raw d.inputs raw (fun _ h => h)
    exact ⟨d,freeWord d.row (Triple.pin q) d.pinTrue raw raw d.inputs _ free base⟩
  · have mem : ∀ i : Fin 9, rawWord i ∈ raw := by decide +kernel
    have start : Valid allMask Table.goal raw (Table46.start true) (headItem q) := by
      apply headerValid (Triple.model q) (rawWord 4) (rawWord 6) (mem 4) (mem 6)
      simp [Table46.start,or_comm,Table46.header,rawWord]
    have edge : EdgeStep allMask (Table46.start true) (triple k :: raw) := by
      constructor
      · apply Made.binary (a := Table46.header) (b := rawWord (vertex k)) (conj := false)
        · simp [Table46.start]
        · simp [Table46.start,mem]
      · intro w hw; simp [Table46.start,hw]
    exact advance_one start edge

theorem good (k : Fin 3) : Invariant allMask Table.goal raw (tripleSignals k) (initial k) := by
  intro i hi
  rcases List.mem_append.mp hi with h|h
  · exact initialized k i h
  · obtain ⟨q,rfl⟩ := List.mem_ofFn.mp h
    exact item_ok k q

def gen (k : Fin 3) := Cached.genExact allMask raw (covers kk) 12 (tripleSignals k) (initial k)
theorem successor (k : Fin 3) (run : NatRun allMask Table.goal 13 (tripleSignals k)) :
    ∃ q ∈ gen k, NatRun allMask Table.goal 12 q.1 := by
  by_contra! deny
  apply Memo.splitRefute (m := allMask) (raw := raw) (cut := RunTable.cut)
    (goal := Table.goal) (s := 12) ?_ (good k) ?_ run
  · intro _ _ _ inv hr
    rw [RunTable.cut,Bool.and_eq_true]
    exact ⟨covers_ok (k := kk) hr, legal_sound inv hr⟩
  · intro q hq
    rw [← Cached.actual_gen] at hq
    exact deny q hq

#print axioms good
#print axioms successor
end Petersen120.Other
