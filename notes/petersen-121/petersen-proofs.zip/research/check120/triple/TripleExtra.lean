import TripleModels

namespace Petersen120.Triple
open PEqualNP.Outside.L_meta_274_aux
open Petersen1676 Petersen1676.Table Petersen1676.Actual Petersen1676.Triples46
open Petersen1676.Prune Petersen1676.PinRules Petersen1676.Search

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 900

def extendedBudget := budget 2 ++ items
theorem startValid : Invariant allMask Table.goal raw (tripleSignals 2) extendedBudget := by
  intro i hi
  rcases List.mem_append.mp hi with h|h
  · exact initialized 2 i h
  · exact extraGood i h

def first := Cached.genExact allMask raw (covers kk) 12 (tripleSignals 2) extendedBudget
private theorem included : first.all (fun q => starts.contains q.1) = true := by decide +kernel

theorem descend (run : NatRun allMask Table.goal 13 (tripleSignals 2)) :
    ∃ w ∈ starts, NatRun allMask Table.goal 12 w := by
  by_contra! deny
  apply Memo.splitRefute (m := allMask) (raw := raw) (cut := RunTable.cut)
    (goal := Table.goal) (s := 12) ?_ startValid ?_ run
  · intro _ _ _ inv hr
    rw [RunTable.cut,Bool.and_eq_true]
    exact ⟨covers_ok (k := kk) hr, legal_sound inv hr⟩
  · intro q hq
    rw [← Cached.actual_gen] at hq
    exact deny q.1 (List.contains_iff_mem.mp (List.all_eq_true.mp included q hq))

def branchBudget (d : Desc) := advance raw (tripleSignals 2) (intermediate d) extendedBudget

private theorem operandBounds : ∀ d ∈ descs, d.2.1 < 10 ∧ d.2.2.1 < 10 := by decide +kernel
private theorem word_mem (j : Nat) (h : j < 10) : word j ∈ tripleSignals 2 := by
  have eq : (tripleSignals 2).length = 10 := by decide +kernel
  unfold word
  rw [List.getD_eq_getElem _ _ (by omega)]
  exact List.getElem_mem _

theorem validAt (d : Desc) (hd : d ∈ descs) :
    Invariant allMask Table.goal raw (Memo.canonical (intermediate d)) (branchBudget d) := by
  obtain ⟨op,a,b,del⟩ := d
  obtain ⟨ha,hb⟩ := operandBounds _ hd
  have ed : EdgeStep allMask (tripleSignals 2) (intermediate (op,a,b,del)) := by
    constructor
    · by_cases hn : op = 2
      · exact (by simpa [emitted,hn] using Made.unary (m := allMask) (word_mem a ha))
      · by_cases ho : op = 1
        · exact (by simpa [emitted,hn,ho] using Made.binary (m := allMask) (word_mem a ha) (word_mem b hb) false)
        · exact (by simpa [emitted,hn,ho] using Made.binary (m := allMask) (word_mem a ha) (word_mem b hb) true)
    · intro w hw
      obtain ⟨i,hi,rfl⟩ := List.mem_map.mp hw
      exact word_mem i (List.mem_range.mp (List.mem_filter.mp hi).1)
  have valid := advance_sound startValid ed
  intro i hi
  obtain ⟨dd,h⟩ := valid i hi
  refine ⟨dd,builtSubset h ?_⟩
  exact fun f hf => ((Memo.canonicalPerm _).map (decode dd.row)).mem_iff.mp hf

#print axioms descend
#print axioms validAt
end Petersen120.Triple
