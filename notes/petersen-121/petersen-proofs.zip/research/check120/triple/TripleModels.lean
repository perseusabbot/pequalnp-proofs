import TripleStates
import TruePins

namespace Petersen120.Triple
open PEqualNP.Outside.L_meta_274_aux
open Petersen1676 Petersen1676.Table Petersen1676.Actual Petersen1676.Triples46
open Petersen1676.Prune Petersen1676.PinRules

/-- Codes 0 through 5 refer to the six remaining coordinates. 6 and 7 encode false and true. -/
def label : Fin 4 → Fin 9 → Nat := ![![6, 0, 2, 6, 7, 1, 4, 3, 5], ![0, 2, 6, 5, 4, 6, 3, 7, 1], ![0, 6, 1, 3, 2, 4, 7, 5, 6], ![0, 2, 3, 1, 6, 4, 6, 6, 5]]
def fields : Fin 4 → Fin 3 → Fin 9 := ![![4, 0, 3], ![7, 2, 5], ![6, 1, 8], ![4, 6, 7]]
def fixed (k : Fin 4) (p : Fin 3) : Bool := decide (k ≠ 3 ∧ p = 0)
def embed (k : Fin 4) (x : Fin 6 → Bool) (i : Fin 9) : Bool :=
  if h : label k i < 6 then x ⟨label k i,h⟩ else decide (label k i = 7)
def condition (k : Fin 4) (p : Fin 3) : Nat :=
  let w := rawWord (fields k p)
  if fixed k p then w else Table.allMask ^^^ w
def pin (k : Fin 4) := condition k 0 &&& condition k 1 &&& condition k 2

private theorem fixed_ok : ∀ k p x, embed k x (fields k p) = fixed k p := by decide +kernel
private theorem cycle_ok : ∀ k x, edge9 (embed k x) = TruePins.cycle x := by decide +kernel

noncomputable def row (k : Fin 4) (x : Fin 6 → Bool) := fullRow (embed k x)

private theorem cond_ok (k p x) : (condition k p).testBit (row k x) = true := by
  unfold condition row
  cases h : fixed k p <;> simp [h,Nat.testBit_xor,fullRaw,fullMask,fixed_ok]

private theorem raw_ok (k : Fin 4) : RawWords (row k) raw := by
  intro w hw
  obtain ⟨j,rfl⟩ := rawHaveIndex w hw
  by_cases h : label k j < 6
  · right
    refine ⟨⟨label k j,h⟩,funext fun x => ?_⟩
    simpa [decode,row,embed,h] using (fullRaw (embed k x) j)
  · left
    refine ⟨decide (label k j = 7),funext fun x => ?_⟩
    simpa [decode,row,embed,h] using (fullRaw (embed k x) j)

noncomputable def model (k : Fin 4) : Model allMask Table.goal (pin k) 8 raw := by
  have target : decode (row k) Table.goal = TruePins.cycle := by
    funext x
    exact (fullGoal (embed k x)).trans (cycle_ok k x)
  refine ⟨6,row k,fun x => fullMask _,?_,raw_ok k,?_,?_⟩
  · intro x
    simp only [pin,Nat.testBit_and,cond_ok,Bool.and_self]
  · rw [target]
    rintro ⟨b,h⟩
    have h0 := congrFun h (fun _ => false)
    have h1 := congrFun h (fun _ => true)
    change false = b at h0
    change true = b at h1
    exact Bool.noConfusion (h0.trans h1.symm)
  · rw [target]; exact TruePins.cycleLower

def items : List Item := List.ofFn fun k : Fin 4 => ⟨pin k,8,0⟩

private theorem free : ∀ k, (tripleSignals 2).all (freeOn (pin k) raw []) = true := by decide +kernel

theorem extraGood : Invariant allMask Table.goal raw (tripleSignals 2) items := by
  intro it hi
  obtain ⟨k,rfl⟩ := List.mem_ofFn.mp hi
  let d := model k
  refine ⟨d,rawBuilt d.row (tripleSignals 2) ?_ (tripleSignals 2) (fun _ h => h)⟩
  intro w hw
  have good := List.all_eq_true.mp (free k) w hw
  simp only [freeOn,List.append_nil,Bool.or_eq_true] at good
  rcases good with hc | ha
  · exact Or.inl (maskedConstant d.row (pin k) d.pinTrue hc)
  · obtain ⟨v,hv,hm⟩ := List.any_eq_true.1 ha
    rw [maskedEqual d.row (pin k) d.pinTrue (of_decide_eq_true hm)]
    exact d.inputs v hv

#print axioms extraGood
end Petersen120.Triple
