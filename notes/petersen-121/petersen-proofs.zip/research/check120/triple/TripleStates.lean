import TripleChecks46

namespace Petersen120.Triple
open Petersen1676 Petersen1676.Table Petersen1676.Triples46 Petersen1676.Actual
open PEqualNP.Outside.L_meta_274_aux
abbrev Desc := Nat × Nat × Nat × Nat
def descs : List Desc := [
  (2, 8, 8, 256),
  (2, 9, 9, 512),
  (2, 1, 1, 2),
  (1, 0, 2, 0),
  (1, 2, 3, 0),
  (1, 0, 5, 0),
  (1, 3, 5, 0),
  (1, 0, 1, 0),
  (1, 1, 2, 0),
  (1, 1, 3, 0),
  (1, 1, 5, 0),
  (1, 3, 8, 0),
  (1, 0, 8, 0),
  (1, 2, 8, 0),
  (1, 5, 8, 0),
  (1, 1, 9, 512),
  (1, 2, 9, 512),
  (1, 0, 9, 512),
  (1, 3, 9, 512),
  (1, 5, 9, 512),
  (1, 8, 9, 512),
  (2, 5, 5, 32),
  (2, 3, 3, 8),
  (2, 2, 2, 4),
  (2, 0, 0, 1)]

def word (i : Nat) := (tripleSignals 2).getD i 0
def emitted (d : Desc) :=
  let (op,a,b,_) := d
  if op = 2 then word a ^^^ allMask else if op = 1 then word a ||| word b else word a &&& word b
def intermediate (d : Desc) : List Nat :=
  emitted d :: (((List.range 10).filter (fun i => !(d.2.2.2.testBit i))).map word)
def starts : List (List Nat) := descs.map (fun d => Memo.canonical (intermediate d))
end Petersen120.Triple
