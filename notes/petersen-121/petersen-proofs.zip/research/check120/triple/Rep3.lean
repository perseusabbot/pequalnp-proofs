import RepCheck

namespace Petersen120.Triple
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

private theorem check3 : test 3 = false := by decide +kernel

theorem noRep3 : ¬ NatRun allMask Table.goal 12 (starts.getD 3 []) :=
  refute 3 (by decide +kernel) check3

#print axioms noRep3
end Petersen120.Triple
