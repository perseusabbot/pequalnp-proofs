import Rep0
import Rep1
import Rep3
import Rep4
import Rep15

namespace Petersen120.Triple
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table

theorem fiveClosed : ∀ i ∈ ([0,1,3,4,15] : List Nat), ¬NatRun allMask Table.goal 12 (starts.getD i []) := by
  intro i hi
  simp only [List.mem_cons,List.not_mem_nil,or_false] at hi
  rcases hi with rfl|rfl|rfl|rfl|rfl
  · exact noRep0
  · exact noRep1
  · exact noRep3
  · exact noRep4
  · exact noRep15

#print axioms fiveClosed
end Petersen120.Triple
