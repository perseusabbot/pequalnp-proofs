import TripleExtra

namespace Petersen120.Triple
open PEqualNP.Outside.L_meta_274_aux
open Petersen1676 Petersen1676.Table

def code (i : Nat) := descs.getD i (0,0,0,0)
def candidates : List Nat := [0,1,3,4,15]
private theorem validCodes : ∀ i ∈ candidates, code i ∈ descs := by decide +kernel
private theorem start_eq : ∀ i ∈ candidates, starts.getD i [] = Memo.canonical (intermediate (code i)) :=
  by decide +kernel

def test (i : Nat) := Cached.search 12 (Memo.root (starts.getD i []) (branchBudget (code i)))

theorem refute (i : Nat) (inList : i ∈ candidates) (checked : test i = false) :
    ¬ NatRun allMask Table.goal 12 (starts.getD i []) := by
  apply Cached.refute _ checked
  rw [start_eq i inList]
  exact validAt _ (validCodes i inList)
end Petersen120.Triple
