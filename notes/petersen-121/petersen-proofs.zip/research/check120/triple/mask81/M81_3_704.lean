import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_704 : chunk words 9 l3 l4 704 4 = true := by decide +kernel
private theorem c3_708 : chunk words 9 l3 l4 708 4 = true := by decide +kernel
private theorem c3_712 : chunk words 9 l3 l4 712 4 = true := by decide +kernel
private theorem c3_716 : chunk words 9 l3 l4 716 4 = true := by decide +kernel
private theorem c3_720 : chunk words 9 l3 l4 720 4 = true := by decide +kernel
private theorem c3_724 : chunk words 9 l3 l4 724 4 = true := by decide +kernel
private theorem c3_728 : chunk words 9 l3 l4 728 4 = true := by decide +kernel
private theorem c3_732 : chunk words 9 l3 l4 732 4 = true := by decide +kernel
private theorem c3_736 : chunk words 9 l3 l4 736 4 = true := by decide +kernel
private theorem c3_740 : chunk words 9 l3 l4 740 4 = true := by decide +kernel
private theorem c3_744 : chunk words 9 l3 l4 744 4 = true := by decide +kernel
private theorem c3_748 : chunk words 9 l3 l4 748 4 = true := by decide +kernel
private theorem c3_752 : chunk words 9 l3 l4 752 4 = true := by decide +kernel
private theorem c3_756 : chunk words 9 l3 l4 756 4 = true := by decide +kernel
private theorem c3_760 : chunk words 9 l3 l4 760 4 = true := by decide +kernel
private theorem c3_764 : chunk words 9 l3 l4 764 4 = true := by decide +kernel

theorem b3_704 (i : Nat) (lo : 704 ≤ i) (hi : i < 768) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_736 : i < 736
  ·
    by_cases cut3_720 : i < 720
    ·
      by_cases cut3_712 : i < 712
      ·
        by_cases cut3_708 : i < 708
        ·
          exact fromChunk c3_704 (by omega) (by omega)
        ·
          exact fromChunk c3_708 (by omega) (by omega)
      ·
        by_cases cut3_716 : i < 716
        ·
          exact fromChunk c3_712 (by omega) (by omega)
        ·
          exact fromChunk c3_716 (by omega) (by omega)
    ·
      by_cases cut3_728 : i < 728
      ·
        by_cases cut3_724 : i < 724
        ·
          exact fromChunk c3_720 (by omega) (by omega)
        ·
          exact fromChunk c3_724 (by omega) (by omega)
      ·
        by_cases cut3_732 : i < 732
        ·
          exact fromChunk c3_728 (by omega) (by omega)
        ·
          exact fromChunk c3_732 (by omega) (by omega)
  ·
    by_cases cut3_752 : i < 752
    ·
      by_cases cut3_744 : i < 744
      ·
        by_cases cut3_740 : i < 740
        ·
          exact fromChunk c3_736 (by omega) (by omega)
        ·
          exact fromChunk c3_740 (by omega) (by omega)
      ·
        by_cases cut3_748 : i < 748
        ·
          exact fromChunk c3_744 (by omega) (by omega)
        ·
          exact fromChunk c3_748 (by omega) (by omega)
    ·
      by_cases cut3_760 : i < 760
      ·
        by_cases cut3_756 : i < 756
        ·
          exact fromChunk c3_752 (by omega) (by omega)
        ·
          exact fromChunk c3_756 (by omega) (by omega)
      ·
        by_cases cut3_764 : i < 764
        ·
          exact fromChunk c3_760 (by omega) (by omega)
        ·
          exact fromChunk c3_764 (by omega) (by omega)

#print axioms b3_704
end Petersen120.Mask81.LayerCheck
