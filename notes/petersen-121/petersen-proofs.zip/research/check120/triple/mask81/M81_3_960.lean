import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_960 : chunk words 9 l3 l4 960 4 = true := by decide +kernel
private theorem c3_964 : chunk words 9 l3 l4 964 4 = true := by decide +kernel
private theorem c3_968 : chunk words 9 l3 l4 968 4 = true := by decide +kernel
private theorem c3_972 : chunk words 9 l3 l4 972 4 = true := by decide +kernel
private theorem c3_976 : chunk words 9 l3 l4 976 4 = true := by decide +kernel
private theorem c3_980 : chunk words 9 l3 l4 980 4 = true := by decide +kernel
private theorem c3_984 : chunk words 9 l3 l4 984 4 = true := by decide +kernel
private theorem c3_988 : chunk words 9 l3 l4 988 4 = true := by decide +kernel
private theorem c3_992 : chunk words 9 l3 l4 992 4 = true := by decide +kernel
private theorem c3_996 : chunk words 9 l3 l4 996 4 = true := by decide +kernel
private theorem c3_1000 : chunk words 9 l3 l4 1000 4 = true := by decide +kernel
private theorem c3_1004 : chunk words 9 l3 l4 1004 4 = true := by decide +kernel
private theorem c3_1008 : chunk words 9 l3 l4 1008 4 = true := by decide +kernel
private theorem c3_1012 : chunk words 9 l3 l4 1012 4 = true := by decide +kernel
private theorem c3_1016 : chunk words 9 l3 l4 1016 4 = true := by decide +kernel
private theorem c3_1020 : chunk words 9 l3 l4 1020 4 = true := by decide +kernel

theorem b3_960 (i : Nat) (lo : 960 ≤ i) (hi : i < 1024) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_992 : i < 992
  ·
    by_cases cut3_976 : i < 976
    ·
      by_cases cut3_968 : i < 968
      ·
        by_cases cut3_964 : i < 964
        ·
          exact fromChunk c3_960 (by omega) (by omega)
        ·
          exact fromChunk c3_964 (by omega) (by omega)
      ·
        by_cases cut3_972 : i < 972
        ·
          exact fromChunk c3_968 (by omega) (by omega)
        ·
          exact fromChunk c3_972 (by omega) (by omega)
    ·
      by_cases cut3_984 : i < 984
      ·
        by_cases cut3_980 : i < 980
        ·
          exact fromChunk c3_976 (by omega) (by omega)
        ·
          exact fromChunk c3_980 (by omega) (by omega)
      ·
        by_cases cut3_988 : i < 988
        ·
          exact fromChunk c3_984 (by omega) (by omega)
        ·
          exact fromChunk c3_988 (by omega) (by omega)
  ·
    by_cases cut3_1008 : i < 1008
    ·
      by_cases cut3_1000 : i < 1000
      ·
        by_cases cut3_996 : i < 996
        ·
          exact fromChunk c3_992 (by omega) (by omega)
        ·
          exact fromChunk c3_996 (by omega) (by omega)
      ·
        by_cases cut3_1004 : i < 1004
        ·
          exact fromChunk c3_1000 (by omega) (by omega)
        ·
          exact fromChunk c3_1004 (by omega) (by omega)
    ·
      by_cases cut3_1016 : i < 1016
      ·
        by_cases cut3_1012 : i < 1012
        ·
          exact fromChunk c3_1008 (by omega) (by omega)
        ·
          exact fromChunk c3_1012 (by omega) (by omega)
      ·
        by_cases cut3_1020 : i < 1020
        ·
          exact fromChunk c3_1016 (by omega) (by omega)
        ·
          exact fromChunk c3_1020 (by omega) (by omega)

#print axioms b3_960
end Petersen120.Mask81.LayerCheck
