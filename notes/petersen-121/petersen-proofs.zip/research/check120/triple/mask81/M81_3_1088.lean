import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_1088 : chunk words 9 l3 l4 1088 4 = true := by decide +kernel
private theorem c3_1092 : chunk words 9 l3 l4 1092 4 = true := by decide +kernel
private theorem c3_1096 : chunk words 9 l3 l4 1096 4 = true := by decide +kernel
private theorem c3_1100 : chunk words 9 l3 l4 1100 4 = true := by decide +kernel
private theorem c3_1104 : chunk words 9 l3 l4 1104 4 = true := by decide +kernel
private theorem c3_1108 : chunk words 9 l3 l4 1108 4 = true := by decide +kernel
private theorem c3_1112 : chunk words 9 l3 l4 1112 4 = true := by decide +kernel
private theorem c3_1116 : chunk words 9 l3 l4 1116 4 = true := by decide +kernel
private theorem c3_1120 : chunk words 9 l3 l4 1120 4 = true := by decide +kernel
private theorem c3_1124 : chunk words 9 l3 l4 1124 4 = true := by decide +kernel
private theorem c3_1128 : chunk words 9 l3 l4 1128 4 = true := by decide +kernel
private theorem c3_1132 : chunk words 9 l3 l4 1132 4 = true := by decide +kernel
private theorem c3_1136 : chunk words 9 l3 l4 1136 4 = true := by decide +kernel
private theorem c3_1140 : chunk words 9 l3 l4 1140 4 = true := by decide +kernel
private theorem c3_1144 : chunk words 9 l3 l4 1144 4 = true := by decide +kernel
private theorem c3_1148 : chunk words 9 l3 l4 1148 4 = true := by decide +kernel

theorem b3_1088 (i : Nat) (lo : 1088 ≤ i) (hi : i < 1152) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_1120 : i < 1120
  ·
    by_cases cut3_1104 : i < 1104
    ·
      by_cases cut3_1096 : i < 1096
      ·
        by_cases cut3_1092 : i < 1092
        ·
          exact fromChunk c3_1088 (by omega) (by omega)
        ·
          exact fromChunk c3_1092 (by omega) (by omega)
      ·
        by_cases cut3_1100 : i < 1100
        ·
          exact fromChunk c3_1096 (by omega) (by omega)
        ·
          exact fromChunk c3_1100 (by omega) (by omega)
    ·
      by_cases cut3_1112 : i < 1112
      ·
        by_cases cut3_1108 : i < 1108
        ·
          exact fromChunk c3_1104 (by omega) (by omega)
        ·
          exact fromChunk c3_1108 (by omega) (by omega)
      ·
        by_cases cut3_1116 : i < 1116
        ·
          exact fromChunk c3_1112 (by omega) (by omega)
        ·
          exact fromChunk c3_1116 (by omega) (by omega)
  ·
    by_cases cut3_1136 : i < 1136
    ·
      by_cases cut3_1128 : i < 1128
      ·
        by_cases cut3_1124 : i < 1124
        ·
          exact fromChunk c3_1120 (by omega) (by omega)
        ·
          exact fromChunk c3_1124 (by omega) (by omega)
      ·
        by_cases cut3_1132 : i < 1132
        ·
          exact fromChunk c3_1128 (by omega) (by omega)
        ·
          exact fromChunk c3_1132 (by omega) (by omega)
    ·
      by_cases cut3_1144 : i < 1144
      ·
        by_cases cut3_1140 : i < 1140
        ·
          exact fromChunk c3_1136 (by omega) (by omega)
        ·
          exact fromChunk c3_1140 (by omega) (by omega)
      ·
        by_cases cut3_1148 : i < 1148
        ·
          exact fromChunk c3_1144 (by omega) (by omega)
        ·
          exact fromChunk c3_1148 (by omega) (by omega)

#print axioms b3_1088
end Petersen120.Mask81.LayerCheck
