import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c2_192 : chunk words 10 l2 l3 192 4 = true := by decide +kernel
private theorem c2_196 : chunk words 10 l2 l3 196 4 = true := by decide +kernel
private theorem c2_200 : chunk words 10 l2 l3 200 4 = true := by decide +kernel
private theorem c2_204 : chunk words 10 l2 l3 204 4 = true := by decide +kernel
private theorem c2_208 : chunk words 10 l2 l3 208 4 = true := by decide +kernel
private theorem c2_212 : chunk words 10 l2 l3 212 4 = true := by decide +kernel
private theorem c2_216 : chunk words 10 l2 l3 216 4 = true := by decide +kernel
private theorem c2_220 : chunk words 10 l2 l3 220 4 = true := by decide +kernel
private theorem c2_224 : chunk words 10 l2 l3 224 4 = true := by decide +kernel
private theorem c2_228 : chunk words 10 l2 l3 228 4 = true := by decide +kernel
private theorem c2_232 : chunk words 10 l2 l3 232 4 = true := by decide +kernel
private theorem c2_236 : chunk words 10 l2 l3 236 4 = true := by decide +kernel
private theorem c2_240 : chunk words 10 l2 l3 240 4 = true := by decide +kernel
private theorem c2_244 : chunk words 10 l2 l3 244 4 = true := by decide +kernel
private theorem c2_248 : chunk words 10 l2 l3 248 4 = true := by decide +kernel
private theorem c2_252 : chunk words 10 l2 l3 252 4 = true := by decide +kernel

theorem b2_192 (i : Nat) (lo : 192 ≤ i) (hi : i < 256) :
    localCheck words 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut2_224 : i < 224
  ·
    by_cases cut2_208 : i < 208
    ·
      by_cases cut2_200 : i < 200
      ·
        by_cases cut2_196 : i < 196
        ·
          exact fromChunk c2_192 (by omega) (by omega)
        ·
          exact fromChunk c2_196 (by omega) (by omega)
      ·
        by_cases cut2_204 : i < 204
        ·
          exact fromChunk c2_200 (by omega) (by omega)
        ·
          exact fromChunk c2_204 (by omega) (by omega)
    ·
      by_cases cut2_216 : i < 216
      ·
        by_cases cut2_212 : i < 212
        ·
          exact fromChunk c2_208 (by omega) (by omega)
        ·
          exact fromChunk c2_212 (by omega) (by omega)
      ·
        by_cases cut2_220 : i < 220
        ·
          exact fromChunk c2_216 (by omega) (by omega)
        ·
          exact fromChunk c2_220 (by omega) (by omega)
  ·
    by_cases cut2_240 : i < 240
    ·
      by_cases cut2_232 : i < 232
      ·
        by_cases cut2_228 : i < 228
        ·
          exact fromChunk c2_224 (by omega) (by omega)
        ·
          exact fromChunk c2_228 (by omega) (by omega)
      ·
        by_cases cut2_236 : i < 236
        ·
          exact fromChunk c2_232 (by omega) (by omega)
        ·
          exact fromChunk c2_236 (by omega) (by omega)
    ·
      by_cases cut2_248 : i < 248
      ·
        by_cases cut2_244 : i < 244
        ·
          exact fromChunk c2_240 (by omega) (by omega)
        ·
          exact fromChunk c2_244 (by omega) (by omega)
      ·
        by_cases cut2_252 : i < 252
        ·
          exact fromChunk c2_248 (by omega) (by omega)
        ·
          exact fromChunk c2_252 (by omega) (by omega)

#print axioms b2_192
end Petersen120.Mask81.LayerCheck
