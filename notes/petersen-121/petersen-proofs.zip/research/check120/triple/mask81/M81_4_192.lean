import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c4_192 : chunk words 8 l4 l5 192 4 = true := by decide +kernel
private theorem c4_196 : chunk words 8 l4 l5 196 4 = true := by decide +kernel
private theorem c4_200 : chunk words 8 l4 l5 200 4 = true := by decide +kernel
private theorem c4_204 : chunk words 8 l4 l5 204 4 = true := by decide +kernel
private theorem c4_208 : chunk words 8 l4 l5 208 4 = true := by decide +kernel
private theorem c4_212 : chunk words 8 l4 l5 212 4 = true := by decide +kernel
private theorem c4_216 : chunk words 8 l4 l5 216 4 = true := by decide +kernel
private theorem c4_220 : chunk words 8 l4 l5 220 4 = true := by decide +kernel
private theorem c4_224 : chunk words 8 l4 l5 224 4 = true := by decide +kernel
private theorem c4_228 : chunk words 8 l4 l5 228 4 = true := by decide +kernel
private theorem c4_232 : chunk words 8 l4 l5 232 4 = true := by decide +kernel
private theorem c4_236 : chunk words 8 l4 l5 236 4 = true := by decide +kernel
private theorem c4_240 : chunk words 8 l4 l5 240 4 = true := by decide +kernel
private theorem c4_244 : chunk words 8 l4 l5 244 4 = true := by decide +kernel
private theorem c4_248 : chunk words 8 l4 l5 248 4 = true := by decide +kernel
private theorem c4_252 : chunk words 8 l4 l5 252 4 = true := by decide +kernel

theorem b4_192 (i : Nat) (lo : 192 ≤ i) (hi : i < 256) :
    localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_224 : i < 224
  ·
    by_cases cut4_208 : i < 208
    ·
      by_cases cut4_200 : i < 200
      ·
        by_cases cut4_196 : i < 196
        ·
          exact fromChunk c4_192 (by omega) (by omega)
        ·
          exact fromChunk c4_196 (by omega) (by omega)
      ·
        by_cases cut4_204 : i < 204
        ·
          exact fromChunk c4_200 (by omega) (by omega)
        ·
          exact fromChunk c4_204 (by omega) (by omega)
    ·
      by_cases cut4_216 : i < 216
      ·
        by_cases cut4_212 : i < 212
        ·
          exact fromChunk c4_208 (by omega) (by omega)
        ·
          exact fromChunk c4_212 (by omega) (by omega)
      ·
        by_cases cut4_220 : i < 220
        ·
          exact fromChunk c4_216 (by omega) (by omega)
        ·
          exact fromChunk c4_220 (by omega) (by omega)
  ·
    by_cases cut4_240 : i < 240
    ·
      by_cases cut4_232 : i < 232
      ·
        by_cases cut4_228 : i < 228
        ·
          exact fromChunk c4_224 (by omega) (by omega)
        ·
          exact fromChunk c4_228 (by omega) (by omega)
      ·
        by_cases cut4_236 : i < 236
        ·
          exact fromChunk c4_232 (by omega) (by omega)
        ·
          exact fromChunk c4_236 (by omega) (by omega)
    ·
      by_cases cut4_248 : i < 248
      ·
        by_cases cut4_244 : i < 244
        ·
          exact fromChunk c4_240 (by omega) (by omega)
        ·
          exact fromChunk c4_244 (by omega) (by omega)
      ·
        by_cases cut4_252 : i < 252
        ·
          exact fromChunk c4_248 (by omega) (by omega)
        ·
          exact fromChunk c4_252 (by omega) (by omega)

#print axioms b4_192
end Petersen120.Mask81.LayerCheck
