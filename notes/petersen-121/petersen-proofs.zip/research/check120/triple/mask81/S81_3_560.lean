import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_560 : chunk words 9 l3 l4 560 4 = true := by decide +kernel
private theorem c3_564 : chunk words 9 l3 l4 564 4 = true := by decide +kernel
private theorem c3_568 : chunk words 9 l3 l4 568 4 = true := by decide +kernel
private theorem c3_572 : chunk words 9 l3 l4 572 4 = true := by decide +kernel
theorem s3_560 (i : Nat) (lo : 560 ≤ i) (hi : i < 576) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_568 : i < 568
  ·
    by_cases cut3_564 : i < 564
    ·
      exact fromChunk c3_560 (by omega) (by omega)
    ·
      exact fromChunk c3_564 (by omega) (by omega)
  ·
    by_cases cut3_572 : i < 572
    ·
      exact fromChunk c3_568 (by omega) (by omega)
    ·
      exact fromChunk c3_572 (by omega) (by omega)

#print axioms s3_560
end Petersen120.Mask81.LayerCheck
