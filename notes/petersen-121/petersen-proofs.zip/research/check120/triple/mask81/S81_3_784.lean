import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_784 : chunk words 9 l3 l4 784 4 = true := by decide +kernel
private theorem c3_788 : chunk words 9 l3 l4 788 4 = true := by decide +kernel
private theorem c3_792 : chunk words 9 l3 l4 792 4 = true := by decide +kernel
private theorem c3_796 : chunk words 9 l3 l4 796 4 = true := by decide +kernel
theorem s3_784 (i : Nat) (lo : 784 ≤ i) (hi : i < 800) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_792 : i < 792
  ·
    by_cases cut3_788 : i < 788
    ·
      exact fromChunk c3_784 (by omega) (by omega)
    ·
      exact fromChunk c3_788 (by omega) (by omega)
  ·
    by_cases cut3_796 : i < 796
    ·
      exact fromChunk c3_792 (by omega) (by omega)
    ·
      exact fromChunk c3_796 (by omega) (by omega)

#print axioms s3_784
end Petersen120.Mask81.LayerCheck
