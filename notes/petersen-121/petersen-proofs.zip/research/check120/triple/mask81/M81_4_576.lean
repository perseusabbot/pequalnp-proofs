import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c4_576 : chunk words 8 l4 l5 576 4 = true := by decide +kernel
private theorem c4_580 : chunk words 8 l4 l5 580 4 = true := by decide +kernel
private theorem c4_584 : chunk words 8 l4 l5 584 4 = true := by decide +kernel
private theorem c4_588 : chunk words 8 l4 l5 588 4 = true := by decide +kernel
private theorem c4_592 : chunk words 8 l4 l5 592 4 = true := by decide +kernel
private theorem c4_596 : chunk words 8 l4 l5 596 4 = true := by decide +kernel
private theorem c4_600 : chunk words 8 l4 l5 600 4 = true := by decide +kernel
private theorem c4_604 : chunk words 8 l4 l5 604 4 = true := by decide +kernel
private theorem c4_608 : chunk words 8 l4 l5 608 4 = true := by decide +kernel
private theorem c4_612 : chunk words 8 l4 l5 612 4 = true := by decide +kernel
private theorem c4_616 : chunk words 8 l4 l5 616 4 = true := by decide +kernel
private theorem c4_620 : chunk words 8 l4 l5 620 4 = true := by decide +kernel
private theorem c4_624 : chunk words 8 l4 l5 624 4 = true := by decide +kernel
private theorem c4_628 : chunk words 8 l4 l5 628 4 = true := by decide +kernel
private theorem c4_632 : chunk words 8 l4 l5 632 4 = true := by decide +kernel
private theorem c4_636 : chunk words 8 l4 l5 636 4 = true := by decide +kernel

theorem b4_576 (i : Nat) (lo : 576 ≤ i) (hi : i < 640) :
    localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_608 : i < 608
  ·
    by_cases cut4_592 : i < 592
    ·
      by_cases cut4_584 : i < 584
      ·
        by_cases cut4_580 : i < 580
        ·
          exact fromChunk c4_576 (by omega) (by omega)
        ·
          exact fromChunk c4_580 (by omega) (by omega)
      ·
        by_cases cut4_588 : i < 588
        ·
          exact fromChunk c4_584 (by omega) (by omega)
        ·
          exact fromChunk c4_588 (by omega) (by omega)
    ·
      by_cases cut4_600 : i < 600
      ·
        by_cases cut4_596 : i < 596
        ·
          exact fromChunk c4_592 (by omega) (by omega)
        ·
          exact fromChunk c4_596 (by omega) (by omega)
      ·
        by_cases cut4_604 : i < 604
        ·
          exact fromChunk c4_600 (by omega) (by omega)
        ·
          exact fromChunk c4_604 (by omega) (by omega)
  ·
    by_cases cut4_624 : i < 624
    ·
      by_cases cut4_616 : i < 616
      ·
        by_cases cut4_612 : i < 612
        ·
          exact fromChunk c4_608 (by omega) (by omega)
        ·
          exact fromChunk c4_612 (by omega) (by omega)
      ·
        by_cases cut4_620 : i < 620
        ·
          exact fromChunk c4_616 (by omega) (by omega)
        ·
          exact fromChunk c4_620 (by omega) (by omega)
    ·
      by_cases cut4_632 : i < 632
      ·
        by_cases cut4_628 : i < 628
        ·
          exact fromChunk c4_624 (by omega) (by omega)
        ·
          exact fromChunk c4_628 (by omega) (by omega)
      ·
        by_cases cut4_636 : i < 636
        ·
          exact fromChunk c4_632 (by omega) (by omega)
        ·
          exact fromChunk c4_636 (by omega) (by omega)

#print axioms b4_576
end Petersen120.Mask81.LayerCheck
