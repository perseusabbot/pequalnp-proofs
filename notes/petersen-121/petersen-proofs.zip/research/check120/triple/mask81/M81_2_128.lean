import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c2_128 : chunk words 10 l2 l3 128 4 = true := by decide +kernel
private theorem c2_132 : chunk words 10 l2 l3 132 4 = true := by decide +kernel
private theorem c2_136 : chunk words 10 l2 l3 136 4 = true := by decide +kernel
private theorem c2_140 : chunk words 10 l2 l3 140 4 = true := by decide +kernel
private theorem c2_144 : chunk words 10 l2 l3 144 4 = true := by decide +kernel
private theorem c2_148 : chunk words 10 l2 l3 148 4 = true := by decide +kernel
private theorem c2_152 : chunk words 10 l2 l3 152 4 = true := by decide +kernel
private theorem c2_156 : chunk words 10 l2 l3 156 4 = true := by decide +kernel
private theorem c2_160 : chunk words 10 l2 l3 160 4 = true := by decide +kernel
private theorem c2_164 : chunk words 10 l2 l3 164 4 = true := by decide +kernel
private theorem c2_168 : chunk words 10 l2 l3 168 4 = true := by decide +kernel
private theorem c2_172 : chunk words 10 l2 l3 172 4 = true := by decide +kernel
private theorem c2_176 : chunk words 10 l2 l3 176 4 = true := by decide +kernel
private theorem c2_180 : chunk words 10 l2 l3 180 4 = true := by decide +kernel
private theorem c2_184 : chunk words 10 l2 l3 184 4 = true := by decide +kernel
private theorem c2_188 : chunk words 10 l2 l3 188 4 = true := by decide +kernel

theorem b2_128 (i : Nat) (lo : 128 ≤ i) (hi : i < 192) :
    localCheck words 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut2_160 : i < 160
  ·
    by_cases cut2_144 : i < 144
    ·
      by_cases cut2_136 : i < 136
      ·
        by_cases cut2_132 : i < 132
        ·
          exact fromChunk c2_128 (by omega) (by omega)
        ·
          exact fromChunk c2_132 (by omega) (by omega)
      ·
        by_cases cut2_140 : i < 140
        ·
          exact fromChunk c2_136 (by omega) (by omega)
        ·
          exact fromChunk c2_140 (by omega) (by omega)
    ·
      by_cases cut2_152 : i < 152
      ·
        by_cases cut2_148 : i < 148
        ·
          exact fromChunk c2_144 (by omega) (by omega)
        ·
          exact fromChunk c2_148 (by omega) (by omega)
      ·
        by_cases cut2_156 : i < 156
        ·
          exact fromChunk c2_152 (by omega) (by omega)
        ·
          exact fromChunk c2_156 (by omega) (by omega)
  ·
    by_cases cut2_176 : i < 176
    ·
      by_cases cut2_168 : i < 168
      ·
        by_cases cut2_164 : i < 164
        ·
          exact fromChunk c2_160 (by omega) (by omega)
        ·
          exact fromChunk c2_164 (by omega) (by omega)
      ·
        by_cases cut2_172 : i < 172
        ·
          exact fromChunk c2_168 (by omega) (by omega)
        ·
          exact fromChunk c2_172 (by omega) (by omega)
    ·
      by_cases cut2_184 : i < 184
      ·
        by_cases cut2_180 : i < 180
        ·
          exact fromChunk c2_176 (by omega) (by omega)
        ·
          exact fromChunk c2_180 (by omega) (by omega)
      ·
        by_cases cut2_188 : i < 188
        ·
          exact fromChunk c2_184 (by omega) (by omega)
        ·
          exact fromChunk c2_188 (by omega) (by omega)

#print axioms b2_128
end Petersen120.Mask81.LayerCheck
