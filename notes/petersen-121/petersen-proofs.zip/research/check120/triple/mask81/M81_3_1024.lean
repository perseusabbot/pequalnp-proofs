import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_1024 : chunk words 9 l3 l4 1024 4 = true := by decide +kernel
private theorem c3_1028 : chunk words 9 l3 l4 1028 4 = true := by decide +kernel
private theorem c3_1032 : chunk words 9 l3 l4 1032 4 = true := by decide +kernel
private theorem c3_1036 : chunk words 9 l3 l4 1036 4 = true := by decide +kernel
private theorem c3_1040 : chunk words 9 l3 l4 1040 4 = true := by decide +kernel
private theorem c3_1044 : chunk words 9 l3 l4 1044 4 = true := by decide +kernel
private theorem c3_1048 : chunk words 9 l3 l4 1048 4 = true := by decide +kernel
private theorem c3_1052 : chunk words 9 l3 l4 1052 4 = true := by decide +kernel
private theorem c3_1056 : chunk words 9 l3 l4 1056 4 = true := by decide +kernel
private theorem c3_1060 : chunk words 9 l3 l4 1060 4 = true := by decide +kernel
private theorem c3_1064 : chunk words 9 l3 l4 1064 4 = true := by decide +kernel
private theorem c3_1068 : chunk words 9 l3 l4 1068 4 = true := by decide +kernel
private theorem c3_1072 : chunk words 9 l3 l4 1072 4 = true := by decide +kernel
private theorem c3_1076 : chunk words 9 l3 l4 1076 4 = true := by decide +kernel
private theorem c3_1080 : chunk words 9 l3 l4 1080 4 = true := by decide +kernel
private theorem c3_1084 : chunk words 9 l3 l4 1084 4 = true := by decide +kernel

theorem b3_1024 (i : Nat) (lo : 1024 ≤ i) (hi : i < 1088) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_1056 : i < 1056
  ·
    by_cases cut3_1040 : i < 1040
    ·
      by_cases cut3_1032 : i < 1032
      ·
        by_cases cut3_1028 : i < 1028
        ·
          exact fromChunk c3_1024 (by omega) (by omega)
        ·
          exact fromChunk c3_1028 (by omega) (by omega)
      ·
        by_cases cut3_1036 : i < 1036
        ·
          exact fromChunk c3_1032 (by omega) (by omega)
        ·
          exact fromChunk c3_1036 (by omega) (by omega)
    ·
      by_cases cut3_1048 : i < 1048
      ·
        by_cases cut3_1044 : i < 1044
        ·
          exact fromChunk c3_1040 (by omega) (by omega)
        ·
          exact fromChunk c3_1044 (by omega) (by omega)
      ·
        by_cases cut3_1052 : i < 1052
        ·
          exact fromChunk c3_1048 (by omega) (by omega)
        ·
          exact fromChunk c3_1052 (by omega) (by omega)
  ·
    by_cases cut3_1072 : i < 1072
    ·
      by_cases cut3_1064 : i < 1064
      ·
        by_cases cut3_1060 : i < 1060
        ·
          exact fromChunk c3_1056 (by omega) (by omega)
        ·
          exact fromChunk c3_1060 (by omega) (by omega)
      ·
        by_cases cut3_1068 : i < 1068
        ·
          exact fromChunk c3_1064 (by omega) (by omega)
        ·
          exact fromChunk c3_1068 (by omega) (by omega)
    ·
      by_cases cut3_1080 : i < 1080
      ·
        by_cases cut3_1076 : i < 1076
        ·
          exact fromChunk c3_1072 (by omega) (by omega)
        ·
          exact fromChunk c3_1076 (by omega) (by omega)
      ·
        by_cases cut3_1084 : i < 1084
        ·
          exact fromChunk c3_1080 (by omega) (by omega)
        ·
          exact fromChunk c3_1084 (by omega) (by omega)

#print axioms b3_1024
end Petersen120.Mask81.LayerCheck
