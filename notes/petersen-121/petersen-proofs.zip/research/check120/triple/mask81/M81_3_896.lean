import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_896 : chunk words 9 l3 l4 896 4 = true := by decide +kernel
private theorem c3_900 : chunk words 9 l3 l4 900 4 = true := by decide +kernel
private theorem c3_904 : chunk words 9 l3 l4 904 4 = true := by decide +kernel
private theorem c3_908 : chunk words 9 l3 l4 908 4 = true := by decide +kernel
private theorem c3_912 : chunk words 9 l3 l4 912 4 = true := by decide +kernel
private theorem c3_916 : chunk words 9 l3 l4 916 4 = true := by decide +kernel
private theorem c3_920 : chunk words 9 l3 l4 920 4 = true := by decide +kernel
private theorem c3_924 : chunk words 9 l3 l4 924 4 = true := by decide +kernel
private theorem c3_928 : chunk words 9 l3 l4 928 4 = true := by decide +kernel
private theorem c3_932 : chunk words 9 l3 l4 932 4 = true := by decide +kernel
private theorem c3_936 : chunk words 9 l3 l4 936 4 = true := by decide +kernel
private theorem c3_940 : chunk words 9 l3 l4 940 4 = true := by decide +kernel
private theorem c3_944 : chunk words 9 l3 l4 944 4 = true := by decide +kernel
private theorem c3_948 : chunk words 9 l3 l4 948 4 = true := by decide +kernel
private theorem c3_952 : chunk words 9 l3 l4 952 4 = true := by decide +kernel
private theorem c3_956 : chunk words 9 l3 l4 956 4 = true := by decide +kernel

theorem b3_896 (i : Nat) (lo : 896 ≤ i) (hi : i < 960) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_928 : i < 928
  ·
    by_cases cut3_912 : i < 912
    ·
      by_cases cut3_904 : i < 904
      ·
        by_cases cut3_900 : i < 900
        ·
          exact fromChunk c3_896 (by omega) (by omega)
        ·
          exact fromChunk c3_900 (by omega) (by omega)
      ·
        by_cases cut3_908 : i < 908
        ·
          exact fromChunk c3_904 (by omega) (by omega)
        ·
          exact fromChunk c3_908 (by omega) (by omega)
    ·
      by_cases cut3_920 : i < 920
      ·
        by_cases cut3_916 : i < 916
        ·
          exact fromChunk c3_912 (by omega) (by omega)
        ·
          exact fromChunk c3_916 (by omega) (by omega)
      ·
        by_cases cut3_924 : i < 924
        ·
          exact fromChunk c3_920 (by omega) (by omega)
        ·
          exact fromChunk c3_924 (by omega) (by omega)
  ·
    by_cases cut3_944 : i < 944
    ·
      by_cases cut3_936 : i < 936
      ·
        by_cases cut3_932 : i < 932
        ·
          exact fromChunk c3_928 (by omega) (by omega)
        ·
          exact fromChunk c3_932 (by omega) (by omega)
      ·
        by_cases cut3_940 : i < 940
        ·
          exact fromChunk c3_936 (by omega) (by omega)
        ·
          exact fromChunk c3_940 (by omega) (by omega)
    ·
      by_cases cut3_952 : i < 952
      ·
        by_cases cut3_948 : i < 948
        ·
          exact fromChunk c3_944 (by omega) (by omega)
        ·
          exact fromChunk c3_948 (by omega) (by omega)
      ·
        by_cases cut3_956 : i < 956
        ·
          exact fromChunk c3_952 (by omega) (by omega)
        ·
          exact fromChunk c3_956 (by omega) (by omega)

#print axioms b3_896
end Petersen120.Mask81.LayerCheck
