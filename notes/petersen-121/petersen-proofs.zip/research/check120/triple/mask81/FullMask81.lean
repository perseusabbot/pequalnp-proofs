import Assembly81
import M81_0_0
import M81_1_0
import M81_2_0
import M81_2_64
import M81_2_128
import M81_2_192
import M81_2_256
import M81_2_320
import M81_2_384
import M81_3_0
import M81_3_64
import M81_3_128
import M81_3_192
import M81_3_256
import M81_3_320
import M81_3_384
import M81_3_448
import M81_3_512
import M81_3_576
import M81_3_640
import M81_3_704
import M81_3_768
import M81_3_832
import M81_3_896
import M81_3_960
import M81_3_1024
import M81_3_1088
import M81_3_1152
import M81_3_1216
import M81_4_0
import M81_4_64
import M81_4_128
import M81_4_192
import M81_4_256
import M81_4_320
import M81_4_384
import M81_4_448
import M81_4_512
import M81_4_576
import M81_4_640
import M81_4_704
import M81_5_0

namespace Petersen120.Mask81.LayerCheck
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem all0 (i : Nat) (hi : i < 1) : localCheck words 12 (l0[i]?.getD default) l1 = true := by
  exact b0_0 i (by omega) (by omega)

private theorem all1 (i : Nat) (hi : i < 36) : localCheck words 11 (l1[i]?.getD default) l2 = true := by
  exact b1_0 i (by omega) (by omega)

private theorem all2 (i : Nat) (hi : i < 421) : localCheck words 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut2_192 : i < 192
  ·
    by_cases cut2_64 : i < 64
    ·
      exact b2_0 i (by omega) (by omega)
    ·
      by_cases cut2_128 : i < 128
      ·
        exact b2_64 i (by omega) (by omega)
      ·
        exact b2_128 i (by omega) (by omega)
  ·
    by_cases cut2_320 : i < 320
    ·
      by_cases cut2_256 : i < 256
      ·
        exact b2_192 i (by omega) (by omega)
      ·
        exact b2_256 i (by omega) (by omega)
    ·
      by_cases cut2_384 : i < 384
      ·
        exact b2_320 i (by omega) (by omega)
      ·
        exact b2_384 i (by omega) (by omega)

private theorem all3 (i : Nat) (hi : i < 1224) : localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_640 : i < 640
  ·
    by_cases cut3_320 : i < 320
    ·
      by_cases cut3_128 : i < 128
      ·
        by_cases cut3_64 : i < 64
        ·
          exact b3_0 i (by omega) (by omega)
        ·
          exact b3_64 i (by omega) (by omega)
      ·
        by_cases cut3_192 : i < 192
        ·
          exact b3_128 i (by omega) (by omega)
        ·
          by_cases cut3_256 : i < 256
          ·
            exact b3_192 i (by omega) (by omega)
          ·
            exact b3_256 i (by omega) (by omega)
    ·
      by_cases cut3_448 : i < 448
      ·
        by_cases cut3_384 : i < 384
        ·
          exact b3_320 i (by omega) (by omega)
        ·
          exact b3_384 i (by omega) (by omega)
      ·
        by_cases cut3_512 : i < 512
        ·
          exact b3_448 i (by omega) (by omega)
        ·
          by_cases cut3_576 : i < 576
          ·
            exact b3_512 i (by omega) (by omega)
          ·
            exact b3_576 i (by omega) (by omega)
  ·
    by_cases cut3_960 : i < 960
    ·
      by_cases cut3_768 : i < 768
      ·
        by_cases cut3_704 : i < 704
        ·
          exact b3_640 i (by omega) (by omega)
        ·
          exact b3_704 i (by omega) (by omega)
      ·
        by_cases cut3_832 : i < 832
        ·
          exact b3_768 i (by omega) (by omega)
        ·
          by_cases cut3_896 : i < 896
          ·
            exact b3_832 i (by omega) (by omega)
          ·
            exact b3_896 i (by omega) (by omega)
    ·
      by_cases cut3_1088 : i < 1088
      ·
        by_cases cut3_1024 : i < 1024
        ·
          exact b3_960 i (by omega) (by omega)
        ·
          exact b3_1024 i (by omega) (by omega)
      ·
        by_cases cut3_1152 : i < 1152
        ·
          exact b3_1088 i (by omega) (by omega)
        ·
          by_cases cut3_1216 : i < 1216
          ·
            exact b3_1152 i (by omega) (by omega)
          ·
            exact b3_1216 i (by omega) (by omega)

private theorem all4 (i : Nat) (hi : i < 723) : localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_384 : i < 384
  ·
    by_cases cut4_192 : i < 192
    ·
      by_cases cut4_64 : i < 64
      ·
        exact b4_0 i (by omega) (by omega)
      ·
        by_cases cut4_128 : i < 128
        ·
          exact b4_64 i (by omega) (by omega)
        ·
          exact b4_128 i (by omega) (by omega)
    ·
      by_cases cut4_256 : i < 256
      ·
        exact b4_192 i (by omega) (by omega)
      ·
        by_cases cut4_320 : i < 320
        ·
          exact b4_256 i (by omega) (by omega)
        ·
          exact b4_320 i (by omega) (by omega)
  ·
    by_cases cut4_576 : i < 576
    ·
      by_cases cut4_448 : i < 448
      ·
        exact b4_384 i (by omega) (by omega)
      ·
        by_cases cut4_512 : i < 512
        ·
          exact b4_448 i (by omega) (by omega)
        ·
          exact b4_512 i (by omega) (by omega)
    ·
      by_cases cut4_640 : i < 640
      ·
        exact b4_576 i (by omega) (by omega)
      ·
        by_cases cut4_704 : i < 704
        ·
          exact b4_640 i (by omega) (by omega)
        ·
          exact b4_704 i (by omega) (by omega)

private theorem all5 (i : Nat) (hi : i < 29) : localCheck words 7 (l5[i]?.getD default) l6 = true := by
  exact b5_0 i (by omega) (by omega)

theorem noMask81 : ¬ NatRun allMask Table.goal 13 (Triples46.tripleSignals 0) :=
  assemble all0 all1 all2 all3 all4 all5

#print axioms noMask81
end Petersen120.Mask81.LayerCheck
