import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_528 : chunk words 9 l3 l4 528 4 = true := by decide +kernel
private theorem c3_532 : chunk words 9 l3 l4 532 4 = true := by decide +kernel
private theorem c3_536 : chunk words 9 l3 l4 536 4 = true := by decide +kernel
private theorem c3_540 : chunk words 9 l3 l4 540 4 = true := by decide +kernel
theorem s3_528 (i : Nat) (lo : 528 ≤ i) (hi : i < 544) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_536 : i < 536
  ·
    by_cases cut3_532 : i < 532
    ·
      exact fromChunk c3_528 (by omega) (by omega)
    ·
      exact fromChunk c3_532 (by omega) (by omega)
  ·
    by_cases cut3_540 : i < 540
    ·
      exact fromChunk c3_536 (by omega) (by omega)
    ·
      exact fromChunk c3_540 (by omega) (by omega)

#print axioms s3_528
end Petersen120.Mask81.LayerCheck
