import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c2_320 : chunk words 10 l2 l3 320 4 = true := by decide +kernel
private theorem c2_324 : chunk words 10 l2 l3 324 4 = true := by decide +kernel
private theorem c2_328 : chunk words 10 l2 l3 328 4 = true := by decide +kernel
private theorem c2_332 : chunk words 10 l2 l3 332 4 = true := by decide +kernel
private theorem c2_336 : chunk words 10 l2 l3 336 4 = true := by decide +kernel
private theorem c2_340 : chunk words 10 l2 l3 340 4 = true := by decide +kernel
private theorem c2_344 : chunk words 10 l2 l3 344 4 = true := by decide +kernel
private theorem c2_348 : chunk words 10 l2 l3 348 4 = true := by decide +kernel
private theorem c2_352 : chunk words 10 l2 l3 352 4 = true := by decide +kernel
private theorem c2_356 : chunk words 10 l2 l3 356 4 = true := by decide +kernel
private theorem c2_360 : chunk words 10 l2 l3 360 4 = true := by decide +kernel
private theorem c2_364 : chunk words 10 l2 l3 364 4 = true := by decide +kernel
private theorem c2_368 : chunk words 10 l2 l3 368 4 = true := by decide +kernel
private theorem c2_372 : chunk words 10 l2 l3 372 4 = true := by decide +kernel
private theorem c2_376 : chunk words 10 l2 l3 376 4 = true := by decide +kernel
private theorem c2_380 : chunk words 10 l2 l3 380 4 = true := by decide +kernel

theorem b2_320 (i : Nat) (lo : 320 ≤ i) (hi : i < 384) :
    localCheck words 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut2_352 : i < 352
  ·
    by_cases cut2_336 : i < 336
    ·
      by_cases cut2_328 : i < 328
      ·
        by_cases cut2_324 : i < 324
        ·
          exact fromChunk c2_320 (by omega) (by omega)
        ·
          exact fromChunk c2_324 (by omega) (by omega)
      ·
        by_cases cut2_332 : i < 332
        ·
          exact fromChunk c2_328 (by omega) (by omega)
        ·
          exact fromChunk c2_332 (by omega) (by omega)
    ·
      by_cases cut2_344 : i < 344
      ·
        by_cases cut2_340 : i < 340
        ·
          exact fromChunk c2_336 (by omega) (by omega)
        ·
          exact fromChunk c2_340 (by omega) (by omega)
      ·
        by_cases cut2_348 : i < 348
        ·
          exact fromChunk c2_344 (by omega) (by omega)
        ·
          exact fromChunk c2_348 (by omega) (by omega)
  ·
    by_cases cut2_368 : i < 368
    ·
      by_cases cut2_360 : i < 360
      ·
        by_cases cut2_356 : i < 356
        ·
          exact fromChunk c2_352 (by omega) (by omega)
        ·
          exact fromChunk c2_356 (by omega) (by omega)
      ·
        by_cases cut2_364 : i < 364
        ·
          exact fromChunk c2_360 (by omega) (by omega)
        ·
          exact fromChunk c2_364 (by omega) (by omega)
    ·
      by_cases cut2_376 : i < 376
      ·
        by_cases cut2_372 : i < 372
        ·
          exact fromChunk c2_368 (by omega) (by omega)
        ·
          exact fromChunk c2_372 (by omega) (by omega)
      ·
        by_cases cut2_380 : i < 380
        ·
          exact fromChunk c2_376 (by omega) (by omega)
        ·
          exact fromChunk c2_380 (by omega) (by omega)

#print axioms b2_320
end Petersen120.Mask81.LayerCheck
