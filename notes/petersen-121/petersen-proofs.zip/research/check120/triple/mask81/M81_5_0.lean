import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c5_0 : chunk words 7 l5 l6 0 4 = true := by decide +kernel
private theorem c5_4 : chunk words 7 l5 l6 4 4 = true := by decide +kernel
private theorem c5_8 : chunk words 7 l5 l6 8 4 = true := by decide +kernel
private theorem c5_12 : chunk words 7 l5 l6 12 4 = true := by decide +kernel
private theorem c5_16 : chunk words 7 l5 l6 16 4 = true := by decide +kernel
private theorem c5_20 : chunk words 7 l5 l6 20 4 = true := by decide +kernel
private theorem c5_24 : chunk words 7 l5 l6 24 4 = true := by decide +kernel
private theorem c5_28 : chunk words 7 l5 l6 28 1 = true := by decide +kernel

theorem b5_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 29) :
    localCheck words 7 (l5[i]?.getD default) l6 = true := by
  by_cases cut5_16 : i < 16
  ·
    by_cases cut5_8 : i < 8
    ·
      by_cases cut5_4 : i < 4
      ·
        exact fromChunk c5_0 (by omega) (by omega)
      ·
        exact fromChunk c5_4 (by omega) (by omega)
    ·
      by_cases cut5_12 : i < 12
      ·
        exact fromChunk c5_8 (by omega) (by omega)
      ·
        exact fromChunk c5_12 (by omega) (by omega)
  ·
    by_cases cut5_24 : i < 24
    ·
      by_cases cut5_20 : i < 20
      ·
        exact fromChunk c5_16 (by omega) (by omega)
      ·
        exact fromChunk c5_20 (by omega) (by omega)
    ·
      by_cases cut5_28 : i < 28
      ·
        exact fromChunk c5_24 (by omega) (by omega)
      ·
        exact fromChunk c5_28 (by omega) (by omega)

#print axioms b5_0
end Petersen120.Mask81.LayerCheck
