import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_1152 : chunk words 9 l3 l4 1152 4 = true := by decide +kernel
private theorem c3_1156 : chunk words 9 l3 l4 1156 4 = true := by decide +kernel
private theorem c3_1160 : chunk words 9 l3 l4 1160 4 = true := by decide +kernel
private theorem c3_1164 : chunk words 9 l3 l4 1164 4 = true := by decide +kernel
private theorem c3_1168 : chunk words 9 l3 l4 1168 4 = true := by decide +kernel
private theorem c3_1172 : chunk words 9 l3 l4 1172 4 = true := by decide +kernel
private theorem c3_1176 : chunk words 9 l3 l4 1176 4 = true := by decide +kernel
private theorem c3_1180 : chunk words 9 l3 l4 1180 4 = true := by decide +kernel
private theorem c3_1184 : chunk words 9 l3 l4 1184 4 = true := by decide +kernel
private theorem c3_1188 : chunk words 9 l3 l4 1188 4 = true := by decide +kernel
private theorem c3_1192 : chunk words 9 l3 l4 1192 4 = true := by decide +kernel
private theorem c3_1196 : chunk words 9 l3 l4 1196 4 = true := by decide +kernel
private theorem c3_1200 : chunk words 9 l3 l4 1200 4 = true := by decide +kernel
private theorem c3_1204 : chunk words 9 l3 l4 1204 4 = true := by decide +kernel
private theorem c3_1208 : chunk words 9 l3 l4 1208 4 = true := by decide +kernel
private theorem c3_1212 : chunk words 9 l3 l4 1212 4 = true := by decide +kernel

theorem b3_1152 (i : Nat) (lo : 1152 ≤ i) (hi : i < 1216) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_1184 : i < 1184
  ·
    by_cases cut3_1168 : i < 1168
    ·
      by_cases cut3_1160 : i < 1160
      ·
        by_cases cut3_1156 : i < 1156
        ·
          exact fromChunk c3_1152 (by omega) (by omega)
        ·
          exact fromChunk c3_1156 (by omega) (by omega)
      ·
        by_cases cut3_1164 : i < 1164
        ·
          exact fromChunk c3_1160 (by omega) (by omega)
        ·
          exact fromChunk c3_1164 (by omega) (by omega)
    ·
      by_cases cut3_1176 : i < 1176
      ·
        by_cases cut3_1172 : i < 1172
        ·
          exact fromChunk c3_1168 (by omega) (by omega)
        ·
          exact fromChunk c3_1172 (by omega) (by omega)
      ·
        by_cases cut3_1180 : i < 1180
        ·
          exact fromChunk c3_1176 (by omega) (by omega)
        ·
          exact fromChunk c3_1180 (by omega) (by omega)
  ·
    by_cases cut3_1200 : i < 1200
    ·
      by_cases cut3_1192 : i < 1192
      ·
        by_cases cut3_1188 : i < 1188
        ·
          exact fromChunk c3_1184 (by omega) (by omega)
        ·
          exact fromChunk c3_1188 (by omega) (by omega)
      ·
        by_cases cut3_1196 : i < 1196
        ·
          exact fromChunk c3_1192 (by omega) (by omega)
        ·
          exact fromChunk c3_1196 (by omega) (by omega)
    ·
      by_cases cut3_1208 : i < 1208
      ·
        by_cases cut3_1204 : i < 1204
        ·
          exact fromChunk c3_1200 (by omega) (by omega)
        ·
          exact fromChunk c3_1204 (by omega) (by omega)
      ·
        by_cases cut3_1212 : i < 1212
        ·
          exact fromChunk c3_1208 (by omega) (by omega)
        ·
          exact fromChunk c3_1212 (by omega) (by omega)

#print axioms b3_1152
end Petersen120.Mask81.LayerCheck
