import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_0 : chunk words 9 l3 l4 0 4 = true := by decide +kernel
private theorem c3_4 : chunk words 9 l3 l4 4 4 = true := by decide +kernel
private theorem c3_8 : chunk words 9 l3 l4 8 4 = true := by decide +kernel
private theorem c3_12 : chunk words 9 l3 l4 12 4 = true := by decide +kernel
private theorem c3_16 : chunk words 9 l3 l4 16 4 = true := by decide +kernel
private theorem c3_20 : chunk words 9 l3 l4 20 4 = true := by decide +kernel
private theorem c3_24 : chunk words 9 l3 l4 24 4 = true := by decide +kernel
private theorem c3_28 : chunk words 9 l3 l4 28 4 = true := by decide +kernel
private theorem c3_32 : chunk words 9 l3 l4 32 4 = true := by decide +kernel
private theorem c3_36 : chunk words 9 l3 l4 36 4 = true := by decide +kernel
private theorem c3_40 : chunk words 9 l3 l4 40 4 = true := by decide +kernel
private theorem c3_44 : chunk words 9 l3 l4 44 4 = true := by decide +kernel
private theorem c3_48 : chunk words 9 l3 l4 48 4 = true := by decide +kernel
private theorem c3_52 : chunk words 9 l3 l4 52 4 = true := by decide +kernel
private theorem c3_56 : chunk words 9 l3 l4 56 4 = true := by decide +kernel
private theorem c3_60 : chunk words 9 l3 l4 60 4 = true := by decide +kernel

theorem b3_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 64) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_32 : i < 32
  ·
    by_cases cut3_16 : i < 16
    ·
      by_cases cut3_8 : i < 8
      ·
        by_cases cut3_4 : i < 4
        ·
          exact fromChunk c3_0 (by omega) (by omega)
        ·
          exact fromChunk c3_4 (by omega) (by omega)
      ·
        by_cases cut3_12 : i < 12
        ·
          exact fromChunk c3_8 (by omega) (by omega)
        ·
          exact fromChunk c3_12 (by omega) (by omega)
    ·
      by_cases cut3_24 : i < 24
      ·
        by_cases cut3_20 : i < 20
        ·
          exact fromChunk c3_16 (by omega) (by omega)
        ·
          exact fromChunk c3_20 (by omega) (by omega)
      ·
        by_cases cut3_28 : i < 28
        ·
          exact fromChunk c3_24 (by omega) (by omega)
        ·
          exact fromChunk c3_28 (by omega) (by omega)
  ·
    by_cases cut3_48 : i < 48
    ·
      by_cases cut3_40 : i < 40
      ·
        by_cases cut3_36 : i < 36
        ·
          exact fromChunk c3_32 (by omega) (by omega)
        ·
          exact fromChunk c3_36 (by omega) (by omega)
      ·
        by_cases cut3_44 : i < 44
        ·
          exact fromChunk c3_40 (by omega) (by omega)
        ·
          exact fromChunk c3_44 (by omega) (by omega)
    ·
      by_cases cut3_56 : i < 56
      ·
        by_cases cut3_52 : i < 52
        ·
          exact fromChunk c3_48 (by omega) (by omega)
        ·
          exact fromChunk c3_52 (by omega) (by omega)
      ·
        by_cases cut3_60 : i < 60
        ·
          exact fromChunk c3_56 (by omega) (by omega)
        ·
          exact fromChunk c3_60 (by omega) (by omega)

#print axioms b3_0
end Petersen120.Mask81.LayerCheck
