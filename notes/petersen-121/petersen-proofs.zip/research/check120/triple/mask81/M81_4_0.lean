import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c4_0 : chunk words 8 l4 l5 0 4 = true := by decide +kernel
private theorem c4_4 : chunk words 8 l4 l5 4 4 = true := by decide +kernel
private theorem c4_8 : chunk words 8 l4 l5 8 4 = true := by decide +kernel
private theorem c4_12 : chunk words 8 l4 l5 12 4 = true := by decide +kernel
private theorem c4_16 : chunk words 8 l4 l5 16 4 = true := by decide +kernel
private theorem c4_20 : chunk words 8 l4 l5 20 4 = true := by decide +kernel
private theorem c4_24 : chunk words 8 l4 l5 24 4 = true := by decide +kernel
private theorem c4_28 : chunk words 8 l4 l5 28 4 = true := by decide +kernel
private theorem c4_32 : chunk words 8 l4 l5 32 4 = true := by decide +kernel
private theorem c4_36 : chunk words 8 l4 l5 36 4 = true := by decide +kernel
private theorem c4_40 : chunk words 8 l4 l5 40 4 = true := by decide +kernel
private theorem c4_44 : chunk words 8 l4 l5 44 4 = true := by decide +kernel
private theorem c4_48 : chunk words 8 l4 l5 48 4 = true := by decide +kernel
private theorem c4_52 : chunk words 8 l4 l5 52 4 = true := by decide +kernel
private theorem c4_56 : chunk words 8 l4 l5 56 4 = true := by decide +kernel
private theorem c4_60 : chunk words 8 l4 l5 60 4 = true := by decide +kernel

theorem b4_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 64) :
    localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_32 : i < 32
  ·
    by_cases cut4_16 : i < 16
    ·
      by_cases cut4_8 : i < 8
      ·
        by_cases cut4_4 : i < 4
        ·
          exact fromChunk c4_0 (by omega) (by omega)
        ·
          exact fromChunk c4_4 (by omega) (by omega)
      ·
        by_cases cut4_12 : i < 12
        ·
          exact fromChunk c4_8 (by omega) (by omega)
        ·
          exact fromChunk c4_12 (by omega) (by omega)
    ·
      by_cases cut4_24 : i < 24
      ·
        by_cases cut4_20 : i < 20
        ·
          exact fromChunk c4_16 (by omega) (by omega)
        ·
          exact fromChunk c4_20 (by omega) (by omega)
      ·
        by_cases cut4_28 : i < 28
        ·
          exact fromChunk c4_24 (by omega) (by omega)
        ·
          exact fromChunk c4_28 (by omega) (by omega)
  ·
    by_cases cut4_48 : i < 48
    ·
      by_cases cut4_40 : i < 40
      ·
        by_cases cut4_36 : i < 36
        ·
          exact fromChunk c4_32 (by omega) (by omega)
        ·
          exact fromChunk c4_36 (by omega) (by omega)
      ·
        by_cases cut4_44 : i < 44
        ·
          exact fromChunk c4_40 (by omega) (by omega)
        ·
          exact fromChunk c4_44 (by omega) (by omega)
    ·
      by_cases cut4_56 : i < 56
      ·
        by_cases cut4_52 : i < 52
        ·
          exact fromChunk c4_48 (by omega) (by omega)
        ·
          exact fromChunk c4_52 (by omega) (by omega)
      ·
        by_cases cut4_60 : i < 60
        ·
          exact fromChunk c4_56 (by omega) (by omega)
        ·
          exact fromChunk c4_60 (by omega) (by omega)

#print axioms b4_0
end Petersen120.Mask81.LayerCheck
