import OtherTriples

namespace Petersen120.Mask81.LayerCheck
open PEqualNP.Outside.L_meta_274_aux
open Petersen1676 Petersen1676.Table Petersen1676.Prune Petersen1676.PinRules Petersen1676.Search

structure Entry where
  wires : List Nat
  spending : Nat
  links : List Nat
deriving Inhabited

def decodeNode (words : Array Nat) (r : Entry) : Memo.Node :=
  (r.wires.map (fun i => words[i]?.getD 0),
   (Other.initial 0).zipIdx.map (fun (it,j) => {it with spent := (r.spending >>> (6*j)) &&& 31}))

def selected (words : Array Nat) (r : Entry) (next : Array Entry) : List Memo.Node :=
  r.links.filterMap (fun i => (next[i]?).map (decodeNode words))

def localCheck (words : Array Nat) (s : Nat) (r : Entry) (next : Array Entry) : Bool :=
  let n := decodeNode words r
  (Cached.genExact allMask raw (covers kk) s n.1 n.2).all (fun q => (selected words r next).contains q)

def chunk (words : Array Nat) (s : Nat) (cur next : Array Entry) (offset size : Nat) : Bool :=
  (List.range size).all (fun j => localCheck words s (cur[offset+j]?.getD default) next)

/-- Every state in the supplied array refutes a run when its projected construction is valid. -/
def Closed (words : Array Nat) (s : Nat) (rows : Array Entry) := ∀ i : Fin rows.size,
  let q := decodeNode words rows[i]
  Invariant allMask Table.goal raw q.1 q.2 → ¬NatRun allMask Table.goal s q.1

private theorem moveValid {s ws budget q}
    (v : Invariant allMask Table.goal raw ws budget)
    (h : q ∈ Memo.gen allMask raw RunTable.cut s ws budget) :
    Invariant allMask Table.goal raw q.1 q.2 := by
  obtain ⟨ys,hy,hq⟩ := List.mem_filterMap.mp h
  simp only at hq
  split at hq
  · cases hq
    have hg := advance_sound v (Memo.child_edge _ _ _ _ hy)
    intro item hi
    obtain ⟨d,hb⟩ := hg item hi
    refine ⟨d,builtSubset hb ?_⟩
    exact fun f hf => ((Memo.canonicalPerm _).map (decode d.row)).mem_iff.mp hf
  · cases hq

set_option maxRecDepth 10000 in
set_option exponentiation.threshold 1000 in
theorem prior (words : Array Nat) (s : Nat) (cur next : Array Entry)
    (ok : ∀ i : Fin cur.size, localCheck words s cur[i] next = true)
    (after : Closed words s next) : Closed words (s+1) cur := by
  intro i
  dsimp only
  intro inv
  refine Memo.splitRefute (cut := RunTable.cut) (raw := raw) (s := s) ?_ inv ?_
  · intro _ _ _ vi hr
    rw [RunTable.cut,Bool.and_eq_true]
    exact ⟨covers_ok (k := kk) hr,legal_sound vi hr⟩
  · intro q hq
    have vi := moveValid inv hq
    rw [← Cached.actual_gen] at hq
    have hsel := List.contains_iff_mem.mp (List.all_eq_true.mp (ok i) q hq)
    obtain ⟨j,_,hj⟩ := List.mem_filterMap.mp hsel
    rcases h : next[j]? with _ | e
    · simp [h] at hj
    · simp [h] at hj
      have hjn : j < next.size := (Array.getElem?_eq_some_iff.mp h).1
      have he := (Array.getElem?_eq_some_iff.mp h).2
      have eq : decodeNode words next[j] = q := (congrArg (decodeNode words) he).trans hj
      rw [← eq] at vi ⊢
      exact after ⟨j,hjn⟩ vi

theorem fromChunk {words s cur next offset count i} (checked : chunk words s cur next offset count = true)
    (lower : offset ≤ i) (upper : i < offset+count) :
    localCheck words s (cur[i]?.getD default) next = true := by
  have j : i-offset < count := by omega
  have := List.all_eq_true.mp checked (i-offset) (List.mem_range.mpr j)
  simpa only [show offset+(i-offset)=i from by omega] using this
end Petersen120.Mask81.LayerCheck
