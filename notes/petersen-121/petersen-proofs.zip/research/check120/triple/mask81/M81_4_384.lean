import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c4_384 : chunk words 8 l4 l5 384 4 = true := by decide +kernel
private theorem c4_388 : chunk words 8 l4 l5 388 4 = true := by decide +kernel
private theorem c4_392 : chunk words 8 l4 l5 392 4 = true := by decide +kernel
private theorem c4_396 : chunk words 8 l4 l5 396 4 = true := by decide +kernel
private theorem c4_400 : chunk words 8 l4 l5 400 4 = true := by decide +kernel
private theorem c4_404 : chunk words 8 l4 l5 404 4 = true := by decide +kernel
private theorem c4_408 : chunk words 8 l4 l5 408 4 = true := by decide +kernel
private theorem c4_412 : chunk words 8 l4 l5 412 4 = true := by decide +kernel
private theorem c4_416 : chunk words 8 l4 l5 416 4 = true := by decide +kernel
private theorem c4_420 : chunk words 8 l4 l5 420 4 = true := by decide +kernel
private theorem c4_424 : chunk words 8 l4 l5 424 4 = true := by decide +kernel
private theorem c4_428 : chunk words 8 l4 l5 428 4 = true := by decide +kernel
private theorem c4_432 : chunk words 8 l4 l5 432 4 = true := by decide +kernel
private theorem c4_436 : chunk words 8 l4 l5 436 4 = true := by decide +kernel
private theorem c4_440 : chunk words 8 l4 l5 440 4 = true := by decide +kernel
private theorem c4_444 : chunk words 8 l4 l5 444 4 = true := by decide +kernel

theorem b4_384 (i : Nat) (lo : 384 ≤ i) (hi : i < 448) :
    localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_416 : i < 416
  ·
    by_cases cut4_400 : i < 400
    ·
      by_cases cut4_392 : i < 392
      ·
        by_cases cut4_388 : i < 388
        ·
          exact fromChunk c4_384 (by omega) (by omega)
        ·
          exact fromChunk c4_388 (by omega) (by omega)
      ·
        by_cases cut4_396 : i < 396
        ·
          exact fromChunk c4_392 (by omega) (by omega)
        ·
          exact fromChunk c4_396 (by omega) (by omega)
    ·
      by_cases cut4_408 : i < 408
      ·
        by_cases cut4_404 : i < 404
        ·
          exact fromChunk c4_400 (by omega) (by omega)
        ·
          exact fromChunk c4_404 (by omega) (by omega)
      ·
        by_cases cut4_412 : i < 412
        ·
          exact fromChunk c4_408 (by omega) (by omega)
        ·
          exact fromChunk c4_412 (by omega) (by omega)
  ·
    by_cases cut4_432 : i < 432
    ·
      by_cases cut4_424 : i < 424
      ·
        by_cases cut4_420 : i < 420
        ·
          exact fromChunk c4_416 (by omega) (by omega)
        ·
          exact fromChunk c4_420 (by omega) (by omega)
      ·
        by_cases cut4_428 : i < 428
        ·
          exact fromChunk c4_424 (by omega) (by omega)
        ·
          exact fromChunk c4_428 (by omega) (by omega)
    ·
      by_cases cut4_440 : i < 440
      ·
        by_cases cut4_436 : i < 436
        ·
          exact fromChunk c4_432 (by omega) (by omega)
        ·
          exact fromChunk c4_436 (by omega) (by omega)
      ·
        by_cases cut4_444 : i < 444
        ·
          exact fromChunk c4_440 (by omega) (by omega)
        ·
          exact fromChunk c4_444 (by omega) (by omega)

#print axioms b4_384
end Petersen120.Mask81.LayerCheck
