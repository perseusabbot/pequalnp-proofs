import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_576 : chunk words 9 l3 l4 576 4 = true := by decide +kernel
private theorem c3_580 : chunk words 9 l3 l4 580 4 = true := by decide +kernel
private theorem c3_584 : chunk words 9 l3 l4 584 4 = true := by decide +kernel
private theorem c3_588 : chunk words 9 l3 l4 588 4 = true := by decide +kernel
private theorem c3_592 : chunk words 9 l3 l4 592 4 = true := by decide +kernel
private theorem c3_596 : chunk words 9 l3 l4 596 4 = true := by decide +kernel
private theorem c3_600 : chunk words 9 l3 l4 600 4 = true := by decide +kernel
private theorem c3_604 : chunk words 9 l3 l4 604 4 = true := by decide +kernel
private theorem c3_608 : chunk words 9 l3 l4 608 4 = true := by decide +kernel
private theorem c3_612 : chunk words 9 l3 l4 612 4 = true := by decide +kernel
private theorem c3_616 : chunk words 9 l3 l4 616 4 = true := by decide +kernel
private theorem c3_620 : chunk words 9 l3 l4 620 4 = true := by decide +kernel
private theorem c3_624 : chunk words 9 l3 l4 624 4 = true := by decide +kernel
private theorem c3_628 : chunk words 9 l3 l4 628 4 = true := by decide +kernel
private theorem c3_632 : chunk words 9 l3 l4 632 4 = true := by decide +kernel
private theorem c3_636 : chunk words 9 l3 l4 636 4 = true := by decide +kernel

theorem b3_576 (i : Nat) (lo : 576 ≤ i) (hi : i < 640) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_608 : i < 608
  ·
    by_cases cut3_592 : i < 592
    ·
      by_cases cut3_584 : i < 584
      ·
        by_cases cut3_580 : i < 580
        ·
          exact fromChunk c3_576 (by omega) (by omega)
        ·
          exact fromChunk c3_580 (by omega) (by omega)
      ·
        by_cases cut3_588 : i < 588
        ·
          exact fromChunk c3_584 (by omega) (by omega)
        ·
          exact fromChunk c3_588 (by omega) (by omega)
    ·
      by_cases cut3_600 : i < 600
      ·
        by_cases cut3_596 : i < 596
        ·
          exact fromChunk c3_592 (by omega) (by omega)
        ·
          exact fromChunk c3_596 (by omega) (by omega)
      ·
        by_cases cut3_604 : i < 604
        ·
          exact fromChunk c3_600 (by omega) (by omega)
        ·
          exact fromChunk c3_604 (by omega) (by omega)
  ·
    by_cases cut3_624 : i < 624
    ·
      by_cases cut3_616 : i < 616
      ·
        by_cases cut3_612 : i < 612
        ·
          exact fromChunk c3_608 (by omega) (by omega)
        ·
          exact fromChunk c3_612 (by omega) (by omega)
      ·
        by_cases cut3_620 : i < 620
        ·
          exact fromChunk c3_616 (by omega) (by omega)
        ·
          exact fromChunk c3_620 (by omega) (by omega)
    ·
      by_cases cut3_632 : i < 632
      ·
        by_cases cut3_628 : i < 628
        ·
          exact fromChunk c3_624 (by omega) (by omega)
        ·
          exact fromChunk c3_628 (by omega) (by omega)
      ·
        by_cases cut3_636 : i < 636
        ·
          exact fromChunk c3_632 (by omega) (by omega)
        ·
          exact fromChunk c3_636 (by omega) (by omega)

#print axioms b3_576
end Petersen120.Mask81.LayerCheck
