import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_640 : chunk words 9 l3 l4 640 4 = true := by decide +kernel
private theorem c3_644 : chunk words 9 l3 l4 644 4 = true := by decide +kernel
private theorem c3_648 : chunk words 9 l3 l4 648 4 = true := by decide +kernel
private theorem c3_652 : chunk words 9 l3 l4 652 4 = true := by decide +kernel
private theorem c3_656 : chunk words 9 l3 l4 656 4 = true := by decide +kernel
private theorem c3_660 : chunk words 9 l3 l4 660 4 = true := by decide +kernel
private theorem c3_664 : chunk words 9 l3 l4 664 4 = true := by decide +kernel
private theorem c3_668 : chunk words 9 l3 l4 668 4 = true := by decide +kernel
private theorem c3_672 : chunk words 9 l3 l4 672 4 = true := by decide +kernel
private theorem c3_676 : chunk words 9 l3 l4 676 4 = true := by decide +kernel
private theorem c3_680 : chunk words 9 l3 l4 680 4 = true := by decide +kernel
private theorem c3_684 : chunk words 9 l3 l4 684 4 = true := by decide +kernel
private theorem c3_688 : chunk words 9 l3 l4 688 4 = true := by decide +kernel
private theorem c3_692 : chunk words 9 l3 l4 692 4 = true := by decide +kernel
private theorem c3_696 : chunk words 9 l3 l4 696 4 = true := by decide +kernel
private theorem c3_700 : chunk words 9 l3 l4 700 4 = true := by decide +kernel

theorem b3_640 (i : Nat) (lo : 640 ≤ i) (hi : i < 704) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_672 : i < 672
  ·
    by_cases cut3_656 : i < 656
    ·
      by_cases cut3_648 : i < 648
      ·
        by_cases cut3_644 : i < 644
        ·
          exact fromChunk c3_640 (by omega) (by omega)
        ·
          exact fromChunk c3_644 (by omega) (by omega)
      ·
        by_cases cut3_652 : i < 652
        ·
          exact fromChunk c3_648 (by omega) (by omega)
        ·
          exact fromChunk c3_652 (by omega) (by omega)
    ·
      by_cases cut3_664 : i < 664
      ·
        by_cases cut3_660 : i < 660
        ·
          exact fromChunk c3_656 (by omega) (by omega)
        ·
          exact fromChunk c3_660 (by omega) (by omega)
      ·
        by_cases cut3_668 : i < 668
        ·
          exact fromChunk c3_664 (by omega) (by omega)
        ·
          exact fromChunk c3_668 (by omega) (by omega)
  ·
    by_cases cut3_688 : i < 688
    ·
      by_cases cut3_680 : i < 680
      ·
        by_cases cut3_676 : i < 676
        ·
          exact fromChunk c3_672 (by omega) (by omega)
        ·
          exact fromChunk c3_676 (by omega) (by omega)
      ·
        by_cases cut3_684 : i < 684
        ·
          exact fromChunk c3_680 (by omega) (by omega)
        ·
          exact fromChunk c3_684 (by omega) (by omega)
    ·
      by_cases cut3_696 : i < 696
      ·
        by_cases cut3_692 : i < 692
        ·
          exact fromChunk c3_688 (by omega) (by omega)
        ·
          exact fromChunk c3_692 (by omega) (by omega)
      ·
        by_cases cut3_700 : i < 700
        ·
          exact fromChunk c3_696 (by omega) (by omega)
        ·
          exact fromChunk c3_700 (by omega) (by omega)

#print axioms b3_640
end Petersen120.Mask81.LayerCheck
