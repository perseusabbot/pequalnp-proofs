import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_816 : chunk words 9 l3 l4 816 4 = true := by decide +kernel
private theorem c3_820 : chunk words 9 l3 l4 820 4 = true := by decide +kernel
private theorem c3_824 : chunk words 9 l3 l4 824 4 = true := by decide +kernel
private theorem c3_828 : chunk words 9 l3 l4 828 4 = true := by decide +kernel
theorem s3_816 (i : Nat) (lo : 816 ≤ i) (hi : i < 832) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_824 : i < 824
  ·
    by_cases cut3_820 : i < 820
    ·
      exact fromChunk c3_816 (by omega) (by omega)
    ·
      exact fromChunk c3_820 (by omega) (by omega)
  ·
    by_cases cut3_828 : i < 828
    ·
      exact fromChunk c3_824 (by omega) (by omega)
    ·
      exact fromChunk c3_828 (by omega) (by omega)

#print axioms s3_816
end Petersen120.Mask81.LayerCheck
