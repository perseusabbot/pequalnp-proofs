import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_192 : chunk words 9 l3 l4 192 4 = true := by decide +kernel
private theorem c3_196 : chunk words 9 l3 l4 196 4 = true := by decide +kernel
private theorem c3_200 : chunk words 9 l3 l4 200 4 = true := by decide +kernel
private theorem c3_204 : chunk words 9 l3 l4 204 4 = true := by decide +kernel
private theorem c3_208 : chunk words 9 l3 l4 208 4 = true := by decide +kernel
private theorem c3_212 : chunk words 9 l3 l4 212 4 = true := by decide +kernel
private theorem c3_216 : chunk words 9 l3 l4 216 4 = true := by decide +kernel
private theorem c3_220 : chunk words 9 l3 l4 220 4 = true := by decide +kernel
private theorem c3_224 : chunk words 9 l3 l4 224 4 = true := by decide +kernel
private theorem c3_228 : chunk words 9 l3 l4 228 4 = true := by decide +kernel
private theorem c3_232 : chunk words 9 l3 l4 232 4 = true := by decide +kernel
private theorem c3_236 : chunk words 9 l3 l4 236 4 = true := by decide +kernel
private theorem c3_240 : chunk words 9 l3 l4 240 4 = true := by decide +kernel
private theorem c3_244 : chunk words 9 l3 l4 244 4 = true := by decide +kernel
private theorem c3_248 : chunk words 9 l3 l4 248 4 = true := by decide +kernel
private theorem c3_252 : chunk words 9 l3 l4 252 4 = true := by decide +kernel

theorem b3_192 (i : Nat) (lo : 192 ≤ i) (hi : i < 256) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_224 : i < 224
  ·
    by_cases cut3_208 : i < 208
    ·
      by_cases cut3_200 : i < 200
      ·
        by_cases cut3_196 : i < 196
        ·
          exact fromChunk c3_192 (by omega) (by omega)
        ·
          exact fromChunk c3_196 (by omega) (by omega)
      ·
        by_cases cut3_204 : i < 204
        ·
          exact fromChunk c3_200 (by omega) (by omega)
        ·
          exact fromChunk c3_204 (by omega) (by omega)
    ·
      by_cases cut3_216 : i < 216
      ·
        by_cases cut3_212 : i < 212
        ·
          exact fromChunk c3_208 (by omega) (by omega)
        ·
          exact fromChunk c3_212 (by omega) (by omega)
      ·
        by_cases cut3_220 : i < 220
        ·
          exact fromChunk c3_216 (by omega) (by omega)
        ·
          exact fromChunk c3_220 (by omega) (by omega)
  ·
    by_cases cut3_240 : i < 240
    ·
      by_cases cut3_232 : i < 232
      ·
        by_cases cut3_228 : i < 228
        ·
          exact fromChunk c3_224 (by omega) (by omega)
        ·
          exact fromChunk c3_228 (by omega) (by omega)
      ·
        by_cases cut3_236 : i < 236
        ·
          exact fromChunk c3_232 (by omega) (by omega)
        ·
          exact fromChunk c3_236 (by omega) (by omega)
    ·
      by_cases cut3_248 : i < 248
      ·
        by_cases cut3_244 : i < 244
        ·
          exact fromChunk c3_240 (by omega) (by omega)
        ·
          exact fromChunk c3_244 (by omega) (by omega)
      ·
        by_cases cut3_252 : i < 252
        ·
          exact fromChunk c3_248 (by omega) (by omega)
        ·
          exact fromChunk c3_252 (by omega) (by omega)

#print axioms b3_192
end Petersen120.Mask81.LayerCheck
