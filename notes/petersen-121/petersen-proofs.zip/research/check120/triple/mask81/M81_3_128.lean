import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_128 : chunk words 9 l3 l4 128 4 = true := by decide +kernel
private theorem c3_132 : chunk words 9 l3 l4 132 4 = true := by decide +kernel
private theorem c3_136 : chunk words 9 l3 l4 136 4 = true := by decide +kernel
private theorem c3_140 : chunk words 9 l3 l4 140 4 = true := by decide +kernel
private theorem c3_144 : chunk words 9 l3 l4 144 4 = true := by decide +kernel
private theorem c3_148 : chunk words 9 l3 l4 148 4 = true := by decide +kernel
private theorem c3_152 : chunk words 9 l3 l4 152 4 = true := by decide +kernel
private theorem c3_156 : chunk words 9 l3 l4 156 4 = true := by decide +kernel
private theorem c3_160 : chunk words 9 l3 l4 160 4 = true := by decide +kernel
private theorem c3_164 : chunk words 9 l3 l4 164 4 = true := by decide +kernel
private theorem c3_168 : chunk words 9 l3 l4 168 4 = true := by decide +kernel
private theorem c3_172 : chunk words 9 l3 l4 172 4 = true := by decide +kernel
private theorem c3_176 : chunk words 9 l3 l4 176 4 = true := by decide +kernel
private theorem c3_180 : chunk words 9 l3 l4 180 4 = true := by decide +kernel
private theorem c3_184 : chunk words 9 l3 l4 184 4 = true := by decide +kernel
private theorem c3_188 : chunk words 9 l3 l4 188 4 = true := by decide +kernel

theorem b3_128 (i : Nat) (lo : 128 ≤ i) (hi : i < 192) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_160 : i < 160
  ·
    by_cases cut3_144 : i < 144
    ·
      by_cases cut3_136 : i < 136
      ·
        by_cases cut3_132 : i < 132
        ·
          exact fromChunk c3_128 (by omega) (by omega)
        ·
          exact fromChunk c3_132 (by omega) (by omega)
      ·
        by_cases cut3_140 : i < 140
        ·
          exact fromChunk c3_136 (by omega) (by omega)
        ·
          exact fromChunk c3_140 (by omega) (by omega)
    ·
      by_cases cut3_152 : i < 152
      ·
        by_cases cut3_148 : i < 148
        ·
          exact fromChunk c3_144 (by omega) (by omega)
        ·
          exact fromChunk c3_148 (by omega) (by omega)
      ·
        by_cases cut3_156 : i < 156
        ·
          exact fromChunk c3_152 (by omega) (by omega)
        ·
          exact fromChunk c3_156 (by omega) (by omega)
  ·
    by_cases cut3_176 : i < 176
    ·
      by_cases cut3_168 : i < 168
      ·
        by_cases cut3_164 : i < 164
        ·
          exact fromChunk c3_160 (by omega) (by omega)
        ·
          exact fromChunk c3_164 (by omega) (by omega)
      ·
        by_cases cut3_172 : i < 172
        ·
          exact fromChunk c3_168 (by omega) (by omega)
        ·
          exact fromChunk c3_172 (by omega) (by omega)
    ·
      by_cases cut3_184 : i < 184
      ·
        by_cases cut3_180 : i < 180
        ·
          exact fromChunk c3_176 (by omega) (by omega)
        ·
          exact fromChunk c3_180 (by omega) (by omega)
      ·
        by_cases cut3_188 : i < 188
        ·
          exact fromChunk c3_184 (by omega) (by omega)
        ·
          exact fromChunk c3_188 (by omega) (by omega)

#print axioms b3_128
end Petersen120.Mask81.LayerCheck
