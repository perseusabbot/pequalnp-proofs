import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c2_384 : chunk words 10 l2 l3 384 4 = true := by decide +kernel
private theorem c2_388 : chunk words 10 l2 l3 388 4 = true := by decide +kernel
private theorem c2_392 : chunk words 10 l2 l3 392 4 = true := by decide +kernel
private theorem c2_396 : chunk words 10 l2 l3 396 4 = true := by decide +kernel
private theorem c2_400 : chunk words 10 l2 l3 400 4 = true := by decide +kernel
private theorem c2_404 : chunk words 10 l2 l3 404 4 = true := by decide +kernel
private theorem c2_408 : chunk words 10 l2 l3 408 4 = true := by decide +kernel
private theorem c2_412 : chunk words 10 l2 l3 412 4 = true := by decide +kernel
private theorem c2_416 : chunk words 10 l2 l3 416 4 = true := by decide +kernel
private theorem c2_420 : chunk words 10 l2 l3 420 1 = true := by decide +kernel

theorem b2_384 (i : Nat) (lo : 384 ≤ i) (hi : i < 421) :
    localCheck words 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut2_404 : i < 404
  ·
    by_cases cut2_392 : i < 392
    ·
      by_cases cut2_388 : i < 388
      ·
        exact fromChunk c2_384 (by omega) (by omega)
      ·
        exact fromChunk c2_388 (by omega) (by omega)
    ·
      by_cases cut2_396 : i < 396
      ·
        exact fromChunk c2_392 (by omega) (by omega)
      ·
        by_cases cut2_400 : i < 400
        ·
          exact fromChunk c2_396 (by omega) (by omega)
        ·
          exact fromChunk c2_400 (by omega) (by omega)
  ·
    by_cases cut2_412 : i < 412
    ·
      by_cases cut2_408 : i < 408
      ·
        exact fromChunk c2_404 (by omega) (by omega)
      ·
        exact fromChunk c2_408 (by omega) (by omega)
    ·
      by_cases cut2_416 : i < 416
      ·
        exact fromChunk c2_412 (by omega) (by omega)
      ·
        by_cases cut2_420 : i < 420
        ·
          exact fromChunk c2_416 (by omega) (by omega)
        ·
          exact fromChunk c2_420 (by omega) (by omega)

#print axioms b2_384
end Petersen120.Mask81.LayerCheck
