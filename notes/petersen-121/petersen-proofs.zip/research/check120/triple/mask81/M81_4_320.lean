import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c4_320 : chunk words 8 l4 l5 320 4 = true := by decide +kernel
private theorem c4_324 : chunk words 8 l4 l5 324 4 = true := by decide +kernel
private theorem c4_328 : chunk words 8 l4 l5 328 4 = true := by decide +kernel
private theorem c4_332 : chunk words 8 l4 l5 332 4 = true := by decide +kernel
private theorem c4_336 : chunk words 8 l4 l5 336 4 = true := by decide +kernel
private theorem c4_340 : chunk words 8 l4 l5 340 4 = true := by decide +kernel
private theorem c4_344 : chunk words 8 l4 l5 344 4 = true := by decide +kernel
private theorem c4_348 : chunk words 8 l4 l5 348 4 = true := by decide +kernel
private theorem c4_352 : chunk words 8 l4 l5 352 4 = true := by decide +kernel
private theorem c4_356 : chunk words 8 l4 l5 356 4 = true := by decide +kernel
private theorem c4_360 : chunk words 8 l4 l5 360 4 = true := by decide +kernel
private theorem c4_364 : chunk words 8 l4 l5 364 4 = true := by decide +kernel
private theorem c4_368 : chunk words 8 l4 l5 368 4 = true := by decide +kernel
private theorem c4_372 : chunk words 8 l4 l5 372 4 = true := by decide +kernel
private theorem c4_376 : chunk words 8 l4 l5 376 4 = true := by decide +kernel
private theorem c4_380 : chunk words 8 l4 l5 380 4 = true := by decide +kernel

theorem b4_320 (i : Nat) (lo : 320 ≤ i) (hi : i < 384) :
    localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_352 : i < 352
  ·
    by_cases cut4_336 : i < 336
    ·
      by_cases cut4_328 : i < 328
      ·
        by_cases cut4_324 : i < 324
        ·
          exact fromChunk c4_320 (by omega) (by omega)
        ·
          exact fromChunk c4_324 (by omega) (by omega)
      ·
        by_cases cut4_332 : i < 332
        ·
          exact fromChunk c4_328 (by omega) (by omega)
        ·
          exact fromChunk c4_332 (by omega) (by omega)
    ·
      by_cases cut4_344 : i < 344
      ·
        by_cases cut4_340 : i < 340
        ·
          exact fromChunk c4_336 (by omega) (by omega)
        ·
          exact fromChunk c4_340 (by omega) (by omega)
      ·
        by_cases cut4_348 : i < 348
        ·
          exact fromChunk c4_344 (by omega) (by omega)
        ·
          exact fromChunk c4_348 (by omega) (by omega)
  ·
    by_cases cut4_368 : i < 368
    ·
      by_cases cut4_360 : i < 360
      ·
        by_cases cut4_356 : i < 356
        ·
          exact fromChunk c4_352 (by omega) (by omega)
        ·
          exact fromChunk c4_356 (by omega) (by omega)
      ·
        by_cases cut4_364 : i < 364
        ·
          exact fromChunk c4_360 (by omega) (by omega)
        ·
          exact fromChunk c4_364 (by omega) (by omega)
    ·
      by_cases cut4_376 : i < 376
      ·
        by_cases cut4_372 : i < 372
        ·
          exact fromChunk c4_368 (by omega) (by omega)
        ·
          exact fromChunk c4_372 (by omega) (by omega)
      ·
        by_cases cut4_380 : i < 380
        ·
          exact fromChunk c4_376 (by omega) (by omega)
        ·
          exact fromChunk c4_380 (by omega) (by omega)

#print axioms b4_320
end Petersen120.Mask81.LayerCheck
