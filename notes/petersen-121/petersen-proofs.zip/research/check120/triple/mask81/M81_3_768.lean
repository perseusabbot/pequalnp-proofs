import S81_3_768
import S81_3_784
import S81_3_800
import S81_3_816

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem b3_768 (i : Nat) (lo : 768 ≤ i) (hi : i < 832) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_800 : i < 800
  ·
    by_cases cut3_784 : i < 784
    ·
      exact s3_768 i (by omega) (by omega)
    ·
      exact s3_784 i (by omega) (by omega)
  ·
    by_cases cut3_816 : i < 816
    ·
      exact s3_800 i (by omega) (by omega)
    ·
      exact s3_816 i (by omega) (by omega)

#print axioms b3_768
end Petersen120.Mask81.LayerCheck
