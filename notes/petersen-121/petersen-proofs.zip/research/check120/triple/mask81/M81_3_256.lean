import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_256 : chunk words 9 l3 l4 256 4 = true := by decide +kernel
private theorem c3_260 : chunk words 9 l3 l4 260 4 = true := by decide +kernel
private theorem c3_264 : chunk words 9 l3 l4 264 4 = true := by decide +kernel
private theorem c3_268 : chunk words 9 l3 l4 268 4 = true := by decide +kernel
private theorem c3_272 : chunk words 9 l3 l4 272 4 = true := by decide +kernel
private theorem c3_276 : chunk words 9 l3 l4 276 4 = true := by decide +kernel
private theorem c3_280 : chunk words 9 l3 l4 280 4 = true := by decide +kernel
private theorem c3_284 : chunk words 9 l3 l4 284 4 = true := by decide +kernel
private theorem c3_288 : chunk words 9 l3 l4 288 4 = true := by decide +kernel
private theorem c3_292 : chunk words 9 l3 l4 292 4 = true := by decide +kernel
private theorem c3_296 : chunk words 9 l3 l4 296 4 = true := by decide +kernel
private theorem c3_300 : chunk words 9 l3 l4 300 4 = true := by decide +kernel
private theorem c3_304 : chunk words 9 l3 l4 304 4 = true := by decide +kernel
private theorem c3_308 : chunk words 9 l3 l4 308 4 = true := by decide +kernel
private theorem c3_312 : chunk words 9 l3 l4 312 4 = true := by decide +kernel
private theorem c3_316 : chunk words 9 l3 l4 316 4 = true := by decide +kernel

theorem b3_256 (i : Nat) (lo : 256 ≤ i) (hi : i < 320) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_288 : i < 288
  ·
    by_cases cut3_272 : i < 272
    ·
      by_cases cut3_264 : i < 264
      ·
        by_cases cut3_260 : i < 260
        ·
          exact fromChunk c3_256 (by omega) (by omega)
        ·
          exact fromChunk c3_260 (by omega) (by omega)
      ·
        by_cases cut3_268 : i < 268
        ·
          exact fromChunk c3_264 (by omega) (by omega)
        ·
          exact fromChunk c3_268 (by omega) (by omega)
    ·
      by_cases cut3_280 : i < 280
      ·
        by_cases cut3_276 : i < 276
        ·
          exact fromChunk c3_272 (by omega) (by omega)
        ·
          exact fromChunk c3_276 (by omega) (by omega)
      ·
        by_cases cut3_284 : i < 284
        ·
          exact fromChunk c3_280 (by omega) (by omega)
        ·
          exact fromChunk c3_284 (by omega) (by omega)
  ·
    by_cases cut3_304 : i < 304
    ·
      by_cases cut3_296 : i < 296
      ·
        by_cases cut3_292 : i < 292
        ·
          exact fromChunk c3_288 (by omega) (by omega)
        ·
          exact fromChunk c3_292 (by omega) (by omega)
      ·
        by_cases cut3_300 : i < 300
        ·
          exact fromChunk c3_296 (by omega) (by omega)
        ·
          exact fromChunk c3_300 (by omega) (by omega)
    ·
      by_cases cut3_312 : i < 312
      ·
        by_cases cut3_308 : i < 308
        ·
          exact fromChunk c3_304 (by omega) (by omega)
        ·
          exact fromChunk c3_308 (by omega) (by omega)
      ·
        by_cases cut3_316 : i < 316
        ·
          exact fromChunk c3_312 (by omega) (by omega)
        ·
          exact fromChunk c3_316 (by omega) (by omega)

#print axioms b3_256
end Petersen120.Mask81.LayerCheck
