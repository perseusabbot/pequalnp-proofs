import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c2_0 : chunk words 10 l2 l3 0 4 = true := by decide +kernel
private theorem c2_4 : chunk words 10 l2 l3 4 4 = true := by decide +kernel
private theorem c2_8 : chunk words 10 l2 l3 8 4 = true := by decide +kernel
private theorem c2_12 : chunk words 10 l2 l3 12 4 = true := by decide +kernel
private theorem c2_16 : chunk words 10 l2 l3 16 4 = true := by decide +kernel
private theorem c2_20 : chunk words 10 l2 l3 20 4 = true := by decide +kernel
private theorem c2_24 : chunk words 10 l2 l3 24 4 = true := by decide +kernel
private theorem c2_28 : chunk words 10 l2 l3 28 4 = true := by decide +kernel
private theorem c2_32 : chunk words 10 l2 l3 32 4 = true := by decide +kernel
private theorem c2_36 : chunk words 10 l2 l3 36 4 = true := by decide +kernel
private theorem c2_40 : chunk words 10 l2 l3 40 4 = true := by decide +kernel
private theorem c2_44 : chunk words 10 l2 l3 44 4 = true := by decide +kernel
private theorem c2_48 : chunk words 10 l2 l3 48 4 = true := by decide +kernel
private theorem c2_52 : chunk words 10 l2 l3 52 4 = true := by decide +kernel
private theorem c2_56 : chunk words 10 l2 l3 56 4 = true := by decide +kernel
private theorem c2_60 : chunk words 10 l2 l3 60 4 = true := by decide +kernel

theorem b2_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 64) :
    localCheck words 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut2_32 : i < 32
  ·
    by_cases cut2_16 : i < 16
    ·
      by_cases cut2_8 : i < 8
      ·
        by_cases cut2_4 : i < 4
        ·
          exact fromChunk c2_0 (by omega) (by omega)
        ·
          exact fromChunk c2_4 (by omega) (by omega)
      ·
        by_cases cut2_12 : i < 12
        ·
          exact fromChunk c2_8 (by omega) (by omega)
        ·
          exact fromChunk c2_12 (by omega) (by omega)
    ·
      by_cases cut2_24 : i < 24
      ·
        by_cases cut2_20 : i < 20
        ·
          exact fromChunk c2_16 (by omega) (by omega)
        ·
          exact fromChunk c2_20 (by omega) (by omega)
      ·
        by_cases cut2_28 : i < 28
        ·
          exact fromChunk c2_24 (by omega) (by omega)
        ·
          exact fromChunk c2_28 (by omega) (by omega)
  ·
    by_cases cut2_48 : i < 48
    ·
      by_cases cut2_40 : i < 40
      ·
        by_cases cut2_36 : i < 36
        ·
          exact fromChunk c2_32 (by omega) (by omega)
        ·
          exact fromChunk c2_36 (by omega) (by omega)
      ·
        by_cases cut2_44 : i < 44
        ·
          exact fromChunk c2_40 (by omega) (by omega)
        ·
          exact fromChunk c2_44 (by omega) (by omega)
    ·
      by_cases cut2_56 : i < 56
      ·
        by_cases cut2_52 : i < 52
        ·
          exact fromChunk c2_48 (by omega) (by omega)
        ·
          exact fromChunk c2_52 (by omega) (by omega)
      ·
        by_cases cut2_60 : i < 60
        ·
          exact fromChunk c2_56 (by omega) (by omega)
        ·
          exact fromChunk c2_60 (by omega) (by omega)

#print axioms b2_0
end Petersen120.Mask81.LayerCheck
