import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c4_64 : chunk words 8 l4 l5 64 4 = true := by decide +kernel
private theorem c4_68 : chunk words 8 l4 l5 68 4 = true := by decide +kernel
private theorem c4_72 : chunk words 8 l4 l5 72 4 = true := by decide +kernel
private theorem c4_76 : chunk words 8 l4 l5 76 4 = true := by decide +kernel
private theorem c4_80 : chunk words 8 l4 l5 80 4 = true := by decide +kernel
private theorem c4_84 : chunk words 8 l4 l5 84 4 = true := by decide +kernel
private theorem c4_88 : chunk words 8 l4 l5 88 4 = true := by decide +kernel
private theorem c4_92 : chunk words 8 l4 l5 92 4 = true := by decide +kernel
private theorem c4_96 : chunk words 8 l4 l5 96 4 = true := by decide +kernel
private theorem c4_100 : chunk words 8 l4 l5 100 4 = true := by decide +kernel
private theorem c4_104 : chunk words 8 l4 l5 104 4 = true := by decide +kernel
private theorem c4_108 : chunk words 8 l4 l5 108 4 = true := by decide +kernel
private theorem c4_112 : chunk words 8 l4 l5 112 4 = true := by decide +kernel
private theorem c4_116 : chunk words 8 l4 l5 116 4 = true := by decide +kernel
private theorem c4_120 : chunk words 8 l4 l5 120 4 = true := by decide +kernel
private theorem c4_124 : chunk words 8 l4 l5 124 4 = true := by decide +kernel

theorem b4_64 (i : Nat) (lo : 64 ≤ i) (hi : i < 128) :
    localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_96 : i < 96
  ·
    by_cases cut4_80 : i < 80
    ·
      by_cases cut4_72 : i < 72
      ·
        by_cases cut4_68 : i < 68
        ·
          exact fromChunk c4_64 (by omega) (by omega)
        ·
          exact fromChunk c4_68 (by omega) (by omega)
      ·
        by_cases cut4_76 : i < 76
        ·
          exact fromChunk c4_72 (by omega) (by omega)
        ·
          exact fromChunk c4_76 (by omega) (by omega)
    ·
      by_cases cut4_88 : i < 88
      ·
        by_cases cut4_84 : i < 84
        ·
          exact fromChunk c4_80 (by omega) (by omega)
        ·
          exact fromChunk c4_84 (by omega) (by omega)
      ·
        by_cases cut4_92 : i < 92
        ·
          exact fromChunk c4_88 (by omega) (by omega)
        ·
          exact fromChunk c4_92 (by omega) (by omega)
  ·
    by_cases cut4_112 : i < 112
    ·
      by_cases cut4_104 : i < 104
      ·
        by_cases cut4_100 : i < 100
        ·
          exact fromChunk c4_96 (by omega) (by omega)
        ·
          exact fromChunk c4_100 (by omega) (by omega)
      ·
        by_cases cut4_108 : i < 108
        ·
          exact fromChunk c4_104 (by omega) (by omega)
        ·
          exact fromChunk c4_108 (by omega) (by omega)
    ·
      by_cases cut4_120 : i < 120
      ·
        by_cases cut4_116 : i < 116
        ·
          exact fromChunk c4_112 (by omega) (by omega)
        ·
          exact fromChunk c4_116 (by omega) (by omega)
      ·
        by_cases cut4_124 : i < 124
        ·
          exact fromChunk c4_120 (by omega) (by omega)
        ·
          exact fromChunk c4_124 (by omega) (by omega)

#print axioms b4_64
end Petersen120.Mask81.LayerCheck
