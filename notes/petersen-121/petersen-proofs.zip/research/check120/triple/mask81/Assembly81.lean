import LayersData
namespace Petersen120.Mask81.LayerCheck
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table
set_option maxRecDepth 100000
set_option maxHeartbeats 0
abbrev Good0 := ∀ i : Nat, i < 1 → localCheck words 12 (l0[i]?.getD default) l1 = true
abbrev Good1 := ∀ i : Nat, i < 36 → localCheck words 11 (l1[i]?.getD default) l2 = true
abbrev Good2 := ∀ i : Nat, i < 421 → localCheck words 10 (l2[i]?.getD default) l3 = true
abbrev Good3 := ∀ i : Nat, i < 1224 → localCheck words 9 (l3[i]?.getD default) l4 = true
abbrev Good4 := ∀ i : Nat, i < 723 → localCheck words 8 (l4[i]?.getD default) l5 = true
abbrev Good5 := ∀ i : Nat, i < 29 → localCheck words 7 (l5[i]?.getD default) l6 = true

private theorem step0 (all0 : Good0) (h : Closed words 12 l1) : Closed words 13 l0 := by
  apply prior _ _ _ _ _ h
  intro i
  have sz : l0.size = 1 := by decide +kernel
  have ok := all0 i.val (sz ▸ i.isLt)
  simpa only [Fin.getElem_fin, Array.getElem?_eq_getElem i.isLt, Option.getD_some] using ok

private theorem step1 (all1 : Good1) (h : Closed words 11 l2) : Closed words 12 l1 := by
  apply prior _ _ _ _ _ h
  intro i
  have sz : l1.size = 36 := by decide +kernel
  have ok := all1 i.val (sz ▸ i.isLt)
  simpa only [Fin.getElem_fin, Array.getElem?_eq_getElem i.isLt, Option.getD_some] using ok

private theorem step2 (all2 : Good2) (h : Closed words 10 l3) : Closed words 11 l2 := by
  apply prior _ _ _ _ _ h
  intro i
  have sz : l2.size = 421 := by decide +kernel
  have ok := all2 i.val (sz ▸ i.isLt)
  simpa only [Fin.getElem_fin, Array.getElem?_eq_getElem i.isLt, Option.getD_some] using ok

private theorem step3 (all3 : Good3) (h : Closed words 9 l4) : Closed words 10 l3 := by
  apply prior _ _ _ _ _ h
  intro i
  have sz : l3.size = 1224 := by decide +kernel
  have ok := all3 i.val (sz ▸ i.isLt)
  simpa only [Fin.getElem_fin, Array.getElem?_eq_getElem i.isLt, Option.getD_some] using ok

private theorem step4 (all4 : Good4) (h : Closed words 8 l5) : Closed words 9 l4 := by
  apply prior _ _ _ _ _ h
  intro i
  have sz : l4.size = 723 := by decide +kernel
  have ok := all4 i.val (sz ▸ i.isLt)
  simpa only [Fin.getElem_fin, Array.getElem?_eq_getElem i.isLt, Option.getD_some] using ok

private theorem step5 (all5 : Good5) (h : Closed words 7 l6) : Closed words 8 l5 := by
  apply prior _ _ _ _ _ h
  intro i
  have sz : l5.size = 29 := by decide +kernel
  have ok := all5 i.val (sz ▸ i.isLt)
  simpa only [Fin.getElem_fin, Array.getElem?_eq_getElem i.isLt, Option.getD_some] using ok

private theorem empty : Closed words 7 l6 := by
  intro i
  have hi := i.isLt
  change i.val < 0 at hi
  omega

private theorem rootEq : decodeNode words l0[0] = (Triples46.tripleSignals 0,Other.initial 0) := by decide +kernel

theorem assemble (g0 : Good0) (g1 : Good1) (g2 : Good2) (g3 : Good3) (g4 : Good4) (g5 : Good5) : ¬ NatRun allMask Table.goal 13 (Triples46.tripleSignals 0) := by
  have closed := step0 g0 (step1 g1 (step2 g2 (step3 g3 (step4 g4 (step5 g5 empty)))))
  have h := closed ⟨0,by decide +kernel⟩
  change PinRules.Invariant allMask Table.goal raw (decodeNode words l0[0]).1 (decodeNode words l0[0]).2 → ¬ NatRun allMask Table.goal 13 (decodeNode words l0[0]).1 at h
  rw [rootEq] at h
  exact h (Other.good 0)

#print axioms assemble
end Petersen120.Mask81.LayerCheck
