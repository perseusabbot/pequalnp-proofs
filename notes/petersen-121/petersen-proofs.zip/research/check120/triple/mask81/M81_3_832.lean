import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_832 : chunk words 9 l3 l4 832 4 = true := by decide +kernel
private theorem c3_836 : chunk words 9 l3 l4 836 4 = true := by decide +kernel
private theorem c3_840 : chunk words 9 l3 l4 840 4 = true := by decide +kernel
private theorem c3_844 : chunk words 9 l3 l4 844 4 = true := by decide +kernel
private theorem c3_848 : chunk words 9 l3 l4 848 4 = true := by decide +kernel
private theorem c3_852 : chunk words 9 l3 l4 852 4 = true := by decide +kernel
private theorem c3_856 : chunk words 9 l3 l4 856 4 = true := by decide +kernel
private theorem c3_860 : chunk words 9 l3 l4 860 4 = true := by decide +kernel
private theorem c3_864 : chunk words 9 l3 l4 864 4 = true := by decide +kernel
private theorem c3_868 : chunk words 9 l3 l4 868 4 = true := by decide +kernel
private theorem c3_872 : chunk words 9 l3 l4 872 4 = true := by decide +kernel
private theorem c3_876 : chunk words 9 l3 l4 876 4 = true := by decide +kernel
private theorem c3_880 : chunk words 9 l3 l4 880 4 = true := by decide +kernel
private theorem c3_884 : chunk words 9 l3 l4 884 4 = true := by decide +kernel
private theorem c3_888 : chunk words 9 l3 l4 888 4 = true := by decide +kernel
private theorem c3_892 : chunk words 9 l3 l4 892 4 = true := by decide +kernel

theorem b3_832 (i : Nat) (lo : 832 ≤ i) (hi : i < 896) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_864 : i < 864
  ·
    by_cases cut3_848 : i < 848
    ·
      by_cases cut3_840 : i < 840
      ·
        by_cases cut3_836 : i < 836
        ·
          exact fromChunk c3_832 (by omega) (by omega)
        ·
          exact fromChunk c3_836 (by omega) (by omega)
      ·
        by_cases cut3_844 : i < 844
        ·
          exact fromChunk c3_840 (by omega) (by omega)
        ·
          exact fromChunk c3_844 (by omega) (by omega)
    ·
      by_cases cut3_856 : i < 856
      ·
        by_cases cut3_852 : i < 852
        ·
          exact fromChunk c3_848 (by omega) (by omega)
        ·
          exact fromChunk c3_852 (by omega) (by omega)
      ·
        by_cases cut3_860 : i < 860
        ·
          exact fromChunk c3_856 (by omega) (by omega)
        ·
          exact fromChunk c3_860 (by omega) (by omega)
  ·
    by_cases cut3_880 : i < 880
    ·
      by_cases cut3_872 : i < 872
      ·
        by_cases cut3_868 : i < 868
        ·
          exact fromChunk c3_864 (by omega) (by omega)
        ·
          exact fromChunk c3_868 (by omega) (by omega)
      ·
        by_cases cut3_876 : i < 876
        ·
          exact fromChunk c3_872 (by omega) (by omega)
        ·
          exact fromChunk c3_876 (by omega) (by omega)
    ·
      by_cases cut3_888 : i < 888
      ·
        by_cases cut3_884 : i < 884
        ·
          exact fromChunk c3_880 (by omega) (by omega)
        ·
          exact fromChunk c3_884 (by omega) (by omega)
      ·
        by_cases cut3_892 : i < 892
        ·
          exact fromChunk c3_888 (by omega) (by omega)
        ·
          exact fromChunk c3_892 (by omega) (by omega)

#print axioms b3_832
end Petersen120.Mask81.LayerCheck
