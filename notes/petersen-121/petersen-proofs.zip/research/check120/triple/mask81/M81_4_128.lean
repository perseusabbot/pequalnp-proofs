import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c4_128 : chunk words 8 l4 l5 128 4 = true := by decide +kernel
private theorem c4_132 : chunk words 8 l4 l5 132 4 = true := by decide +kernel
private theorem c4_136 : chunk words 8 l4 l5 136 4 = true := by decide +kernel
private theorem c4_140 : chunk words 8 l4 l5 140 4 = true := by decide +kernel
private theorem c4_144 : chunk words 8 l4 l5 144 4 = true := by decide +kernel
private theorem c4_148 : chunk words 8 l4 l5 148 4 = true := by decide +kernel
private theorem c4_152 : chunk words 8 l4 l5 152 4 = true := by decide +kernel
private theorem c4_156 : chunk words 8 l4 l5 156 4 = true := by decide +kernel
private theorem c4_160 : chunk words 8 l4 l5 160 4 = true := by decide +kernel
private theorem c4_164 : chunk words 8 l4 l5 164 4 = true := by decide +kernel
private theorem c4_168 : chunk words 8 l4 l5 168 4 = true := by decide +kernel
private theorem c4_172 : chunk words 8 l4 l5 172 4 = true := by decide +kernel
private theorem c4_176 : chunk words 8 l4 l5 176 4 = true := by decide +kernel
private theorem c4_180 : chunk words 8 l4 l5 180 4 = true := by decide +kernel
private theorem c4_184 : chunk words 8 l4 l5 184 4 = true := by decide +kernel
private theorem c4_188 : chunk words 8 l4 l5 188 4 = true := by decide +kernel

theorem b4_128 (i : Nat) (lo : 128 ≤ i) (hi : i < 192) :
    localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_160 : i < 160
  ·
    by_cases cut4_144 : i < 144
    ·
      by_cases cut4_136 : i < 136
      ·
        by_cases cut4_132 : i < 132
        ·
          exact fromChunk c4_128 (by omega) (by omega)
        ·
          exact fromChunk c4_132 (by omega) (by omega)
      ·
        by_cases cut4_140 : i < 140
        ·
          exact fromChunk c4_136 (by omega) (by omega)
        ·
          exact fromChunk c4_140 (by omega) (by omega)
    ·
      by_cases cut4_152 : i < 152
      ·
        by_cases cut4_148 : i < 148
        ·
          exact fromChunk c4_144 (by omega) (by omega)
        ·
          exact fromChunk c4_148 (by omega) (by omega)
      ·
        by_cases cut4_156 : i < 156
        ·
          exact fromChunk c4_152 (by omega) (by omega)
        ·
          exact fromChunk c4_156 (by omega) (by omega)
  ·
    by_cases cut4_176 : i < 176
    ·
      by_cases cut4_168 : i < 168
      ·
        by_cases cut4_164 : i < 164
        ·
          exact fromChunk c4_160 (by omega) (by omega)
        ·
          exact fromChunk c4_164 (by omega) (by omega)
      ·
        by_cases cut4_172 : i < 172
        ·
          exact fromChunk c4_168 (by omega) (by omega)
        ·
          exact fromChunk c4_172 (by omega) (by omega)
    ·
      by_cases cut4_184 : i < 184
      ·
        by_cases cut4_180 : i < 180
        ·
          exact fromChunk c4_176 (by omega) (by omega)
        ·
          exact fromChunk c4_180 (by omega) (by omega)
      ·
        by_cases cut4_188 : i < 188
        ·
          exact fromChunk c4_184 (by omega) (by omega)
        ·
          exact fromChunk c4_188 (by omega) (by omega)

#print axioms b4_128
end Petersen120.Mask81.LayerCheck
