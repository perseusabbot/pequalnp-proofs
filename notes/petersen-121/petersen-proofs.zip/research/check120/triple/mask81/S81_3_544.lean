import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_544 : chunk words 9 l3 l4 544 4 = true := by decide +kernel
private theorem c3_548 : chunk words 9 l3 l4 548 4 = true := by decide +kernel
private theorem c3_552 : chunk words 9 l3 l4 552 4 = true := by decide +kernel
private theorem c3_556 : chunk words 9 l3 l4 556 4 = true := by decide +kernel
theorem s3_544 (i : Nat) (lo : 544 ≤ i) (hi : i < 560) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_552 : i < 552
  ·
    by_cases cut3_548 : i < 548
    ·
      exact fromChunk c3_544 (by omega) (by omega)
    ·
      exact fromChunk c3_548 (by omega) (by omega)
  ·
    by_cases cut3_556 : i < 556
    ·
      exact fromChunk c3_552 (by omega) (by omega)
    ·
      exact fromChunk c3_556 (by omega) (by omega)

#print axioms s3_544
end Petersen120.Mask81.LayerCheck
