import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c2_256 : chunk words 10 l2 l3 256 4 = true := by decide +kernel
private theorem c2_260 : chunk words 10 l2 l3 260 4 = true := by decide +kernel
private theorem c2_264 : chunk words 10 l2 l3 264 4 = true := by decide +kernel
private theorem c2_268 : chunk words 10 l2 l3 268 4 = true := by decide +kernel
private theorem c2_272 : chunk words 10 l2 l3 272 4 = true := by decide +kernel
private theorem c2_276 : chunk words 10 l2 l3 276 4 = true := by decide +kernel
private theorem c2_280 : chunk words 10 l2 l3 280 4 = true := by decide +kernel
private theorem c2_284 : chunk words 10 l2 l3 284 4 = true := by decide +kernel
private theorem c2_288 : chunk words 10 l2 l3 288 4 = true := by decide +kernel
private theorem c2_292 : chunk words 10 l2 l3 292 4 = true := by decide +kernel
private theorem c2_296 : chunk words 10 l2 l3 296 4 = true := by decide +kernel
private theorem c2_300 : chunk words 10 l2 l3 300 4 = true := by decide +kernel
private theorem c2_304 : chunk words 10 l2 l3 304 4 = true := by decide +kernel
private theorem c2_308 : chunk words 10 l2 l3 308 4 = true := by decide +kernel
private theorem c2_312 : chunk words 10 l2 l3 312 4 = true := by decide +kernel
private theorem c2_316 : chunk words 10 l2 l3 316 4 = true := by decide +kernel

theorem b2_256 (i : Nat) (lo : 256 ≤ i) (hi : i < 320) :
    localCheck words 10 (l2[i]?.getD default) l3 = true := by
  by_cases cut2_288 : i < 288
  ·
    by_cases cut2_272 : i < 272
    ·
      by_cases cut2_264 : i < 264
      ·
        by_cases cut2_260 : i < 260
        ·
          exact fromChunk c2_256 (by omega) (by omega)
        ·
          exact fromChunk c2_260 (by omega) (by omega)
      ·
        by_cases cut2_268 : i < 268
        ·
          exact fromChunk c2_264 (by omega) (by omega)
        ·
          exact fromChunk c2_268 (by omega) (by omega)
    ·
      by_cases cut2_280 : i < 280
      ·
        by_cases cut2_276 : i < 276
        ·
          exact fromChunk c2_272 (by omega) (by omega)
        ·
          exact fromChunk c2_276 (by omega) (by omega)
      ·
        by_cases cut2_284 : i < 284
        ·
          exact fromChunk c2_280 (by omega) (by omega)
        ·
          exact fromChunk c2_284 (by omega) (by omega)
  ·
    by_cases cut2_304 : i < 304
    ·
      by_cases cut2_296 : i < 296
      ·
        by_cases cut2_292 : i < 292
        ·
          exact fromChunk c2_288 (by omega) (by omega)
        ·
          exact fromChunk c2_292 (by omega) (by omega)
      ·
        by_cases cut2_300 : i < 300
        ·
          exact fromChunk c2_296 (by omega) (by omega)
        ·
          exact fromChunk c2_300 (by omega) (by omega)
    ·
      by_cases cut2_312 : i < 312
      ·
        by_cases cut2_308 : i < 308
        ·
          exact fromChunk c2_304 (by omega) (by omega)
        ·
          exact fromChunk c2_308 (by omega) (by omega)
      ·
        by_cases cut2_316 : i < 316
        ·
          exact fromChunk c2_312 (by omega) (by omega)
        ·
          exact fromChunk c2_316 (by omega) (by omega)

#print axioms b2_256
end Petersen120.Mask81.LayerCheck
