import MaskCase208
namespace Petersen120.Mask81.LayerCheck
open Petersen120.Triple.Orbit
open PEqualNP.Outside.L_meta_274_aux PEqualNP.Outside.L_meta_3348_aux.FirstWireRun
open Petersen1676 Petersen1676.Table Petersen1676.Triples46
set_option maxRecDepth 10000 in
private theorem inputs : ∀ x : Fin 9 → Bool, Fin.snoc (Fin.snoc x (x 4 || x 6))
    (decide (∃ i : Fin 9, (81 : Nat).testBit i.val = true ∧ x i = true)) = extended 0 x :=
  by decide +kernel

set_option maxRecDepth 10000 in
private theorem targets : ∀ x : Fin 9 → Bool,
    (([1,12,23,34,40,5,16,27,38,57,68,85] : List Nat).any
      (fun e => x (Fin.ofNat 9 (e/10)) && x (Fin.ofNat 9 (e%10)))) = edgeFn x := by decide +kernel

theorem case81 (closed : ¬ NatRun allMask Table.goal 13 (tripleSignals 0)) : Printed [81] := by
  intro m hm D fan promise
  have eq : m = 81 := by simpa only [List.mem_singleton] using hm
  subst m
  by_contra! small
  apply closed (forced 0 D (by omega) fan ?_)
  intro x
  rw [← inputs]
  exact (promise x).trans (targets x)

#print axioms case81
end Petersen120.Mask81.LayerCheck
