import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c4_704 : chunk words 8 l4 l5 704 4 = true := by decide +kernel
private theorem c4_708 : chunk words 8 l4 l5 708 4 = true := by decide +kernel
private theorem c4_712 : chunk words 8 l4 l5 712 4 = true := by decide +kernel
private theorem c4_716 : chunk words 8 l4 l5 716 4 = true := by decide +kernel
private theorem c4_720 : chunk words 8 l4 l5 720 3 = true := by decide +kernel

theorem b4_704 (i : Nat) (lo : 704 ≤ i) (hi : i < 723) :
    localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_712 : i < 712
  ·
    by_cases cut4_708 : i < 708
    ·
      exact fromChunk c4_704 (by omega) (by omega)
    ·
      exact fromChunk c4_708 (by omega) (by omega)
  ·
    by_cases cut4_716 : i < 716
    ·
      exact fromChunk c4_712 (by omega) (by omega)
    ·
      by_cases cut4_720 : i < 720
      ·
        exact fromChunk c4_716 (by omega) (by omega)
      ·
        exact fromChunk c4_720 (by omega) (by omega)

#print axioms b4_704
end Petersen120.Mask81.LayerCheck
