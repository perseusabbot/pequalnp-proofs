import LayerCheck
namespace Petersen120.Mask81.LayerCheck
open PEqualNP.Outside.L_meta_274_aux
open Petersen1676 Petersen1676.Table Petersen1676.PinRules Petersen1676.Prune
open Petersen1676.FastTrial Petersen1676.Cached Petersen1676.Memo

def scan (accept : Choice → Nat → Bool) : List Choice → Nat → Bool
  | [],_ => true
  | c::cs,w => accept c (w % 128) && scan accept cs (w >>> 7)

private theorem hit {accept cs w} (h : scan accept cs w = true) :
    ∀ c ∈ cs, ∃ t, accept c t = true := by
  induction cs generalizing w with
  | nil => simp
  | cons a rest ih =>
    obtain ⟨h1,h2⟩ := Bool.and_eq_true_iff.mp h
    intro c hc
    rcases List.mem_cons.mp hc with rfl|hc
    · exact ⟨_,h1⟩
    · exact ih h2 _ hc

def gateOK (s : Nat) (rr : List Ready) (targets : List Memo.Node) (c : Choice) (t : Nat) : Bool :=
  if t=0 then !(covers kk s c.output)
  else if t≤rr.length then
    (rr[t-1]?).any (fun r => decide (r.margin < 2) && !urgent r c.v c.a c.b (!c.keepA) (c.hasB && !c.keepB))
  else
    (targets[t-rr.length-1]?).any (fun n => n.1 == canonical c.output && n.2 == rr.map (fun r => updated r c.v))

def fastLocal (words : Array Nat) (s : Nat) (r : Entry) (next : Array Entry) (hint : Nat) : Bool :=
  let n := decodeNode words r
  if legal (s+1) n.1 n.2 then
    let rr := n.2.map (prep (s+1) raw n.1)
    scan (gateOK s rr (selected words r next)) (annotated allMask (s+2-n.1.length) n.1) hint
  else localCheck words s r next

theorem witness_ok (words : Array Nat) (s : Nat) (r : Entry) (next : Array Entry) (hint : Nat)
    (checked : fastLocal words s r next hint = true) : localCheck words s r next = true := by
  let n := decodeNode words r
  let rr := n.2.map (prep (s+1) raw n.1)
  let targets := selected words r next
  by_cases parent : legal (s+1) n.1 n.2 = true
  · change (if legal (s+1) n.1 n.2 then scan (gateOK s rr targets) _ hint else _) = true at checked
    rw [if_pos parent] at checked
    change (genExact allMask raw (covers kk) s n.1 n.2).all (fun q => targets.contains q) = true
    rw [genExact,if_pos parent]
    apply List.all_eq_true.2
    intro out ho
    obtain ⟨c,hc,e⟩ := List.mem_filterMap.mp ho
    change (if covers kk s c.output &&
      (rr.filter (fun r => decide (r.margin<2))).all (fun r => urgent r c.v c.a c.b (!c.keepA) (c.hasB && !c.keepB))
      then some (canonical c.output,rr.map (fun r => updated r c.v)) else none) = some out at e
    split at e
    · rename_i passed
      cases e
      obtain ⟨cv,hot⟩ := Bool.and_eq_true_iff.mp passed
      obtain ⟨t,ok⟩ := hit checked c hc
      unfold gateOK at ok
      split at ok
      · simp [cv] at ok
      · split at ok
        · rcases e : rr[t-1]? with _ | k
          · simp [e] at ok
          · simp only [e,Option.any_some,Bool.and_eq_true,Bool.not_eq_true'] at ok
            have mem := List.mem_of_getElem? e
            have eq := List.all_eq_true.mp hot k (List.mem_filter.mpr ⟨mem,ok.1⟩)
            simp [eq] at ok
        · rcases e : targets[t-rr.length-1]? with _ | q
          · simp [e] at ok
          · simp only [e,Option.any_some,Bool.and_eq_true,beq_iff_eq] at ok
            obtain ⟨w,b⟩ := q
            obtain ⟨rfl,rfl⟩ := ok
            exact List.contains_iff_mem.mpr (List.mem_of_getElem? e)
    · cases e
  · simpa [fastLocal,n,parent] using checked

def fastChunk (words : Array Nat) (s : Nat) (cur next : Array Entry) (keys : Array Nat)
    (offset size : Nat) : Bool := (List.range size).all fun j =>
  fastLocal words s (cur[offset+j]?.getD default) next (keys[offset+j]?.getD 0)

theorem fastChunk_ok {words s cur next keys offset size}
    (ok : fastChunk words s cur next keys offset size = true) : chunk words s cur next offset size = true := by
  apply List.all_eq_true.2
  intro j hj
  exact witness_ok _ _ _ _ _ (List.all_eq_true.mp ok j hj)
#print axioms fastChunk_ok
end Petersen120.Mask81.LayerCheck
