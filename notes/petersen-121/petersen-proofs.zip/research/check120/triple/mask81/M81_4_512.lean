import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c4_512 : chunk words 8 l4 l5 512 4 = true := by decide +kernel
private theorem c4_516 : chunk words 8 l4 l5 516 4 = true := by decide +kernel
private theorem c4_520 : chunk words 8 l4 l5 520 4 = true := by decide +kernel
private theorem c4_524 : chunk words 8 l4 l5 524 4 = true := by decide +kernel
private theorem c4_528 : chunk words 8 l4 l5 528 4 = true := by decide +kernel
private theorem c4_532 : chunk words 8 l4 l5 532 4 = true := by decide +kernel
private theorem c4_536 : chunk words 8 l4 l5 536 4 = true := by decide +kernel
private theorem c4_540 : chunk words 8 l4 l5 540 4 = true := by decide +kernel
private theorem c4_544 : chunk words 8 l4 l5 544 4 = true := by decide +kernel
private theorem c4_548 : chunk words 8 l4 l5 548 4 = true := by decide +kernel
private theorem c4_552 : chunk words 8 l4 l5 552 4 = true := by decide +kernel
private theorem c4_556 : chunk words 8 l4 l5 556 4 = true := by decide +kernel
private theorem c4_560 : chunk words 8 l4 l5 560 4 = true := by decide +kernel
private theorem c4_564 : chunk words 8 l4 l5 564 4 = true := by decide +kernel
private theorem c4_568 : chunk words 8 l4 l5 568 4 = true := by decide +kernel
private theorem c4_572 : chunk words 8 l4 l5 572 4 = true := by decide +kernel

theorem b4_512 (i : Nat) (lo : 512 ≤ i) (hi : i < 576) :
    localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_544 : i < 544
  ·
    by_cases cut4_528 : i < 528
    ·
      by_cases cut4_520 : i < 520
      ·
        by_cases cut4_516 : i < 516
        ·
          exact fromChunk c4_512 (by omega) (by omega)
        ·
          exact fromChunk c4_516 (by omega) (by omega)
      ·
        by_cases cut4_524 : i < 524
        ·
          exact fromChunk c4_520 (by omega) (by omega)
        ·
          exact fromChunk c4_524 (by omega) (by omega)
    ·
      by_cases cut4_536 : i < 536
      ·
        by_cases cut4_532 : i < 532
        ·
          exact fromChunk c4_528 (by omega) (by omega)
        ·
          exact fromChunk c4_532 (by omega) (by omega)
      ·
        by_cases cut4_540 : i < 540
        ·
          exact fromChunk c4_536 (by omega) (by omega)
        ·
          exact fromChunk c4_540 (by omega) (by omega)
  ·
    by_cases cut4_560 : i < 560
    ·
      by_cases cut4_552 : i < 552
      ·
        by_cases cut4_548 : i < 548
        ·
          exact fromChunk c4_544 (by omega) (by omega)
        ·
          exact fromChunk c4_548 (by omega) (by omega)
      ·
        by_cases cut4_556 : i < 556
        ·
          exact fromChunk c4_552 (by omega) (by omega)
        ·
          exact fromChunk c4_556 (by omega) (by omega)
    ·
      by_cases cut4_568 : i < 568
      ·
        by_cases cut4_564 : i < 564
        ·
          exact fromChunk c4_560 (by omega) (by omega)
        ·
          exact fromChunk c4_564 (by omega) (by omega)
      ·
        by_cases cut4_572 : i < 572
        ·
          exact fromChunk c4_568 (by omega) (by omega)
        ·
          exact fromChunk c4_572 (by omega) (by omega)

#print axioms b4_512
end Petersen120.Mask81.LayerCheck
