import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c0_0 : chunk words 12 l0 l1 0 1 = true := by decide +kernel

theorem b0_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 1) :
    localCheck words 12 (l0[i]?.getD default) l1 = true := by
  exact fromChunk c0_0 (by omega) (by omega)

#print axioms b0_0
end Petersen120.Mask81.LayerCheck
