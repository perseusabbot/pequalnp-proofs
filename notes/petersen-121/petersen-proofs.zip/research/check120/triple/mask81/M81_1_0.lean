import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c1_0 : chunk words 11 l1 l2 0 4 = true := by decide +kernel
private theorem c1_4 : chunk words 11 l1 l2 4 4 = true := by decide +kernel
private theorem c1_8 : chunk words 11 l1 l2 8 4 = true := by decide +kernel
private theorem c1_12 : chunk words 11 l1 l2 12 4 = true := by decide +kernel
private theorem c1_16 : chunk words 11 l1 l2 16 4 = true := by decide +kernel
private theorem c1_20 : chunk words 11 l1 l2 20 4 = true := by decide +kernel
private theorem c1_24 : chunk words 11 l1 l2 24 4 = true := by decide +kernel
private theorem c1_28 : chunk words 11 l1 l2 28 4 = true := by decide +kernel
private theorem c1_32 : chunk words 11 l1 l2 32 4 = true := by decide +kernel

theorem b1_0 (i : Nat) (lo : 0 ≤ i) (hi : i < 36) :
    localCheck words 11 (l1[i]?.getD default) l2 = true := by
  by_cases cut1_16 : i < 16
  ·
    by_cases cut1_8 : i < 8
    ·
      by_cases cut1_4 : i < 4
      ·
        exact fromChunk c1_0 (by omega) (by omega)
      ·
        exact fromChunk c1_4 (by omega) (by omega)
    ·
      by_cases cut1_12 : i < 12
      ·
        exact fromChunk c1_8 (by omega) (by omega)
      ·
        exact fromChunk c1_12 (by omega) (by omega)
  ·
    by_cases cut1_24 : i < 24
    ·
      by_cases cut1_20 : i < 20
      ·
        exact fromChunk c1_16 (by omega) (by omega)
      ·
        exact fromChunk c1_20 (by omega) (by omega)
    ·
      by_cases cut1_28 : i < 28
      ·
        exact fromChunk c1_24 (by omega) (by omega)
      ·
        by_cases cut1_32 : i < 32
        ·
          exact fromChunk c1_28 (by omega) (by omega)
        ·
          exact fromChunk c1_32 (by omega) (by omega)

#print axioms b1_0
end Petersen120.Mask81.LayerCheck
