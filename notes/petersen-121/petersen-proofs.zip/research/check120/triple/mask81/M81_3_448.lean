import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_448 : chunk words 9 l3 l4 448 4 = true := by decide +kernel
private theorem c3_452 : chunk words 9 l3 l4 452 4 = true := by decide +kernel
private theorem c3_456 : chunk words 9 l3 l4 456 4 = true := by decide +kernel
private theorem c3_460 : chunk words 9 l3 l4 460 4 = true := by decide +kernel
private theorem c3_464 : chunk words 9 l3 l4 464 4 = true := by decide +kernel
private theorem c3_468 : chunk words 9 l3 l4 468 4 = true := by decide +kernel
private theorem c3_472 : chunk words 9 l3 l4 472 4 = true := by decide +kernel
private theorem c3_476 : chunk words 9 l3 l4 476 4 = true := by decide +kernel
private theorem c3_480 : chunk words 9 l3 l4 480 4 = true := by decide +kernel
private theorem c3_484 : chunk words 9 l3 l4 484 4 = true := by decide +kernel
private theorem c3_488 : chunk words 9 l3 l4 488 4 = true := by decide +kernel
private theorem c3_492 : chunk words 9 l3 l4 492 4 = true := by decide +kernel
private theorem c3_496 : chunk words 9 l3 l4 496 4 = true := by decide +kernel
private theorem c3_500 : chunk words 9 l3 l4 500 4 = true := by decide +kernel
private theorem c3_504 : chunk words 9 l3 l4 504 4 = true := by decide +kernel
private theorem c3_508 : chunk words 9 l3 l4 508 4 = true := by decide +kernel

theorem b3_448 (i : Nat) (lo : 448 ≤ i) (hi : i < 512) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_480 : i < 480
  ·
    by_cases cut3_464 : i < 464
    ·
      by_cases cut3_456 : i < 456
      ·
        by_cases cut3_452 : i < 452
        ·
          exact fromChunk c3_448 (by omega) (by omega)
        ·
          exact fromChunk c3_452 (by omega) (by omega)
      ·
        by_cases cut3_460 : i < 460
        ·
          exact fromChunk c3_456 (by omega) (by omega)
        ·
          exact fromChunk c3_460 (by omega) (by omega)
    ·
      by_cases cut3_472 : i < 472
      ·
        by_cases cut3_468 : i < 468
        ·
          exact fromChunk c3_464 (by omega) (by omega)
        ·
          exact fromChunk c3_468 (by omega) (by omega)
      ·
        by_cases cut3_476 : i < 476
        ·
          exact fromChunk c3_472 (by omega) (by omega)
        ·
          exact fromChunk c3_476 (by omega) (by omega)
  ·
    by_cases cut3_496 : i < 496
    ·
      by_cases cut3_488 : i < 488
      ·
        by_cases cut3_484 : i < 484
        ·
          exact fromChunk c3_480 (by omega) (by omega)
        ·
          exact fromChunk c3_484 (by omega) (by omega)
      ·
        by_cases cut3_492 : i < 492
        ·
          exact fromChunk c3_488 (by omega) (by omega)
        ·
          exact fromChunk c3_492 (by omega) (by omega)
    ·
      by_cases cut3_504 : i < 504
      ·
        by_cases cut3_500 : i < 500
        ·
          exact fromChunk c3_496 (by omega) (by omega)
        ·
          exact fromChunk c3_500 (by omega) (by omega)
      ·
        by_cases cut3_508 : i < 508
        ·
          exact fromChunk c3_504 (by omega) (by omega)
        ·
          exact fromChunk c3_508 (by omega) (by omega)

#print axioms b3_448
end Petersen120.Mask81.LayerCheck
