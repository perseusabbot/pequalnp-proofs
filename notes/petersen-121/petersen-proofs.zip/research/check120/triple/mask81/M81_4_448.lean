import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c4_448 : chunk words 8 l4 l5 448 4 = true := by decide +kernel
private theorem c4_452 : chunk words 8 l4 l5 452 4 = true := by decide +kernel
private theorem c4_456 : chunk words 8 l4 l5 456 4 = true := by decide +kernel
private theorem c4_460 : chunk words 8 l4 l5 460 4 = true := by decide +kernel
private theorem c4_464 : chunk words 8 l4 l5 464 4 = true := by decide +kernel
private theorem c4_468 : chunk words 8 l4 l5 468 4 = true := by decide +kernel
private theorem c4_472 : chunk words 8 l4 l5 472 4 = true := by decide +kernel
private theorem c4_476 : chunk words 8 l4 l5 476 4 = true := by decide +kernel
private theorem c4_480 : chunk words 8 l4 l5 480 4 = true := by decide +kernel
private theorem c4_484 : chunk words 8 l4 l5 484 4 = true := by decide +kernel
private theorem c4_488 : chunk words 8 l4 l5 488 4 = true := by decide +kernel
private theorem c4_492 : chunk words 8 l4 l5 492 4 = true := by decide +kernel
private theorem c4_496 : chunk words 8 l4 l5 496 4 = true := by decide +kernel
private theorem c4_500 : chunk words 8 l4 l5 500 4 = true := by decide +kernel
private theorem c4_504 : chunk words 8 l4 l5 504 4 = true := by decide +kernel
private theorem c4_508 : chunk words 8 l4 l5 508 4 = true := by decide +kernel

theorem b4_448 (i : Nat) (lo : 448 ≤ i) (hi : i < 512) :
    localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_480 : i < 480
  ·
    by_cases cut4_464 : i < 464
    ·
      by_cases cut4_456 : i < 456
      ·
        by_cases cut4_452 : i < 452
        ·
          exact fromChunk c4_448 (by omega) (by omega)
        ·
          exact fromChunk c4_452 (by omega) (by omega)
      ·
        by_cases cut4_460 : i < 460
        ·
          exact fromChunk c4_456 (by omega) (by omega)
        ·
          exact fromChunk c4_460 (by omega) (by omega)
    ·
      by_cases cut4_472 : i < 472
      ·
        by_cases cut4_468 : i < 468
        ·
          exact fromChunk c4_464 (by omega) (by omega)
        ·
          exact fromChunk c4_468 (by omega) (by omega)
      ·
        by_cases cut4_476 : i < 476
        ·
          exact fromChunk c4_472 (by omega) (by omega)
        ·
          exact fromChunk c4_476 (by omega) (by omega)
  ·
    by_cases cut4_496 : i < 496
    ·
      by_cases cut4_488 : i < 488
      ·
        by_cases cut4_484 : i < 484
        ·
          exact fromChunk c4_480 (by omega) (by omega)
        ·
          exact fromChunk c4_484 (by omega) (by omega)
      ·
        by_cases cut4_492 : i < 492
        ·
          exact fromChunk c4_488 (by omega) (by omega)
        ·
          exact fromChunk c4_492 (by omega) (by omega)
    ·
      by_cases cut4_504 : i < 504
      ·
        by_cases cut4_500 : i < 500
        ·
          exact fromChunk c4_496 (by omega) (by omega)
        ·
          exact fromChunk c4_500 (by omega) (by omega)
      ·
        by_cases cut4_508 : i < 508
        ·
          exact fromChunk c4_504 (by omega) (by omega)
        ·
          exact fromChunk c4_508 (by omega) (by omega)

#print axioms b4_448
end Petersen120.Mask81.LayerCheck
