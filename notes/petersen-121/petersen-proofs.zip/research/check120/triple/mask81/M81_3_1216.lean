import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_1216 : chunk words 9 l3 l4 1216 4 = true := by decide +kernel
private theorem c3_1220 : chunk words 9 l3 l4 1220 4 = true := by decide +kernel

theorem b3_1216 (i : Nat) (lo : 1216 ≤ i) (hi : i < 1224) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_1220 : i < 1220
  ·
    exact fromChunk c3_1216 (by omega) (by omega)
  ·
    exact fromChunk c3_1220 (by omega) (by omega)

#print axioms b3_1216
end Petersen120.Mask81.LayerCheck
