import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_64 : chunk words 9 l3 l4 64 4 = true := by decide +kernel
private theorem c3_68 : chunk words 9 l3 l4 68 4 = true := by decide +kernel
private theorem c3_72 : chunk words 9 l3 l4 72 4 = true := by decide +kernel
private theorem c3_76 : chunk words 9 l3 l4 76 4 = true := by decide +kernel
private theorem c3_80 : chunk words 9 l3 l4 80 4 = true := by decide +kernel
private theorem c3_84 : chunk words 9 l3 l4 84 4 = true := by decide +kernel
private theorem c3_88 : chunk words 9 l3 l4 88 4 = true := by decide +kernel
private theorem c3_92 : chunk words 9 l3 l4 92 4 = true := by decide +kernel
private theorem c3_96 : chunk words 9 l3 l4 96 4 = true := by decide +kernel
private theorem c3_100 : chunk words 9 l3 l4 100 4 = true := by decide +kernel
private theorem c3_104 : chunk words 9 l3 l4 104 4 = true := by decide +kernel
private theorem c3_108 : chunk words 9 l3 l4 108 4 = true := by decide +kernel
private theorem c3_112 : chunk words 9 l3 l4 112 4 = true := by decide +kernel
private theorem c3_116 : chunk words 9 l3 l4 116 4 = true := by decide +kernel
private theorem c3_120 : chunk words 9 l3 l4 120 4 = true := by decide +kernel
private theorem c3_124 : chunk words 9 l3 l4 124 4 = true := by decide +kernel

theorem b3_64 (i : Nat) (lo : 64 ≤ i) (hi : i < 128) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_96 : i < 96
  ·
    by_cases cut3_80 : i < 80
    ·
      by_cases cut3_72 : i < 72
      ·
        by_cases cut3_68 : i < 68
        ·
          exact fromChunk c3_64 (by omega) (by omega)
        ·
          exact fromChunk c3_68 (by omega) (by omega)
      ·
        by_cases cut3_76 : i < 76
        ·
          exact fromChunk c3_72 (by omega) (by omega)
        ·
          exact fromChunk c3_76 (by omega) (by omega)
    ·
      by_cases cut3_88 : i < 88
      ·
        by_cases cut3_84 : i < 84
        ·
          exact fromChunk c3_80 (by omega) (by omega)
        ·
          exact fromChunk c3_84 (by omega) (by omega)
      ·
        by_cases cut3_92 : i < 92
        ·
          exact fromChunk c3_88 (by omega) (by omega)
        ·
          exact fromChunk c3_92 (by omega) (by omega)
  ·
    by_cases cut3_112 : i < 112
    ·
      by_cases cut3_104 : i < 104
      ·
        by_cases cut3_100 : i < 100
        ·
          exact fromChunk c3_96 (by omega) (by omega)
        ·
          exact fromChunk c3_100 (by omega) (by omega)
      ·
        by_cases cut3_108 : i < 108
        ·
          exact fromChunk c3_104 (by omega) (by omega)
        ·
          exact fromChunk c3_108 (by omega) (by omega)
    ·
      by_cases cut3_120 : i < 120
      ·
        by_cases cut3_116 : i < 116
        ·
          exact fromChunk c3_112 (by omega) (by omega)
        ·
          exact fromChunk c3_116 (by omega) (by omega)
      ·
        by_cases cut3_124 : i < 124
        ·
          exact fromChunk c3_120 (by omega) (by omega)
        ·
          exact fromChunk c3_124 (by omega) (by omega)

#print axioms b3_64
end Petersen120.Mask81.LayerCheck
