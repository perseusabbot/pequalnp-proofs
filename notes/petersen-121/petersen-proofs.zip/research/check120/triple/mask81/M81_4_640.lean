import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c4_640 : chunk words 8 l4 l5 640 4 = true := by decide +kernel
private theorem c4_644 : chunk words 8 l4 l5 644 4 = true := by decide +kernel
private theorem c4_648 : chunk words 8 l4 l5 648 4 = true := by decide +kernel
private theorem c4_652 : chunk words 8 l4 l5 652 4 = true := by decide +kernel
private theorem c4_656 : chunk words 8 l4 l5 656 4 = true := by decide +kernel
private theorem c4_660 : chunk words 8 l4 l5 660 4 = true := by decide +kernel
private theorem c4_664 : chunk words 8 l4 l5 664 4 = true := by decide +kernel
private theorem c4_668 : chunk words 8 l4 l5 668 4 = true := by decide +kernel
private theorem c4_672 : chunk words 8 l4 l5 672 4 = true := by decide +kernel
private theorem c4_676 : chunk words 8 l4 l5 676 4 = true := by decide +kernel
private theorem c4_680 : chunk words 8 l4 l5 680 4 = true := by decide +kernel
private theorem c4_684 : chunk words 8 l4 l5 684 4 = true := by decide +kernel
private theorem c4_688 : chunk words 8 l4 l5 688 4 = true := by decide +kernel
private theorem c4_692 : chunk words 8 l4 l5 692 4 = true := by decide +kernel
private theorem c4_696 : chunk words 8 l4 l5 696 4 = true := by decide +kernel
private theorem c4_700 : chunk words 8 l4 l5 700 4 = true := by decide +kernel

theorem b4_640 (i : Nat) (lo : 640 ≤ i) (hi : i < 704) :
    localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_672 : i < 672
  ·
    by_cases cut4_656 : i < 656
    ·
      by_cases cut4_648 : i < 648
      ·
        by_cases cut4_644 : i < 644
        ·
          exact fromChunk c4_640 (by omega) (by omega)
        ·
          exact fromChunk c4_644 (by omega) (by omega)
      ·
        by_cases cut4_652 : i < 652
        ·
          exact fromChunk c4_648 (by omega) (by omega)
        ·
          exact fromChunk c4_652 (by omega) (by omega)
    ·
      by_cases cut4_664 : i < 664
      ·
        by_cases cut4_660 : i < 660
        ·
          exact fromChunk c4_656 (by omega) (by omega)
        ·
          exact fromChunk c4_660 (by omega) (by omega)
      ·
        by_cases cut4_668 : i < 668
        ·
          exact fromChunk c4_664 (by omega) (by omega)
        ·
          exact fromChunk c4_668 (by omega) (by omega)
  ·
    by_cases cut4_688 : i < 688
    ·
      by_cases cut4_680 : i < 680
      ·
        by_cases cut4_676 : i < 676
        ·
          exact fromChunk c4_672 (by omega) (by omega)
        ·
          exact fromChunk c4_676 (by omega) (by omega)
      ·
        by_cases cut4_684 : i < 684
        ·
          exact fromChunk c4_680 (by omega) (by omega)
        ·
          exact fromChunk c4_684 (by omega) (by omega)
    ·
      by_cases cut4_696 : i < 696
      ·
        by_cases cut4_692 : i < 692
        ·
          exact fromChunk c4_688 (by omega) (by omega)
        ·
          exact fromChunk c4_692 (by omega) (by omega)
      ·
        by_cases cut4_700 : i < 700
        ·
          exact fromChunk c4_696 (by omega) (by omega)
        ·
          exact fromChunk c4_700 (by omega) (by omega)

#print axioms b4_640
end Petersen120.Mask81.LayerCheck
