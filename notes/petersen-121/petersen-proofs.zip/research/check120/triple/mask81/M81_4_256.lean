import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c4_256 : chunk words 8 l4 l5 256 4 = true := by decide +kernel
private theorem c4_260 : chunk words 8 l4 l5 260 4 = true := by decide +kernel
private theorem c4_264 : chunk words 8 l4 l5 264 4 = true := by decide +kernel
private theorem c4_268 : chunk words 8 l4 l5 268 4 = true := by decide +kernel
private theorem c4_272 : chunk words 8 l4 l5 272 4 = true := by decide +kernel
private theorem c4_276 : chunk words 8 l4 l5 276 4 = true := by decide +kernel
private theorem c4_280 : chunk words 8 l4 l5 280 4 = true := by decide +kernel
private theorem c4_284 : chunk words 8 l4 l5 284 4 = true := by decide +kernel
private theorem c4_288 : chunk words 8 l4 l5 288 4 = true := by decide +kernel
private theorem c4_292 : chunk words 8 l4 l5 292 4 = true := by decide +kernel
private theorem c4_296 : chunk words 8 l4 l5 296 4 = true := by decide +kernel
private theorem c4_300 : chunk words 8 l4 l5 300 4 = true := by decide +kernel
private theorem c4_304 : chunk words 8 l4 l5 304 4 = true := by decide +kernel
private theorem c4_308 : chunk words 8 l4 l5 308 4 = true := by decide +kernel
private theorem c4_312 : chunk words 8 l4 l5 312 4 = true := by decide +kernel
private theorem c4_316 : chunk words 8 l4 l5 316 4 = true := by decide +kernel

theorem b4_256 (i : Nat) (lo : 256 ≤ i) (hi : i < 320) :
    localCheck words 8 (l4[i]?.getD default) l5 = true := by
  by_cases cut4_288 : i < 288
  ·
    by_cases cut4_272 : i < 272
    ·
      by_cases cut4_264 : i < 264
      ·
        by_cases cut4_260 : i < 260
        ·
          exact fromChunk c4_256 (by omega) (by omega)
        ·
          exact fromChunk c4_260 (by omega) (by omega)
      ·
        by_cases cut4_268 : i < 268
        ·
          exact fromChunk c4_264 (by omega) (by omega)
        ·
          exact fromChunk c4_268 (by omega) (by omega)
    ·
      by_cases cut4_280 : i < 280
      ·
        by_cases cut4_276 : i < 276
        ·
          exact fromChunk c4_272 (by omega) (by omega)
        ·
          exact fromChunk c4_276 (by omega) (by omega)
      ·
        by_cases cut4_284 : i < 284
        ·
          exact fromChunk c4_280 (by omega) (by omega)
        ·
          exact fromChunk c4_284 (by omega) (by omega)
  ·
    by_cases cut4_304 : i < 304
    ·
      by_cases cut4_296 : i < 296
      ·
        by_cases cut4_292 : i < 292
        ·
          exact fromChunk c4_288 (by omega) (by omega)
        ·
          exact fromChunk c4_292 (by omega) (by omega)
      ·
        by_cases cut4_300 : i < 300
        ·
          exact fromChunk c4_296 (by omega) (by omega)
        ·
          exact fromChunk c4_300 (by omega) (by omega)
    ·
      by_cases cut4_312 : i < 312
      ·
        by_cases cut4_308 : i < 308
        ·
          exact fromChunk c4_304 (by omega) (by omega)
        ·
          exact fromChunk c4_308 (by omega) (by omega)
      ·
        by_cases cut4_316 : i < 316
        ·
          exact fromChunk c4_312 (by omega) (by omega)
        ·
          exact fromChunk c4_316 (by omega) (by omega)

#print axioms b4_256
end Petersen120.Mask81.LayerCheck
