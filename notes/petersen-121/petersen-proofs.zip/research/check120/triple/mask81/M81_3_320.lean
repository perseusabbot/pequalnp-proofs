import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_320 : chunk words 9 l3 l4 320 4 = true := by decide +kernel
private theorem c3_324 : chunk words 9 l3 l4 324 4 = true := by decide +kernel
private theorem c3_328 : chunk words 9 l3 l4 328 4 = true := by decide +kernel
private theorem c3_332 : chunk words 9 l3 l4 332 4 = true := by decide +kernel
private theorem c3_336 : chunk words 9 l3 l4 336 4 = true := by decide +kernel
private theorem c3_340 : chunk words 9 l3 l4 340 4 = true := by decide +kernel
private theorem c3_344 : chunk words 9 l3 l4 344 4 = true := by decide +kernel
private theorem c3_348 : chunk words 9 l3 l4 348 4 = true := by decide +kernel
private theorem c3_352 : chunk words 9 l3 l4 352 4 = true := by decide +kernel
private theorem c3_356 : chunk words 9 l3 l4 356 4 = true := by decide +kernel
private theorem c3_360 : chunk words 9 l3 l4 360 4 = true := by decide +kernel
private theorem c3_364 : chunk words 9 l3 l4 364 4 = true := by decide +kernel
private theorem c3_368 : chunk words 9 l3 l4 368 4 = true := by decide +kernel
private theorem c3_372 : chunk words 9 l3 l4 372 4 = true := by decide +kernel
private theorem c3_376 : chunk words 9 l3 l4 376 4 = true := by decide +kernel
private theorem c3_380 : chunk words 9 l3 l4 380 4 = true := by decide +kernel

theorem b3_320 (i : Nat) (lo : 320 ≤ i) (hi : i < 384) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_352 : i < 352
  ·
    by_cases cut3_336 : i < 336
    ·
      by_cases cut3_328 : i < 328
      ·
        by_cases cut3_324 : i < 324
        ·
          exact fromChunk c3_320 (by omega) (by omega)
        ·
          exact fromChunk c3_324 (by omega) (by omega)
      ·
        by_cases cut3_332 : i < 332
        ·
          exact fromChunk c3_328 (by omega) (by omega)
        ·
          exact fromChunk c3_332 (by omega) (by omega)
    ·
      by_cases cut3_344 : i < 344
      ·
        by_cases cut3_340 : i < 340
        ·
          exact fromChunk c3_336 (by omega) (by omega)
        ·
          exact fromChunk c3_340 (by omega) (by omega)
      ·
        by_cases cut3_348 : i < 348
        ·
          exact fromChunk c3_344 (by omega) (by omega)
        ·
          exact fromChunk c3_348 (by omega) (by omega)
  ·
    by_cases cut3_368 : i < 368
    ·
      by_cases cut3_360 : i < 360
      ·
        by_cases cut3_356 : i < 356
        ·
          exact fromChunk c3_352 (by omega) (by omega)
        ·
          exact fromChunk c3_356 (by omega) (by omega)
      ·
        by_cases cut3_364 : i < 364
        ·
          exact fromChunk c3_360 (by omega) (by omega)
        ·
          exact fromChunk c3_364 (by omega) (by omega)
    ·
      by_cases cut3_376 : i < 376
      ·
        by_cases cut3_372 : i < 372
        ·
          exact fromChunk c3_368 (by omega) (by omega)
        ·
          exact fromChunk c3_372 (by omega) (by omega)
      ·
        by_cases cut3_380 : i < 380
        ·
          exact fromChunk c3_376 (by omega) (by omega)
        ·
          exact fromChunk c3_380 (by omega) (by omega)

#print axioms b3_320
end Petersen120.Mask81.LayerCheck
