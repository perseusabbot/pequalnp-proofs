import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_800 : chunk words 9 l3 l4 800 4 = true := by decide +kernel
private theorem c3_804 : chunk words 9 l3 l4 804 4 = true := by decide +kernel
private theorem c3_808 : chunk words 9 l3 l4 808 4 = true := by decide +kernel
private theorem c3_812 : chunk words 9 l3 l4 812 4 = true := by decide +kernel
theorem s3_800 (i : Nat) (lo : 800 ≤ i) (hi : i < 816) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_808 : i < 808
  ·
    by_cases cut3_804 : i < 804
    ·
      exact fromChunk c3_800 (by omega) (by omega)
    ·
      exact fromChunk c3_804 (by omega) (by omega)
  ·
    by_cases cut3_812 : i < 812
    ·
      exact fromChunk c3_808 (by omega) (by omega)
    ·
      exact fromChunk c3_812 (by omega) (by omega)

#print axioms s3_800
end Petersen120.Mask81.LayerCheck
