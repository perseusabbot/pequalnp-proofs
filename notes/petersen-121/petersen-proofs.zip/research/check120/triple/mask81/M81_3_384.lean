import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_384 : chunk words 9 l3 l4 384 4 = true := by decide +kernel
private theorem c3_388 : chunk words 9 l3 l4 388 4 = true := by decide +kernel
private theorem c3_392 : chunk words 9 l3 l4 392 4 = true := by decide +kernel
private theorem c3_396 : chunk words 9 l3 l4 396 4 = true := by decide +kernel
private theorem c3_400 : chunk words 9 l3 l4 400 4 = true := by decide +kernel
private theorem c3_404 : chunk words 9 l3 l4 404 4 = true := by decide +kernel
private theorem c3_408 : chunk words 9 l3 l4 408 4 = true := by decide +kernel
private theorem c3_412 : chunk words 9 l3 l4 412 4 = true := by decide +kernel
private theorem c3_416 : chunk words 9 l3 l4 416 4 = true := by decide +kernel
private theorem c3_420 : chunk words 9 l3 l4 420 4 = true := by decide +kernel
private theorem c3_424 : chunk words 9 l3 l4 424 4 = true := by decide +kernel
private theorem c3_428 : chunk words 9 l3 l4 428 4 = true := by decide +kernel
private theorem c3_432 : chunk words 9 l3 l4 432 4 = true := by decide +kernel
private theorem c3_436 : chunk words 9 l3 l4 436 4 = true := by decide +kernel
private theorem c3_440 : chunk words 9 l3 l4 440 4 = true := by decide +kernel
private theorem c3_444 : chunk words 9 l3 l4 444 4 = true := by decide +kernel

theorem b3_384 (i : Nat) (lo : 384 ≤ i) (hi : i < 448) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_416 : i < 416
  ·
    by_cases cut3_400 : i < 400
    ·
      by_cases cut3_392 : i < 392
      ·
        by_cases cut3_388 : i < 388
        ·
          exact fromChunk c3_384 (by omega) (by omega)
        ·
          exact fromChunk c3_388 (by omega) (by omega)
      ·
        by_cases cut3_396 : i < 396
        ·
          exact fromChunk c3_392 (by omega) (by omega)
        ·
          exact fromChunk c3_396 (by omega) (by omega)
    ·
      by_cases cut3_408 : i < 408
      ·
        by_cases cut3_404 : i < 404
        ·
          exact fromChunk c3_400 (by omega) (by omega)
        ·
          exact fromChunk c3_404 (by omega) (by omega)
      ·
        by_cases cut3_412 : i < 412
        ·
          exact fromChunk c3_408 (by omega) (by omega)
        ·
          exact fromChunk c3_412 (by omega) (by omega)
  ·
    by_cases cut3_432 : i < 432
    ·
      by_cases cut3_424 : i < 424
      ·
        by_cases cut3_420 : i < 420
        ·
          exact fromChunk c3_416 (by omega) (by omega)
        ·
          exact fromChunk c3_420 (by omega) (by omega)
      ·
        by_cases cut3_428 : i < 428
        ·
          exact fromChunk c3_424 (by omega) (by omega)
        ·
          exact fromChunk c3_428 (by omega) (by omega)
    ·
      by_cases cut3_440 : i < 440
      ·
        by_cases cut3_436 : i < 436
        ·
          exact fromChunk c3_432 (by omega) (by omega)
        ·
          exact fromChunk c3_436 (by omega) (by omega)
      ·
        by_cases cut3_444 : i < 444
        ·
          exact fromChunk c3_440 (by omega) (by omega)
        ·
          exact fromChunk c3_444 (by omega) (by omega)

#print axioms b3_384
end Petersen120.Mask81.LayerCheck
