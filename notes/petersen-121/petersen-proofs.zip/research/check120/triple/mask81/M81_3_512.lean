import S81_3_512
import S81_3_528
import S81_3_544
import S81_3_560

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem b3_512 (i : Nat) (lo : 512 ≤ i) (hi : i < 576) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_544 : i < 544
  ·
    by_cases cut3_528 : i < 528
    ·
      exact s3_512 i (by omega) (by omega)
    ·
      exact s3_528 i (by omega) (by omega)
  ·
    by_cases cut3_560 : i < 560
    ·
      exact s3_544 i (by omega) (by omega)
    ·
      exact s3_560 i (by omega) (by omega)

#print axioms b3_512
end Petersen120.Mask81.LayerCheck
