import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_512 : chunk words 9 l3 l4 512 4 = true := by decide +kernel
private theorem c3_516 : chunk words 9 l3 l4 516 4 = true := by decide +kernel
private theorem c3_520 : chunk words 9 l3 l4 520 4 = true := by decide +kernel
private theorem c3_524 : chunk words 9 l3 l4 524 4 = true := by decide +kernel
theorem s3_512 (i : Nat) (lo : 512 ≤ i) (hi : i < 528) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_520 : i < 520
  ·
    by_cases cut3_516 : i < 516
    ·
      exact fromChunk c3_512 (by omega) (by omega)
    ·
      exact fromChunk c3_516 (by omega) (by omega)
  ·
    by_cases cut3_524 : i < 524
    ·
      exact fromChunk c3_520 (by omega) (by omega)
    ·
      exact fromChunk c3_524 (by omega) (by omega)

#print axioms s3_512
end Petersen120.Mask81.LayerCheck
