import LayersData

namespace Petersen120.Mask81.LayerCheck
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

private theorem c3_768 : chunk words 9 l3 l4 768 4 = true := by decide +kernel
private theorem c3_772 : chunk words 9 l3 l4 772 4 = true := by decide +kernel
private theorem c3_776 : chunk words 9 l3 l4 776 4 = true := by decide +kernel
private theorem c3_780 : chunk words 9 l3 l4 780 4 = true := by decide +kernel
theorem s3_768 (i : Nat) (lo : 768 ≤ i) (hi : i < 784) :
    localCheck words 9 (l3[i]?.getD default) l4 = true := by
  by_cases cut3_776 : i < 776
  ·
    by_cases cut3_772 : i < 772
    ·
      exact fromChunk c3_768 (by omega) (by omega)
    ·
      exact fromChunk c3_772 (by omega) (by omega)
  ·
    by_cases cut3_780 : i < 780
    ·
      exact fromChunk c3_776 (by omega) (by omega)
    ·
      exact fromChunk c3_780 (by omega) (by omega)

#print axioms s3_768
end Petersen120.Mask81.LayerCheck
