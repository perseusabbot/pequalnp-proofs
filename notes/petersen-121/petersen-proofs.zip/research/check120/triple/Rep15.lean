import RepCheck

namespace Petersen120.Triple
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

private theorem check15 : test 15 = false := by decide +kernel

theorem noRep15 : ¬ NatRun allMask Table.goal 12 (starts.getD 15 []) :=
  refute 15 (by decide +kernel) check15

#print axioms noRep15
end Petersen120.Triple
