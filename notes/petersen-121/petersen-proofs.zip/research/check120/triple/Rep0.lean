import RepCheck

namespace Petersen120.Triple
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

private theorem check0 : test 0 = false := by decide +kernel

theorem noRep0 : ¬ NatRun allMask Table.goal 12 (starts.getD 0 []) :=
  refute 0 (by decide +kernel) check0

#print axioms noRep0
end Petersen120.Triple
