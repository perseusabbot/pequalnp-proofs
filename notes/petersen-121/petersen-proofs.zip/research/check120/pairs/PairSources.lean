import Posted46
import PEqualNP.Outside.L_meta_2012

namespace Checkpoint120.Pair
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_274_aux
open PEqualNP.Outside.L_meta_3348_aux.FirstWireRun
open Petersen1676 Petersen1676.Table Petersen1676.Prune Petersen1676.PinRules

set_option maxRecDepth 16000
set_option maxHeartbeats 6000000

def left : Fin 9 → Fin 9 := ![0,0,0,0,0,0,0,2,2]
def right : Fin 9 → Fin 9 := ![1,2,3,5,6,7,8,5,7]
def support : Fin 9 → ℕ := ![3,5,9,33,65,129,257,36,132]
def headA (x : Fin 9 → Bool) := x 4 || x 6
def headB (k : Fin 9) (x : Fin 9 → Bool) := x (left k) || x (right k)
def extended (k : Fin 9) (x : Fin 9 → Bool) : Fin 11 → Bool := Fin.snoc (Fin.snoc x (headA x)) (headB k x)
def signal (k : Fin 9) (i : Fin 11) (x : Fin 9 → Bool) := extended k x i

theorem runInputs (k : Fin 9) (D : Circuit) (ok : FanInTwo D)
    (spec : ∀ x, circuitFun 11 D (extended k x) = edgeFn x) :
    ∃ s ≤ D.size, ∃ I : List (Fin 11), I.Sublist (List.finRange 11) ∧
      Run invF meetF joinF edgeFn s (I.map (signal k)) := by
  let f := circuitFun 11 D
  have nc : ∃ y y', f y ≠ f y' := by
    refine ⟨extended k (fun _ => false), extended k (fun _ => true), ?_⟩
    change circuitFun 11 D _ ≠ circuitFun 11 D _
    rw [spec,spec]; decide
  obtain ⟨s,hs,ws,sub,rr⟩ := exists_run f nc D.size ⟨D,ok,le_rfl,fun _ => rfl⟩
  have rawEq : (List.ofFn fun i : Fin 11 => fun x : Fin 11 → Bool => x i) =
      (List.finRange 11).map (fun i => fun x : Fin 11 → Bool => x i) := by
    simp only [List.finRange,List.map_ofFn,Function.comp_def]
  rw [rawEq] at sub
  obtain ⟨I,hi,rfl⟩ := List.sublist_map_iff.mp sub
  let p : BFn 11 → BFn 9 := fun g x => g (extended k x)
  have r : Run invF meetF joinF (p f) s (((I.map (fun i => fun x : Fin 11 → Bool => x i))).map p) :=
    Run.map p (fun _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl) rr
  have eq : p f = edgeFn := funext spec
  rw [eq,List.map_map] at r
  exact ⟨s,hs,I,hi,r⟩

private theorem base : Built 0 rawSignals := by
  refine ⟨[],?_,by simp,?_⟩
  · intro g hg; cases hg
  · intro f hf
    obtain ⟨i,rfl⟩ := List.mem_ofFn.mp hf
    exact rawHave [] i

private theorem rawMem (i : Fin 9) : (fun x : Fin 9 → Bool => x i) ∈ rawSignals := by
  exact List.mem_ofFn.mpr ⟨i,rfl⟩

private def signals (k : Fin 9) (a b : Bool) :=
  (if b then [headB k] else []) ++ (if a then [headA] else []) ++ rawSignals
private def charge (a b : Bool) : ℕ := a.toNat + b.toNat

private theorem build (k : Fin 9) (a b : Bool) : Built (charge a b) (signals k a b) := by
  have A : Built 1 (headA :: rawSignals) := buildBinary base (rawMem 4) (rawMem 6) false
  have B : Built 1 (headB k :: rawSignals) := buildBinary base (rawMem (left k)) (rawMem (right k)) false
  cases a <;> cases b
  · exact base
  · exact B
  · exact A
  · exact buildBinary A (List.mem_cons_of_mem _ (rawMem (left k)))
      (List.mem_cons_of_mem _ (rawMem (right k))) false

private theorem member (k : Fin 9) (I : List (Fin 11)) (i : Fin 11) (hi : i ∈ I) :
    signal k i ∈ signals k (decide (9 ∈ I)) (decide (10 ∈ I)) := by
  rcases Fin.eq_castSucc_or_eq_last i with ⟨j,rfl⟩ | rfl
  · rcases Fin.eq_castSucc_or_eq_last j with ⟨q,rfl⟩ | rfl
    · have same : signal k q.castSucc.castSucc = (fun x : Fin 9 → Bool => x q) := by
        funext x; simp [signal,extended]
      simp [same,signals,rawMem]
    · have hm : (9 : Fin 11) ∈ I := hi
      have same : signal k (Fin.last 9).castSucc = headA := by funext x; simp only [signal,extended,Fin.snoc_castSucc,Fin.snoc_last]
      rw [same]; simp [signals,hm]
  · have hm : (10 : Fin 11) ∈ I := hi
    have same : signal k (Fin.last 10) = headB k := by funext x; simp only [signal,extended,Fin.snoc_last]
    rw [same]; simp [signals,hm]

/-- Each missing promised OR can be omitted when reconstructing a nine-input circuit. -/
theorem budget {k : Fin 9} {s : ℕ} {I : List (Fin 11)} (run : Run invF meetF joinF edgeFn s (I.map (signal k))) :
    15 ≤ s + (decide ((9 : Fin 11) ∈ I)).toNat + (decide ((10 : Fin 11) ∈ I)).toNat := by
  obtain ⟨gs,ok,le,available⟩ := build k (decide (9 ∈ I)) (decide (10 ∈ I))
  have built : Built (charge (decide (9 ∈ I)) (decide (10 ∈ I))) (I.map (signal k)) := by
    refine ⟨gs,ok,le,?_⟩
    intro f hf
    obtain ⟨i,hi,rfl⟩ := List.mem_map.mp hf
    exact available _ (member k I i hi)
  have nc : ¬Constant (edgeFn ∘ id) := by
    rintro ⟨v,h⟩
    have a := congrFun h (fun _ => false)
    have b := congrFun h (fun _ => true)
    change false = v at a; change true = v at b
    exact Bool.noConfusion (a.trans b.symm)
  have build' : Built (charge (decide (9 ∈ I)) (decide (10 ∈ I))) ((I.map (signal k)).map (fun f => f ∘ id)) := by simpa only [List.map_map,Function.comp_def,id_eq] using built
  obtain ⟨t, ⟨C,legal,size,correct⟩, size'⟩ := runPruneMap id run nc build'
  by_contra! small
  apply Posted46.rawBound PEqualNP.Outside.L_meta_2012
  exact ⟨C, legal, by unfold charge at size'; omega, correct⟩

theorem both {k : Fin 9} {s : ℕ} {I : List (Fin 11)} (cheap : s ≤ 13) (run : Run invF meetF joinF edgeFn s (I.map (signal k))) :
    s = 13 ∧ (9 : Fin 11) ∈ I ∧ (10 : Fin 11) ∈ I := by
  have h := budget run
  by_cases a : (9 : Fin 11) ∈ I <;> by_cases b : (10 : Fin 11) ∈ I <;>
    simp_all [Bool.toNat] <;> omega

#print axioms both
end Checkpoint120.Pair
