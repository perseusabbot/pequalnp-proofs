import ExactInputs
import CachedSearch
import PrintedThree

namespace Checkpoint120.Pair
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_274_aux
open PEqualNP.Outside.L_meta_3348_aux.FirstWireRun
open Petersen1676 Petersen1676.Table Petersen1676.Actual Petersen1676.Search
open Petersen1676.Prune Petersen1676.PinRules
set_option maxRecDepth 16000
set_option maxHeartbeats 6000000

def pairWord (k : Fin 9) := rawWord (left k) ||| rawWord (right k)
def words (k : Fin 9) := (liveIx k).map (fun i => encL (signal k i) Table.rows)
def full (k : Fin 9) := pairWord k :: Table46.start true
def items (k : Fin 9) := advance raw (Table46.start true) (full k) (Table46.initial (Table46.start true))
def test (k : Fin 9) := Cached.search 13 (Memo.root (words k) (items k))

private theorem original (i : Fin 9) : rawWord i ∈ Table46.start true := by
  have h : ∀ v : Fin 9, rawWord v ∈ raw := by decide +kernel
  simp [Table46.start,h]
private theorem subset : ∀ k, ∀ w ∈ words k, w ∈ full k := by decide +kernel

theorem invariant (k : Fin 9) : Invariant allMask Table.goal raw (words k) (items k) := by
  have step : EdgeStep allMask (Table46.start true) (full k) := by
    constructor
    · exact Made.binary (conj := false) (original (left k)) (original (right k))
    · intro w hw
      simpa [full] using hw
  have hs := advance_sound (Actual46.actualStart true) step
  intro item hm
  obtain ⟨d,h⟩ := hs item hm
  refine ⟨d,builtSubset h ?_⟩
  intro f hf
  obtain ⟨w,hw,rfl⟩ := List.mem_map.mp hf
  exact List.mem_map_of_mem (subset k w hw)

private theorem rowGoal : encL edgeFn Table.rows = Table.goal := by decide +kernel
private theorem rowMask : 2^Table.rows.length-1 = allMask := by decide +kernel
theorem liveRun {k : Fin 9} {D : Circuit} (cheap : D.size ≤ 13) (legal : FanInTwo D)
    (spec : ∀ x, circuitFun 11 D (extended k x) = edgeFn x) : NatRun allMask Table.goal 13 (words k) := by
  obtain ⟨_,run⟩ := forced k D cheap legal spec
  have h : NatRun (2^Table.rows.length-1) (encL edgeFn Table.rows) 13
      (((liveIx k).map (signal k)).map (fun f => encL f Table.rows)) :=
    Run.map (fun f => encL f Table.rows) (fun f => encL_inv f Table.rows)
      (fun a b => encL_and a b Table.rows) (fun a b => encL_or a b Table.rows) run
  rwa [rowGoal,rowMask,List.map_map] at h

private theorem identify : ∀ m ∈ ([3,5,9,33,65,129,257,36,132] : List ℕ),
    ∃ k : Fin 9, m = support k := by decide +kernel
private theorem inputsAgree : ∀ k (x : Fin 9 → Bool), Fin.snoc (Fin.snoc x (x 4 || x 6))
    (decide (∃ i : Fin 9, (support k).testBit i.val = true ∧ x i = true)) = extended k x := by decide +kernel
private theorem targetsAgree : ∀ x : Fin 9 → Bool,
    (([1,12,23,34,40,5,16,27,38,57,68,85] : List Nat).any
      (fun e => x (Fin.ofNat 9 (e/10)) && x (Fin.ofNat 9 (e%10)))) = edgeFn x := by decide +kernel

/-- The nine concrete Boolean checks suffice for the entire second-raw-OR child,
including the three cases already closed via the projected eight-input lower bound. -/
theorem nineTests (h : ∀ k, test k = false) :
have x1 : (Fin (9 : ℕ) → Bool) → Bool := fun (x1 : Fin (9 : ℕ) → Bool) => [(1 : ℕ), (12 : ℕ), (23 : ℕ), (34 : ℕ), (40 : ℕ), (5 : ℕ), (16 : ℕ), (27 : ℕ), (38 : ℕ), (57 : ℕ), (68 : ℕ), (85 : ℕ)].any fun (x2 : ℕ) => x1 (Fin.ofNat (9 : ℕ) (x2 / (10 : ℕ))) && x1 (Fin.ofNat (9 : ℕ) (x2 % (10 : ℕ))); ∀ x2 ∈ [(3 : ℕ), (5 : ℕ), (9 : ℕ), (17 : ℕ), (33 : ℕ), (65 : ℕ), (129 : ℕ), (257 : ℕ), (20 : ℕ), (36 : ℕ), (132 : ℕ), (144 : ℕ)], ∀ (x4 : PEqualNP.CircuitLowerBounds.Circuit), PEqualNP.MetaComplexity.FanInTwo x4 → (∀ (x6 : Fin (9 : ℕ) → Bool), PEqualNP.MetaComplexity.circuitFun (11 : ℕ) x4 (Fin.snoc (Fin.snoc x6 (x6 (4 : Fin (9 : ℕ)) || x6 (6 : Fin (9 : ℕ)))) (Decidable.decide (∃ (x7 : Fin (9 : ℕ)), x2.testBit ↑x7 = Bool.true ∧ x6 x7 = Bool.true))) = x1 x6) → (14 : ℕ) ≤ x4.size := by
  apply PEqualNP.Outside.L_meta_3348_aux.ThreeProper.printedNineSuffice
  dsimp only
  intro m hm D legal spec
  obtain ⟨k,rfl⟩ := identify m hm
  by_contra! cheap
  apply Cached.refute (invariant k) (h k)
  apply liveRun (by omega : D.size ≤ 13) legal
  intro x
  rw [← inputsAgree]
  exact (spec x).trans (targetsAgree x)

#print axioms invariant
#print axioms liveRun
#print axioms nineTests
end Checkpoint120.Pair
