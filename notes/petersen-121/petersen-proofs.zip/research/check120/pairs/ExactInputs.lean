import PairSources

namespace Checkpoint120.Pair
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_274_aux
open PEqualNP.Outside.L_meta_3348_aux.FirstWireRun
open Petersen1676 Petersen1676.Table Petersen1676.Prune Petersen1676.PinRules

set_option maxRecDepth 16000
set_option maxHeartbeats 6000000

private def before : Fin 9 → Fin 9 → Nat := ![
  ![2,1,2,4,65,1,18,4,8], ![20,1,9,4,65,1,18,4,8], ![10,1,2,5,65,1,18,4,8],
  ![32,1,2,4,65,1,18,4,8], ![80,1,2,4,65,1,0,4,8], ![130,1,2,4,65,1,18,5,8],
  ![258,1,2,4,65,1,18,4,9], ![2,1,34,4,65,5,18,4,8], ![2,1,128,4,65,1,18,4,8]]
private def rows (k i : Fin 9) := [before k i, before k i ||| (1 <<< i.val)]
private theorem observations : ∀ k i : Fin 9, k ≠ 4 ∨ i ≠ 6 →
    (encL edgeFn (rows k i)).testBit 0 ≠ (encL edgeFn (rows k i)).testBit 1 ∧
    ∀ j : Fin 11, j.val ≠ i.val → (encL (signal k j) (rows k i)).testBit 0 =
      (encL (signal k j) (rows k i)).testBit 1 := by decide +kernel

theorem rawRequired {k s} {I : List (Fin 11)} (run : Run invF meetF joinF edgeFn s (I.map (signal k)))
    (i : Fin 9) (active : k ≠ 4 ∨ i ≠ 6) : i.castSucc.castSucc ∈ I := by
  by_contra missing
  obtain ⟨ne,eq⟩ := observations k i active
  let r := rows k i
  have mapped : NatRun (2^r.length-1) (encL edgeFn r) s
      ((I.map (signal k)).map (fun a => encL a r)) :=
    Run.map (fun f => encL f r) (fun f => encL_inv f r)
      (fun a b => encL_and a b r) (fun a b => encL_or a b r) run
  apply ne
  apply run_bits mapped 0 1 (by change (3 : ℕ).testBit 0 = (3 : ℕ).testBit 1; decide)
  intro w hw
  obtain ⟨f,hf,rfl⟩ := List.mem_map.mp hw
  obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hf
  apply eq j
  intro he
  exact missing ((Fin.ext (a := j) (b := i.castSucc.castSucc) he) ▸ hj)

private def fixSix (x : Fin 8 → Bool) : Fin 9 → Bool := (6 : Fin 9).insertNth false x
private theorem projected : ∀ j : Fin 11,
    (∀ x, signal 4 j (fixSix x) = false) ∨ ∃ i : Fin 8, ∀ x, signal 4 j (fixSix x) = x i := by
  decide +kernel
private theorem unusedAtZero : ∀ x, signal 4 6 (fixSix x) = false := by decide +kernel

/-- Fixing vertex six makes both headers free. The optimal eight-input cofactor uses
the entire budget of thirteen gates, which precludes a live constant source. -/
theorem noSix {s} {I : List (Fin 11)} (cheap : s ≤ 13)
    (run : Run invF meetF joinF edgeFn s (I.map (signal 4))) : (6 : Fin 11) ∉ I := by
  intro mem
  let ws := (I.map (signal 4)).map (fun f => f ∘ fixSix)
  have built : Built 0 ws := by
    refine ⟨[],?_,by simp,?_⟩
    · intro g hg; cases hg
    · intro f hf
      obtain ⟨g,hg,rfl⟩ := List.mem_map.mp hf
      obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hg
      rcases projected j with h | ⟨i,h⟩
      · exact constantHave [] ⟨false, funext h⟩
      · rw [show signal 4 j ∘ fixSix = fun x => x i from funext h]
        exact rawHave [] i
  have nc : ¬Constant (edgeFn ∘ fixSix) := by
    rintro ⟨b,h⟩
    have f := congrFun h (fun _ => false)
    have t := congrFun h (fun _ => true)
    change false = b at f; change true = b at t
    exact Bool.noConfusion (f.trans t.symm)
  obtain ⟨t,proof,le⟩ := runPruneMap fixSix run nc built
  have lo : 13 ≤ t := Actual.allSingleLower 6 t proof
  have hm : (signal 4 6 ∘ fixSix) ∈ ws := List.mem_map_of_mem (List.mem_map_of_mem mem)
  have cost : Prune.charge (signal 4 6 ∘ fixSix) = 1 := by
    have c : Constant (signal 4 6 ∘ fixSix) := ⟨false,funext unusedAtZero⟩
    simp [Prune.charge,c]
  have hm' := List.mem_map_of_mem (f := Prune.charge) hm
  rw [cost] at hm'
  have pos : 1 ≤ count ws := List.single_le_sum (by simp) _ hm'
  change t + count ws ≤ 0+s at le
  omega

def liveIx (k : Fin 9) := (List.finRange 11).filter (fun j => decide (k ≠ 4 ∨ j ≠ 6))

private theorem listShape : ∀ k : Fin 9, ∀ I ∈ (List.finRange 11).sublists,
    (9 : Fin 11) ∈ I → (10 : Fin 11) ∈ I →
    (∀ i : Fin 9, k ≠ 4 ∨ i ≠ 6 → i.castSucc.castSucc ∈ I) →
    (k = 4 → (6 : Fin 11) ∉ I) → I = liveIx k := by
  intro k I hi ha hb raw no
  let ok (j : Fin 11) := decide (k ≠ 4 ∨ j ≠ 6)
  have kept : I.filter ok = I := List.filter_eq_self.mpr (by
    intro j hj
    apply decide_eq_true
    by_cases h : k = 4
    · exact Or.inr (fun eq => no h (eq ▸ hj))
    · exact Or.inl h)
  have sub := (List.mem_sublists.mp hi).filter ok
  rw [kept] at sub
  apply sub.eq_of_length_le
  have nd : (List.finRange 11).Nodup := by decide
  apply (nd.filter ok).length_le_of_subset
  intro j hj
  have active := of_decide_eq_true (List.mem_filter.mp hj).2
  rcases Fin.eq_castSucc_or_eq_last j with ⟨t,rfl⟩ | rfl
  · rcases Fin.eq_castSucc_or_eq_last t with ⟨i,rfl⟩ | rfl
    · apply raw i
      by_cases h : i = 6
      · subst i; exact Or.inl (active.resolve_right (by decide))
      · exact Or.inr h
    · exact ha
  · exact hb

theorem forced (k : Fin 9) (D : Circuit) (cheap : D.size ≤ 13)
    (legal : FanInTwo D) (spec : ∀ x, circuitFun 11 D (extended k x) = edgeFn x) :
    D.size = 13 ∧ Run invF meetF joinF edgeFn 13 ((liveIx k).map (signal k)) := by
  obtain ⟨s,le,I,hi,run⟩ := runInputs k D legal spec
  obtain ⟨rfl,ha,hb⟩ := both (le.trans cheap) run
  obtain rfl := listShape k I (List.mem_sublists.mpr hi) ha hb (rawRequired run)
    (fun h => noSix (by omega) (h ▸ run))
  exact ⟨by omega,run⟩

#print axioms rawRequired
#print axioms noSix
#print axioms forced
end Checkpoint120.Pair
