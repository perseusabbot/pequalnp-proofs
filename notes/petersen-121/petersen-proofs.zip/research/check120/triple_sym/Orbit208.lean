import Orbit46
import OrbitRows208
import TripleStates

namespace Petersen120.Triple.Orbit
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table
open Petersen1676.Orbit46 (select select_xor select_and select_or)

set_option maxRecDepth 48000
set_option maxHeartbeats 0

def state (i : Fin 25) : List Nat := starts.getD i.val []

private theorem maskFixed : ∀ i : Fin 12, select allMask (rowFamily i.val) = allMask := by
  decide +kernel
private theorem goalFixed : ∀ i : Fin 12, select Table.goal (rowFamily i.val) = Table.goal := by
  decide +kernel
private theorem stateFixed : ∀ i : Fin 25,
    Memo.canonical ((state i).map fun w => select w (rowFamily (symmetry i).val)) =
    state (representative i) := by decide +kernel
private theorem listed : ∀ i : Fin 25, (representative i).val ∈ reps := by decide +kernel

/-- A complete run for one of the 25 successor states transports to the
representative specified in the orbit table, with its step count preserved. -/
theorem transport {s : Nat} (i : Fin 25) (run : NatRun allMask Table.goal s (state i)) :
    NatRun allMask Table.goal s (state (representative i)) := by
  let r := rowFamily (symmetry i).val
  have mapped : NatRun allMask (select Table.goal r) s ((state i).map (fun w => select w r)) :=
    Run.map (fun a => select a r) (fun a => by rw [select_xor,maskFixed])
      (fun a b => select_and a b r) (fun a b => select_or a b r) run
  rw [show select Table.goal r = Table.goal from goalFixed _] at mapped
  rw [← stateFixed]
  exact Run.perm (Memo.canonicalPerm _).symm mapped

/-- Five 12-step exclusions suffice for all of the states in the tightened first frontier. -/
theorem allSuccessors
    (closed : ∀ i ∈ reps, ¬ NatRun allMask Table.goal 12 (starts.getD i [])) :
    ∀ w ∈ starts, ¬ NatRun allMask Table.goal 12 w := by
  intro w hw run
  obtain ⟨n,hn,eq⟩ := List.getElem_of_mem hw
  have length : starts.length = 25 := by decide +kernel
  let i : Fin 25 := ⟨n,length ▸ hn⟩
  have hs : state i = w := by
    simpa [state,i,List.getD_eq_getElem?_getD,List.getElem?_eq_getElem hn] using eq
  exact closed _ (listed i) (transport i (hs ▸ run))

end Petersen120.Triple.Orbit

#print axioms Petersen120.Triple.Orbit.allSuccessors
