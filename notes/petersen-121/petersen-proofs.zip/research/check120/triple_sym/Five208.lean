import Orbit208
import TripleExtra

namespace Petersen120.Triple.Orbit
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table Petersen1676.Triples46

/-- Eliminating the five representatives rules out the complete thirteen-gate
run on the raw signals together with the OR of vertices 4, 6 and 7. -/
theorem five (closed : ∀ i ∈ reps, ¬ NatRun allMask Table.goal 12 (starts.getD i [])) :
    ¬ NatRun allMask Table.goal 13 (tripleSignals 2) := by
  intro run
  obtain ⟨w,hw,tail⟩ := descend run
  exact allSuccessors closed w hw tail

end Petersen120.Triple.Orbit

#print axioms Petersen120.Triple.Orbit.five
