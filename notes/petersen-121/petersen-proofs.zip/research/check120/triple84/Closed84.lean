import Stage84D0
import Link84

namespace Petersen120.Triple84
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table Petersen1676.Triples46

theorem allClosed : ∀ i ∈ reps, ¬ NatRun allMask Table.goal 12 (starts.getD i []) :=
  LayerData.most LayerData.stage0

theorem no84 : ¬ NatRun allMask Table.goal 13 (tripleSignals 1) := by
  intro run
  obtain ⟨w,hw,tail⟩ := descend run
  exact allSuccessors allClosed w hw tail

end Petersen120.Triple84
#print axioms Petersen120.Triple84.no84
