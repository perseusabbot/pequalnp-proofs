import TripleStates
import Orbit208

namespace Petersen120.Triple84
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table Petersen1676.Triples46
open Petersen1676.Orbit46 (select select_xor select_and select_or)

def descs : List Petersen120.Triple.Desc := [
  (2, 8, 8, 256),
  (2, 9, 9, 512),
  (2, 7, 7, 128),
  (2, 1, 1, 2),
  (1, 0, 2, 0),
  (1, 2, 3, 0),
  (0, 5, 9, 0),
  (0, 5, 9, 512),
  (1, 0, 5, 0),
  (1, 2, 5, 0),
  (1, 3, 5, 0),
  (2, 5, 5, 0),
  (1, 0, 1, 0),
  (1, 1, 2, 0),
  (1, 0, 7, 0),
  (1, 1, 7, 0),
  (1, 1, 3, 0),
  (1, 3, 7, 0),
  (1, 1, 5, 0),
  (1, 5, 7, 0),
  (1, 3, 8, 0),
  (1, 0, 8, 0),
  (1, 2, 8, 0),
  (1, 5, 8, 0),
  (1, 7, 8, 0),
  (1, 1, 9, 512),
  (1, 0, 9, 512),
  (1, 7, 9, 512),
  (1, 3, 9, 512),
  (1, 5, 9, 512),
  (1, 8, 9, 512),
  (1, 1, 4, 16),
  (1, 3, 6, 64),
  (2, 5, 5, 32),
  (2, 3, 3, 8),
  (2, 2, 2, 4),
  (2, 0, 0, 1)]
def word (i : Nat) := (tripleSignals 1).getD i 0
def emitted (d : Petersen120.Triple.Desc) :=
  let (op,a,b,_) := d
  if op = 2 then word a ^^^ allMask else if op = 1 then word a ||| word b else word a &&& word b
def intermediate (d : Petersen120.Triple.Desc) : List Nat :=
  emitted d :: (((List.range 10).filter (fun i => !(d.2.2.2.testBit i))).map word)
def starts := descs.map (fun d => Memo.canonical (intermediate d))

def reps : List Nat := [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,19,21,25,26,27,29,31,33,35]
def representative (i : Fin 37) : Fin 37 := ([0,1,2,3,4,5,6,7,8,9,10,11,12,5,14,15,16,15,10,19,12,21,4,8,14,25,26,27,25,29,26,31,31,33,3,35,0] : List (Fin 37)).getD i.val 0
def symmetry (i : Fin 37) : Fin 2 := ([0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,1,0,1,1,1,0,0,0,1,0,1,0,1,0,1,0,1] : List (Fin 2)).getD i.val 0
def relativeSymmetry (j : Fin 2) := ([0,10] : List Nat).getD j.val 0
def state (i : Fin 37) := starts.getD i.val []

set_option maxRecDepth 48000
set_option maxHeartbeats 0

def rows (j : Fin 2) := Petersen120.Triple.Orbit.rowFamily (relativeSymmetry j)

private theorem maskFixed : ∀ j : Fin 2, select allMask (rows j) = allMask := by decide +kernel
private theorem goalFixed : ∀ j : Fin 2, select Table.goal (rows j) = Table.goal := by decide +kernel
private theorem stateFixed : ∀ i : Fin 37,
    Memo.canonical ((state i).map (fun a => select a (rows (symmetry i)))) = state (representative i) := by
  decide +kernel
private theorem listed : ∀ i : Fin 37, (representative i).val ∈ reps := by decide +kernel

theorem transport {s : Nat} (i : Fin 37) (run : NatRun allMask Table.goal s (state i)) :
    NatRun allMask Table.goal s (state (representative i)) := by
  let r := rows (symmetry i)
  have mapped : NatRun allMask (select Table.goal r) s ((state i).map (fun w => select w r)) :=
    Run.map (fun a => select a r) (fun a => by rw [select_xor,maskFixed])
      (fun a b => select_and a b r) (fun a b => select_or a b r) run
  rw [show select Table.goal r = Table.goal from goalFixed _] at mapped
  rw [← stateFixed]
  exact Run.perm (Memo.canonicalPerm _).symm mapped

theorem allSuccessors
    (closed : ∀ i ∈ reps, ¬ NatRun allMask Table.goal 12 (starts.getD i [])) :
    ∀ w ∈ starts, ¬ NatRun allMask Table.goal 12 w := by
  intro w hw run
  obtain ⟨n,hn,eq⟩ := List.getElem_of_mem hw
  have length : starts.length = 37 := by decide +kernel
  let i : Fin 37 := ⟨n,length ▸ hn⟩
  have hs : state i = w := by
    simpa [state,i,List.getD_eq_getElem?_getD,List.getElem?_eq_getElem hn] using eq
  exact closed _ (listed i) (transport i (hs ▸ run))

end Petersen120.Triple84

#print axioms Petersen120.Triple84.allSuccessors
