import Mask84D1S0
import Mask84D1S30
import Mask84D1S60
import Mask84D1S90
import Mask84D1S120
import Mask84D1S150
import Mask84D1S180
import Mask84D1S210
import Mask84D1S240
import Mask84D1S270
import Stage84D2

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem stage1 : Closed words 11 l1 := by
  apply prior words 10 l1 l2 _ stage2
  intro i
  have bound : i.val < 296 := i.isLt
  by_cases upper : i.val < 3
  · exact ofChunk i pass1_0 (by omega) upper
  have ge3 : 3 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 6
  · exact ofChunk i pass1_3 (by omega) upper
  have ge6 : 6 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 9
  · exact ofChunk i pass1_6 (by omega) upper
  have ge9 : 9 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 12
  · exact ofChunk i pass1_9 (by omega) upper
  have ge12 : 12 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 15
  · exact ofChunk i pass1_12 (by omega) upper
  have ge15 : 15 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 18
  · exact ofChunk i pass1_15 (by omega) upper
  have ge18 : 18 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 21
  · exact ofChunk i pass1_18 (by omega) upper
  have ge21 : 21 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 24
  · exact ofChunk i pass1_21 (by omega) upper
  have ge24 : 24 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 27
  · exact ofChunk i pass1_24 (by omega) upper
  have ge27 : 27 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 30
  · exact ofChunk i pass1_27 (by omega) upper
  have ge30 : 30 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 33
  · exact ofChunk i pass1_30 (by omega) upper
  have ge33 : 33 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 36
  · exact ofChunk i pass1_33 (by omega) upper
  have ge36 : 36 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 39
  · exact ofChunk i pass1_36 (by omega) upper
  have ge39 : 39 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 42
  · exact ofChunk i pass1_39 (by omega) upper
  have ge42 : 42 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 45
  · exact ofChunk i pass1_42 (by omega) upper
  have ge45 : 45 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 48
  · exact ofChunk i pass1_45 (by omega) upper
  have ge48 : 48 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 51
  · exact ofChunk i pass1_48 (by omega) upper
  have ge51 : 51 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 54
  · exact ofChunk i pass1_51 (by omega) upper
  have ge54 : 54 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 57
  · exact ofChunk i pass1_54 (by omega) upper
  have ge57 : 57 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 60
  · exact ofChunk i pass1_57 (by omega) upper
  have ge60 : 60 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 63
  · exact ofChunk i pass1_60 (by omega) upper
  have ge63 : 63 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 66
  · exact ofChunk i pass1_63 (by omega) upper
  have ge66 : 66 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 69
  · exact ofChunk i pass1_66 (by omega) upper
  have ge69 : 69 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 72
  · exact ofChunk i pass1_69 (by omega) upper
  have ge72 : 72 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 75
  · exact ofChunk i pass1_72 (by omega) upper
  have ge75 : 75 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 78
  · exact ofChunk i pass1_75 (by omega) upper
  have ge78 : 78 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 81
  · exact ofChunk i pass1_78 (by omega) upper
  have ge81 : 81 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 84
  · exact ofChunk i pass1_81 (by omega) upper
  have ge84 : 84 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 87
  · exact ofChunk i pass1_84 (by omega) upper
  have ge87 : 87 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 90
  · exact ofChunk i pass1_87 (by omega) upper
  have ge90 : 90 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 93
  · exact ofChunk i pass1_90 (by omega) upper
  have ge93 : 93 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 96
  · exact ofChunk i pass1_93 (by omega) upper
  have ge96 : 96 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 99
  · exact ofChunk i pass1_96 (by omega) upper
  have ge99 : 99 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 102
  · exact ofChunk i pass1_99 (by omega) upper
  have ge102 : 102 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 105
  · exact ofChunk i pass1_102 (by omega) upper
  have ge105 : 105 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 108
  · exact ofChunk i pass1_105 (by omega) upper
  have ge108 : 108 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 111
  · exact ofChunk i pass1_108 (by omega) upper
  have ge111 : 111 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 114
  · exact ofChunk i pass1_111 (by omega) upper
  have ge114 : 114 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 117
  · exact ofChunk i pass1_114 (by omega) upper
  have ge117 : 117 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 120
  · exact ofChunk i pass1_117 (by omega) upper
  have ge120 : 120 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 123
  · exact ofChunk i pass1_120 (by omega) upper
  have ge123 : 123 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 126
  · exact ofChunk i pass1_123 (by omega) upper
  have ge126 : 126 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 129
  · exact ofChunk i pass1_126 (by omega) upper
  have ge129 : 129 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 132
  · exact ofChunk i pass1_129 (by omega) upper
  have ge132 : 132 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 135
  · exact ofChunk i pass1_132 (by omega) upper
  have ge135 : 135 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 138
  · exact ofChunk i pass1_135 (by omega) upper
  have ge138 : 138 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 141
  · exact ofChunk i pass1_138 (by omega) upper
  have ge141 : 141 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 144
  · exact ofChunk i pass1_141 (by omega) upper
  have ge144 : 144 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 147
  · exact ofChunk i pass1_144 (by omega) upper
  have ge147 : 147 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 150
  · exact ofChunk i pass1_147 (by omega) upper
  have ge150 : 150 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 153
  · exact ofChunk i pass1_150 (by omega) upper
  have ge153 : 153 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 156
  · exact ofChunk i pass1_153 (by omega) upper
  have ge156 : 156 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 159
  · exact ofChunk i pass1_156 (by omega) upper
  have ge159 : 159 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 162
  · exact ofChunk i pass1_159 (by omega) upper
  have ge162 : 162 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 165
  · exact ofChunk i pass1_162 (by omega) upper
  have ge165 : 165 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 168
  · exact ofChunk i pass1_165 (by omega) upper
  have ge168 : 168 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 171
  · exact ofChunk i pass1_168 (by omega) upper
  have ge171 : 171 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 174
  · exact ofChunk i pass1_171 (by omega) upper
  have ge174 : 174 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 177
  · exact ofChunk i pass1_174 (by omega) upper
  have ge177 : 177 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 180
  · exact ofChunk i pass1_177 (by omega) upper
  have ge180 : 180 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 183
  · exact ofChunk i pass1_180 (by omega) upper
  have ge183 : 183 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 186
  · exact ofChunk i pass1_183 (by omega) upper
  have ge186 : 186 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 189
  · exact ofChunk i pass1_186 (by omega) upper
  have ge189 : 189 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 192
  · exact ofChunk i pass1_189 (by omega) upper
  have ge192 : 192 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 195
  · exact ofChunk i pass1_192 (by omega) upper
  have ge195 : 195 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 198
  · exact ofChunk i pass1_195 (by omega) upper
  have ge198 : 198 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 201
  · exact ofChunk i pass1_198 (by omega) upper
  have ge201 : 201 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 204
  · exact ofChunk i pass1_201 (by omega) upper
  have ge204 : 204 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 207
  · exact ofChunk i pass1_204 (by omega) upper
  have ge207 : 207 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 210
  · exact ofChunk i pass1_207 (by omega) upper
  have ge210 : 210 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 213
  · exact ofChunk i pass1_210 (by omega) upper
  have ge213 : 213 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 216
  · exact ofChunk i pass1_213 (by omega) upper
  have ge216 : 216 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 219
  · exact ofChunk i pass1_216 (by omega) upper
  have ge219 : 219 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 222
  · exact ofChunk i pass1_219 (by omega) upper
  have ge222 : 222 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 225
  · exact ofChunk i pass1_222 (by omega) upper
  have ge225 : 225 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 228
  · exact ofChunk i pass1_225 (by omega) upper
  have ge228 : 228 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 231
  · exact ofChunk i pass1_228 (by omega) upper
  have ge231 : 231 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 234
  · exact ofChunk i pass1_231 (by omega) upper
  have ge234 : 234 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 237
  · exact ofChunk i pass1_234 (by omega) upper
  have ge237 : 237 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 240
  · exact ofChunk i pass1_237 (by omega) upper
  have ge240 : 240 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 243
  · exact ofChunk i pass1_240 (by omega) upper
  have ge243 : 243 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 246
  · exact ofChunk i pass1_243 (by omega) upper
  have ge246 : 246 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 249
  · exact ofChunk i pass1_246 (by omega) upper
  have ge249 : 249 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 252
  · exact ofChunk i pass1_249 (by omega) upper
  have ge252 : 252 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 255
  · exact ofChunk i pass1_252 (by omega) upper
  have ge255 : 255 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 258
  · exact ofChunk i pass1_255 (by omega) upper
  have ge258 : 258 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 261
  · exact ofChunk i pass1_258 (by omega) upper
  have ge261 : 261 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 264
  · exact ofChunk i pass1_261 (by omega) upper
  have ge264 : 264 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 267
  · exact ofChunk i pass1_264 (by omega) upper
  have ge267 : 267 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 270
  · exact ofChunk i pass1_267 (by omega) upper
  have ge270 : 270 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 273
  · exact ofChunk i pass1_270 (by omega) upper
  have ge273 : 273 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 276
  · exact ofChunk i pass1_273 (by omega) upper
  have ge276 : 276 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 279
  · exact ofChunk i pass1_276 (by omega) upper
  have ge279 : 279 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 282
  · exact ofChunk i pass1_279 (by omega) upper
  have ge282 : 282 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 285
  · exact ofChunk i pass1_282 (by omega) upper
  have ge285 : 285 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 288
  · exact ofChunk i pass1_285 (by omega) upper
  have ge288 : 288 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 291
  · exact ofChunk i pass1_288 (by omega) upper
  have ge291 : 291 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 294
  · exact ofChunk i pass1_291 (by omega) upper
  have ge294 : 294 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  exact ofChunk i pass1_294 (by omega) bound
#print axioms stage1
end Petersen120.Triple84.LayerData
