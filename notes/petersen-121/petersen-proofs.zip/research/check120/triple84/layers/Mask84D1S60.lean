import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass1_60 : chunk words 10 l1 l2 60 3 = true := by decide +kernel
theorem pass1_63 : chunk words 10 l1 l2 63 3 = true := by decide +kernel
theorem pass1_66 : chunk words 10 l1 l2 66 3 = true := by decide +kernel
theorem pass1_69 : chunk words 10 l1 l2 69 3 = true := by decide +kernel
theorem pass1_72 : chunk words 10 l1 l2 72 3 = true := by decide +kernel
theorem pass1_75 : chunk words 10 l1 l2 75 3 = true := by decide +kernel
theorem pass1_78 : chunk words 10 l1 l2 78 3 = true := by decide +kernel
theorem pass1_81 : chunk words 10 l1 l2 81 3 = true := by decide +kernel
theorem pass1_84 : chunk words 10 l1 l2 84 3 = true := by decide +kernel
theorem pass1_87 : chunk words 10 l1 l2 87 3 = true := by decide +kernel
#print axioms pass1_60
end Petersen120.Triple84.LayerData
