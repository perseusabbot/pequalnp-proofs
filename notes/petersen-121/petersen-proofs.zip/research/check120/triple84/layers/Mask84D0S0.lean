import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass0_0 : chunk words 11 l0 l1 0 2 = true := by decide +kernel
theorem pass0_2 : chunk words 11 l0 l1 2 2 = true := by decide +kernel
theorem pass0_4 : chunk words 11 l0 l1 4 2 = true := by decide +kernel
theorem pass0_6 : chunk words 11 l0 l1 6 2 = true := by decide +kernel
theorem pass0_8 : chunk words 11 l0 l1 8 2 = true := by decide +kernel
theorem pass0_10 : chunk words 11 l0 l1 10 2 = true := by decide +kernel
theorem pass0_12 : chunk words 11 l0 l1 12 2 = true := by decide +kernel
theorem pass0_14 : chunk words 11 l0 l1 14 2 = true := by decide +kernel
theorem pass0_16 : chunk words 11 l0 l1 16 1 = true := by decide +kernel
#print axioms pass0_0
end Petersen120.Triple84.LayerData
