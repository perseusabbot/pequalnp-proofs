import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass1_240 : chunk words 10 l1 l2 240 3 = true := by decide +kernel
theorem pass1_243 : chunk words 10 l1 l2 243 3 = true := by decide +kernel
theorem pass1_246 : chunk words 10 l1 l2 246 3 = true := by decide +kernel
theorem pass1_249 : chunk words 10 l1 l2 249 3 = true := by decide +kernel
theorem pass1_252 : chunk words 10 l1 l2 252 3 = true := by decide +kernel
theorem pass1_255 : chunk words 10 l1 l2 255 3 = true := by decide +kernel
theorem pass1_258 : chunk words 10 l1 l2 258 3 = true := by decide +kernel
theorem pass1_261 : chunk words 10 l1 l2 261 3 = true := by decide +kernel
theorem pass1_264 : chunk words 10 l1 l2 264 3 = true := by decide +kernel
theorem pass1_267 : chunk words 10 l1 l2 267 3 = true := by decide +kernel
#print axioms pass1_240
end Petersen120.Triple84.LayerData
