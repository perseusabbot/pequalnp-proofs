import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass1_150 : chunk words 10 l1 l2 150 3 = true := by decide +kernel
theorem pass1_153 : chunk words 10 l1 l2 153 3 = true := by decide +kernel
theorem pass1_156 : chunk words 10 l1 l2 156 3 = true := by decide +kernel
theorem pass1_159 : chunk words 10 l1 l2 159 3 = true := by decide +kernel
theorem pass1_162 : chunk words 10 l1 l2 162 3 = true := by decide +kernel
theorem pass1_165 : chunk words 10 l1 l2 165 3 = true := by decide +kernel
theorem pass1_168 : chunk words 10 l1 l2 168 3 = true := by decide +kernel
theorem pass1_171 : chunk words 10 l1 l2 171 3 = true := by decide +kernel
theorem pass1_174 : chunk words 10 l1 l2 174 3 = true := by decide +kernel
theorem pass1_177 : chunk words 10 l1 l2 177 3 = true := by decide +kernel
#print axioms pass1_150
end Petersen120.Triple84.LayerData
