import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass1_120 : chunk words 10 l1 l2 120 3 = true := by decide +kernel
theorem pass1_123 : chunk words 10 l1 l2 123 3 = true := by decide +kernel
theorem pass1_126 : chunk words 10 l1 l2 126 3 = true := by decide +kernel
theorem pass1_129 : chunk words 10 l1 l2 129 3 = true := by decide +kernel
theorem pass1_132 : chunk words 10 l1 l2 132 3 = true := by decide +kernel
theorem pass1_135 : chunk words 10 l1 l2 135 3 = true := by decide +kernel
theorem pass1_138 : chunk words 10 l1 l2 138 3 = true := by decide +kernel
theorem pass1_141 : chunk words 10 l1 l2 141 3 = true := by decide +kernel
theorem pass1_144 : chunk words 10 l1 l2 144 3 = true := by decide +kernel
theorem pass1_147 : chunk words 10 l1 l2 147 3 = true := by decide +kernel
#print axioms pass1_120
end Petersen120.Triple84.LayerData
