import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_0 : chunk words 9 l2 l3 0 5 = true := by decide +kernel
theorem pass2_5 : chunk words 9 l2 l3 5 5 = true := by decide +kernel
theorem pass2_10 : chunk words 9 l2 l3 10 5 = true := by decide +kernel
theorem pass2_15 : chunk words 9 l2 l3 15 5 = true := by decide +kernel
theorem pass2_20 : chunk words 9 l2 l3 20 5 = true := by decide +kernel
theorem pass2_25 : chunk words 9 l2 l3 25 5 = true := by decide +kernel
theorem pass2_30 : chunk words 9 l2 l3 30 5 = true := by decide +kernel
theorem pass2_35 : chunk words 9 l2 l3 35 5 = true := by decide +kernel
theorem pass2_40 : chunk words 9 l2 l3 40 5 = true := by decide +kernel
theorem pass2_45 : chunk words 9 l2 l3 45 5 = true := by decide +kernel
#print axioms pass2_0
end Petersen120.Triple84.LayerData
