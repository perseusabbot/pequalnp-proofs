import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_150 : chunk words 9 l2 l3 150 5 = true := by decide +kernel
theorem pass2_155 : chunk words 9 l2 l3 155 5 = true := by decide +kernel
theorem pass2_160 : chunk words 9 l2 l3 160 5 = true := by decide +kernel
theorem pass2_165 : chunk words 9 l2 l3 165 5 = true := by decide +kernel
theorem pass2_170 : chunk words 9 l2 l3 170 5 = true := by decide +kernel
theorem pass2_175 : chunk words 9 l2 l3 175 5 = true := by decide +kernel
theorem pass2_180 : chunk words 9 l2 l3 180 5 = true := by decide +kernel
theorem pass2_185 : chunk words 9 l2 l3 185 5 = true := by decide +kernel
theorem pass2_190 : chunk words 9 l2 l3 190 5 = true := by decide +kernel
theorem pass2_195 : chunk words 9 l2 l3 195 5 = true := by decide +kernel
#print axioms pass2_150
end Petersen120.Triple84.LayerData
