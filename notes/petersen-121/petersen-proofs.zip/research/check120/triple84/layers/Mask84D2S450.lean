import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_450 : chunk words 9 l2 l3 450 5 = true := by decide +kernel
theorem pass2_455 : chunk words 9 l2 l3 455 5 = true := by decide +kernel
theorem pass2_460 : chunk words 9 l2 l3 460 5 = true := by decide +kernel
theorem pass2_465 : chunk words 9 l2 l3 465 5 = true := by decide +kernel
theorem pass2_470 : chunk words 9 l2 l3 470 5 = true := by decide +kernel
theorem pass2_475 : chunk words 9 l2 l3 475 5 = true := by decide +kernel
theorem pass2_480 : chunk words 9 l2 l3 480 5 = true := by decide +kernel
theorem pass2_485 : chunk words 9 l2 l3 485 5 = true := by decide +kernel
theorem pass2_490 : chunk words 9 l2 l3 490 5 = true := by decide +kernel
theorem pass2_495 : chunk words 9 l2 l3 495 5 = true := by decide +kernel
#print axioms pass2_450
end Petersen120.Triple84.LayerData
