import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_100 : chunk words 9 l2 l3 100 5 = true := by decide +kernel
theorem pass2_105 : chunk words 9 l2 l3 105 5 = true := by decide +kernel
theorem pass2_110 : chunk words 9 l2 l3 110 5 = true := by decide +kernel
theorem pass2_115 : chunk words 9 l2 l3 115 5 = true := by decide +kernel
theorem pass2_120 : chunk words 9 l2 l3 120 5 = true := by decide +kernel
theorem pass2_125 : chunk words 9 l2 l3 125 5 = true := by decide +kernel
theorem pass2_130 : chunk words 9 l2 l3 130 5 = true := by decide +kernel
theorem pass2_135 : chunk words 9 l2 l3 135 5 = true := by decide +kernel
theorem pass2_140 : chunk words 9 l2 l3 140 5 = true := by decide +kernel
theorem pass2_145 : chunk words 9 l2 l3 145 5 = true := by decide +kernel
#print axioms pass2_100
end Petersen120.Triple84.LayerData
