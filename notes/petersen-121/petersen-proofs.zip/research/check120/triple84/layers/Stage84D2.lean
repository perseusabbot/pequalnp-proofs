import Mask84D2S0
import Mask84D2S50
import Mask84D2S100
import Mask84D2S150
import Mask84D2S200
import Mask84D2S250
import Mask84D2S300
import Mask84D2S350
import Mask84D2S400
import Mask84D2S450
import Mask84D2S500
import Mask84D2S550
import Mask84D2S600
import Stage84D3

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem stage2 : Closed words 10 l2 := by
  apply prior words 9 l2 l3 _ stage3
  intro i
  have bound : i.val < 612 := i.isLt
  by_cases upper : i.val < 5
  · exact ofChunk i pass2_0 (by omega) upper
  have ge5 : 5 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 10
  · exact ofChunk i pass2_5 (by omega) upper
  have ge10 : 10 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 15
  · exact ofChunk i pass2_10 (by omega) upper
  have ge15 : 15 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 20
  · exact ofChunk i pass2_15 (by omega) upper
  have ge20 : 20 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 25
  · exact ofChunk i pass2_20 (by omega) upper
  have ge25 : 25 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 30
  · exact ofChunk i pass2_25 (by omega) upper
  have ge30 : 30 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 35
  · exact ofChunk i pass2_30 (by omega) upper
  have ge35 : 35 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 40
  · exact ofChunk i pass2_35 (by omega) upper
  have ge40 : 40 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 45
  · exact ofChunk i pass2_40 (by omega) upper
  have ge45 : 45 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 50
  · exact ofChunk i pass2_45 (by omega) upper
  have ge50 : 50 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 55
  · exact ofChunk i pass2_50 (by omega) upper
  have ge55 : 55 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 60
  · exact ofChunk i pass2_55 (by omega) upper
  have ge60 : 60 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 65
  · exact ofChunk i pass2_60 (by omega) upper
  have ge65 : 65 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 70
  · exact ofChunk i pass2_65 (by omega) upper
  have ge70 : 70 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 75
  · exact ofChunk i pass2_70 (by omega) upper
  have ge75 : 75 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 80
  · exact ofChunk i pass2_75 (by omega) upper
  have ge80 : 80 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 85
  · exact ofChunk i pass2_80 (by omega) upper
  have ge85 : 85 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 90
  · exact ofChunk i pass2_85 (by omega) upper
  have ge90 : 90 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 95
  · exact ofChunk i pass2_90 (by omega) upper
  have ge95 : 95 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 100
  · exact ofChunk i pass2_95 (by omega) upper
  have ge100 : 100 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 105
  · exact ofChunk i pass2_100 (by omega) upper
  have ge105 : 105 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 110
  · exact ofChunk i pass2_105 (by omega) upper
  have ge110 : 110 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 115
  · exact ofChunk i pass2_110 (by omega) upper
  have ge115 : 115 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 120
  · exact ofChunk i pass2_115 (by omega) upper
  have ge120 : 120 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 125
  · exact ofChunk i pass2_120 (by omega) upper
  have ge125 : 125 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 130
  · exact ofChunk i pass2_125 (by omega) upper
  have ge130 : 130 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 135
  · exact ofChunk i pass2_130 (by omega) upper
  have ge135 : 135 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 140
  · exact ofChunk i pass2_135 (by omega) upper
  have ge140 : 140 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 145
  · exact ofChunk i pass2_140 (by omega) upper
  have ge145 : 145 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 150
  · exact ofChunk i pass2_145 (by omega) upper
  have ge150 : 150 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 155
  · exact ofChunk i pass2_150 (by omega) upper
  have ge155 : 155 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 160
  · exact ofChunk i pass2_155 (by omega) upper
  have ge160 : 160 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 165
  · exact ofChunk i pass2_160 (by omega) upper
  have ge165 : 165 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 170
  · exact ofChunk i pass2_165 (by omega) upper
  have ge170 : 170 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 175
  · exact ofChunk i pass2_170 (by omega) upper
  have ge175 : 175 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 180
  · exact ofChunk i pass2_175 (by omega) upper
  have ge180 : 180 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 185
  · exact ofChunk i pass2_180 (by omega) upper
  have ge185 : 185 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 190
  · exact ofChunk i pass2_185 (by omega) upper
  have ge190 : 190 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 195
  · exact ofChunk i pass2_190 (by omega) upper
  have ge195 : 195 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 200
  · exact ofChunk i pass2_195 (by omega) upper
  have ge200 : 200 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 205
  · exact ofChunk i pass2_200 (by omega) upper
  have ge205 : 205 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 210
  · exact ofChunk i pass2_205 (by omega) upper
  have ge210 : 210 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 215
  · exact ofChunk i pass2_210 (by omega) upper
  have ge215 : 215 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 220
  · exact ofChunk i pass2_215 (by omega) upper
  have ge220 : 220 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 225
  · exact ofChunk i pass2_220 (by omega) upper
  have ge225 : 225 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 230
  · exact ofChunk i pass2_225 (by omega) upper
  have ge230 : 230 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 235
  · exact ofChunk i pass2_230 (by omega) upper
  have ge235 : 235 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 240
  · exact ofChunk i pass2_235 (by omega) upper
  have ge240 : 240 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 245
  · exact ofChunk i pass2_240 (by omega) upper
  have ge245 : 245 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 250
  · exact ofChunk i pass2_245 (by omega) upper
  have ge250 : 250 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 255
  · exact ofChunk i pass2_250 (by omega) upper
  have ge255 : 255 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 260
  · exact ofChunk i pass2_255 (by omega) upper
  have ge260 : 260 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 265
  · exact ofChunk i pass2_260 (by omega) upper
  have ge265 : 265 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 270
  · exact ofChunk i pass2_265 (by omega) upper
  have ge270 : 270 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 275
  · exact ofChunk i pass2_270 (by omega) upper
  have ge275 : 275 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 280
  · exact ofChunk i pass2_275 (by omega) upper
  have ge280 : 280 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 285
  · exact ofChunk i pass2_280 (by omega) upper
  have ge285 : 285 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 290
  · exact ofChunk i pass2_285 (by omega) upper
  have ge290 : 290 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 295
  · exact ofChunk i pass2_290 (by omega) upper
  have ge295 : 295 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 300
  · exact ofChunk i pass2_295 (by omega) upper
  have ge300 : 300 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 305
  · exact ofChunk i pass2_300 (by omega) upper
  have ge305 : 305 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 310
  · exact ofChunk i pass2_305 (by omega) upper
  have ge310 : 310 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 315
  · exact ofChunk i pass2_310 (by omega) upper
  have ge315 : 315 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 320
  · exact ofChunk i pass2_315 (by omega) upper
  have ge320 : 320 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 325
  · exact ofChunk i pass2_320 (by omega) upper
  have ge325 : 325 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 330
  · exact ofChunk i pass2_325 (by omega) upper
  have ge330 : 330 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 335
  · exact ofChunk i pass2_330 (by omega) upper
  have ge335 : 335 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 340
  · exact ofChunk i pass2_335 (by omega) upper
  have ge340 : 340 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 345
  · exact ofChunk i pass2_340 (by omega) upper
  have ge345 : 345 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 350
  · exact ofChunk i pass2_345 (by omega) upper
  have ge350 : 350 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 355
  · exact ofChunk i pass2_350 (by omega) upper
  have ge355 : 355 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 360
  · exact ofChunk i pass2_355 (by omega) upper
  have ge360 : 360 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 365
  · exact ofChunk i pass2_360 (by omega) upper
  have ge365 : 365 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 370
  · exact ofChunk i pass2_365 (by omega) upper
  have ge370 : 370 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 375
  · exact ofChunk i pass2_370 (by omega) upper
  have ge375 : 375 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 380
  · exact ofChunk i pass2_375 (by omega) upper
  have ge380 : 380 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 385
  · exact ofChunk i pass2_380 (by omega) upper
  have ge385 : 385 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 390
  · exact ofChunk i pass2_385 (by omega) upper
  have ge390 : 390 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 395
  · exact ofChunk i pass2_390 (by omega) upper
  have ge395 : 395 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 400
  · exact ofChunk i pass2_395 (by omega) upper
  have ge400 : 400 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 405
  · exact ofChunk i pass2_400 (by omega) upper
  have ge405 : 405 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 410
  · exact ofChunk i pass2_405 (by omega) upper
  have ge410 : 410 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 415
  · exact ofChunk i pass2_410 (by omega) upper
  have ge415 : 415 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 420
  · exact ofChunk i pass2_415 (by omega) upper
  have ge420 : 420 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 425
  · exact ofChunk i pass2_420 (by omega) upper
  have ge425 : 425 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 430
  · exact ofChunk i pass2_425 (by omega) upper
  have ge430 : 430 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 435
  · exact ofChunk i pass2_430 (by omega) upper
  have ge435 : 435 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 440
  · exact ofChunk i pass2_435 (by omega) upper
  have ge440 : 440 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 445
  · exact ofChunk i pass2_440 (by omega) upper
  have ge445 : 445 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 450
  · exact ofChunk i pass2_445 (by omega) upper
  have ge450 : 450 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 455
  · exact ofChunk i pass2_450 (by omega) upper
  have ge455 : 455 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 460
  · exact ofChunk i pass2_455 (by omega) upper
  have ge460 : 460 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 465
  · exact ofChunk i pass2_460 (by omega) upper
  have ge465 : 465 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 470
  · exact ofChunk i pass2_465 (by omega) upper
  have ge470 : 470 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 475
  · exact ofChunk i pass2_470 (by omega) upper
  have ge475 : 475 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 480
  · exact ofChunk i pass2_475 (by omega) upper
  have ge480 : 480 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 485
  · exact ofChunk i pass2_480 (by omega) upper
  have ge485 : 485 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 490
  · exact ofChunk i pass2_485 (by omega) upper
  have ge490 : 490 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 495
  · exact ofChunk i pass2_490 (by omega) upper
  have ge495 : 495 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 500
  · exact ofChunk i pass2_495 (by omega) upper
  have ge500 : 500 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 505
  · exact ofChunk i pass2_500 (by omega) upper
  have ge505 : 505 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 510
  · exact ofChunk i pass2_505 (by omega) upper
  have ge510 : 510 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 515
  · exact ofChunk i pass2_510 (by omega) upper
  have ge515 : 515 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 520
  · exact ofChunk i pass2_515 (by omega) upper
  have ge520 : 520 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 525
  · exact ofChunk i pass2_520 (by omega) upper
  have ge525 : 525 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 530
  · exact ofChunk i pass2_525 (by omega) upper
  have ge530 : 530 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 535
  · exact ofChunk i pass2_530 (by omega) upper
  have ge535 : 535 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 540
  · exact ofChunk i pass2_535 (by omega) upper
  have ge540 : 540 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 545
  · exact ofChunk i pass2_540 (by omega) upper
  have ge545 : 545 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 550
  · exact ofChunk i pass2_545 (by omega) upper
  have ge550 : 550 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 555
  · exact ofChunk i pass2_550 (by omega) upper
  have ge555 : 555 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 560
  · exact ofChunk i pass2_555 (by omega) upper
  have ge560 : 560 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 565
  · exact ofChunk i pass2_560 (by omega) upper
  have ge565 : 565 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 570
  · exact ofChunk i pass2_565 (by omega) upper
  have ge570 : 570 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 575
  · exact ofChunk i pass2_570 (by omega) upper
  have ge575 : 575 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 580
  · exact ofChunk i pass2_575 (by omega) upper
  have ge580 : 580 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 585
  · exact ofChunk i pass2_580 (by omega) upper
  have ge585 : 585 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 590
  · exact ofChunk i pass2_585 (by omega) upper
  have ge590 : 590 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 595
  · exact ofChunk i pass2_590 (by omega) upper
  have ge595 : 595 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 600
  · exact ofChunk i pass2_595 (by omega) upper
  have ge600 : 600 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 605
  · exact ofChunk i pass2_600 (by omega) upper
  have ge605 : 605 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 610
  · exact ofChunk i pass2_605 (by omega) upper
  have ge610 : 610 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  exact ofChunk i pass2_610 (by omega) bound
#print axioms stage2
end Petersen120.Triple84.LayerData
