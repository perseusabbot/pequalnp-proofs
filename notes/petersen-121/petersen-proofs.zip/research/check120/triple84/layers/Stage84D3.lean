import Mask84D3S0
import Mask84D3S80
import Mask84D3S160
import Mask84D3S240
import Stage84D4

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem stage3 : Closed words 9 l3 := by
  apply prior words 8 l3 l4 _ stage4
  intro i
  have bound : i.val < 263 := i.isLt
  by_cases upper : i.val < 8
  · exact ofChunk i pass3_0 (by omega) upper
  have ge8 : 8 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 16
  · exact ofChunk i pass3_8 (by omega) upper
  have ge16 : 16 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 24
  · exact ofChunk i pass3_16 (by omega) upper
  have ge24 : 24 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 32
  · exact ofChunk i pass3_24 (by omega) upper
  have ge32 : 32 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 40
  · exact ofChunk i pass3_32 (by omega) upper
  have ge40 : 40 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 48
  · exact ofChunk i pass3_40 (by omega) upper
  have ge48 : 48 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 56
  · exact ofChunk i pass3_48 (by omega) upper
  have ge56 : 56 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 64
  · exact ofChunk i pass3_56 (by omega) upper
  have ge64 : 64 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 72
  · exact ofChunk i pass3_64 (by omega) upper
  have ge72 : 72 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 80
  · exact ofChunk i pass3_72 (by omega) upper
  have ge80 : 80 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 88
  · exact ofChunk i pass3_80 (by omega) upper
  have ge88 : 88 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 96
  · exact ofChunk i pass3_88 (by omega) upper
  have ge96 : 96 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 104
  · exact ofChunk i pass3_96 (by omega) upper
  have ge104 : 104 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 112
  · exact ofChunk i pass3_104 (by omega) upper
  have ge112 : 112 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 120
  · exact ofChunk i pass3_112 (by omega) upper
  have ge120 : 120 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 128
  · exact ofChunk i pass3_120 (by omega) upper
  have ge128 : 128 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 136
  · exact ofChunk i pass3_128 (by omega) upper
  have ge136 : 136 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 144
  · exact ofChunk i pass3_136 (by omega) upper
  have ge144 : 144 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 152
  · exact ofChunk i pass3_144 (by omega) upper
  have ge152 : 152 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 160
  · exact ofChunk i pass3_152 (by omega) upper
  have ge160 : 160 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 168
  · exact ofChunk i pass3_160 (by omega) upper
  have ge168 : 168 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 176
  · exact ofChunk i pass3_168 (by omega) upper
  have ge176 : 176 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 184
  · exact ofChunk i pass3_176 (by omega) upper
  have ge184 : 184 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 192
  · exact ofChunk i pass3_184 (by omega) upper
  have ge192 : 192 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 200
  · exact ofChunk i pass3_192 (by omega) upper
  have ge200 : 200 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 208
  · exact ofChunk i pass3_200 (by omega) upper
  have ge208 : 208 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 216
  · exact ofChunk i pass3_208 (by omega) upper
  have ge216 : 216 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 224
  · exact ofChunk i pass3_216 (by omega) upper
  have ge224 : 224 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 232
  · exact ofChunk i pass3_224 (by omega) upper
  have ge232 : 232 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 240
  · exact ofChunk i pass3_232 (by omega) upper
  have ge240 : 240 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 248
  · exact ofChunk i pass3_240 (by omega) upper
  have ge248 : 248 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 256
  · exact ofChunk i pass3_248 (by omega) upper
  have ge256 : 256 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  exact ofChunk i pass3_256 (by omega) bound
#print axioms stage3
end Petersen120.Triple84.LayerData
