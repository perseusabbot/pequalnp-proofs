import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass3_160 : chunk words 8 l3 l4 160 8 = true := by decide +kernel
theorem pass3_168 : chunk words 8 l3 l4 168 8 = true := by decide +kernel
theorem pass3_176 : chunk words 8 l3 l4 176 8 = true := by decide +kernel
theorem pass3_184 : chunk words 8 l3 l4 184 8 = true := by decide +kernel
theorem pass3_192 : chunk words 8 l3 l4 192 8 = true := by decide +kernel
theorem pass3_200 : chunk words 8 l3 l4 200 8 = true := by decide +kernel
theorem pass3_208 : chunk words 8 l3 l4 208 8 = true := by decide +kernel
theorem pass3_216 : chunk words 8 l3 l4 216 8 = true := by decide +kernel
theorem pass3_224 : chunk words 8 l3 l4 224 8 = true := by decide +kernel
theorem pass3_232 : chunk words 8 l3 l4 232 8 = true := by decide +kernel
#print axioms pass3_160
end Petersen120.Triple84.LayerData
