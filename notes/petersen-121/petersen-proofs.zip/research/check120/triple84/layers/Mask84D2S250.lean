import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_250 : chunk words 9 l2 l3 250 5 = true := by decide +kernel
theorem pass2_255 : chunk words 9 l2 l3 255 5 = true := by decide +kernel
theorem pass2_260 : chunk words 9 l2 l3 260 5 = true := by decide +kernel
theorem pass2_265 : chunk words 9 l2 l3 265 5 = true := by decide +kernel
theorem pass2_270 : chunk words 9 l2 l3 270 5 = true := by decide +kernel
theorem pass2_275 : chunk words 9 l2 l3 275 5 = true := by decide +kernel
theorem pass2_280 : chunk words 9 l2 l3 280 5 = true := by decide +kernel
theorem pass2_285 : chunk words 9 l2 l3 285 5 = true := by decide +kernel
theorem pass2_290 : chunk words 9 l2 l3 290 5 = true := by decide +kernel
theorem pass2_295 : chunk words 9 l2 l3 295 5 = true := by decide +kernel
#print axioms pass2_250
end Petersen120.Triple84.LayerData
