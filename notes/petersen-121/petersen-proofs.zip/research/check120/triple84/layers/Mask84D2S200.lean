import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_200 : chunk words 9 l2 l3 200 5 = true := by decide +kernel
theorem pass2_205 : chunk words 9 l2 l3 205 5 = true := by decide +kernel
theorem pass2_210 : chunk words 9 l2 l3 210 5 = true := by decide +kernel
theorem pass2_215 : chunk words 9 l2 l3 215 5 = true := by decide +kernel
theorem pass2_220 : chunk words 9 l2 l3 220 5 = true := by decide +kernel
theorem pass2_225 : chunk words 9 l2 l3 225 5 = true := by decide +kernel
theorem pass2_230 : chunk words 9 l2 l3 230 5 = true := by decide +kernel
theorem pass2_235 : chunk words 9 l2 l3 235 5 = true := by decide +kernel
theorem pass2_240 : chunk words 9 l2 l3 240 5 = true := by decide +kernel
theorem pass2_245 : chunk words 9 l2 l3 245 5 = true := by decide +kernel
#print axioms pass2_200
end Petersen120.Triple84.LayerData
