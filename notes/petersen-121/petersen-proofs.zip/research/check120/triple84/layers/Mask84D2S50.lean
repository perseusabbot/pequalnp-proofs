import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_50 : chunk words 9 l2 l3 50 5 = true := by decide +kernel
theorem pass2_55 : chunk words 9 l2 l3 55 5 = true := by decide +kernel
theorem pass2_60 : chunk words 9 l2 l3 60 5 = true := by decide +kernel
theorem pass2_65 : chunk words 9 l2 l3 65 5 = true := by decide +kernel
theorem pass2_70 : chunk words 9 l2 l3 70 5 = true := by decide +kernel
theorem pass2_75 : chunk words 9 l2 l3 75 5 = true := by decide +kernel
theorem pass2_80 : chunk words 9 l2 l3 80 5 = true := by decide +kernel
theorem pass2_85 : chunk words 9 l2 l3 85 5 = true := by decide +kernel
theorem pass2_90 : chunk words 9 l2 l3 90 5 = true := by decide +kernel
theorem pass2_95 : chunk words 9 l2 l3 95 5 = true := by decide +kernel
#print axioms pass2_50
end Petersen120.Triple84.LayerData
