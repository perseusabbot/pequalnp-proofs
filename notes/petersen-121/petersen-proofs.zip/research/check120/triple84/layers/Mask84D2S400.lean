import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_400 : chunk words 9 l2 l3 400 5 = true := by decide +kernel
theorem pass2_405 : chunk words 9 l2 l3 405 5 = true := by decide +kernel
theorem pass2_410 : chunk words 9 l2 l3 410 5 = true := by decide +kernel
theorem pass2_415 : chunk words 9 l2 l3 415 5 = true := by decide +kernel
theorem pass2_420 : chunk words 9 l2 l3 420 5 = true := by decide +kernel
theorem pass2_425 : chunk words 9 l2 l3 425 5 = true := by decide +kernel
theorem pass2_430 : chunk words 9 l2 l3 430 5 = true := by decide +kernel
theorem pass2_435 : chunk words 9 l2 l3 435 5 = true := by decide +kernel
theorem pass2_440 : chunk words 9 l2 l3 440 5 = true := by decide +kernel
theorem pass2_445 : chunk words 9 l2 l3 445 5 = true := by decide +kernel
#print axioms pass2_400
end Petersen120.Triple84.LayerData
