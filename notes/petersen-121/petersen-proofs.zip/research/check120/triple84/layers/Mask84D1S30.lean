import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass1_30 : chunk words 10 l1 l2 30 3 = true := by decide +kernel
theorem pass1_33 : chunk words 10 l1 l2 33 3 = true := by decide +kernel
theorem pass1_36 : chunk words 10 l1 l2 36 3 = true := by decide +kernel
theorem pass1_39 : chunk words 10 l1 l2 39 3 = true := by decide +kernel
theorem pass1_42 : chunk words 10 l1 l2 42 3 = true := by decide +kernel
theorem pass1_45 : chunk words 10 l1 l2 45 3 = true := by decide +kernel
theorem pass1_48 : chunk words 10 l1 l2 48 3 = true := by decide +kernel
theorem pass1_51 : chunk words 10 l1 l2 51 3 = true := by decide +kernel
theorem pass1_54 : chunk words 10 l1 l2 54 3 = true := by decide +kernel
theorem pass1_57 : chunk words 10 l1 l2 57 3 = true := by decide +kernel
#print axioms pass1_30
end Petersen120.Triple84.LayerData
