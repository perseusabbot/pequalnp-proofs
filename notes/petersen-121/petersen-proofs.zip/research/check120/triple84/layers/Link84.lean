import LayersData84
import Batch84_0

namespace Petersen120.Triple84.LayerData
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table Petersen1676.PinRules
open Petersen120.Mask81.LayerCheck

def rootIndex (i : Fin 17) := ([2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 14, 15, 16, 19, 21, 33, 35] : List Nat).getD i.val 0

set_option maxRecDepth 20000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000

private theorem decoding : ∀ i : Fin 17, decodeNode words l0[i.val]! =
    (starts.getD (rootIndex i) [],branchBudget (code (rootIndex i))) := by decide +kernel
private theorem rootLength : l0.size = 17 := by decide +kernel
private theorem checkedRoots : ∀ i : Fin 17,
    code (rootIndex i) ∈ descs ∧ starts.getD (rootIndex i) [] =
      Memo.canonical (intermediate (code (rootIndex i))) := by decide +kernel

theorem oneRoot (all : Closed words 12 l0) (i : Fin 17) :
    ¬ NatRun allMask Table.goal 12 (starts.getD (rootIndex i) []) := by
  have idx : i.val < l0.size := rootLength.symm ▸ i.isLt
  have eq := decoding i
  simp only [getElem!_pos l0 i.val idx] at eq
  have rr := all ⟨i.val,idx⟩
  change Invariant allMask Table.goal raw (decodeNode words l0[i.val]).1
    (decodeNode words l0[i.val]).2 → ¬NatRun allMask Table.goal 12 (decodeNode words l0[i.val]).1 at rr
  rw [eq] at rr
  apply rr
  change Invariant allMask Table.goal raw (starts.getD (rootIndex i) []) _
  rw [(checkedRoots i).2]
  exact validAt _ (checkedRoots i).1

theorem most (all : Closed words 12 l0) :
    ∀ i ∈ reps, ¬NatRun allMask Table.goal 12 (starts.getD i []) := by
  intro i hi
  simp only [reps,List.mem_cons,List.not_mem_nil,or_false] at hi
  rcases hi with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact noRep0
  · exact noRep1
  · exact oneRoot all (0 : Fin 17)
  · exact oneRoot all (1 : Fin 17)
  · exact oneRoot all (2 : Fin 17)
  · exact oneRoot all (3 : Fin 17)
  · exact noRep6
  · exact oneRoot all (4 : Fin 17)
  · exact oneRoot all (5 : Fin 17)
  · exact oneRoot all (6 : Fin 17)
  · exact oneRoot all (7 : Fin 17)
  · exact oneRoot all (8 : Fin 17)
  · exact oneRoot all (9 : Fin 17)
  · exact oneRoot all (10 : Fin 17)
  · exact oneRoot all (11 : Fin 17)
  · exact oneRoot all (12 : Fin 17)
  · exact oneRoot all (13 : Fin 17)
  · exact oneRoot all (14 : Fin 17)
  · exact noRep25
  · exact noRep26
  · exact noRep27
  · exact noRep29
  · exact noRep31
  · exact oneRoot all (15 : Fin 17)
  · exact oneRoot all (16 : Fin 17)

end Petersen120.Triple84.LayerData

#print axioms Petersen120.Triple84.LayerData.most
