import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_550 : chunk words 9 l2 l3 550 5 = true := by decide +kernel
theorem pass2_555 : chunk words 9 l2 l3 555 5 = true := by decide +kernel
theorem pass2_560 : chunk words 9 l2 l3 560 5 = true := by decide +kernel
theorem pass2_565 : chunk words 9 l2 l3 565 5 = true := by decide +kernel
theorem pass2_570 : chunk words 9 l2 l3 570 5 = true := by decide +kernel
theorem pass2_575 : chunk words 9 l2 l3 575 5 = true := by decide +kernel
theorem pass2_580 : chunk words 9 l2 l3 580 5 = true := by decide +kernel
theorem pass2_585 : chunk words 9 l2 l3 585 5 = true := by decide +kernel
theorem pass2_590 : chunk words 9 l2 l3 590 5 = true := by decide +kernel
theorem pass2_595 : chunk words 9 l2 l3 595 5 = true := by decide +kernel
#print axioms pass2_550
end Petersen120.Triple84.LayerData
