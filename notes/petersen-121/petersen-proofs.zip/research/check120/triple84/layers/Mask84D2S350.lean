import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_350 : chunk words 9 l2 l3 350 5 = true := by decide +kernel
theorem pass2_355 : chunk words 9 l2 l3 355 5 = true := by decide +kernel
theorem pass2_360 : chunk words 9 l2 l3 360 5 = true := by decide +kernel
theorem pass2_365 : chunk words 9 l2 l3 365 5 = true := by decide +kernel
theorem pass2_370 : chunk words 9 l2 l3 370 5 = true := by decide +kernel
theorem pass2_375 : chunk words 9 l2 l3 375 5 = true := by decide +kernel
theorem pass2_380 : chunk words 9 l2 l3 380 5 = true := by decide +kernel
theorem pass2_385 : chunk words 9 l2 l3 385 5 = true := by decide +kernel
theorem pass2_390 : chunk words 9 l2 l3 390 5 = true := by decide +kernel
theorem pass2_395 : chunk words 9 l2 l3 395 5 = true := by decide +kernel
#print axioms pass2_350
end Petersen120.Triple84.LayerData
