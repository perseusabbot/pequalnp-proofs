import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_600 : chunk words 9 l2 l3 600 5 = true := by decide +kernel
theorem pass2_605 : chunk words 9 l2 l3 605 5 = true := by decide +kernel
theorem pass2_610 : chunk words 9 l2 l3 610 2 = true := by decide +kernel
#print axioms pass2_600
end Petersen120.Triple84.LayerData
