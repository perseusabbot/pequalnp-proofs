import Mask84D4S0

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem stage4 : Closed words 8 l4 := by
  apply prior words 7 l4 l5 _ emptyLast
  intro i
  have bound : i.val < 9 := i.isLt
  by_cases upper : i.val < 3
  · exact ofChunk i pass4_0 (by omega) upper
  have ge3 : 3 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 6
  · exact ofChunk i pass4_3 (by omega) upper
  have ge6 : 6 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  exact ofChunk i pass4_6 (by omega) bound
#print axioms stage4
end Petersen120.Triple84.LayerData
