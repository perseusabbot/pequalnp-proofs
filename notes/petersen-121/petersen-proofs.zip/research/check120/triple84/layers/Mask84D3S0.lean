import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass3_0 : chunk words 8 l3 l4 0 8 = true := by decide +kernel
theorem pass3_8 : chunk words 8 l3 l4 8 8 = true := by decide +kernel
theorem pass3_16 : chunk words 8 l3 l4 16 8 = true := by decide +kernel
theorem pass3_24 : chunk words 8 l3 l4 24 8 = true := by decide +kernel
theorem pass3_32 : chunk words 8 l3 l4 32 8 = true := by decide +kernel
theorem pass3_40 : chunk words 8 l3 l4 40 8 = true := by decide +kernel
theorem pass3_48 : chunk words 8 l3 l4 48 8 = true := by decide +kernel
theorem pass3_56 : chunk words 8 l3 l4 56 8 = true := by decide +kernel
theorem pass3_64 : chunk words 8 l3 l4 64 8 = true := by decide +kernel
theorem pass3_72 : chunk words 8 l3 l4 72 8 = true := by decide +kernel
#print axioms pass3_0
end Petersen120.Triple84.LayerData
