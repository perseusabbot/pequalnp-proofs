import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass1_90 : chunk words 10 l1 l2 90 3 = true := by decide +kernel
theorem pass1_93 : chunk words 10 l1 l2 93 3 = true := by decide +kernel
theorem pass1_96 : chunk words 10 l1 l2 96 3 = true := by decide +kernel
theorem pass1_99 : chunk words 10 l1 l2 99 3 = true := by decide +kernel
theorem pass1_102 : chunk words 10 l1 l2 102 3 = true := by decide +kernel
theorem pass1_105 : chunk words 10 l1 l2 105 3 = true := by decide +kernel
theorem pass1_108 : chunk words 10 l1 l2 108 3 = true := by decide +kernel
theorem pass1_111 : chunk words 10 l1 l2 111 3 = true := by decide +kernel
theorem pass1_114 : chunk words 10 l1 l2 114 3 = true := by decide +kernel
theorem pass1_117 : chunk words 10 l1 l2 117 3 = true := by decide +kernel
#print axioms pass1_90
end Petersen120.Triple84.LayerData
