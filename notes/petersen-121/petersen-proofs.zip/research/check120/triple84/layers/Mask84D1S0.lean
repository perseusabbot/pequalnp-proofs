import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass1_0 : chunk words 10 l1 l2 0 3 = true := by decide +kernel
theorem pass1_3 : chunk words 10 l1 l2 3 3 = true := by decide +kernel
theorem pass1_6 : chunk words 10 l1 l2 6 3 = true := by decide +kernel
theorem pass1_9 : chunk words 10 l1 l2 9 3 = true := by decide +kernel
theorem pass1_12 : chunk words 10 l1 l2 12 3 = true := by decide +kernel
theorem pass1_15 : chunk words 10 l1 l2 15 3 = true := by decide +kernel
theorem pass1_18 : chunk words 10 l1 l2 18 3 = true := by decide +kernel
theorem pass1_21 : chunk words 10 l1 l2 21 3 = true := by decide +kernel
theorem pass1_24 : chunk words 10 l1 l2 24 3 = true := by decide +kernel
theorem pass1_27 : chunk words 10 l1 l2 27 3 = true := by decide +kernel
#print axioms pass1_0
end Petersen120.Triple84.LayerData
