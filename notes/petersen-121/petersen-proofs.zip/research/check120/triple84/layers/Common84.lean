import LayersData84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem emptyLast : Closed words 7 l5 := by
  intro i
  exact Fin.elim0 i

theorem ofChunk {s cur next offset count} (i : Fin cur.size)
    (checked : chunk words s cur next offset count = true)
    (low : offset ≤ i.val) (high : i.val < offset+count) :
    localCheck words s cur[i.val] next = true := by
  simpa only [Array.getElem?_eq_getElem i.isLt,Option.getD_some] using
    (fromChunk (i := i.val) checked low high)

end Petersen120.Triple84.LayerData
