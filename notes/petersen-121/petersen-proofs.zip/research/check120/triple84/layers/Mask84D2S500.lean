import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_500 : chunk words 9 l2 l3 500 5 = true := by decide +kernel
theorem pass2_505 : chunk words 9 l2 l3 505 5 = true := by decide +kernel
theorem pass2_510 : chunk words 9 l2 l3 510 5 = true := by decide +kernel
theorem pass2_515 : chunk words 9 l2 l3 515 5 = true := by decide +kernel
theorem pass2_520 : chunk words 9 l2 l3 520 5 = true := by decide +kernel
theorem pass2_525 : chunk words 9 l2 l3 525 5 = true := by decide +kernel
theorem pass2_530 : chunk words 9 l2 l3 530 5 = true := by decide +kernel
theorem pass2_535 : chunk words 9 l2 l3 535 5 = true := by decide +kernel
theorem pass2_540 : chunk words 9 l2 l3 540 5 = true := by decide +kernel
theorem pass2_545 : chunk words 9 l2 l3 545 5 = true := by decide +kernel
#print axioms pass2_500
end Petersen120.Triple84.LayerData
