import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass3_80 : chunk words 8 l3 l4 80 8 = true := by decide +kernel
theorem pass3_88 : chunk words 8 l3 l4 88 8 = true := by decide +kernel
theorem pass3_96 : chunk words 8 l3 l4 96 8 = true := by decide +kernel
theorem pass3_104 : chunk words 8 l3 l4 104 8 = true := by decide +kernel
theorem pass3_112 : chunk words 8 l3 l4 112 8 = true := by decide +kernel
theorem pass3_120 : chunk words 8 l3 l4 120 8 = true := by decide +kernel
theorem pass3_128 : chunk words 8 l3 l4 128 8 = true := by decide +kernel
theorem pass3_136 : chunk words 8 l3 l4 136 8 = true := by decide +kernel
theorem pass3_144 : chunk words 8 l3 l4 144 8 = true := by decide +kernel
theorem pass3_152 : chunk words 8 l3 l4 152 8 = true := by decide +kernel
#print axioms pass3_80
end Petersen120.Triple84.LayerData
