import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass1_270 : chunk words 10 l1 l2 270 3 = true := by decide +kernel
theorem pass1_273 : chunk words 10 l1 l2 273 3 = true := by decide +kernel
theorem pass1_276 : chunk words 10 l1 l2 276 3 = true := by decide +kernel
theorem pass1_279 : chunk words 10 l1 l2 279 3 = true := by decide +kernel
theorem pass1_282 : chunk words 10 l1 l2 282 3 = true := by decide +kernel
theorem pass1_285 : chunk words 10 l1 l2 285 3 = true := by decide +kernel
theorem pass1_288 : chunk words 10 l1 l2 288 3 = true := by decide +kernel
theorem pass1_291 : chunk words 10 l1 l2 291 3 = true := by decide +kernel
theorem pass1_294 : chunk words 10 l1 l2 294 2 = true := by decide +kernel
#print axioms pass1_270
end Petersen120.Triple84.LayerData
