import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass2_300 : chunk words 9 l2 l3 300 5 = true := by decide +kernel
theorem pass2_305 : chunk words 9 l2 l3 305 5 = true := by decide +kernel
theorem pass2_310 : chunk words 9 l2 l3 310 5 = true := by decide +kernel
theorem pass2_315 : chunk words 9 l2 l3 315 5 = true := by decide +kernel
theorem pass2_320 : chunk words 9 l2 l3 320 5 = true := by decide +kernel
theorem pass2_325 : chunk words 9 l2 l3 325 5 = true := by decide +kernel
theorem pass2_330 : chunk words 9 l2 l3 330 5 = true := by decide +kernel
theorem pass2_335 : chunk words 9 l2 l3 335 5 = true := by decide +kernel
theorem pass2_340 : chunk words 9 l2 l3 340 5 = true := by decide +kernel
theorem pass2_345 : chunk words 9 l2 l3 345 5 = true := by decide +kernel
#print axioms pass2_300
end Petersen120.Triple84.LayerData
