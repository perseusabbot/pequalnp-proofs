import Mask84D0S0
import Stage84D1

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem stage0 : Closed words 12 l0 := by
  apply prior words 11 l0 l1 _ stage1
  intro i
  have bound : i.val < 17 := i.isLt
  by_cases upper : i.val < 2
  · exact ofChunk i pass0_0 (by omega) upper
  have ge2 : 2 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 4
  · exact ofChunk i pass0_2 (by omega) upper
  have ge4 : 4 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 6
  · exact ofChunk i pass0_4 (by omega) upper
  have ge6 : 6 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 8
  · exact ofChunk i pass0_6 (by omega) upper
  have ge8 : 8 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 10
  · exact ofChunk i pass0_8 (by omega) upper
  have ge10 : 10 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 12
  · exact ofChunk i pass0_10 (by omega) upper
  have ge12 : 12 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 14
  · exact ofChunk i pass0_12 (by omega) upper
  have ge14 : 14 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  by_cases upper : i.val < 16
  · exact ofChunk i pass0_14 (by omega) upper
  have ge16 : 16 ≤ i.val := Nat.le_of_not_gt upper
  clear upper
  exact ofChunk i pass0_16 (by omega) bound
#print axioms stage0
end Petersen120.Triple84.LayerData
