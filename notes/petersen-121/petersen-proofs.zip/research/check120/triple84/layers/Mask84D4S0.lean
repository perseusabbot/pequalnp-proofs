import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass4_0 : chunk words 7 l4 l5 0 3 = true := by decide +kernel
theorem pass4_3 : chunk words 7 l4 l5 3 3 = true := by decide +kernel
theorem pass4_6 : chunk words 7 l4 l5 6 3 = true := by decide +kernel
#print axioms pass4_0
end Petersen120.Triple84.LayerData
