import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass1_210 : chunk words 10 l1 l2 210 3 = true := by decide +kernel
theorem pass1_213 : chunk words 10 l1 l2 213 3 = true := by decide +kernel
theorem pass1_216 : chunk words 10 l1 l2 216 3 = true := by decide +kernel
theorem pass1_219 : chunk words 10 l1 l2 219 3 = true := by decide +kernel
theorem pass1_222 : chunk words 10 l1 l2 222 3 = true := by decide +kernel
theorem pass1_225 : chunk words 10 l1 l2 225 3 = true := by decide +kernel
theorem pass1_228 : chunk words 10 l1 l2 228 3 = true := by decide +kernel
theorem pass1_231 : chunk words 10 l1 l2 231 3 = true := by decide +kernel
theorem pass1_234 : chunk words 10 l1 l2 234 3 = true := by decide +kernel
theorem pass1_237 : chunk words 10 l1 l2 237 3 = true := by decide +kernel
#print axioms pass1_210
end Petersen120.Triple84.LayerData
