import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass1_180 : chunk words 10 l1 l2 180 3 = true := by decide +kernel
theorem pass1_183 : chunk words 10 l1 l2 183 3 = true := by decide +kernel
theorem pass1_186 : chunk words 10 l1 l2 186 3 = true := by decide +kernel
theorem pass1_189 : chunk words 10 l1 l2 189 3 = true := by decide +kernel
theorem pass1_192 : chunk words 10 l1 l2 192 3 = true := by decide +kernel
theorem pass1_195 : chunk words 10 l1 l2 195 3 = true := by decide +kernel
theorem pass1_198 : chunk words 10 l1 l2 198 3 = true := by decide +kernel
theorem pass1_201 : chunk words 10 l1 l2 201 3 = true := by decide +kernel
theorem pass1_204 : chunk words 10 l1 l2 204 3 = true := by decide +kernel
theorem pass1_207 : chunk words 10 l1 l2 207 3 = true := by decide +kernel
#print axioms pass1_180
end Petersen120.Triple84.LayerData
