import Common84

namespace Petersen120.Triple84.LayerData
open Petersen120.Mask81.LayerCheck

set_option maxRecDepth 32000
set_option maxHeartbeats 0
set_option exponentiation.threshold 1000
set_option Elab.async false

theorem pass3_240 : chunk words 8 l3 l4 240 8 = true := by decide +kernel
theorem pass3_248 : chunk words 8 l3 l4 248 8 = true := by decide +kernel
theorem pass3_256 : chunk words 8 l3 l4 256 7 = true := by decide +kernel
#print axioms pass3_240
end Petersen120.Triple84.LayerData
