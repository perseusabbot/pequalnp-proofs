import Check84

namespace Petersen120.Triple84
open PEqualNP.Outside.L_meta_274_aux Petersen1676 Petersen1676.Table
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

private theorem check27 : test 27 = false := by decide +kernel
theorem noRep27 : ¬ NatRun allMask Table.goal 12 (starts.getD 27 []) :=
  refute 27 (by decide +kernel) check27
#print axioms noRep27

private theorem check6 : test 6 = false := by decide +kernel
theorem noRep6 : ¬ NatRun allMask Table.goal 12 (starts.getD 6 []) :=
  refute 6 (by decide +kernel) check6
#print axioms noRep6

private theorem check29 : test 29 = false := by decide +kernel
theorem noRep29 : ¬ NatRun allMask Table.goal 12 (starts.getD 29 []) :=
  refute 29 (by decide +kernel) check29
#print axioms noRep29

private theorem check31 : test 31 = false := by decide +kernel
theorem noRep31 : ¬ NatRun allMask Table.goal 12 (starts.getD 31 []) :=
  refute 31 (by decide +kernel) check31
#print axioms noRep31

private theorem check25 : test 25 = false := by decide +kernel
theorem noRep25 : ¬ NatRun allMask Table.goal 12 (starts.getD 25 []) :=
  refute 25 (by decide +kernel) check25
#print axioms noRep25

private theorem check1 : test 1 = false := by decide +kernel
theorem noRep1 : ¬ NatRun allMask Table.goal 12 (starts.getD 1 []) :=
  refute 1 (by decide +kernel) check1
#print axioms noRep1

private theorem check26 : test 26 = false := by decide +kernel
theorem noRep26 : ¬ NatRun allMask Table.goal 12 (starts.getD 26 []) :=
  refute 26 (by decide +kernel) check26
#print axioms noRep26

private theorem check0 : test 0 = false := by decide +kernel
theorem noRep0 : ¬ NatRun allMask Table.goal 12 (starts.getD 0 []) :=
  refute 0 (by decide +kernel) check0
#print axioms noRep0

end Petersen120.Triple84
