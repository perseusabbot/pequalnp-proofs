import Printed208

namespace Petersen120.Triple84
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_274_aux
open PEqualNP.Outside.L_meta_3348_aux.FirstWireRun
open Petersen1676 Petersen1676.Table Petersen1676.Triples46
open Petersen120.Triple.Orbit (Printed)

set_option maxRecDepth 10000 in
private theorem inputs : ∀ x : Fin 9 → Bool, Fin.snoc (Fin.snoc x (x 4 || x 6))
    (decide (∃ i : Fin 9, (84 : Nat).testBit i.val = true ∧ x i = true)) = extended 1 x :=
  by decide +kernel

set_option maxRecDepth 10000 in
private theorem targets : ∀ x : Fin 9 → Bool,
    (([1,12,23,34,40,5,16,27,38,57,68,85] : List Nat).any
      (fun e => x (Fin.ofNat 9 (e/10)) && x (Fin.ofNat 9 (e%10)))) = edgeFn x := by decide +kernel

theorem case84 (closed : ¬ NatRun allMask Table.goal 13 (tripleSignals 1)) : Petersen120.Triple.Orbit.Printed [84] := by
  intro m hm D fan promise
  have eq : m = 84 := by simpa only [List.mem_singleton] using hm
  subst m
  by_contra! small
  apply closed (forced 1 D (by omega) fan ?_)
  intro x
  rw [← inputs]
  exact (promise x).trans (targets x)

/-- Mask 81 suffices for the complete printed child-four statement. -/
theorem sufficesOf84 (h84 : Printed [84]) :
    (have x1 : (Fin (9 : ℕ) → Bool) → Bool := fun (x1 : Fin (9 : ℕ) → Bool) => [(1 : ℕ), (12 : ℕ), (23 : ℕ), (34 : ℕ), (40 : ℕ), (5 : ℕ), (16 : ℕ), (27 : ℕ), (38 : ℕ), (57 : ℕ), (68 : ℕ), (85 : ℕ)].any fun (x2 : ℕ) => x1 (Fin.ofNat (9 : ℕ) (x2 / (10 : ℕ))) && x1 (Fin.ofNat (9 : ℕ) (x2 % (10 : ℕ))); ∀ x2 ∈ [(81 : ℕ)], ∀ (x4 : PEqualNP.CircuitLowerBounds.Circuit), PEqualNP.MetaComplexity.FanInTwo x4 → (∀ (x6 : Fin (9 : ℕ) → Bool), PEqualNP.MetaComplexity.circuitFun (11 : ℕ) x4 (Fin.snoc (Fin.snoc x6 (x6 (4 : Fin (9 : ℕ)) || x6 (6 : Fin (9 : ℕ)))) (Decidable.decide (∃ (x7 : Fin (9 : ℕ)), x2.testBit ↑x7 = Bool.true ∧ x6 x7 = Bool.true))) = x1 x6) → (14 : ℕ) ≤ x4.size) →
    have x1 : (Fin (9 : ℕ) → Bool) → Bool := fun (x1 : Fin (9 : ℕ) → Bool) => [(1 : ℕ), (12 : ℕ), (23 : ℕ), (34 : ℕ), (40 : ℕ), (5 : ℕ), (16 : ℕ), (27 : ℕ), (38 : ℕ), (57 : ℕ), (68 : ℕ), (85 : ℕ)].any fun (x2 : ℕ) => x1 (Fin.ofNat (9 : ℕ) (x2 / (10 : ℕ))) && x1 (Fin.ofNat (9 : ℕ) (x2 % (10 : ℕ))); ∀ x2 ∈ [(81 : ℕ), (84 : ℕ), (208 : ℕ)], ∀ (x4 : PEqualNP.CircuitLowerBounds.Circuit), PEqualNP.MetaComplexity.FanInTwo x4 → (∀ (x6 : Fin (9 : ℕ) → Bool), PEqualNP.MetaComplexity.circuitFun (11 : ℕ) x4 (Fin.snoc (Fin.snoc x6 (x6 (4 : Fin (9 : ℕ)) || x6 (6 : Fin (9 : ℕ)))) (Decidable.decide (∃ (x7 : Fin (9 : ℕ)), x2.testBit ↑x7 = Bool.true ∧ x6 x7 = Bool.true))) = x1 x6) → (14 : ℕ) ≤ x4.size := by
  intro one
  apply Petersen120.Triple.Orbit.printedTwoSuffice
  intro f m hm
  rcases List.mem_cons.mp hm with h | h
  · exact one m (by simp [h])
  · exact h84 m h

end Petersen120.Triple84

#print axioms Petersen120.Triple84.case84
#print axioms Petersen120.Triple84.sufficesOf84
