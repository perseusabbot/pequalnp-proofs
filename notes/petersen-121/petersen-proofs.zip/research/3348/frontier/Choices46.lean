import Root46
import CachedGen

namespace Petersen1676.Choice46
open PEqualNP.Outside.L_meta_274_aux Petersen1676.Table Petersen1676.PinRules

abbrev Descriptor := Nat × Nat × Nat × Nat
def descriptors : List Descriptor := [
  (0, 2, 5, 0),
  (2, 8, 8, 256),
  (2, 7, 7, 128),
  (2, 1, 1, 2),
  (1, 0, 2, 0),
  (1, 0, 3, 0),
  (1, 2, 3, 0),
  (1, 0, 5, 0),
  (1, 2, 5, 0),
  (1, 3, 5, 0),
  (2, 5, 5, 0),
  (2, 2, 2, 0),
  (1, 0, 1, 0),
  (1, 1, 2, 0),
  (1, 2, 7, 0),
  (1, 0, 7, 0),
  (1, 1, 7, 0),
  (1, 1, 3, 0),
  (1, 3, 7, 0),
  (1, 1, 5, 0),
  (1, 5, 7, 0),
  (1, 3, 8, 0),
  (1, 0, 8, 0),
  (1, 1, 8, 0),
  (1, 2, 8, 0),
  (1, 5, 8, 0),
  (1, 7, 8, 0),
  (1, 1, 9, 512),
  (1, 0, 9, 512),
  (1, 2, 9, 512),
  (1, 7, 9, 512),
  (1, 3, 9, 512),
  (1, 5, 9, 512),
  (1, 8, 9, 512),
  (1, 1, 4, 16),
  (1, 4, 8, 16),
  (1, 0, 6, 64),
  (1, 3, 6, 64),
  (2, 5, 5, 32),
  (2, 3, 3, 8),
  (2, 2, 2, 4),
  (2, 0, 0, 1)]
def word (k : Nat) := (Table46.start true).getD k 0
def signals (d : Descriptor) : List Nat :=
  let (op,a,b,del) := d
  let s := if op=2 then word a ^^^ Table.allMask else if op=1 then word a ||| word b else word a &&& word b
  Memo.canonical (s :: (((List.range 10).filter (fun i => !(del.testBit i))).map word))
def lists := descriptors.map signals

private def fast := Cached.genExact Table.allMask Table.raw (covers Table.kk) 13
  (Table46.start true) (Table46.initial (Table46.start true))

set_option maxRecDepth 32000 in
set_option maxHeartbeats 0 in
private theorem allChoices : (fast.all (fun node => lists.contains node.1)) = true ∧
    (lists.all (fun ws => fast.any (fun node => node.1 == ws))) = true := by decide +kernel

theorem membership {q} (hq : q ∈ Memo.gen Table.allMask Table.raw Table46.cut 13
    (Table46.start true) (Table46.initial (Table46.start true))) : q.1 ∈ lists := by
  change q ∈ Memo.gen Table.allMask Table.raw RunTable.cut 13 _ _ at hq
  rw [← Cached.actual_gen] at hq
  exact List.contains_iff_mem.mp (List.all_eq_true.mp allChoices.1 q hq)

theorem total : descriptors.length = 42 ∧ (descriptors.filter fun d => d.1=1).length=32 ∧
    (descriptors.filter fun d => d.1=2).length=9 ∧ (descriptors.filter fun d => d.1=0).length=1 := by decide +kernel

set_option maxRecDepth 8000 in
set_option maxHeartbeats 2000000 in
theorem dependency (run : NatRun Table.allMask Table.goal 14 (Table46.start true)) :
    ∃ w ∈ lists, NatRun Table.allMask Table.goal 13 w := by
  by_contra! deny
  exact Memo.splitRefute (s := 13) (is := Table46.initial _) (m := Table.allMask)
    (goal := Table.goal) (raw := Table.raw) (cut := Table46.cut)
    (fun inv rr => by
      rw [Table46.cut,Bool.and_eq_true]
      exact ⟨covers_ok (k := Table.kk) rr,legal_sound inv rr⟩)
    (Actual46.actualStart true) (fun q hq => deny q.1 (membership hq)) run

#print axioms dependency
end Petersen1676.Choice46
