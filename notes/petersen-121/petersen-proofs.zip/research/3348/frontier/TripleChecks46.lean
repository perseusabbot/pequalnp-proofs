import Triples46
import CachedSearch

namespace Petersen1676.Triples46
open PEqualNP.Outside.L_meta_274_aux Petersen1676.Table Petersen1676.Actual
open Petersen1676.Prune Petersen1676.PinRules Petersen1676.Search

set_option maxRecDepth 16000
set_option maxHeartbeats 0

def budget (k : Fin 3) := advance raw (Table46.start true) (triple k :: raw)
  (Table46.initial (Table46.start true))

theorem initialized (k : Fin 3) : Invariant allMask Table.goal raw (tripleSignals k) (budget k) := by
  have ev : EdgeStep allMask (Table46.start true) (triple k :: raw) := by
    constructor
    · apply Made.binary (a := Table46.header) (b := rawWord (vertex k)) (conj := false)
      · simp [Table46.start]
      · have hr : ∀ i : Fin 9, rawWord i ∈ raw := by decide +kernel
        simp [Table46.start, hr]
    · intro w hw
      simp [Table46.start,hw]
  have valid := advance_sound (Actual46.actualStart true) ev
  intro i hi
  obtain ⟨d,h⟩ := valid i hi
  refine ⟨d, builtSubset h ?_⟩
  simp [tripleSignals,or_comm]

def check (k : Fin 3) := Cached.search 13 (Memo.root (tripleSignals k) (budget k))

/-- Three ordinary finite word tests imply child 4 as recorded by the project checker. -/
theorem threeTests (hs : ∀ k, check k = false) :
  have x1 : (Fin (9 : ℕ) → Bool) → Bool := fun (x1 : Fin (9 : ℕ) → Bool) => [(1 : ℕ), (12 : ℕ), (23 : ℕ), (34 : ℕ), (40 : ℕ), (5 : ℕ), (16 : ℕ), (27 : ℕ), (38 : ℕ), (57 : ℕ), (68 : ℕ), (85 : ℕ)].any fun (x2 : ℕ) => x1 (Fin.ofNat (9 : ℕ) (x2 / (10 : ℕ))) && x1 (Fin.ofNat (9 : ℕ) (x2 % (10 : ℕ))); ∀ x2 ∈ [(81 : ℕ), (84 : ℕ), (208 : ℕ)], ∀ (x4 : PEqualNP.CircuitLowerBounds.Circuit), PEqualNP.MetaComplexity.FanInTwo x4 → (∀ (x6 : Fin (9 : ℕ) → Bool), PEqualNP.MetaComplexity.circuitFun (11 : ℕ) x4 (Fin.snoc (Fin.snoc x6 (x6 (4 : Fin (9 : ℕ)) || x6 (6 : Fin (9 : ℕ)))) (Decidable.decide (∃ (x7 : Fin (9 : ℕ)), x2.testBit ↑x7 = Bool.true ∧ x6 x7 = Bool.true))) = x1 x6) → (14 : ℕ) ≤ x4.size := child4
  (fun k => Cached.refute (initialized k) (hs k))

def firstChoices (k : Fin 3) := Cached.genExact allMask raw (covers kk) 12
  (tripleSignals k) (budget k)
private theorem size_0 : (firstChoices 0).length = 44 := by decide +kernel
private theorem size_1 : (firstChoices 1).length = 46 := by decide +kernel
private theorem size_2 : (firstChoices 2).length = 35 := by decide +kernel
theorem successorCounts : ∀ k, (firstChoices k).length = ![44,46,35] k := by
  intro k; fin_cases k
  · exact size_0
  · exact size_1
  · exact size_2

#print axioms threeTests
#print axioms successorCounts
end Petersen1676.Triples46
