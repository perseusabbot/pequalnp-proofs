import PEqualNP.Outside.L_meta_274

namespace PEqualNP.Outside.L_meta_3348_aux.FirstWireRun

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_274_aux

def edgeFn (x : Fin 9 → Bool) :=
  (x 0 && x 1) || (x 1 && x 2) || (x 2 && x 3) || (x 3 && x 4) ||
  (x 4 && x 0) || (x 0 && x 5) || (x 1 && x 6) || (x 2 && x 7) ||
  (x 3 && x 8) || (x 5 && x 7) || (x 6 && x 8) || (x 8 && x 5)

/-- Supply the semantic value of wire 9 as an additional input of the tail. -/
def extend (x : Fin 9 → Bool) : Fin 10 → Bool := Fin.snoc x (x 4 || x 6)

/-- Bit `j` holds the value on the input encoded by `rows[j]`. -/
def signalWords (rows : List ℕ) : List ℕ :=
  (List.ofFn fun i : Fin 9 => encL (fun x => x i) rows) ++
    [encL (fun x : Fin 9 → Bool => x 4 || x 6) rows]

private theorem inputs_extend (x : Fin 9 → Bool) :
    List.ofFn (extend x) = List.ofFn x ++ [x 4 || x 6] := by
  rw [List.ofFn_succ_last]; simp only [extend, Fin.snoc_castSucc, Fin.snoc_last]

/-- Raw sources followed by the specified first-gate signal. -/
def signals : List (BFn 9) :=
  (List.ofFn fun i : Fin 9 => (fun x : Fin 9 → Bool => x i)) ++
    [fun x => x 4 || x 6]

private theorem functions_extend :
    (List.ofFn fun i : Fin 10 => (fun x => extend x i)) = signals := by
  rw [List.ofFn_succ_last]; simp only [extend, Fin.snoc_castSucc, Fin.snoc_last, signals]

private theorem words_signals (rows : List ℕ) :
    signals.map (fun a => encL a rows) = signalWords rows := by
  simp only [signals, signalWords, List.map_append, List.map_ofFn, List.map_cons, List.map_nil]
  rfl

/-- The semantic first-wire premise is enough, including for degenerate gates
or an original output pointing to a raw input or to the first gate itself. -/
theorem first_run_function (C : Circuit) (hF : FanInTwo C)
    (h9 : ∀ y : Fin 9 → Bool, (C.wires (List.ofFn y)).getD 9 false = (y 4 || y 6))
    (he : circuitFun 9 C = edgeFn) :
    ∃ s ≤ C.size - 1, ∃ ws : List (BFn 9), ws.Sublist signals ∧
      Run invF meetF joinF edgeFn s ws := by
  obtain ⟨gs, o⟩ := C
  cases gs with
  | nil =>
    have hf := h9 (fun _ => true)
    simp [Circuit.wires] at hf
  | cons g gs =>
    let D : Circuit := ⟨gs, o⟩
    let f : BFn 10 := circuitFun 10 D
    have spec (x : Fin 9 → Bool) : f (extend x) = edgeFn x := by
      let b := g.op.eval (g.inputs.map fun i => (List.ofFn x).getD i false)
      have h := h9 x
      change (wiresFrom gs (List.ofFn x ++ [b])).getD 9 false = (x 4 || x 6) at h
      rw [getD_wiresFrom _ _ _ (by simp), getD_snoc_len _ _ _ _ (by simp)] at h
      have out := congrFun he x
      change (wiresFrom gs (List.ofFn x ++ [b])).getD o false = edgeFn x at out
      change (wiresFrom gs (List.ofFn (extend x))).getD o false = edgeFn x
      rwa [inputs_extend, ← h]
    have nc : ∃ y y', f y ≠ f y' := by
      refine ⟨extend (fun _ => false), extend (fun _ => true), ?_⟩
      rw [spec, spec]; decide
    have hc : HasCircuitSize 10 f gs.length := by
      exact ⟨D, fun a ha => hF a (List.mem_cons_of_mem _ ha), le_rfl, fun _ => rfl⟩
    obtain ⟨s, hs, ws, hw, hr⟩ := exists_run f nc gs.length hc
    let restrictToSignals : BFn 10 → BFn 9 := fun a x => a (extend x)
    have hr' : Run invF meetF joinF (restrictToSignals f) s (ws.map restrictToSignals) :=
      Run.map restrictToSignals (fun _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl) hr
    have hread : restrictToSignals f = edgeFn := funext spec
    refine ⟨s, by simpa [Circuit.size] using hs, ws.map restrictToSignals, ?_, hread ▸ hr'⟩
    have hm := hw.map restrictToSignals
    rw [List.map_ofFn] at hm
    exact functions_extend ▸ hm

/-- Project a functional run onto arbitrary selected rows, in list order. -/
theorem first_run (C : Circuit) (hF : FanInTwo C)
    (h9 : ∀ y : Fin 9 → Bool, (C.wires (List.ofFn y)).getD 9 false = (y 4 || y 6))
    (he : circuitFun 9 C = edgeFn) (rows : List ℕ) :
    ∃ s ≤ C.size - 1, ∃ ws : List ℕ, ws.Sublist (signalWords rows) ∧
      NatRun (2 ^ rows.length - 1) (encL edgeFn rows) s ws := by
  obtain ⟨s, hs, ws, hw, hr⟩ := first_run_function C hF h9 he
  refine ⟨s, hs, ws.map (fun a => encL a rows), words_signals rows ▸ hw.map _, ?_⟩
  exact Run.map (fun a => encL a rows) (fun a => encL_inv a rows)
    (fun a b => encL_and a b rows) (fun a b => encL_or a b rows) hr

/-- A checked absence of runs of cost at most 14 implies the posted bound. -/
theorem lower_of_no_runs (rows : List ℕ)
    (noRun : ∀ s ≤ 14, ∀ ws : List ℕ, ws.Sublist (signalWords rows) →
      ¬NatRun (2 ^ rows.length - 1) (encL edgeFn rows) s ws)
    (C : Circuit) (hF : FanInTwo C)
    (h9 : ∀ y : Fin 9 → Bool, (C.wires (List.ofFn y)).getD 9 false = (y 4 || y 6))
    (he : circuitFun 9 C = edgeFn) : 16 ≤ C.size := by
  by_contra! small
  obtain ⟨s, hs, ws, hw, hr⟩ := first_run C hF h9 he rows
  exact noRun s (by omega) ws hw hr

end PEqualNP.Outside.L_meta_3348_aux.FirstWireRun
