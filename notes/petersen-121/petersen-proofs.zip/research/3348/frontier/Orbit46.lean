import Posted46
import OrbitData46

namespace Petersen1676.Orbit46
open PEqualNP.Outside.L_meta_274_aux Petersen1676.Table
set_option maxRecDepth 32000
set_option maxHeartbeats 0
/-- Select, duplicate and reorder rows of an ordinary Boolean truth word. -/
def select (a : ℕ) : List ℕ → ℕ
  | [] => 0
  | v :: rest => Nat.bit (a.testBit v) (select a rest)

theorem bits (a : ℕ) : ∀ (l : List ℕ) (j : ℕ),
    (select a l).testBit j = (l.map a.testBit).getD j false
  | [],j => by simp [select]
  | _::_,0 => by simp [select]
  | _::_,j+1 => by simp [select,Nat.testBit_bit_succ,bits a _ j]

theorem select_xor (a b : ℕ) (l : List ℕ) : select (a ^^^ b) l = select a l ^^^ select b l := by
  apply Nat.eq_of_testBit_eq
  intro j
  rw [Nat.testBit_xor,bits,bits,bits]
  by_cases h : j < l.length
  · simp [h,Nat.testBit_xor]
  · rw [List.getD_eq_default _ _ (by simp; omega),List.getD_eq_default _ _ (by simp; omega),
      List.getD_eq_default _ _ (by simp; omega)]
    rfl

theorem select_and (a b : ℕ) (l : List ℕ) : select (a &&& b) l = select a l &&& select b l := by
  apply Nat.eq_of_testBit_eq
  intro j
  rw [Nat.testBit_and,bits,bits,bits]
  by_cases h : j < l.length
  · simp [h,Nat.testBit_and]
  · rw [List.getD_eq_default _ _ (by simp; omega),List.getD_eq_default _ _ (by simp; omega),
      List.getD_eq_default _ _ (by simp; omega)]
    rfl

theorem select_or (a b : ℕ) (l : List ℕ) : select (a ||| b) l = select a l ||| select b l := by
  apply Nat.eq_of_testBit_eq
  intro j
  rw [Nat.testBit_or,bits,bits,bits]
  by_cases h : j < l.length
  · simp [h,Nat.testBit_or]
  · rw [List.getD_eq_default _ _ (by simp; omega),List.getD_eq_default _ _ (by simp; omega),
      List.getD_eq_default _ _ (by simp; omega)]
    rfl


def state (i : Fin 42) := Choice46.lists.getD i.val []
private theorem maskFixed : ∀ i : Fin 4, select Table.allMask (rowFamily i) = Table.allMask :=
  by decide +kernel
private theorem goalFixed : ∀ i : Fin 4, select Table.goal (rowFamily i) = Table.goal :=
  by decide +kernel
private theorem transitions : ∀ i : Fin 42,
    Memo.canonical ((state i).map (fun a => select a (rowFamily (symmetry i)))) = state (representative i) :=
  by decide +kernel
private theorem reaches : ∀ i : Fin 42, representative i ∈ representatives := by decide +kernel

theorem transport {s : Nat} (i : Fin 42) (run : NatRun Table.allMask Table.goal s (state i)) :
    NatRun Table.allMask Table.goal s (state (representative i)) := by
  let r := rowFamily (symmetry i)
  have m : NatRun Table.allMask (select Table.goal r) s ((state i).map (fun x => select x r)) :=
    Run.map (fun a => select a r) (fun a => by rw [select_xor,maskFixed])
      (fun a b => select_and a b _) (fun a b => select_or a b _) run
  rw [show select Table.goal r = Table.goal from goalFixed _] at m
  rw [← transitions]
  exact Run.perm (Memo.canonicalPerm _).symm m

theorem representativeCases (pub : Posted46.Public2012)
    (excluded : ∀ i ∈ representatives, ¬ NatRun Table.allMask Table.goal 13 (state i)) :
    Posted46.Posted := by
  apply Posted46.fortyTwo pub
  rintro w hw run
  obtain ⟨j,hj,eq⟩ := List.getElem_of_mem hw
  have length : Choice46.lists.length = 42 := by decide +kernel
  let i : Fin 42 := ⟨j,length ▸ hj⟩
  have hs : state i = w := by
    simpa [state,i,List.getD_eq_getElem?_getD,List.getElem?_eq_getElem hj] using eq
  exact excluded _ (reaches i) (transport i (hs ▸ run))

#print axioms representativeCases
end Petersen1676.Orbit46
