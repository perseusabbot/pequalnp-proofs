import First46

namespace PEqualNP.Outside.L_meta_3348_aux.FirstWireRun

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_274_aux

def rawSignals : List (BFn 9) := List.ofFn fun i : Fin 9 => fun x => x i
private def indexed (i : Fin 10) (x : Fin 9 → Bool) : Bool := extend x i
private def rawIndices : List (Fin 10) := (List.finRange 9).map Fin.castSucc

private theorem all_indices : (List.finRange 10).map indexed = signals := by
  simp only [List.finRange, List.map_ofFn, Function.comp_def]
  change (List.ofFn fun i : Fin 10 => fun x => extend x i) = signals
  rw [List.ofFn_succ_last]; simp only [extend, Fin.snoc_castSucc, Fin.snoc_last, signals]

private theorem raw_indices : rawIndices.map indexed = rawSignals := by
  simp only [rawIndices, List.finRange, List.map_ofFn, Function.comp_def]
  change (List.ofFn fun i : Fin 9 => fun x => extend x i.castSucc) = rawSignals
  simp only [extend, Fin.snoc_castSucc, rawSignals]

-- Each second-half row adds one critical raw bit to the paired first-half row.
-- The added bit keeps the semantic first gate fixed in each pair.
private def pivotRows : List ℕ := [2, 1, 2, 4, 65, 1, 18, 4, 8, 3, 3, 6, 12, 81, 33, 82, 132, 264]
private def pivotWord (i : Fin 10) : ℕ := encL (indexed i) pivotRows
private theorem pivot_goal : encL edgeFn pivotRows = goal 9 := by decide +kernel
private theorem pivot_mask : 2^pivotRows.length-1 = mask 9 := by decide +kernel

private theorem essential_sublists : ∀ I ∈ (List.finRange 10).sublists,
    (cov 9 (I.map pivotWord) &&& lo 9) = lo 9 → I = rawIndices ∨ I = List.finRange 10 := by
  decide +kernel

/-- Even a run observed later on only a few rows starts from one of the
 two named source lists, because the circuit itself works on all assignments. -/
theorem exact_sources {s : Nat} {ws : List (BFn 9)} (hw : ws.Sublist signals)
    (hr : Run invF meetF joinF edgeFn s ws) : ws = rawSignals ∨ ws = signals := by
  rw [← all_indices] at hw
  obtain ⟨I, hi, rfl⟩ := List.sublist_map_iff.mp hw
  have sampled : NatRun (2^pivotRows.length-1) (encL edgeFn pivotRows) s
      ((I.map indexed).map fun a => encL a pivotRows) :=
    Run.map (fun a => encL a pivotRows) (fun a => encL_inv a pivotRows)
      (fun a b => encL_and a b pivotRows) (fun a b => encL_or a b pivotRows) hr
  rw [pivot_mask, pivot_goal] at sampled
  have cover := required sampled
  rw [List.map_map] at cover
  rcases essential_sublists I (List.mem_sublists.mpr hi) cover with rfl | rfl
  · exact Or.inl raw_indices
  · exact Or.inr all_indices

theorem first_run_two_sources (C : Circuit) (hF : FanInTwo C)
    (h9 : ∀ y : Fin 9 → Bool, (C.wires (List.ofFn y)).getD 9 false = (y 4 || y 6))
    (he : circuitFun 9 C = edgeFn) :
    ∃ s ≤ C.size - 1, Run invF meetF joinF edgeFn s rawSignals ∨
      Run invF meetF joinF edgeFn s signals := by
  obtain ⟨s, hs, ws, hw, hr⟩ := first_run_function C hF h9 he
  exact ⟨s, hs, (exact_sources hw hr).elim (fun h => Or.inl (h ▸ hr)) (fun h => Or.inr (h ▸ hr))⟩

end PEqualNP.Outside.L_meta_3348_aux.FirstWireRun
