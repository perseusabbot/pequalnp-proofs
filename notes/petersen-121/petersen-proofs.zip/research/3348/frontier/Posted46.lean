import Choices46
namespace Petersen1676.Posted46
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_274_aux PEqualNP.Outside.L_meta_3348_aux.FirstWireRun
open Petersen1676.PinRules

abbrev Public2012 : Prop := have x1 : (Fin (9 : ℕ) → Bool) → Bool := fun (x1 : Fin (9 : ℕ) → Bool) => [(1 : ℕ), (12 : ℕ), (23 : ℕ), (34 : ℕ), (40 : ℕ), (5 : ℕ), (16 : ℕ), (27 : ℕ), (38 : ℕ), (57 : ℕ), (68 : ℕ), (85 : ℕ)].any fun (x2 : ℕ) => x1 (Fin.ofNat (9 : ℕ) (x2 / (10 : ℕ))) && x1 (Fin.ofNat (9 : ℕ) (x2 % (10 : ℕ))); ¬PEqualNP.MetaComplexity.HasCircuitSize (9 : ℕ) x1 (14 : ℕ)
theorem rawBound (h : Public2012) : ¬HasCircuitSize 9 edgeFn 14 := by
  change ¬HasCircuitSize 9 _ 14 at h
  have same : (fun x : Fin 9 → Bool => ([1,12,23,34,40,5,16,27,38,57,68,85] : List ℕ).any
     (fun k => x (Fin.ofNat 9 (k/10)) && x (Fin.ofNat 9 (k%10)))) = edgeFn := by decide +kernel
  rwa [same] at h

def Posted : Prop := ∀ (x1 : PEqualNP.CircuitLowerBounds.Circuit), PEqualNP.MetaComplexity.FanInTwo x1 → (∀ (x3 : Fin (9 : ℕ) → Bool), (x1.wires (List.ofFn x3)).getD (9 : ℕ) Bool.false = (x3 (4 : Fin (9 : ℕ)) || x3 (6 : Fin (9 : ℕ)))) → (PEqualNP.MetaComplexity.circuitFun (9 : ℕ) x1 = fun (x4 : Fin (9 : ℕ) → Bool) => x4 (0 : Fin (9 : ℕ)) && x4 (1 : Fin (9 : ℕ)) || x4 (1 : Fin (9 : ℕ)) && x4 (2 : Fin (9 : ℕ)) || x4 (2 : Fin (9 : ℕ)) && x4 (3 : Fin (9 : ℕ)) || x4 (3 : Fin (9 : ℕ)) && x4 (4 : Fin (9 : ℕ)) || x4 (4 : Fin (9 : ℕ)) && x4 (0 : Fin (9 : ℕ)) || x4 (0 : Fin (9 : ℕ)) && x4 (5 : Fin (9 : ℕ)) || x4 (1 : Fin (9 : ℕ)) && x4 (6 : Fin (9 : ℕ)) || x4 (2 : Fin (9 : ℕ)) && x4 (7 : Fin (9 : ℕ)) || x4 (3 : Fin (9 : ℕ)) && x4 (8 : Fin (9 : ℕ)) || x4 (5 : Fin (9 : ℕ)) && x4 (7 : Fin (9 : ℕ)) || x4 (6 : Fin (9 : ℕ)) && x4 (8 : Fin (9 : ℕ)) || x4 (8 : Fin (9 : ℕ)) && x4 (5 : Fin (9 : ℕ))) → Option.map (fun (x5 : PEqualNP.CircuitLowerBounds.Gate) => x5.op) x1.gates[(1 : ℕ)]? = Option.some PEqualNP.CircuitLowerBounds.GateOp.or → (16 : ℕ) ≤ x1.size

set_option maxRecDepth 8000 in
set_option maxHeartbeats 4000000 in
set_option exponentiation.threshold 800 in
theorem oneLiveTest (unrestricted : Public2012) (closed : Root46.checkRoot true = false) : Posted := by
  intro C hf head goal _secondOR
  by_contra! small
  have run := Root46.liveForced (rawBound unrestricted) C hf head goal small
  have h : Root46.checkRoot true = true := by
    unfold Root46.checkRoot
    apply Memo.root_of_run _ (Actual46.actualStart true) run
    intro _ _ _ inv next
    rw [Table46.cut, Bool.and_eq_true]
    exact ⟨covers_ok (k := Table.kk) next, legal_sound inv next⟩
  simp [closed] at h

theorem fortyTwo (unrestricted : Public2012)
   (impossible : ∀ w ∈ Choice46.lists, ¬NatRun Table.allMask Table.goal 13 w) : Posted := by
  intro C hf first goal _secondOR
  by_contra! small
  obtain ⟨w,hw,run⟩ := Choice46.dependency (Root46.liveForced (rawBound unrestricted) C hf first goal small)
  exact impossible w hw run

#print axioms oneLiveTest
#print axioms fortyTwo
end Petersen1676.Posted46
