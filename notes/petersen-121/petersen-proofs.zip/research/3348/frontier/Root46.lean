import Valid46
import Sources46
import MemoSearch

namespace Petersen1676.Root46
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity
open PEqualNP.Outside.L_meta_274_aux
open PEqualNP.Outside.L_meta_3348_aux.FirstWireRun
open Petersen1676.Table Petersen1676.PinRules Petersen1676.Prune

set_option maxRecDepth 8000
set_option maxHeartbeats 4000000

private def rowWord (f : BFn 9) : Nat := encL f Table.rows
private theorem rowsMask : 2 ^ Table.rows.length - 1 = Table.allMask := by decide +kernel
private theorem rowsGoal : rowWord edgeFn = Table.goal := by decide +kernel
private theorem literalRows :
    (List.ofFn fun i : Fin 9 => rowWord (fun x => x i)) = Table.raw := by decide +kernel

private theorem mappedRaw : rawSignals.map rowWord = Table46.start false := by
  change rawSignals.map rowWord = Table.raw
  simpa only [rawSignals,List.map_ofFn,Function.comp_def] using literalRows

private theorem mappedBoth : signals.map rowWord = Table46.start true := by
  have hh : rowWord (fun x => x 4 || x 6) = Table46.header := by decide +kernel
  change (rawSignals ++ [_]).map rowWord = Table.raw ++ [Table46.header]
  rw [List.map_append, List.map_cons, List.map_nil, hh, mappedRaw]
  rfl

private theorem projectedRun {s ws} (h : Run invF meetF joinF edgeFn s ws) :
    NatRun Table.allMask Table.goal s (ws.map rowWord) := by
  have mapped : NatRun (2 ^ Table.rows.length - 1) (encL edgeFn Table.rows) s
      (ws.map (fun a => encL a Table.rows)) :=
    Run.map (fun a => encL a Table.rows) (fun a => encL_inv a Table.rows)
      (fun a b => encL_and a b Table.rows) (fun a b => encL_or a b Table.rows) h
  change NatRun (2 ^ Table.rows.length - 1) (rowWord edgeFn) s (ws.map rowWord) at mapped
  rwa [rowsMask, rowsGoal] at mapped

private def pivot : Item := ⟨Table.pinMask 16,13,0⟩
private theorem pivotMem (b : Bool) : pivot ∈ Table46.initial (Table46.start b) := by
  cases b <;> decide +kernel
private theorem oneFrozen (b : Bool) :
    ((Table46.start b).filter (Prune.constantOn pivot.pin)).length = 1 := by
  cases b <;> decide +kernel

theorem rootBudget {b s} (h : NatRun Table.allMask Table.goal s (Table46.start b)) : 14 ≤ s := by
  have hg := legal_sound (Actual46.actualStart b) h
  have hh := List.all_eq_true.mp hg pivot (pivotMem b)
  have hi : pivot.lower + ((Table46.start b).filter (Prune.constantOn pivot.pin)).length ≤ pivot.spent + s :=
    of_decide_eq_true hh
  rw [oneFrozen] at hi
  change 13 + 1 ≤ 0 + s at hi
  omega

private theorem actualCut {s ws is} (g : Invariant Table.allMask Table.goal Table.raw ws is)
    (h : NatRun Table.allMask Table.goal s ws) : Table46.cut s ws is = true := by
  rw [Table46.cut,Bool.and_eq_true]
  exact ⟨covers_ok (k := Table.kk) h, legal_sound g h⟩

/-- The two finite residuals, one for each possible initial source list. -/
def checkRoot (useHeader : Bool) : Bool :=
  let ws := Table46.start useHeader
  Memo.search Table.allMask Table.goal Table.raw Table46.cut 14 (Memo.root ws (Table46.initial ws))

theorem residual (dead : checkRoot false = false) (live : checkRoot true = false)
    (C : Circuit) (hF : FanInTwo C)
    (first : ∀ y : Fin 9 → Bool, (C.wires (List.ofFn y)).getD 9 false = (y 4 || y 6))
    (he : circuitFun 9 C = edgeFn) : 16 ≤ C.size := by
  by_contra! small
  obtain ⟨s,bound,hr⟩ := first_run_two_sources C hF first he
  have deny (b : Bool) (root : NatRun Table.allMask Table.goal s (Table46.start b)) : False := by
    have lo := rootBudget root
    have eq : s = 14 := by omega
    have passed : checkRoot b = true := by
      unfold checkRoot
      exact Memo.root_of_run @actualCut (Actual46.actualStart b) (eq ▸ root)
    cases b <;> simp_all
  rcases hr with hr | hr
  · exact deny false (mappedRaw ▸ projectedRun hr)
  · exact deny true (mappedBoth ▸ projectedRun hr)

/-- The raw-only normalized run already realizes an ordinary circuit. -/
theorem fromRawRun {s : Nat} (run : Run invF meetF joinF edgeFn s rawSignals) :
    HasCircuitSize 9 edgeFn s := by
  have use : Built 0 rawSignals := by
    refine ⟨[], ?_, by simp, ?_⟩
    · intro g hg; cases hg
    · intro f hf
      obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hf
      exact rawHave [] i
  have real : ¬Constant (edgeFn ∘ (id : (Fin 9 → Bool) → (Fin 9 → Bool))) := by
    rintro ⟨b,h⟩
    have h0 := congrFun h (fun _ => false)
    have h1 := congrFun h (fun _ => true)
    change false = b at h0
    change true = b at h1
    exact Bool.noConfusion (h0.trans h1.symm)
  have use' : Built 0 (rawSignals.map (fun f => f ∘ (id : (Fin 9 → Bool) → (Fin 9 → Bool)))) := by
    simpa using use
  obtain ⟨t,ht,le⟩ := runPruneMap id run real use'
  obtain ⟨c,hc,st,fc⟩ := ht
  exact ⟨c,hc,by omega,fc⟩

/-- Once the public child L-meta-2012 is supplied, only the live-header search is needed. -/
theorem liveForced (rawLower : ¬HasCircuitSize 9 edgeFn 14) (C : Circuit) (hF : FanInTwo C)
    (first : ∀ x : Fin 9 → Bool, (C.wires (List.ofFn x)).getD 9 false = (x 4 || x 6))
    (he : circuitFun 9 C = edgeFn) (small : C.size < 16) :
    NatRun Table.allMask Table.goal 14 (Table46.start true) := by
  obtain ⟨s,bound,hr⟩ := first_run_two_sources C hF first he
  rcases hr with raw | live
  · obtain ⟨c,hc,st,fc⟩ := fromRawRun raw
    exact False.elim (rawLower ⟨c,hc,by omega,fc⟩)
  · have run : NatRun Table.allMask Table.goal s (Table46.start true) := mappedBoth ▸ projectedRun live
    have b := rootBudget run
    have e : s = 14 := by omega
    exact e ▸ run

#print axioms residual
#print axioms liveForced
end Petersen1676.Root46
