import Posted46

namespace Petersen1676.Triples46
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_274_aux
open PEqualNP.Outside.L_meta_3348_aux.FirstWireRun
open Petersen1676.Table Petersen1676.Actual Petersen1676.Prune Petersen1676.PinRules

set_option maxRecDepth 16000
set_option maxHeartbeats 6000000

def vertex : Fin 3 → Fin 9 := ![0,2,7]
def fixation : Fin 3 → Nat := ![81,84,208]
def extended (k : Fin 3) (x : Fin 9 → Bool) : Fin 11 → Bool :=
  Fin.snoc (Fin.snoc x (x 4 || x 6)) (x 4 || x 6 || x (vertex k))
def readAt (k : Fin 3) (i : Fin 11) (x : Fin 9 → Bool) := extended k x i
def pivotRows : Fin 3 → List Nat := ![
  [16,1,2,4,65,1,18,4,8,17,3,6,12,81,33,82,132,264],
  [2,1,18,4,65,1,18,4,8,3,3,22,12,81,33,82,132,264],
  [2,1,2,4,65,1,18,20,8,3,3,6,12,81,33,82,148,264]]
def pivot (k : Fin 3) (i : Fin 11) := encL (readAt k i) (pivotRows k)
def rawIx : List (Fin 11) := [0,1,2,3,4,5,6,7,8]
def hdrIx : List (Fin 11) := rawIx ++ [9]
def triIx : List (Fin 11) := rawIx ++ [10]

private theorem pivotGoal : ∀ k, encL edgeFn (pivotRows k) = PEqualNP.Outside.L_meta_274_aux.goal 9 := by
  decide +kernel
private theorem pivotMask : ∀ k, 2^(pivotRows k).length-1 = mask 9 := by decide +kernel
private theorem essential : ∀ k, ∀ I ∈ (List.finRange 11).sublists,
    (cov 9 (I.map (pivot k)) &&& lo 9) = lo 9 →
    I = rawIx ∨ I = hdrIx ∨ I = triIx ∨ I = List.finRange 11 := by decide +kernel

private theorem runInputs (k : Fin 3) (D : Circuit) (valid : FanInTwo D)
    (spec : ∀ x, circuitFun 11 D (extended k x) = edgeFn x) :
    ∃ s ≤ D.size, ∃ I : List (Fin 11), I.Sublist (List.finRange 11) ∧
      Run invF meetF joinF edgeFn s (I.map (readAt k)) := by
  let f := circuitFun 11 D
  have nc : ∃ y y', f y ≠ f y' := by
    refine ⟨extended k (fun _ => false),extended k (fun _ => true),?_⟩
    change circuitFun 11 D _ ≠ circuitFun 11 D _
    rw [spec,spec]; decide
  have hcir : HasCircuitSize 11 f D.size := ⟨D,valid,le_rfl,fun _ => rfl⟩
  obtain ⟨s,hs,ws,sub,rr⟩ := exists_run f nc D.size hcir
  have rawEq : (List.ofFn fun i : Fin 11 => fun x : Fin 11 → Bool => x i) =
      (List.finRange 11).map (fun i => fun x : Fin 11 → Bool => x i) := by
    simp only [List.finRange,List.map_ofFn,Function.comp_def]
  rw [rawEq] at sub
  obtain ⟨I,hi,rfl⟩ := List.sublist_map_iff.mp sub
  let p : BFn 11 → BFn 9 := fun g x => g (extended k x)
  have r : Run invF meetF joinF (p f) s (((I.map (fun i => fun x : Fin 11 → Bool => x i))).map p) :=
    Run.map p (fun _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl) rr
  have eq : p f = edgeFn := funext spec
  rw [eq,List.map_map] at r
  have agree : (p ∘ (fun (i : Fin 11) (x : Fin 11 → Bool) => x i)) = readAt k := by
    funext i x; rfl
  rw [agree] at r
  exact ⟨s,hs,I,hi,r⟩

private theorem sources {k s I} (hi : List.Sublist I (List.finRange 11))
    (run : Run invF meetF joinF edgeFn s (I.map (readAt k))) :
    I = rawIx ∨ I = hdrIx ∨ I = triIx ∨ I = List.finRange 11 := by
  let r := pivotRows k
  have samples : NatRun (2^r.length-1) (encL edgeFn r) s
      ((I.map (readAt k)).map fun a => encL a r) :=
    Run.map (fun a => encL a r) (fun a => encL_inv a r)
      (fun a b => encL_and a b r) (fun a b => encL_or a b r) run
  rw [show 2^r.length-1 = mask 9 from pivotMask k,
      show encL edgeFn r = PEqualNP.Outside.L_meta_274_aux.goal 9 from pivotGoal k] at samples
  have ok := required samples
  rw [List.map_map] at ok
  exact essential k I (List.mem_sublists.mpr hi) ok

def triple (k : Fin 3) := Table46.header ||| rawWord (vertex k)
def tripleSignals (k : Fin 3) := raw ++ [triple k]
def fullSignals (k : Fin 3) := raw ++ [Table46.header,triple k]
def words (k : Fin 3) (I : List (Fin 11)) := I.map (fun i => encL (readAt k i) Table.rows)

private theorem wordTables : ∀ k, words k rawIx = raw ∧ words k hdrIx = Table46.start true ∧
    words k triIx = tripleSignals k ∧ words k (List.finRange 11) = fullSignals k := by decide +kernel
private theorem rowGoal : encL edgeFn Table.rows = Table.goal := by decide +kernel
private theorem rowMask : 2^Table.rows.length-1 = allMask := by decide +kernel
private theorem toWords {k s I} (r : Run invF meetF joinF edgeFn s (I.map (readAt k))) :
    NatRun allMask Table.goal s (words k I) := by
  have h : NatRun (2^Table.rows.length-1) (encL edgeFn Table.rows) s
      ((I.map (readAt k)).map fun a => encL a Table.rows) :=
    Run.map (fun a => encL a Table.rows) (fun a => encL_inv a Table.rows)
      (fun a b => encL_and a b Table.rows) (fun a b => encL_or a b Table.rows) r
  rwa [rowGoal,rowMask,List.map_map] at h

private theorem freeBudget {w s pin lower} (d : Model allMask Table.goal pin lower raw)
    (free : w.all (freeOn pin raw []) = true) (r : NatRun allMask Table.goal s w) :
    lower + (w.filter (constantOn pin)).length ≤ s := by
  have allFree : RawWords d.row w := by
    intro z hz
    have good := List.all_eq_true.mp free z hz
    simp only [freeOn,List.append_nil,Bool.or_eq_true] at good
    rcases good with hc | ha
    · exact Or.inl (maskedConstant d.row pin d.pinTrue hc)
    · obtain ⟨v,hv,hm⟩ := List.any_eq_true.1 ha
      rw [maskedEqual d.row pin d.pinTrue (of_decide_eq_true hm)]
      exact d.inputs v hv
  have emptyBuilt := rawBuilt d.row w allFree w (fun _ h => h)
  obtain ⟨t,ht,sz⟩ := wordPrune d.row d.maskTrue r pin d.pinTrue d.nonconstant emptyBuilt
  have := d.bound t ht
  omega

private theorem doubleFree : ∀ k,
  (tripleSignals k).all (freeOn (pinMask (pairFix 4)) raw []) = true ∧
  ((tripleSignals k).filter (constantOn (pinMask (pairFix 4)))).length = 2 ∧
  (fullSignals k).all (freeOn (pinMask (pairFix 4)) raw []) = true ∧
  ((fullSignals k).filter (constantOn (pinMask (pairFix 4)))).length = 3 := by decide +kernel

/-- Of the eleven available signals, an optimal thirteen-gate tail must retain exactly
the nine raw signals and the triple OR. Its normalized run starts with wire 9 omitted. -/
theorem forced (k : Fin 3) (D : Circuit) (small : D.size ≤ 13) (valid : FanInTwo D)
    (spec : ∀ x, circuitFun 11 D (extended k x) = edgeFn x) :
    NatRun allMask Table.goal 13 (tripleSignals k) := by
  obtain ⟨s,hs,I,hi,run⟩ := runInputs k D valid spec
  have num := toWords run
  rcases sources hi run with rfl|rfl|rfl|rfl
  · rw [(wordTables k).1] at num
    have h := Root46.rootBudget (b := false) num
    omega
  · rw [(wordTables k).2.1] at num
    have h := Root46.rootBudget (b := true) num
    omega
  · rw [(wordTables k).2.2.1] at num
    have h := freeBudget (doubleModel 4) (doubleFree k).1 num
    rw [(doubleFree k).2.1] at h
    have eq : s = 13 := by omega
    exact eq ▸ num
  · rw [(wordTables k).2.2.2] at num
    have h := freeBudget (doubleModel 4) (doubleFree k).2.2.1 num
    rw [(doubleFree k).2.2.2] at h
    omega

private theorem identify : ∀ m ∈ ([81,84,208] : List Nat), ∃ k : Fin 3, m = fixation k := by
  decide +kernel
private theorem inputsAgree : ∀ k (x : Fin 9 → Bool), Fin.snoc (Fin.snoc x (x 4 || x 6))
    (decide (∃ i : Fin 9, (fixation k).testBit i.val = true ∧ x i = true)) = extended k x := by
  decide +kernel
private theorem targetsAgree : ∀ x : Fin 9 → Bool,
    (([1,12,23,34,40,5,16,27,38,57,68,85] : List Nat).any
      (fun e => x (Fin.ofNat 9 (e/10)) && x (Fin.ofNat 9 (e%10)))) = edgeFn x := by decide +kernel

theorem child4 (closed : ∀ k, ¬ NatRun allMask Table.goal 13 (tripleSignals k)) :
  have x1 : (Fin (9 : ℕ) → Bool) → Bool := fun (x1 : Fin (9 : ℕ) → Bool) => [(1 : ℕ), (12 : ℕ), (23 : ℕ), (34 : ℕ), (40 : ℕ), (5 : ℕ), (16 : ℕ), (27 : ℕ), (38 : ℕ), (57 : ℕ), (68 : ℕ), (85 : ℕ)].any fun (x2 : ℕ) => x1 (Fin.ofNat (9 : ℕ) (x2 / (10 : ℕ))) && x1 (Fin.ofNat (9 : ℕ) (x2 % (10 : ℕ))); ∀ x2 ∈ [(81 : ℕ), (84 : ℕ), (208 : ℕ)], ∀ (x4 : PEqualNP.CircuitLowerBounds.Circuit), PEqualNP.MetaComplexity.FanInTwo x4 → (∀ (x6 : Fin (9 : ℕ) → Bool), PEqualNP.MetaComplexity.circuitFun (11 : ℕ) x4 (Fin.snoc (Fin.snoc x6 (x6 (4 : Fin (9 : ℕ)) || x6 (6 : Fin (9 : ℕ)))) (Decidable.decide (∃ (x7 : Fin (9 : ℕ)), x2.testBit ↑x7 = Bool.true ∧ x6 x7 = Bool.true))) = x1 x6) → (14 : ℕ) ≤ x4.size := by
  dsimp only
  intro m hm D hf hs
  obtain ⟨k,rfl⟩ := identify m hm
  by_contra! small
  apply closed k
  apply forced k D (by omega) hf
  intro x
  rw [← inputsAgree]
  exact (hs x).trans (targetsAgree x)

#print axioms forced
#print axioms child4
end Petersen1676.Triples46
