import ActualPins
import Table46

namespace Petersen1676.Actual46
open Table Prune PinRules Actual

private theorem ruleIndex : ∀ r ∈ Table46.rules,
    (∃ i : Fin 9, r = (singleFix i,low1 i)) ∨ (∃ i : Fin 9, r = (pairFix i,11)) := by
  decide +kernel

theorem actualInitial (ws : List Nat) (inputs : ∀ w ∈ ws, w = Table46.header ∨ w ∈ raw) :
    Invariant allMask goal raw ws (Table46.initial ws) := by
  have a : rawWord 4 ∈ raw := by decide +kernel
  have b : rawWord 6 ∈ raw := by decide +kernel
  intro it hi
  obtain ⟨r,hr,rfl⟩ := List.mem_map.1 hi
  rcases ruleIndex r hr with ⟨i,rfl⟩ | ⟨i,rfl⟩
  · exact headerValid (singleModel i) _ _ a b inputs
  · exact headerValid (doubleModel i) _ _ a b inputs

theorem actualStart (live : Bool) : Invariant allMask goal raw (Table46.start live)
    (Table46.initial (Table46.start live)) := by
  apply actualInitial
  cases live
  · exact fun _ h => Or.inr h
  · simp [Table46.start,or_comm]

#print axioms actualStart
end Petersen1676.Actual46
