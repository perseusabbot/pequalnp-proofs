import AliasTail

namespace PEqualNP.Outside.L_meta_3348_aux.Alias
open PEqualNP.MetaComplexity PEqualNP.CircuitLowerBounds

theorem fromPublic (base : let f : (Fin 9 → Bool) → Bool := fun x : Fin 9 → Bool => ([1,12,23,34,40,5,16,27,38,57,68,85] : List ℕ).any (fun e => x (Fin.ofNat 9 (e / 10)) && x (Fin.ofNat 9 (e % 10))); ¬ HasCircuitSize 9 f 14) : let f : (Fin 9 → Bool) → Bool := fun x : Fin 9 → Bool => ([1,12,23,34,40,5,16,27,38,57,68,85] : List ℕ).any (fun e => x (Fin.ofNat 9 (e / 10)) && x (Fin.ofNat 9 (e % 10))); ∀ m ∈ ([0, 1, 4, 16, 128, 80] : List ℕ), ∀ D : Circuit, FanInTwo D → (∀ x : Fin 9 → Bool, circuitFun 11 D (Fin.snoc (Fin.snoc x (x 4 || x 6)) (decide (∃ i : Fin 9, m.testBit i.val = true ∧ x i = true))) = f x) → 14 ≤ D.size := by
  intro f m hm D ok eq
  let p (x : Fin 9 → Bool) : Fin 10 → Bool := Fin.snoc x (x 4 || x 6)
  let sourceFor (k : ℕ) : Option (Fin 10) :=
    if k=0 then none else if k=1 then some 0 else if k=4 then some 2
    else if k=16 then some 4 else if k=128 then some 7 else some 9
  have signal : ∀ x : Fin 9 → Bool,
      decide (∃ i : Fin 9, m.testBit i.val = true ∧ x i = true) = (sourceFor m).elim false (p x) := by
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl <;> decide +kernel
  obtain ⟨E,hE,good,runE⟩ := eliminateLast D ok (sourceFor m)
  obtain ⟨C,hC,legal,runC⟩ := prependHeader E good
  by_contra! cheap
  apply base
  refine ⟨C,legal,by omega,?_⟩
  intro x
  have same := runE (p x)
  rw [← signal x] at same
  exact (runC x).trans (same.trans (eq x))

end PEqualNP.Outside.L_meta_3348_aux.Alias
