import PEqualNP.Defs

namespace PEqualNP.Outside.L_meta_3348_aux.Alias
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

private def readIndex (n src j : ℕ) : ℕ :=
  if j < n then j else if j = n then src else j-1

private def mapped (n src : ℕ) (g : Gate) : Gate :=
  ⟨g.op,g.inputs.map (readIndex n src)⟩

private def run (gs : List Gate) (xs : List Bool) : List Bool :=
  gs.foldl (fun w g => w ++ [g.op.eval (g.inputs.map fun i => w.getD i false)]) xs

private theorem snoc_ne (w : List Bool) (v : Bool) (j : ℕ) (ne : j ≠ w.length) :
    (w ++ [v]).getD j false = w.getD j false := by
  by_cases h : j < w.length
  · exact List.getD_append _ _ _ _ h
  · rw [List.getD_eq_default _ _ (by simp; omega), List.getD_eq_default _ _ (by omega)]

private theorem run_agrees (n src bound : ℕ) (gs : List Gate) (old new : List Bool)
    (safe : src < n ∨ bound ≤ src) (past : n ≤ new.length)
    (space : new.length + gs.length ≤ bound) (lengths : old.length = new.length + 1)
    (before : ∀ j, old.getD j false = new.getD (readIndex n src j) false) :
    ∀ j, (run gs old).getD j false = (run (gs.map (mapped n src)) new).getD (readIndex n src j) false := by
  induction gs generalizing old new with
  | nil => exact before
  | cons g gs ih =>
    let b := g.op.eval (g.inputs.map fun i => old.getD i false)
    have beq : b = (mapped n src g).op.eval ((mapped n src g).inputs.map fun i => new.getD i false) := by
      unfold b
      simp only [mapped, List.map_map, Function.comp_def]
      apply congrArg g.op.eval
      exact List.map_congr_left fun i _ => before i
    change ∀ j, (run gs (old ++ [b])).getD j false =
      (run (gs.map (mapped n src)) (new ++ [_])).getD (readIndex n src j) false
    rw [← beq]
    apply ih (old ++ [b]) (new ++ [b]) (by simp; omega) (by simp at space ⊢; omega) (by simp [lengths])
    intro j
    have bounded : new.length < bound := by simp at space; omega
    by_cases last : j = old.length
    · have right : readIndex n src j = new.length := by unfold readIndex; split_ifs <;> omega
      rw [right,last]
      simp [List.getD_eq_getElem?_getD]
    · have right : readIndex n src j ≠ new.length := by unfold readIndex; split_ifs <;> omega
      rw [snoc_ne _ _ _ last,snoc_ne _ _ _ right,before]

theorem eliminateLast {n : ℕ} (D : Circuit) (ok : FanInTwo D) (o : Option (Fin n)) :
    ∃ E : Circuit, E.size = D.size ∧ FanInTwo E ∧
      ∀ x : Fin n → Bool, circuitFun n E x =
        circuitFun (n+1) D (Fin.snoc x (o.elim false x)) := by
  let src := o.elim (n+D.size) Fin.val
  let E : Circuit := ⟨D.gates.map (mapped n src), readIndex n src D.output⟩
  refine ⟨E,by simp [E,Circuit.size],?_,?_⟩
  · intro g hg
    obtain ⟨v,hv,rfl⟩ := List.mem_map.mp hg
    have h := ok v hv
    exact ⟨h.1,by simpa [mapped] using h.2⟩
  · intro x
    have init : List.ofFn (Fin.snoc x (o.elim false x)) = List.ofFn x ++ [o.elim false x] := by
      rw [List.ofFn_succ_last]; simp only [Fin.snoc_castSucc,Fin.snoc_last]
    change (run (D.gates.map (mapped n src)) (List.ofFn x)).getD (readIndex n src D.output) false =
      (run D.gates (List.ofFn (Fin.snoc x (o.elim false x)))).getD D.output false
    rw [init]; symm
    apply run_agrees n src (n+D.size) _ _ _ (by cases o <;> simp [src]) (by simp) (by simp [Circuit.size]) (by simp)
    intro j
    rcases Nat.lt_trichotomy j n with lt | eq | gt
    · rw [List.getD_append _ _ _ _ (by simpa using lt)]
      simp [readIndex,lt]
    · subst j
      simp only [readIndex,lt_irrefl,ite_false,ite_true]
      cases o with
      | none =>
        simp only [Option.elim,src]
        rw [List.getD_eq_default (List.ofFn x) false (by simp : (List.ofFn x).length ≤ n + D.size)]
        simp [List.getD_eq_getElem?_getD]
      | some k =>
        simp [src,Option.elim,List.getD_eq_getElem?_getD,k.isLt]
    · have h : readIndex n src j = j-1 := by unfold readIndex; split_ifs <;> omega
      rw [h,List.getD_eq_default _ _ (by simp; omega), List.getD_eq_default _ _ (by simp; omega)]

theorem prependHeader (D : Circuit) (ok : FanInTwo D) :
    ∃ C : Circuit, C.size = D.size+1 ∧ FanInTwo C ∧ ∀ x : Fin 9 → Bool,
      circuitFun 9 C x = circuitFun 10 D (Fin.snoc x (x 4 || x 6)) := by
  let gate : Gate := ⟨GateOp.or,[4,6]⟩
  let C : Circuit := ⟨gate::D.gates,D.output⟩
  refine ⟨C,by simp [C,Circuit.size],?_,?_⟩
  · intro g hg
    rcases List.mem_cons.mp hg with rfl | h
    · simp [gate]
    · exact ok g h
  · intro x
    have init : List.ofFn (Fin.snoc x (x 4 || x 6)) = List.ofFn x ++ [x 4 || x 6] := by
      rw [List.ofFn_succ_last]; simp only [Fin.snoc_castSucc,Fin.snoc_last]
    change (run D.gates (List.ofFn x ++ [_])).getD D.output false =
      (run D.gates (List.ofFn (Fin.snoc x (x 4 || x 6)))).getD D.output false
    rw [init]
    simp [gate,GateOp.eval,List.getD_eq_getElem?_getD]
end PEqualNP.Outside.L_meta_3348_aux.Alias
