import AliasTail
import Relabel
import PEqualNP.Outside.L_meta_1007
import L_meta_2535

namespace PEqualNP.Outside.L_meta_3348_aux.ThreeProper

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

def target (x : Fin 9 → Bool) : Bool :=
  ([1,12,23,34,40,5,16,27,38,57,68,85] : List ℕ).any
    (fun e => x (Fin.ofNat 9 (e/10)) && x (Fin.ofNat 9 (e%10)))
def second (m : ℕ) (x : Fin 9 → Bool) : Bool :=
  decide (∃ i : Fin 9, m.testBit i.val = true ∧ x i = true)
def jOf (m : ℕ) : Fin 9 := if m = 17 then 0 else if m = 20 then 2 else 7
def xw (j : Fin 9) (i : Fin 9) : Bool := decide (i = 0 ∨ i = 6 ∨ i = j)
def perm : Fin 9 → Fin 8 := ![0,1,2,3,0,4,5,6,7]

/-- Vertex numbering of the checked eight-input bound L-meta-1007. -/
def cofactor8 (x : Fin 8 → Bool) : Bool :=
  (x 0 && x 1) || (x 1 && x 2) || (x 2 && x 3) || (x 0 && x 4) ||
  (x 1 && x 5) || (x 2 && x 6) || (x 3 && x 7) || (x 4 && x 6) ||
  (x 5 && x 7) || (x 7 && x 4)

private theorem bitSet (m : ℕ) (hm : m ∈ ([17,20,144] : List ℕ)) :
    ∀ i : Fin 9, m.testBit i.val = true ↔ i = 4 ∨ i = jOf m := by
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
  rcases hm with rfl | rfl | rfl <;> decide +kernel

private theorem secondEq (m : ℕ) (hm : m ∈ ([17,20,144] : List ℕ)) (x : Fin 9 → Bool) :
    second m x = (x 4 || x (jOf m)) := by
  apply Bool.eq_iff_iff.mpr
  simp only [second,decide_eq_true_eq,Bool.or_eq_true,bitSet m hm]
  constructor
  · rintro ⟨i,hi,act⟩
    rcases hi with rfl | rfl
    · exact Or.inl act
    · exact Or.inr act
  · rintro (h | h)
    · exact ⟨4,Or.inl rfl,h⟩
    · exact ⟨jOf m,Or.inr rfl,h⟩

set_option maxRecDepth 4000 in
private theorem e8 :
    (fun y => target (Function.update (y ∘ perm) (4 : Fin 9) false)) = cofactor8 := by
  decide +kernel

private theorem polarized (m : ℕ) (hm : m ∈ ([17,20,144] : List ℕ)) :
    let z := Function.update (xw (jOf m)) (4 : Fin 9) true
    z 6 = true ∧ z (jOf m) = true ∧
    target (Function.update (xw (jOf m)) 4 false) ≠ target z := by
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hm
  rcases hm with rfl | rfl | rfl <;> decide +kernel

set_option maxRecDepth 4000 in
private theorem nonconstant :
    target (Function.update (fun (_ : Fin 9) => false) 4 false) ≠
    target (Function.update (fun i : Fin 9 => decide (i = 0 ∨ i = 1)) 4 false) := by decide +kernel

theorem noThree (m : ℕ) (hm : m ∈ ([17,20,144] : List ℕ)) (D : Circuit) (ok : FanInTwo D)
    (promise : ∀ x : Fin 9 → Bool, circuitFun 11 D (Fin.snoc (Fin.snoc x (x 4 || x 6))
      (second m x)) = target x) : 14 ≤ D.size := by
  by_contra! cheap
  let j := jOf m
  obtain ⟨E,sE,okE,rE⟩ := Alias.eliminateLast D ok (some j.castSucc)
  obtain ⟨C,sC,okC,rC⟩ := Alias.eliminateLast E okE (some (6 : Fin 9))
  let g := circuitFun 9 C
  have evaluates (x : Fin 9 → Bool) :
      g x = circuitFun 11 D (Fin.snoc (Fin.snoc x (x 6)) (x j)) := by
    simpa [g,Option.elim] using (rC x).trans (rE (Fin.snoc x (x 6)))
  have agrees (x : Fin 9 → Bool) (h : x 4 = false ∨ x 6 = true ∧ x j = true) :
      g x = target x := by
    rw [evaluates, ← promise]
    apply congrArg (circuitFun 11 D)
    rw [secondEq m hm]
    rcases h with h | ⟨h6,hj⟩
    · simp [h,j]
    · simp [h6,hj,j] at *
  have gzero (x : Fin 9 → Bool) :
      g (Function.update x 4 false) = target (Function.update x 4 false) :=
    agrees _ (Or.inl (Function.update_self ..))
  have dep : ∃ x, g (Function.update x 4 false) ≠ g (Function.update x 4 true) := by
    have z := polarized m hm
    exact ⟨xw j, by rw [gzero,agrees _ (Or.inr ⟨z.1,z.2.1⟩)]; exact z.2.2⟩
  have nc : ∃ x y, g (Function.update x 4 false) ≠ g (Function.update y 4 false) := by
    exact ⟨(fun _ => false),(fun i => decide (i=0 ∨ i=1)),by rw [gzero,gzero]; exact nonconstant⟩
  have cs : HasCircuitSize 9 g 13 := ⟨C,okC,by omega,fun _ => rfl⟩
  have save := PEqualNP.Outside.L_meta_2535 9 13 g 4 cs dep nc
  have reduce : HasCircuitSize 8 (fun y => g (Function.update (y ∘ perm) 4 false)) 12 :=
    Prefix.Rename.relabel_size perm _ 12 save
  have rename : (fun y => g (Function.update (y ∘ perm) 4 false)) = cofactor8 := by
    funext y
    exact (gzero _).trans (congrFun e8 y)
  rw [rename] at reduce
  exact PEqualNP.Outside.L_meta_1007 reduce

end PEqualNP.Outside.L_meta_3348_aux.ThreeProper
